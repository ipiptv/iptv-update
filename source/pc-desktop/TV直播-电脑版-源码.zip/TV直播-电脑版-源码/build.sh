#!/bin/bash
# 一键编译 Mac 版「TV 直播」
set -e
cd "$(dirname "$0")"

APP="build/TV直播.app"
rm -rf "$APP"
mkdir -p "$APP/Contents/MacOS" "$APP/Contents/Resources"

# 网页资源
cp mac/Resources/* "$APP/Contents/Resources/"

# 应用图标（若有 icon.png）
if [ -f icon.png ]; then
  rm -rf /tmp/tvicon.iconset && mkdir -p /tmp/tvicon.iconset
  for s in 16 32 64 128 256 512; do
    sips -z $s $s icon.png --out "/tmp/tvicon.iconset/icon_${s}x${s}.png" >/dev/null
    sips -z $((s*2)) $((s*2)) icon.png --out "/tmp/tvicon.iconset/icon_${s}x${s}@2x.png" >/dev/null
  done
  iconutil -c icns /tmp/tvicon.iconset -o "$APP/Contents/Resources/icon.icns"
fi

cat > "$APP/Contents/Info.plist" <<'PLIST'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>CFBundleName</key><string>TV 直播</string>
  <key>CFBundleDisplayName</key><string>TV 直播</string>
  <key>CFBundleExecutable</key><string>TVLive</string>
  <key>CFBundleIconFile</key><string>icon</string>
  <key>CFBundleIdentifier</key><string>tv.live.desktop</string>
  <key>CFBundleVersion</key><string>1.0.0</string>
  <key>CFBundleShortVersionString</key><string>1.0.0</string>
  <key>CFBundlePackageType</key><string>APPL</string>
  <key>LSMinimumSystemVersion</key><string>11.0</string>
  <key>NSHighResolutionCapable</key><true/>
  <key>NSAppTransportSecurity</key><dict><key>NSAllowsArbitraryLoads</key><true/></dict>
</dict>
</plist>
PLIST

# 编译原生外壳
swiftc -O mac/main.swift -o "$APP/Contents/MacOS/TVLive"

# 本地签名（自己编的，不需要开发者证书）
codesign --force --deep --sign - "$APP" >/dev/null 2>&1 || true
echo "编译完成：$APP"
