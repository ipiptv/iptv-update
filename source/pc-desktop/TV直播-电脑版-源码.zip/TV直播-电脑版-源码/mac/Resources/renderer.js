/* TV 直播 · Mac 版 v2
   - 一级浮出 / 选中后旁边滑出二级（甲案：离开即收起）
   - 多源管理（保存多个源、点选切换、刷新、删除）
   - 播放交给原生 AVPlayer；底部信息条默认隐藏，换台时浮出 4 秒
*/

const DEFAULT_SOURCES = [
  { id: 'default', name: '默认源（酒店）', url: 'https://gitee.com/IptvIptv/Iptv/raw/master/bbxx365_hotel.m3u', builtin: true }
];
const EPG_URL = 'http://epg.51zmt.top:8000/e.xml';

const LS = {
  sources: 'tvdesk2_sources',
  current: 'tvdesk2_current',
  hidden: 'tvdesk2_hidden',
  order: 'tvdesk2_order',
  last: 'tvdesk2_last',
  mode: 'tvdesk2_mode',
  timeout: 'tvdesk2_timeout'
};

const state = {
  channels: [],
  groups: [],
  hidden: new Set(JSON.parse(localStorage.getItem(LS.hidden) || '[]')),
  order: JSON.parse(localStorage.getItem(LS.order) || '[]'),
  group: null,
  channel: null,
  sourceIndex: 0,
  epg: null,
  selGroup: 0,        // 一级高亮位置
  lvl2Open: false,
  lvl2Sel: 0,         // 二级高亮
  keyboard: false,
  sources: [],
  currentSrc: 'default',
  mode: (localStorage.getItem('tvdesk2_modeV2') ? (localStorage.getItem(LS.mode) || 'fit') : 'fit'),
  timeoutSec: parseInt(localStorage.getItem(LS.timeout) || '5', 10)
};

const el = (id) => document.getElementById(id);
let bottomTimer = null;
let playToken = 0;

/* ---------------- 错误提示（调试用） ---------------- */
window.onerror = (m, src, line, col, err) => {
  const d = document.getElementById('errBox');
  if (d) { d.style.display = 'block'; d.textContent = 'ERR: ' + m + ' @' + line + ':' + col; }
};
window.addEventListener('unhandledrejection', (e) => {
  const d = document.getElementById('errBox');
  if (d) { d.style.display = 'block'; d.textContent = 'REJ: ' + (e.reason && e.reason.message || e.reason); }
});

/* ---------------- 字号缩放 ---------------- */
function applyScale() {
  const scale = Math.min(2.4, Math.max(0.95, window.innerHeight / 900));
  document.documentElement.style.setProperty('--s', scale.toFixed(3));
}
window.addEventListener('resize', applyScale);
applyScale();

/* ---------------- 桥 ---------------- */
let seq = 0;
const pendingFetches = {};
window.tv = {
  fetchText(url) {
    return new Promise((resolve) => {
      const id = String(++seq);
      pendingFetches[id] = resolve;
      try { window.webkit.messageHandlers.tvFetch.postMessage({ url, id }); }
      catch (e) { resolve({ ok: false, status: 0, error: 'bridge' }); }
    });
  }
};
window.__tvFetchDone = (obj) => {
  const cb = pendingFetches[obj.id];
  if (!cb) return;
  delete pendingFetches[obj.id];
  cb(obj.ok ? { ok: true, status: obj.status, text: obj.text }
            : { ok: false, status: obj.status, error: obj.error });
};

function sendCmd(cmd, extra) {
  try { window.webkit.messageHandlers.tvCmd.postMessage(Object.assign({ cmd }, extra || {})); } catch (e) {}
}
function playNative(url) {
  try { window.webkit.messageHandlers.tvPlay.postMessage({ url, seq: playToken }); } catch (e) {}
}
/* 原生播放回调：ready / failed */
function dbgLine(t) {}   // 调试输出已关闭
window.__tvPlayerEvent = (ev) => {
  dbgLine('ev ' + ev.type + ' seq=' + ev.seq + '/' + playToken + ' w=' + ev.w + ' h=' + ev.h + ' ' + (ev.reason || ''));
  // 旧线路/旧频道的迟到事件直接丢弃，避免把新频道顶掉
  if (ev && ev.seq !== undefined && ev.seq !== playToken) return;
  if (ev.type === 'ready') {
    const hasVideo = !ev.w || ev.w > 0;
    state.playReady = hasVideo;
    state.resLabel = resLabel(ev.w, ev.h);
    el('bRes').textContent = state.resLabel;
    if (!hasVideo) return;      // 只有声音没有画面 → 继续按超时换线路
    state.hopCount = 0;
    clearTimeout(state.playTimer);
    clearTimeout(state.failTimer);
    state.failCount = 0;
    state.failCount = 0;
    renderLvl2();
    clearTimeout(state.playTimer);
    showLoading(false);
    clearInterval(state.frameTimer);
    const ch = state.channel;
    if (ch) {
      localStorage.setItem(LS.last, JSON.stringify({ name: ch.name, group: ch.group }));
    }
  } else if (ev.type === 'failed') {
    clearTimeout(state.playTimer);
    showLoading(false);
    nextUrl();
  }
};

/* ---------------- 源管理 ---------------- */
function loadSources() {
  try {
    state.sources = JSON.parse(localStorage.getItem(LS.sources) || 'null') || DEFAULT_SOURCES.slice();
  } catch (e) { state.sources = DEFAULT_SOURCES.slice(); }
  state.currentSrc = localStorage.getItem(LS.current) || (state.sources[0] && state.sources[0].id) || 'default';
  if (!state.sources.find(s => s.id === state.currentSrc)) state.currentSrc = state.sources[0].id;
}
function saveSources() {
  localStorage.setItem(LS.sources, JSON.stringify(state.sources));
  localStorage.setItem(LS.current, state.currentSrc);
}
function currentSource() {
  return state.sources.find(s => s.id === state.currentSrc) || state.sources[0];
}

/* ---------------- 解析 ---------------- */
function parseM3U(text) {
  const lines = text.split(/\r?\n/);
  const map = new Map();
  let pending = null;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    if (line.startsWith('#EXTINF')) {
      const name = line.substring(line.lastIndexOf(',') + 1).trim();
      const attrs = {};
      const re = /([\w-]+)="([^"]*)"/g;
      let m;
      while ((m = re.exec(line)) !== null) attrs[m[1].toLowerCase()] = m[2];
      pending = {
        name: name || attrs['tvg-name'] || '未命名',
        tvg: attrs['tvg-name'] || '',
        group: attrs['group-title'] || '未分组'
      };
    } else if (!line.startsWith('#') && pending) {
      const key = (pending.tvg || pending.name) + '@' + pending.group;
      let ch = map.get(key);
      if (!ch) {
        ch = { name: pending.name, tvg: pending.tvg, group: pending.group, urls: [] };
        map.set(key, ch);
      }
      if (!ch.urls.includes(line)) ch.urls.push(line);
      pending = null;
    }
  }
  return Array.from(map.values());
}

/* ---------------- 分组 ---------------- */
function orderedGroups() {
  const raw = Array.from(new Set(state.channels.map(c => c.group)));
  const out = [];
  state.order.forEach(g => { if (raw.includes(g) && !out.includes(g)) out.push(g); });
  raw.forEach(g => { if (!out.includes(g)) out.push(g); });
  return out;
}
function visibleGroups() {
  const all = orderedGroups().filter(g => !state.hidden.has(g));
  return all.length ? all : orderedGroups();   // 兜底：全隐藏就全放行
}
function channelsOfGroup(g) { return state.channels.filter(c => c.group === g); }

/* ---------------- 拉源 ---------------- */
async function loadSource(url) {
  el('srcHint').textContent = '正在拉取订阅源…';
  const res = await window.tv.fetchText(url);
  if (!res.ok) { el('srcHint').textContent = '拉取失败：' + (res.error || res.status); return false; }
  const parsed = parseM3U(res.text);
  if (!parsed.length) { el('srcHint').textContent = '解析为空，检查源格式'; return false; }
  state.channels = parsed;
  state.groups = visibleGroups();
  if (!state.groups.includes(state.group)) state.group = state.groups[0] || null;
  state.selGroup = Math.max(0, state.groups.indexOf(state.group));
  renderLvl1();
  renderGroupAdmin();
  renderSources();
  el('srcHint').textContent = `已加载 ${parsed.length} 个频道 · ${state.groups.length} 个分组`;
  return true;
}

/* ---------------- 渲染：一级 / 二级 ---------------- */
function renderLvl1() {
  const box = el('lvl1');
  box.innerHTML = '';
  state.groups.forEach((g, i) => {
    const div = document.createElement('div');
    div.className = 'row' + (i === state.selGroup ? ' sel' : '');
    div.textContent = g;
    div.title = g;
    div.onmouseenter = () => {
      state.selGroup = i;
      state.lvl2Open = true;
      state.lvl2Sel = 0;
      state.group = g;
      renderLvl1();
      renderLvl2();
    };
    div.onmousedown = (ev) => {
      ev.preventDefault();
      state.selGroup = i; state.group = g; state.lvl2Open = true;
      state.lvl2Sel = 0;
      renderLvl1(); renderLvl2();
    };
    box.appendChild(div);
  });
}

function renderLvl2() {
  const box = el('lvl2');
  if (!state.lvl2Open) { box.classList.add('hidden'); return; }
  const g = state.groups[state.selGroup];
  if (!g) { box.classList.add('hidden'); return; }
  box.classList.remove('hidden');
  const list = channelsOfGroup(g);
  const selIdx = state.lvl2Sel;
  box.innerHTML = '';
  list.forEach((c, i) => {
    const div = document.createElement('div');
    div.className = 'row' + (i === selIdx ? ' sel' : '') +
      (state.channel && state.channel.name === c.name && state.playReady ? ' playing' : '');
    const no = document.createElement('span');
    no.className = 'no';
    no.textContent = String(i + 1);
    const wrap = document.createElement('div');
    wrap.className = 'wrap';
    const nm = document.createElement('span');
    nm.className = 'nm';
    nm.textContent = c.name;
    wrap.appendChild(nm);
    const subText = epgLineFor(c);
    if (subText) {
      const sub = document.createElement('div');
      sub.className = 'sub';
      const inner = document.createElement('span');
      inner.textContent = subText;
      sub.appendChild(inner);
      wrap.appendChild(sub);
      requestAnimationFrame(() => {
        if (inner.scrollWidth > sub.clientWidth + 2) {
          sub.classList.add('marq');
          sub.style.setProperty('--mq', (inner.scrollWidth - sub.clientWidth) + 'px');
        }
      });
    }
    const srcNo = document.createElement('span');
    srcNo.className = 'srcNo';
    const isCur = state.channel && state.channel.name === c.name && state.channel.group === c.group;
    srcNo.textContent = ((isCur ? state.sourceIndex + 1 : 1)) + '/' + c.urls.length;
    div.append(no, wrap, srcNo);
    div.title = c.name;
    div.onmouseenter = () => { state.lvl2Sel = i; renderLvl2(); };
    div.onmousedown = (ev) => { ev.preventDefault(); playChannel(c); closeRail(); };
    box.appendChild(div);
  });
  if (!list.length) box.innerHTML = '<div class="row">这个分组没有频道</div>';
}

/* 鼠标热区：左出菜单、下出信息条、右出设置、右上出按钮 */
function closeRail() {
  state.lvl2Open = false;
  renderLvl2();
}

const HOT = 70;             // 触发区宽度/高度（逻辑像素）
let settingsPinned = false; // 设置里点过东西后，鼠标移开不立刻收（避免操作中消失）

function showRail() {
  clearTimeout(railHideTimer);
  const rail = el('rail');
  if (!rail.classList.contains('hidden')) return;
  rail.classList.remove('hidden');
  el('bottom').classList.add('hidden');   // 菜单展开时底部条不显示
  state.bottomLocked = false;
  // 打开时定位到正在播放的频道所在分组，并把光标停在该频道上
  const cur = state.channel;
  const g = (cur && cur.group) || state.group;
  state.group = g;
  state.selGroup = Math.max(0, state.groups.indexOf(g));
  state.lvl2Open = true;
  state.picking = false;
  const list = channelsOfGroup(g);
  state.lvl2Sel = cur ? Math.max(0, list.findIndex(c => c.name === cur.name)) : 0;
  renderLvl1(); renderLvl2();
  requestAnimationFrame(() => {
    const g1 = el('lvl1').querySelectorAll('.row');
    if (g1[state.selGroup]) g1[state.selGroup].scrollIntoView({ block: 'center' });
    const g2 = el('lvl2').querySelectorAll('.row');
    if (g2[state.lvl2Sel]) g2[state.lvl2Sel].scrollIntoView({ block: 'center' });
  });
  // 不移动系统光标（会跟用户抢鼠标），只做高亮定位
}
let railHideTimer = null;
function hideRail(now) {
  if (el('rail').classList.contains('hidden')) return;
  clearTimeout(railHideTimer);
  const doHide = () => {
    el('rail').classList.add('hidden');
    closeRail();
  };
  if (now) doHide(); else railHideTimer = setTimeout(doHide, 260);
}
function showSettings() {
  el('settings').classList.remove('hidden');
  const sw = el('settings').getBoundingClientRect();
  el('bottom').style.right = Math.max(0, window.innerWidth - sw.left + 16) + 'px';
  renderSources();
  if (!settingsPinned) showSettingsPage('main');
}
function hideSettings() {
  if (settingsPinned) return;
  el('settings').classList.add('hidden');
  el('bottom').style.right = '';
}
function showTop() {}   // 右上角按钮已移除

function handleHover(x, y) {
  const w = window.innerWidth, h = window.innerHeight;
  // 鼠标在窗口外：全部收起
  if (x < 0 || y < 0 || x > w || y > h) {
    hideRail(); el('bottom').classList.add('hidden');
    settingsPinned = false; hideSettings();
    return;
  }

  // 只在这些区域的“中间段”才唤出，避免边角（改窗口大小 / 系统按钮）误触
  const yMid = y > h * 0.22 && y < h * 0.78;   // 左侧、右侧：垂直中间段
  const xMid = x > w * 0.25 && x < w * 0.75;   // 底部：水平中间段

  // 左上角三个系统按钮区域：不唤出左侧菜单
  if (x < 130 && y < 56) {
    hideRail();
    return;
  }

  // 左侧一级二级：左边缘 + 垂直中间段（或已经在面板里）
  const rr = el('rail').getBoundingClientRect();
  const inRail = !el('rail').classList.contains('hidden') &&
                 x >= rr.left - 24 && x <= rr.right + 36 && y >= rr.top - 24 && y <= rr.bottom + 24;
  if ((x < HOT && yMid) || inRail) { kbOpen.rail = false; showRail(); }
  else if (!kbOpen.rail) hideRail();

  // 底部信息条：底部 + 水平中间段；左侧菜单展开时不弹
  const railOpen = !el('rail').classList.contains('hidden');
  if (railOpen) { el('bottom').classList.add('hidden'); state.bottomLocked = false; }
  else if (y > h - 90 && xMid) { kbOpen.bottom = false; showBottom(true); }
  else if (!kbOpen.bottom) hideBottom();

  // 右侧设置：右边缘 + 垂直中间段
  const sr = el('settings').getBoundingClientRect();
  const inSettings = !el('settings').classList.contains('hidden') &&
                     x >= sr.left - 6 && y >= sr.top && y <= sr.bottom;
  if ((x > w - HOT && yMid) || inSettings) { kbOpen.settings = false; showSettings(); }
  else if (!kbOpen.settings) { settingsPinned = false; hideSettings(); }
}
document.addEventListener('mousemove', (e) => handleHover(e.clientX, e.clientY));
window.__hover = (x, y) => handleHover(x, y);   // 原生层全局鼠标监听调用
window.__clickAt = (x, y) => {                  // 原生层转发点击（窗口不在前台时）
  handleHover(x, y);
  const t = document.elementFromPoint(x, y);
  if (t) {
    t.dispatchEvent(new MouseEvent('mousedown', { bubbles: true, clientX: x, clientY: y }));
    t.dispatchEvent(new MouseEvent('mouseup', { bubbles: true, clientX: x, clientY: y }));
    t.dispatchEvent(new MouseEvent('click', { bubbles: true, clientX: x, clientY: y }));
  }
};

// 画面区单击 / 右键换台：左键上一个，右键下一个
function inPanel(target) {
  return target && target.closest && target.closest('#rail, #settings, #dlg, #bottom');
}
function stepChannel(delta) {
  if (!state.channel) return;
  if (Date.now() - (state.lastSwitch || 0) < 1200) return;   // 1.2 秒内不重复切
  state.lastSwitch = Date.now();
  const list = channelsOfGroup(state.channel.group);
  const i = list.findIndex(c => c.name === state.channel.name);
  if (i < 0) return;
  const n = (i + delta + list.length) % list.length;
  if (list[n]) playChannel(list[n]);
}
function switchSource(delta) {
  const ch = state.channel;
  if (!ch || !ch.urls.length) return;
  if (Date.now() - (state.lastSwitch || 0) < 1200) return;
  state.lastSwitch = Date.now();
  const n = (state.sourceIndex + delta + ch.urls.length) % ch.urls.length;
  tryUrl(n);
}
function inBottomZone(x, y) {
  return y >= window.innerHeight - 120 || (document.elementFromPoint(x, y) || {}).closest?.('#bottom');
}
// 右键只拦系统菜单，不再切频道（换台已改为键盘 ↑↓）
document.addEventListener('contextmenu', (e) => { e.preventDefault(); }, { capture: true });

// 进全屏时收起所有浮层
window.__tvFullscreen = (on) => {
  document.body.classList.toggle('fullscreen', !!on);
  if (on) { hideRail(); el('bottom').classList.add('hidden'); }
};

/* ---------------- 键盘操作 ---------------- */
const kbOpen = { rail: false, settings: false, bottom: false };

function panelKb(mode, code) {
  dbgLine('key=' + code + ' mode=' + mode);
  // 正在输入框里打字：不拦截
  const t = document.activeElement;
  if (t && (t.tagName === 'INPUT' || t.tagName === 'TEXTAREA' || t.isContentEditable)) return false;

  if (code === 'up' || code === 'down') {
    stepChannel(code === 'up' ? -1 : 1);
    return true;
  }
  if (code === 'left' || code === 'right') {
    switchSource(code === 'left' ? -1 : 1);
    return true;
  }
  if (code === 'a') {
    kbOpen.rail = !kbOpen.rail;
    if (kbOpen.rail) { showRail(); }
    else { hideRail(true); }
    return true;
  }
  if (code === 's') {
    kbOpen.settings = !kbOpen.settings;
    if (kbOpen.settings) { showSettings(); settingsPinned = true; }
    else { settingsPinned = false; hideSettings(); }
    return true;
  }
  if (code === 'b') {
    kbOpen.bottom = !kbOpen.bottom;
    if (kbOpen.bottom) el('bottom').classList.remove('hidden');
    else el('bottom').classList.add('hidden');
    return true;
  }
  if (code === 'f') { sendCmd('fullscreen'); return true; }
  if (code === 'esc') {
    kbOpen.rail = kbOpen.settings = kbOpen.bottom = false;
    settingsPinned = false;
    hideRail(true); hideSettings(); el('bottom').classList.add('hidden');
    return true;
  }
  return false;
}

const KEYMAP = { 126: 'up', 125: 'down', 123: 'left', 124: 'right', 0: 'a', 1: 's', 11: 'b', 3: 'f', 53: 'esc' };
// 原生层转发（WebView 没焦点时）
window.__key = (code) => panelKb(null, code);
document.addEventListener('keydown', (e) => {
  const code = KEYMAP[e.keyCode];
  if (!code) return;
  if (panelKb(null, code)) { e.preventDefault(); }
});

/* ---------------- 底部信息条 ---------------- */
el('srcPrev').onclick = (e) => { e.stopPropagation(); switchSource(-1); };
el('srcNext').onclick = (e) => { e.stopPropagation(); switchSource(1); };
function resLabel(w, h) {
  if (!w || !h) return '';
  const s = Math.min(w, h);
  if (s >= 2000) return '4K';
  if (s >= 1000) return '1080P';
  if (s >= 700) return '720P';
  if (s >= 460) return '480P';
  return String(Math.round(s)) + 'P';
}
function showBottom(byHover) {
  el('bottom').classList.remove('hidden');
  clearTimeout(bottomTimer);
  if (byHover) return;                 // 鼠标在底部：一直显示，移开才收
  bottomTimer = setTimeout(() => el('bottom').classList.add('hidden'), 4000);
}
function hideBottom(now) {
  if (el('settings').classList.contains('hidden')) el('bottom').style.right = '';
  clearTimeout(bottomTimer);
  const doHide = () => el('bottom').classList.add('hidden');
  if (now) doHide(); else bottomTimer = setTimeout(doHide, 180);
}

function updateBottom() {
  const ch = state.channel;
  if (!ch) return;
  const list = channelsOfGroup(ch.group);
  const idx = list.findIndex(c => c.name === ch.name);
  el('bNum').textContent = idx >= 0 ? idx + 1 : '—';
  el('bName').textContent = ch.name;
  el('bSrc').textContent = `源 ${state.sourceIndex + 1}/${ch.urls.length}`;
  updateEpgText(ch);
}

function epgLineFor(c) {
  if (!state.epg) return '';
  const progs = state.epg.get(c.name) || state.epg.get(c.tvg);
  if (!progs || !progs.length) return '';
  const now = Date.now();
  const cur = progs.find(p => p.start <= now && p.end > now);
  const next = progs.find(p => p.start > now);
  const fmt = (t) => {
    const d = new Date(t);
    return String(d.getHours()).padStart(2, '0') + ':' + String(d.getMinutes()).padStart(2, '0');
  };
  const parts = [];
  if (cur) parts.push(fmt(cur.start) + ' ' + cur.title);
  if (next) parts.push('接着 ' + fmt(next.start) + ' ' + next.title);
  return parts.join('   ｜   ');
}

function updateEpgText(ch) {
  const box = el('bEpg');
  box.textContent = '';
  if (!state.epg) return;
  const progs = state.epg.get(ch.name) || state.epg.get(ch.tvg);
  if (!progs || !progs.length) return;
  const now = Date.now();
  const cur = progs.find(p => p.start <= now && p.end > now);
  const next = progs.find(p => p.start > now);
  const fmt = (t) => {
    const d = new Date(t);
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  };
  if (cur) box.appendChild(document.createTextNode('正在播  ' + cur.title + '  ·  ' + fmt(cur.start) + '–' + fmt(cur.end)));
  if (next) {
    if (cur) box.appendChild(document.createTextNode('    ｜    '));
    box.appendChild(document.createTextNode('下一个  ' + fmt(next.start) + '  ' + next.title));
  }
}

/* ---------------- 播放 ---------------- */
function showLoading(on) { el('loading').classList.toggle('show', on); }

function playChannel(ch, startIndex = 0) {
  if (!ch) return;
  // 点/滚到正在播放的频道：什么都不做
  if (state.channel && state.channel.name === ch.name && state.channel.group === ch.group &&
      state.playing && startIndex === 0) { closeRail(); return; }
  clearTimeout(state.playTimer);
  state.deadline = Date.now() + 14000;   // 整台最多尝试 14 秒，超时就放弃，避免像卡死
  state.channel = ch;
  state.playReady = false;
  state.resLabel = '';
  el('bRes').textContent = '';
  state.tryCount = 0;
  state.chanStart = Date.now();
  state.group = ch.group;
  const gi = state.groups.indexOf(ch.group);
  if (gi >= 0) state.selGroup = gi;
  const gl = channelsOfGroup(ch.group);
  state.lvl2Sel = Math.max(0, gl.findIndex(c => c.name === ch.name));
  state.playing = false;
  state.sourceIndex = startIndex;
  el('bSrc').textContent = `源 ${startIndex + 1}/${ch.urls.length}`;
  updateBottom();
  showBottom();
  renderLvl1();
  renderLvl2();
  tryUrl(startIndex);
}

function nextUrl() {
  dbgLine('nextUrl src=' + (state.sourceIndex + 1) + ' ready=' + state.playReady + ' dt=' + (Date.now() - (state.urlStart || 0)));
  const ch = state.channel;
  if (!ch) return;
  if (state.playReady) return;                       // 出画面了就不换
  const wait = (state.timeoutSec || 5) * 1000;
  const elapsed = Date.now() - (state.urlStart || 0);
  if (elapsed < wait) {                              // 没满时间，等满再换
    clearTimeout(state.playTimer);
    state.playTimer = setTimeout(() => { if (!state.playReady) nextUrl(); }, wait - elapsed);
    return;
  }
  if (Date.now() > (state.deadline || 0) || state.sourceIndex + 1 >= ch.urls.length ||
      (state.tryCount || 0) > 8) {
    el('bSrc').textContent = '这个频道所有线路都连不上';
    el('bEpg').textContent = '换一个频道试试';
    showBottom();
    showLoading(false);
    return;
  }
  tryUrl(state.sourceIndex + 1);
}

function autoNextChannel() {
  const cur = state.channel;
  if (!cur) return;
  // 至少在当前频道停留“换源超时”那么久，再跳下一个频道
  const wait = (state.timeoutSec || 5) * 1000;
  const elapsed = Date.now() - (state.chanStart || 0);
  if (elapsed < wait) {
    clearTimeout(state.failTimer);
    state.failTimer = setTimeout(autoNextChannel, wait - elapsed);
    return;
  }
  // 只在本分组内循环，绝不跳到别的分组
  const list = channelsOfGroup(cur.group);
  const i = list.findIndex(c => c.name === cur.name);
  if (list.length > 1) {
    const n = (i + 1) % list.length;
    if (list[n] && list[n].name !== cur.name) { playChannel(list[n]); return; }
  }
}

function tryUrl(i) {
  const ch = state.channel;
  if (!ch || i >= ch.urls.length) { showLoading(false); return; }
  state.sourceIndex = i;
  state.urlStart = Date.now();
  state.tryCount = (state.tryCount || 0) + 1;
  const token = ++playToken;
  updateBottom();
  showBottom();
  showLoading(true);

  clearTimeout(state.playTimer);
  state.playTimer = setTimeout(() => {
    if (token !== playToken) return;
    showLoading(false);
    nextUrl();
  }, 3500);

  sendCmd('gravity', { mode: state.mode });
  playNative(ch.urls[i]);
}

/* ---------------- 节目单 ---------------- */
async function loadEpg() {
  el('epgHint').textContent = '拉取中…（文件较大，可能要十几秒）';
  const res = await window.tv.fetchText(EPG_URL);
  if (!res.ok) { el('epgHint').textContent = '节目单拉取失败：' + (res.error || res.status); return; }
  try {
    const xml = new DOMParser().parseFromString(res.text, 'text/xml');
    const names = {};
    for (const ch of xml.getElementsByTagName('channel')) {
      const id = ch.getAttribute('id');
      const titles = ch.getElementsByTagName('display-name');
      if (!id || !titles.length) continue;
      names[id] = titles[0].textContent.trim();
    }
    const map = new Map();
    for (const p of xml.getElementsByTagName('programme')) {
      const cid = p.getAttribute('channel');
      const start = parseXmlTime(p.getAttribute('start'));
      const stop = parseXmlTime(p.getAttribute('stop'));
      const t = p.getElementsByTagName('title')[0];
      if (!cid || !start || !stop || !t) continue;
      const key = names[cid] || cid;
      if (!map.has(key)) map.set(key, []);
      map.get(key).push({ start, end: stop, title: t.textContent.trim() });
    }
    map.forEach(arr => arr.sort((a, b) => a.start - b.start));
    state.epg = map;
    el('epgHint').textContent = `已加载 ${map.size} 个频道的节目单`;
    if (state.channel) { updateEpgText(state.channel); showBottom(); }
    renderLvl2();
  } catch (e) {
    el('epgHint').textContent = '节目单解析失败';
  }
}
function parseXmlTime(s) {
  if (!s) return 0;
  const m = s.match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/);
  if (!m) return 0;
  return new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]).getTime();
}

/* ---------------- 设置：源列表 ---------------- */
function renderSources() {
  const box = el('srcList');
  box.innerHTML = '';
  state.sources.forEach(s => {
    const row = document.createElement('div');
    row.className = 'srcRow' + (s.id === state.currentSrc ? ' cur' : '');
    const name = document.createElement('div');
    name.className = 'sname';
    name.textContent = s.name;
    name.title = s.url;
    name.onclick = () => switchSource(s.id);
    row.appendChild(name);
    if (s.id === state.currentSrc) {
      const tag = document.createElement('span');
      tag.className = 'tag';
      tag.textContent = '使用中';
      row.appendChild(tag);
    }
    const refresh = document.createElement('button');
    refresh.textContent = '刷新';
    refresh.onclick = async () => {
      if (s.id !== state.currentSrc) await switchSource(s.id, true);
      else await loadSource(s.url);
    };
    const del = document.createElement('button');
    del.textContent = '删除';
    del.onclick = () => {
      if (s.builtin) { el('srcHint').textContent = '默认源不能删除'; return; }
      state.sources = state.sources.filter(x => x.id !== s.id);
      if (state.currentSrc === s.id) state.currentSrc = state.sources[0].id;
      saveSources(); renderSources();
      el('srcHint').textContent = '已删除';
    };
    row.append(refresh, del);
    box.appendChild(row);
  });
}

async function switchSource(id, silent) {
  state.currentSrc = id;
  saveSources();
  renderSources();
  const src = currentSource();
  el('srcHint').textContent = '正在切换到「' + src.name + '」…';
  const ok = await loadSource(src.url);
  if (ok && !silent) el('srcHint').textContent = '已切换到「' + src.name + '」';
  const first = channelsOfGroup(state.group)[0] || state.channels[0];
  if (ok && first) playChannel(first);
}

/* ---------------- 设置：分组管理 ---------------- */
function renderGroupAdmin() {
  const box = el('groupAdmin');
  box.innerHTML = '';
  orderedGroups().forEach(g => {
    const row = document.createElement('div');
    row.className = 'grow';
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = !state.hidden.has(g);
    cb.onchange = () => {
      if (cb.checked) state.hidden.delete(g); else state.hidden.add(g);
      localStorage.setItem(LS.hidden, JSON.stringify([...state.hidden]));
      applyGroupChange();
    };
    const name = document.createElement('span');
    name.className = 'gname';
    name.textContent = g;
    name.onclick = () => {
      state.group = g;
      state.selGroup = Math.max(0, visibleGroups().indexOf(g));
      state.lvl2Open = true;
      renderLvl1(); renderLvl2();
    };
    const up = document.createElement('button');
    up.textContent = '↑';
    up.onclick = () => moveGroup(g, -1);
    const down = document.createElement('button');
    down.textContent = '↓';
    down.onclick = () => moveGroup(g, 1);
    row.append(cb, name, up, down);
    box.appendChild(row);
  });
}

function applyGroupChange() {
  state.groups = visibleGroups();
  if (!state.groups.includes(state.group)) state.group = state.groups[0] || null;
  state.selGroup = Math.max(0, state.groups.indexOf(state.group));
  renderLvl1(); renderLvl2();
}

function moveGroup(g, delta) {
  const list = orderedGroups().slice();
  const i = list.indexOf(g);
  const to = i + delta;
  if (i < 0 || to < 0 || to >= list.length) return;
  [list[i], list[to]] = [list[to], list[i]];
  state.order = list;
  localStorage.setItem(LS.order, JSON.stringify(list));
  applyGroupChange();
  renderGroupAdmin();
}

/* ---------------- 事件 ---------------- */
let sPage = 'main';
function showSettingsPage(p) {
  sPage = p;
  el('groupsPage').classList.toggle('hidden', p !== 'groups');
  el('sBack').classList.toggle('hidden', p !== 'groups');
  el('sTitle').textContent = p === 'groups' ? '分组管理' : '设置';
  // 主页面各 section 在分页时隐藏
  [...el('settings').querySelectorAll('.sBody')].forEach(b => {
    b.classList.toggle('hidden', (p === 'groups') === (b.id !== 'groupsPage'));
  });
  if (p === 'groups') renderGroupAdmin();
  settingsPinned = true;
}
el('sBack').onclick = () => showSettingsPage('main');
el('groupsEntry').onclick = () => showSettingsPage('groups');
el('loadEpg').onclick = () => loadEpg();

el('toRow').querySelectorAll('button').forEach(b => {
  b.onclick = () => {
    state.timeoutSec = parseInt(b.dataset.t, 10);
    localStorage.setItem(LS.timeout, String(state.timeoutSec));
    markTimeout();
  };
});
function markTimeout() {
  el('toRow').querySelectorAll('button').forEach(b => {
    b.classList.toggle('on', parseInt(b.dataset.t, 10) === state.timeoutSec);
  });
}
markTimeout();

el('modeFill').onclick = () => applyMode('fill');
el('mode169').onclick = () => applyMode('169');
el('modeFit').onclick = () => applyMode('fit');
function applyMode(m) {
  state.mode = m;
  localStorage.setItem(LS.mode, m);
  sendCmd('gravity', { mode: m });
  el('modeFill').classList.toggle('on', m === 'fill');
  el('mode169').classList.toggle('on', m === '169');
  el('modeFit').classList.toggle('on', m === 'fit');
}
applyMode(state.mode);
localStorage.setItem('tvdesk2_modeV2', '1');

el('addSource').onclick = () => {
  el('dlg').classList.remove('hidden');
  el('dlgName').value = '';
  el('dlgUrl').value = '';
};
el('dlgCancel').onclick = () => el('dlg').classList.add('hidden');
el('dlgOk').onclick = async () => {
  const name = el('dlgName').value.trim() || '新源';
  const url = el('dlgUrl').value.trim();
  if (!url) { el('srcHint').textContent = '地址不能为空'; return; }
  const id = 's' + Date.now();
  state.sources.push({ id, name, url });
  state.currentSrc = id;
  saveSources();
  el('dlg').classList.add('hidden');
  renderSources();
  await switchSource(id);
};

document.addEventListener('keydown', (e) => {
  if (e.key === 'f' || e.key === 'F') { e.preventDefault(); sendCmd('fullscreen'); return; }
  if (e.key === 'Escape') {
    if (!el('settings').classList.contains('hidden')) { el('settings').classList.add('hidden'); return; }
    if (!el('dlg').classList.contains('hidden')) { el('dlg').classList.add('hidden'); return; }
    if (document.body.classList.contains('fullscreen')) { sendCmd('unfullscreen'); return; }
    closeRail();
    return;
  }
  if (!el('settings').classList.contains('hidden')) return;

  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    e.preventDefault();
    if (state.lvl2Open) {
      const list = channelsOfGroup(state.groups[state.selGroup]);
      state.lvl2Sel = Math.max(0, Math.min(state.lvl2Sel + (e.key === 'ArrowDown' ? 1 : -1), list.length - 1));
      renderLvl2();
    } else {
      state.selGroup = Math.max(0, Math.min(state.selGroup + (e.key === 'ArrowDown' ? 1 : -1), state.groups.length - 1));
      state.group = state.groups[state.selGroup];
      renderLvl1();
    }
  }
  if (e.key === 'ArrowRight') {
    e.preventDefault();
    state.lvl2Open = true; state.lvl2Sel = 0;
    renderLvl2();
  }
  if (e.key === 'ArrowLeft') {
    e.preventDefault();
    if (state.lvl2Open) closeRail();
  }
  if (e.key === 'Enter') {
    e.preventDefault();
    if (state.lvl2Open) {
      const list = channelsOfGroup(state.groups[state.selGroup]);
      const ch = list[state.lvl2Sel];
      if (ch) { playChannel(ch); closeRail(); }
    } else {
      state.lvl2Open = true; renderLvl2();
    }
  }
});

/* ---------------- 启动 ---------------- */
(async () => {
  loadSources();
  el('verHint').textContent = 'TV 直播 · Mac 版 v1.1';
  renderSources();
  await loadSource(currentSource().url);
  loadEpg();   // 进软件就自动拉节目单

  const last = JSON.parse(localStorage.getItem(LS.last) || 'null');
  if (last) {
    const ch = state.channels.find(c => c.name === last.name && c.group === last.group) ||
               state.channels.find(c => c.name === last.name);
    if (ch) { playChannel(ch); return; }
  }
  const first = channelsOfGroup(state.group)[0];
  if (first) playChannel(first);
})();
