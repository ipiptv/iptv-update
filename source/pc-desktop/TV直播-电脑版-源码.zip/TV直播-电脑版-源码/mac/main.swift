import Cocoa
import WebKit
import AVFoundation

// MARK: - 网络桥（拉 m3u / 节目单，自动跟随 302）
final class Bridge: NSObject, WKScriptMessageHandler {
    weak var webView: WKWebView?

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard message.name == "tvFetch",
              let body = message.body as? [String: Any],
              let urlStr = body["url"] as? String,
              let cbId = body["id"] as? String else { return }
        fetchText(urlStr) { ok, text, status, error in
            let payload: [String: Any] = ["id": cbId, "ok": ok, "text": text, "status": status, "error": error]
            guard let data = try? JSONSerialization.data(withJSONObject: payload),
                  let json = String(data: data, encoding: .utf8) else { return }
            DispatchQueue.main.async {
                self.webView?.evaluateJavaScript("window.__tvFetchDone(\(json));", completionHandler: nil)
            }
        }
    }

    private func fetchText(_ urlStr: String, completion: @escaping (Bool, String, Int, String) -> Void) {
        let escaped = urlStr.addingPercentEncoding(withAllowedCharacters: .urlFragmentAllowed) ?? urlStr
        guard let url = URL(string: escaped) else { completion(false, "", 0, "bad url"); return }
        var req = URLRequest(url: url)
        req.timeoutInterval = 25
        req.setValue("Mozilla/5.0 (Macintosh) TVDesktop/1.0", forHTTPHeaderField: "User-Agent")
        req.setValue("identity", forHTTPHeaderField: "Accept-Encoding")
        let cfg = URLSessionConfiguration.ephemeral
        cfg.timeoutIntervalForRequest = 25
        cfg.timeoutIntervalForResource = 40
        URLSession(configuration: cfg).dataTask(with: req) { data, resp, err in
            if let err = err { completion(false, "", 0, err.localizedDescription); return }
            let code = (resp as? HTTPURLResponse)?.statusCode ?? 0
            guard let data = data, code == 200 else { completion(false, "", code, "http \(code)"); return }
            completion(true, String(data: data, encoding: .utf8) ?? "", code, "")
        }.resume()
    }
}

// MARK: - 视频层（原生 AVPlayer，垫在网页下面）
final class PlayerHost: NSView {
    let player = AVPlayer()
    let playerLayer = AVPlayerLayer()
    weak var web: WKWebView?
    private var watchdog: Timer?
    private var obs: NSKeyValueObservation?

    override init(frame frameRect: NSRect) {
        super.init(frame: frameRect)
        wantsLayer = true
        layer = CALayer()
        layer?.backgroundColor = NSColor.black.cgColor
        playerLayer.videoGravity = .resizeAspect
        playerLayer.player = player
        layer?.addSublayer(playerLayer)
    }
    required init?(coder: NSCoder) { fatalError() }

    var mode: String = "fill"

    override func layout() {
        super.layout()
        CATransaction.begin()
        CATransaction.setDisableActions(true)
        if mode == "169", bounds.width > 0, bounds.height > 0 {
            // 固定 16:9 画框，居中（画面按 16:9 铺在这个框里）
            var w = bounds.width
            var h = w * 9.0 / 16.0
            if h > bounds.height { h = bounds.height; w = h * 16.0 / 9.0 }
            playerLayer.frame = CGRect(x: (bounds.width - w) / 2, y: (bounds.height - h) / 2, width: w, height: h)
        } else {
            playerLayer.frame = bounds
        }
        CATransaction.commit()
    }

    private func notifyJS(_ payload: [String: Any]) {
        guard let data = try? JSONSerialization.data(withJSONObject: payload),
              let json = String(data: data, encoding: .utf8) else { return }
        web?.evaluateJavaScript("window.__tvPlayerEvent(\(json));", completionHandler: nil)
    }

    func play(_ urlStr: String, seq: Int = 0) {
        stop()
        let escaped = urlStr.addingPercentEncoding(withAllowedCharacters: .urlFragmentAllowed) ?? urlStr
        guard let url = URL(string: escaped) else { notifyJS(["type": "failed", "reason": "bad url", "seq": seq]); return }
        let item = AVPlayerItem(url: url)
        player.replaceCurrentItem(with: item)
        player.play()

        obs = item.observe(\.status, options: [.new]) { [weak self] it, _ in
            guard let self = self else { return }
            if it.status == .readyToPlay {
                DispatchQueue.main.asyncAfter(deadline: .now() + 1.0) {
                    self.notifyJS(["type": "ready", "seq": seq,
                                   "w": Double(it.presentationSize.width),
                                   "h": Double(it.presentationSize.height)])
                }
            } else if it.status == .failed {
                self.notifyJS(["type": "failed", "seq": seq, "reason": it.error?.localizedDescription ?? "failed"])
            }
        }

        var ticks = 0
        watchdog = Timer.scheduledTimer(withTimeInterval: 1.0, repeats: true) { [weak self] t in
            guard let self = self, let cur = self.player.currentItem else { t.invalidate(); return }
            ticks += 1
            if cur.status == .failed { t.invalidate(); return }
            if cur.status == .readyToPlay {
                // 有声音没画面（AVS/少见 HEVC profile）→ 判失败
                if cur.presentationSize.width == 0 && ticks >= 3 {
                    t.invalidate()
                    self.notifyJS(["type": "failed", "seq": seq, "reason": "no video track"])
                } else if ticks >= 4 {
                    t.invalidate()
                }
            } else if ticks >= 5 {
                t.invalidate()
                self.notifyJS(["type": "failed", "seq": seq, "reason": "timeout"])
            }
        }
    }

    func stop() {
        watchdog?.invalidate(); watchdog = nil
        obs?.invalidate(); obs = nil
        player.pause()
        player.replaceCurrentItem(with: nil)
    }
}

// MARK: - 应用
final class AppDelegate: NSObject, NSApplicationDelegate, NSWindowDelegate, WKScriptMessageHandler {
    var window: NSWindow!
    var webView: WKWebView!
    var playerHost: PlayerHost!
    let bridge = Bridge()

    func applicationDidFinishLaunching(_ notification: Notification) {
        buildMenu()

        playerHost = PlayerHost(frame: NSRect(x: 0, y: 0, width: 1600, height: 1000))

        let cfg = WKWebViewConfiguration()
        cfg.websiteDataStore = .nonPersistent()   // 不吃磁盘缓存，界面改动立即生效
        cfg.preferences.setValue(true, forKey: "developerExtrasEnabled")
        let ucc = WKUserContentController()
        ucc.add(bridge, name: "tvFetch")
        ucc.add(self, name: "tvCmd")
        ucc.add(self, name: "tvPlay")
        cfg.userContentController = ucc
        cfg.mediaTypesRequiringUserActionForPlayback = []

        webView = WKWebView(frame: .zero, configuration: cfg)
        bridge.webView = webView
        playerHost.web = webView
        webView.setValue(false, forKey: "drawsBackground")
        if #available(macOS 12.0, *) { webView.underPageBackgroundColor = .clear }

        window = NSWindow(contentRect: NSRect(x: 0, y: 0, width: 1600, height: 1000),
                          styleMask: [.titled, .closable, .miniaturizable, .resizable],
                          backing: .buffered, defer: false)
        window.title = "TV 直播"
        window.titleVisibility = .hidden            // 不显示标题文字
        window.titlebarAppearsTransparent = true    // 标题栏背景透明，画面直接透上来
        window.styleMask.insert(.fullSizeContentView)
        window.backgroundColor = .black
        window.minSize = NSSize(width: 1100, height: 680)
        window.delegate = self
        window.collectionBehavior.insert(.fullScreenPrimary)

        let container = NSView(frame: NSRect(x: 0, y: 0, width: 1600, height: 1000))
        playerHost.frame = container.bounds
        playerHost.autoresizingMask = [.width, .height]
        webView.frame = container.bounds
        webView.autoresizingMask = [.width, .height]
        container.addSubview(playerHost)
        container.addSubview(webView)
        window.contentView = container

        styleTrafficLights(false)
        window.center()
        window.makeKeyAndOrderFront(nil)
        window.makeFirstResponder(webView)
        NSApp.activate(ignoringOtherApps: true)
        installGlobalHover()
        NSApp.activate(ignoringOtherApps: true)

        if let resURL = Bundle.main.resourceURL {
            webView.loadFileURL(resURL.appendingPathComponent("index.html"), allowingReadAccessTo: resURL)
        }
    }

    func userContentController(_ userContentController: WKUserContentController, didReceive message: WKScriptMessage) {
        guard let body = message.body as? [String: Any] else { return }
        switch message.name {
        case "tvPlay":
            if let url = body["url"] as? String {
                let seq = (body["seq"] as? Int) ?? 0
                playerHost.play(url, seq: seq)
            }
        case "tvCmd":
            guard let cmd = body["cmd"] as? String else { return }
            switch cmd {
            case "fullscreen": DispatchQueue.main.async { self.window.toggleFullScreen(nil) }
            case "unfullscreen":
                DispatchQueue.main.async { if self.window.styleMask.contains(.fullScreen) { self.window.toggleFullScreen(nil) } }
            case "stop": DispatchQueue.main.async { self.playerHost.stop() }
            case "warp":
                let px = (body["x"] as? Double) ?? 0
                let py = (body["y"] as? Double) ?? 0
                DispatchQueue.main.async {
                    guard let win = self.window, let cv = win.contentView else { return }
                    // 网页坐标(左上原点) → 窗口坐标(左下原点)
                    let p = cv.convert(NSPoint(x: px, y: cv.bounds.height - py), to: nil)
                    let sp = win.convertPoint(toScreen: p)
                    let primaryH = NSScreen.screens.first?.frame.height ?? sp.y
                    CGWarpMouseCursorPosition(CGPoint(x: sp.x, y: primaryH - sp.y))
                }
            case "gravity":
                let m = (body["mode"] as? String) ?? "fit"
                DispatchQueue.main.async {
                    self.playerHost.mode = m
                    self.playerHost.playerLayer.videoGravity = (m == "fill") ? .resizeAspectFill : .resizeAspect
                    self.playerHost.needsLayout = true
                }
            default: break
            }
        default: break
        }
    }

    private var globalMonitor: Any?
    private var globalClickMonitor: Any?
    private var lastHover = CFAbsoluteTimeGetCurrent()
    private var trafficBright = false
    private var keyMonitor: Any?
    private var globalKeyMonitor: Any?

    func installGlobalHover() {
        globalMonitor = NSEvent.addGlobalMonitorForEvents(matching: [.mouseMoved]) { [weak self] _ in
            guard let self = self, let win = self.window, win.isVisible,
                  let web = self.webView else { return }
            let now = CFAbsoluteTimeGetCurrent()
            if now - self.lastHover < 0.05 { return }
            self.lastHover = now
            let mouse = NSEvent.mouseLocation
            let inWin = win.convertPoint(fromScreen: mouse)
            guard let cv = win.contentView else { return }
            let p = cv.convert(inWin, from: nil)
            let x = Double(p.x)
            let y = Double(cv.bounds.height - p.y)
            web.evaluateJavaScript("window.__hover && window.__hover(\(x), \(y));", completionHandler: nil)

            // 顶部 50pt 内：系统按钮变亮，否则灰暗
            let bright = (y <= 50)
            if bright != self.trafficBright {
                self.trafficBright = bright
                self.styleTrafficLights(bright)
            }
        }

        // 键盘兜底：WebView 没焦点时，方向键/A/S/B/F/Esc 由这里转给网页
        keyMonitor = NSEvent.addLocalMonitorForEvents(matching: [.keyDown]) { [weak self] ev in
            guard let self = self, let win = self.window, win.isKeyWindow,
                  let web = self.webView else { return ev }
            let map: [UInt16: String] = [126: "up", 125: "down", 123: "left", 124: "right",
                                         0: "a", 1: "s", 11: "b", 3: "f", 53: "esc"]
            if let name = map[ev.keyCode] {
                let js = "window.__key && window.__key('" + name + "');"
                web.evaluateJavaScript(js, completionHandler: nil)
                return nil
            }
            return ev
        }

        // 窗口不在前台时，点击只激活窗口、落不到网页上 → 这里把点击转发进网页
        globalClickMonitor = NSEvent.addGlobalMonitorForEvents(matching: [.leftMouseDown]) { [weak self] _ in
            guard let self = self, let win = self.window, win.isVisible, !NSApp.isActive,
                  let web = self.webView else { return }
            let mouse = NSEvent.mouseLocation
            guard win.frame.contains(mouse) else { return }
            NSApp.activate(ignoringOtherApps: true)
            win.makeKey()
            if let cv = win.contentView {
                let p = cv.convert(win.convertPoint(fromScreen: mouse), from: nil)
                let x = Double(p.x), y = Double(cv.bounds.height - p.y)
                web.evaluateJavaScript("window.__hover && window.__hover(\(x), \(y)); window.__clickAt && window.__clickAt(\(x), \(y));", completionHandler: nil)
            }
        }
    }

    /// 顶部三个系统按钮：平时灰暗，鼠标靠近变亮
    private func styleTrafficLights(_ bright: Bool) {
        guard let win = window else { return }
        for t in [NSWindow.ButtonType.closeButton, .miniaturizeButton, .zoomButton] {
            win.standardWindowButton(t)?.alphaValue = bright ? 1.0 : 0.45
        }
    }

    func windowDidEnterFullScreen(_ notification: Notification) {
        // 全屏时铺满整块屏幕
        if let screen = window.screen {
            window.setFrame(screen.frame, display: true)
        }
        webView?.evaluateJavaScript("window.__tvFullscreen && window.__tvFullscreen(true);", completionHandler: nil)
    }
    func windowDidExitFullScreen(_ notification: Notification) {
        webView?.evaluateJavaScript("window.__tvFullscreen && window.__tvFullscreen(false);", completionHandler: nil)
    }
    func applicationShouldTerminateAfterLastWindowClosed(_ sender: NSApplication) -> Bool { true }

    private func buildMenu() {
        let mainMenu = NSMenu()
        let appItem = NSMenuItem()
        mainMenu.addItem(appItem)
        let appMenu = NSMenu()
        appMenu.addItem(withTitle: "关于 TV 直播", action: #selector(NSApplication.orderFrontStandardAboutPanel(_:)), keyEquivalent: "")
        appMenu.addItem(NSMenuItem.separator())
        appMenu.addItem(withTitle: "隐藏", action: #selector(NSApplication.hide(_:)), keyEquivalent: "h")
        appMenu.addItem(withTitle: "退出", action: #selector(NSApplication.terminate(_:)), keyEquivalent: "q")
        appItem.submenu = appMenu
        NSApp.mainMenu = mainMenu
    }
}

let app = NSApplication.shared
let delegate = AppDelegate()
app.delegate = delegate
app.setActivationPolicy(.regular)
app.run()
