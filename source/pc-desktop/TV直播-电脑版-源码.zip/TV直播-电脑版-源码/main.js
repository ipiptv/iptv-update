const { app, BrowserWindow, ipcMain, net } = require('electron');
const path = require('path');

let win = null;

function createWindow() {
  win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1000,
    minHeight: 640,
    backgroundColor: '#05070a',
    title: 'TV 直播',
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      nodeIntegration: false,
      webSecurity: false, // 允许跨域拉取 m3u8 / 节目单
      backgroundThrottling: false
    }
  });
  win.setMenuBarVisibility(false);
  win.loadFile('index.html');
  win.on('closed', () => { win = null; });
}

/** 拉取文本：手动跟随 302（Gitee 现在会跳 raw.giteeusercontent.com） */
function fetchText(url, depth = 0) {
  return new Promise((resolve) => {
    let settled = false;
    const done = (r) => { if (!settled) { settled = true; resolve(r); } };
    let req;
    try {
      req = net.request({ method: 'GET', url, redirect: 'manual' });
    } catch (e) {
      return done({ ok: false, status: 0, error: String(e) });
    }
    req.setHeader('User-Agent', 'Mozilla/5.0 (Macintosh) TVDesktop/1.0');
    const timer = setTimeout(() => {
      try { req.abort(); } catch (e) {}
      done({ ok: false, status: 0, error: 'timeout' });
    }, 20000);

    req.on('response', (res) => {
      const code = res.statusCode;
      if (code >= 300 && code < 400 && depth < 5) {
        const loc = res.headers.location;
        clearTimeout(timer);
        try { res.destroy(); } catch (e) {}
        if (!loc) return done({ ok: false, status: code, error: 'redirect without location' });
        const next = loc.startsWith('http') ? loc : new URL(loc, url).toString();
        return fetchText(next, depth + 1).then(done);
      }
      if (code !== 200) {
        clearTimeout(timer);
        return done({ ok: false, status: code, error: 'http ' + code });
      }
      const chunks = [];
      res.on('data', (c) => chunks.push(c));
      res.on('end', () => {
        clearTimeout(timer);
        const buf = Buffer.concat(chunks);
        done({ ok: true, status: 200, text: buf.toString('utf8') });
      });
      res.on('error', (e) => { clearTimeout(timer); done({ ok: false, status: 0, error: String(e) }); });
    });
    req.on('error', (e) => { clearTimeout(timer); done({ ok: false, status: 0, error: String(e) }); });
    req.end();
  });
}

ipcMain.handle('fetch-text', (evt, url) => fetchText(url));
ipcMain.handle('app-version', () => app.getVersion());

app.whenReady().then(createWindow);
app.on('window-all-closed', () => { if (process.platform !== 'darwin') app.quit(); });
app.on('activate', () => { if (BrowserWindow.getAllWindows().length === 0) createWindow(); });
