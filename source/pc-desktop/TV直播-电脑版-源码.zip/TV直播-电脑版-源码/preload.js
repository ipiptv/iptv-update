const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('tv', {
  fetchText: (url) => ipcRenderer.invoke('fetch-text', url),
  appVersion: () => ipcRenderer.invoke('app-version')
});
