/* TV 直播 · 电脑版 v1
   - 拉取 m3u 订阅源、分组、多线路自动换源
   - 底部条：编号 + 名称 + 正在播/下一个 + 源 x/y
*/

const DEFAULT_SOURCE = 'https://gitee.com/IptvIptv/Iptv/raw/master/bbxx365_hotel.m3u';
const EPG_URL = 'https://epg.112114.xyz/pp.xml';

const LS = {
  source: 'tvdesk_source',
  hidden: 'tvdesk_hidden',
  order: 'tvdesk_order',
  last: 'tvdesk_last'
};

const state = {
  channels: [],          // {name, tvg, group, logo, urls: []}
  groups: [],            // 显示中的分组（有序）
  allGroups: [],
  hidden: new Set(JSON.parse(localStorage.getItem(LS.hidden) || '[]')),
  order: JSON.parse(localStorage.getItem(LS.order) || '[]'),
  group: null,
  channel: null,         // 当前播放频道对象
  sourceIndex: 0,
  epg: null              // Map<channelKey, [{start,end,title}]>
};

const el = (id) => document.getElementById(id);
const video = el('video');
let hls = null;
let probeTimer = null;
let currentToken = 0;

/* ---------------- 工具 ---------------- */
function toast(msg) {
  el('srcHint').textContent = msg;
}

/* ---------------- 解析 m3u ---------------- */
function parseM3U(text) {
  const lines = text.split(/\r?\n/);
  const map = new Map();
  let pending = null;
  for (let i = 0; i < lines.length; i++) {
    const line = lines[i].trim();
    if (!line) continue;
    if (line.startsWith('#EXTINF')) {
      const name = line.substring(line.lastIndexOf(',') + 1).trim();
      const attrs = {};
      const re = /([\w-]+)="([^"]*)"/g;
      let m;
      while ((m = re.exec(line)) !== null) attrs[m[1].toLowerCase()] = m[2];
      pending = {
        name: name || attrs['tvg-name'] || '未命名',
        tvg: attrs['tvg-name'] || '',
        logo: attrs['tvg-logo'] || '',
        group: attrs['group-title'] || '未分组'
      };
    } else if (!line.startsWith('#') && pending) {
      const key = pending.tvg || pending.name;
      let ch = map.get(key);
      if (!ch) {
        ch = { name: pending.name, tvg: pending.tvg, logo: pending.logo, group: pending.group, urls: [] };
        map.set(key, ch);
      }
      if (!ch.urls.includes(line)) ch.urls.push(line);
      pending = null;
    }
  }
  return Array.from(map.values());
}

/* ---------------- 分组顺序 ---------------- */
function orderedGroups() {
  const raw = Array.from(new Set(state.channels.map(c => c.group)));
  state.allGroups = raw;
  const out = [];
  state.order.forEach(g => { if (raw.includes(g) && !out.includes(g)) out.push(g); });
  raw.forEach(g => { if (!out.includes(g)) out.push(g); });
  return out;
}

function visibleGroups() {
  return orderedGroups().filter(g => !state.hidden.has(g));
}

/* ---------------- 拉源 ---------------- */
async function loadSource(url) {
  toast('正在拉取订阅源…');
  const res = await window.tv.fetchText(url);
  if (!res.ok) {
    toast('拉取失败：' + (res.error || res.status));
    return false;
  }
  const parsed = parseM3U(res.text);
  if (!parsed.length) {
    toast('解析为空，检查源格式');
    return false;
  }
  state.channels = parsed;
  // 兜底：全隐藏时放行全部，避免列表空白
  const vis = visibleGroups();
  state.groups = vis.length ? vis : orderedGroups();
  state.group = state.groups[0] || null;
  renderGroups();
  renderChannels();
  renderGroupAdmin();
  toast(`已加载 ${parsed.length} 个频道 · ${state.groups.length} 个分组`);
  return true;
}

/* ---------------- 渲染 ---------------- */
function renderGroups() {
  const box = el('groups');
  box.innerHTML = '';
  state.groups.forEach(g => {
    const div = document.createElement('div');
    div.className = 'item' + (g === state.group ? ' active' : '');
    div.textContent = g;
    div.title = g;
    div.onclick = () => { state.group = g; renderGroups(); renderChannels(); };
    box.appendChild(div);
  });
}

function channelsOfGroup(g) {
  return state.channels.filter(c => c.group === g);
}

function renderChannels() {
  const box = el('channels');
  box.innerHTML = '';
  const list = channelsOfGroup(state.group);
  list.forEach((c, i) => {
    const div = document.createElement('div');
    div.className = 'item' + (state.channel && state.channel.name === c.name ? ' playing' : '');
    div.title = c.name;
    const num = document.createElement('span');
    num.style.color = '#5f7f92';
    num.style.marginRight = '8px';
    num.textContent = String(i + 1);
    div.appendChild(num);
    div.appendChild(document.createTextNode(c.name));
    div.onclick = () => playChannel(c);
    box.appendChild(div);
  });
  if (!list.length) {
    box.innerHTML = '<div class="hint" style="padding:12px">这个分组没有频道</div>';
  }
}

function renderGroupAdmin() {
  const box = el('groupAdmin');
  box.innerHTML = '';
  const vis = visibleGroups();
  const all = orderedGroups();
  all.forEach(g => {
    const row = document.createElement('div');
    row.className = 'grow';
    const cb = document.createElement('input');
    cb.type = 'checkbox';
    cb.checked = !state.hidden.has(g);
    cb.onchange = () => {
      if (cb.checked) state.hidden.delete(g); else state.hidden.add(g);
      localStorage.setItem(LS.hidden, JSON.stringify([...state.hidden]));
      refreshGroupsAfterChange();
    };
    const name = document.createElement('span');
    name.className = 'gname';
    name.textContent = g;
    name.title = g;
    const up = document.createElement('button');
    up.textContent = '↑';
    up.onclick = () => moveGroup(g, -1);
    const down = document.createElement('button');
    down.textContent = '↓';
    down.onclick = () => moveGroup(g, 1);
    row.append(cb, name, up, down);
    box.appendChild(row);
  });
}

function refreshGroupsAfterChange() {
  const vis = visibleGroups();
  state.groups = vis.length ? vis : orderedGroups();
  if (!state.groups.includes(state.group)) state.group = state.groups[0] || null;
  renderGroups();
  renderChannels();
}

function moveGroup(g, delta) {
  const list = orderedGroups().slice();
  const i = list.indexOf(g);
  const to = i + delta;
  if (i < 0 || to < 0 || to >= list.length) return;
  [list[i], list[to]] = [list[to], list[i]];
  state.order = list;
  localStorage.setItem(LS.order, JSON.stringify(list));
  refreshGroupsAfterChange();
  renderGroupAdmin();
}

/* ---------------- 播放 ---------------- */
function showLoading(on) {
  el('loading').classList.toggle('show', on);
}

function playChannel(ch, startIndex = 0) {
  state.channel = ch;
  state.sourceIndex = startIndex;
  localStorage.setItem(LS.last, JSON.stringify({ name: ch.name, group: ch.group }));
  el('empty').classList.add('hidden');
  el('bottom').classList.remove('hidden');
  updateBottom();
  renderChannels();
  tryUrl(startIndex);
}

function updateBottom() {
  const ch = state.channel;
  if (!ch) return;
  const list = channelsOfGroup(ch.group);
  const idx = list.findIndex(c => c.name === ch.name);
  el('bNum').textContent = idx >= 0 ? idx + 1 : '—';
  el('bName').textContent = ch.name;
  el('bSrc').textContent = `源 ${state.sourceIndex + 1}/${ch.urls.length}`;
  updateEpgText(ch);
}

function updateEpgText(ch) {
  const box = el('bEpg');
  if (!state.epg) { box.textContent = ''; return; }
  const progs = state.epg.get(ch.name) || state.epg.get(ch.tvg);
  if (!progs || !progs.length) { box.textContent = ''; return; }
  const now = Date.now();
  const cur = progs.find(p => p.start <= now && p.end > now);
  const next = progs.find(p => p.start > now);
  const fmt = (t) => {
    const d = new Date(t);
    return `${String(d.getHours()).padStart(2, '0')}:${String(d.getMinutes()).padStart(2, '0')}`;
  };
  box.textContent = '';
  if (cur) box.appendChild(document.createTextNode('正在播  ' + cur.title + '  ·  ' + fmt(cur.start) + '–' + fmt(cur.end)));
  if (next) {
    if (cur) box.appendChild(document.createTextNode('    ｜    '));
    box.appendChild(document.createTextNode('下一个  ' + fmt(next.start) + '  ' + next.title));
  }
}

function tryUrl(i) {
  const ch = state.channel;
  if (!ch || i >= ch.urls.length) {
    showLoading(false);
    el('bSrc').textContent = '所有线路都连不上';
    return;
  }
  state.sourceIndex = i;
  updateBottom();
  const url = ch.urls[i];
  const token = ++currentToken;

  if (hls) { try { hls.destroy(); } catch (e) {} hls = null; }
  clearTimeout(probeTimer);
  video.removeAttribute('src');
  video.load();
  showLoading(true);

  const fallback = () => {
    if (token !== currentToken) return;
    clearTimeout(probeTimer);
    showLoading(false);
    tryUrl(i + 1);
  };

  probeTimer = setTimeout(fallback, 5000);

  if (url.includes('.m3u8')) {
    if (window.Hls && Hls.isSupported()) {
      hls = new Hls({ manifestLoadingTimeOut: 6000, fragLoadingTimeOut: 8000, maxBufferLength: 20 });
      hls.loadSource(url);
      hls.attachMedia(video);
      hls.on(Hls.Events.MANIFEST_PARSED, () => { video.play().catch(() => {}); });
      hls.on(Hls.Events.FRAG_BUFFERED, () => {
        if (token !== currentToken) return;
        clearTimeout(probeTimer);
        showLoading(false);
      });
      hls.on(Hls.Events.ERROR, (evt, data) => {
        if (token !== currentToken) return;
        if (data.fatal) fallback();
      });
    } else {
      video.src = url;
      video.play().catch(fallback);
    }
  } else {
    video.src = url;
    video.play().catch(fallback);
  }

  video.onplaying = () => {
    if (token !== currentToken) return;
    clearTimeout(probeTimer);
    showLoading(false);
  };
  video.onerror = () => { if (token === currentToken) fallback(); };
}

/* ---------------- 节目单 ---------------- */
async function loadEpg() {
  el('epgHint').textContent = '拉取中…（文件较大，可能要十几秒）';
  const res = await window.tv.fetchText(EPG_URL);
  if (!res.ok) { el('epgHint').textContent = '节目单拉取失败：' + (res.error || res.status); return; }
  try {
    const parser = new DOMParser();
    const xml = parser.parseFromString(res.text, 'text/xml');
    const map = new Map();
    const nodes = xml.getElementsByTagName('channel');
    // 建立 channel id -> 显示名
    for (const ch of nodes) {
      const id = ch.getAttribute('id');
      const titles = ch.getElementsByTagName('display-name');
      if (!id || !titles.length) continue;
      const name = titles[0].textContent.trim();
      if (!map.has(name)) map.set(name, []);
    }
    const progs = xml.getElementsByTagName('programme');
    for (const p of progs) {
      const cid = p.getAttribute('channel');
      const start = parseXmlTime(p.getAttribute('start'));
      const stop = parseXmlTime(p.getAttribute('stop'));
      const t = p.getElementsByTagName('title')[0];
      if (!cid || !start || !stop || !t) continue;
      const arr = map.get(cid) || [];
      arr.push({ start, end: stop, title: t.textContent.trim() });
      map.set(cid, arr);
    }
    // 按显示名也建一份索引（频道名常直接用名字匹配）
    state.epg = map;
    el('epgHint').textContent = `已加载 ${map.size} 个频道的节目单`;
    if (state.channel) updateEpgText(state.channel);
  } catch (e) {
    el('epgHint').textContent = '节目单解析失败';
  }
}

function parseXmlTime(s) {
  if (!s) return 0;
  const m = s.match(/^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/);
  if (!m) return 0;
  return new Date(+m[1], +m[2] - 1, +m[3], +m[4], +m[5], +m[6]).getTime();
}

/* ---------------- 事件绑定 ---------------- */
el('gear').onclick = () => {
  el('settings').classList.remove('hidden');
  el('srcHint').textContent = '';
};
el('closeSettings').onclick = () => el('settings').classList.add('hidden');

el('srcUrl').value = localStorage.getItem(LS.source) || DEFAULT_SOURCE;
el('saveSource').onclick = async () => {
  const url = el('srcUrl').value.trim();
  if (!url) return;
  localStorage.setItem(LS.source, url);
  await loadSource(url);
};
el('reloadSource').onclick = () => loadSource(localStorage.getItem(LS.source) || DEFAULT_SOURCE);
el('loadEpg').onclick = () => loadEpg();

window.tv.appVersion().then(v => { el('verHint').textContent = 'TV 直播 电脑版  ' + v; });

/* 键盘：上下切频道，回车播放 */
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    if (!el('settings').classList.contains('hidden')) el('settings').classList.add('hidden');
    return;
  }
  if (!el('settings').classList.contains('hidden')) return;
  const list = channelsOfGroup(state.group);
  if (!list.length) return;
  if (e.key === 'ArrowDown' || e.key === 'ArrowUp') {
    e.preventDefault();
    let i = state.channel ? list.findIndex(c => c.name === state.channel.name) : -1;
    i = e.key === 'ArrowDown' ? Math.min(i + 1, list.length - 1) : Math.max(i - 1, 0);
    const target = list[i];
    const box = el('channels');
    const children = box.querySelectorAll('.item');
    children.forEach((c, k) => c.classList.toggle('active', k === i));
    if (children[i]) children[i].scrollIntoView({ block: 'nearest' });
    state.pending = target;
  }
  if (e.key === 'Enter') {
    e.preventDefault();
    if (state.pending) { playChannel(state.pending); state.pending = null; }
  }
});

/* ---------------- 启动 ---------------- */
(async () => {
  el('verHint').textContent = 'TV 直播 电脑版';
  await loadSource(localStorage.getItem(LS.source) || DEFAULT_SOURCE);
  const last = JSON.parse(localStorage.getItem(LS.last) || 'null');
  if (last) {
    const ch = state.channels.find(c => c.name === last.name && c.group === last.group) ||
               state.channels.find(c => c.name === last.name);
    if (ch) {
      state.group = ch.group;
      renderGroups(); renderChannels();
      playChannel(ch);
    }
  }
})();
