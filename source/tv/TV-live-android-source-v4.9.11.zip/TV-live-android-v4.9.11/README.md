TV直播 电视版（Android TV）源码  v4.9.11  versionCode 499
=====================================================

包名 tv.live，minSdk 21 / targetSdk 28，Kotlin + Gradle 工程。
Android Studio 直接打开，或 ./gradlew assembleRelease（需要 JDK 17）。

v4.9.11 变更：
- 订阅源支持独立 UA：手机配源网页新增「UA（可留空）」输入框，留空用默认 UA
- 该源的 UA 同时用于拉取列表与播放（VideoView 带 User-Agent 请求头）
- 扫码换源页只保留二维码，背景高光透，二维码放大到 300dp
- 手机配源网页重排为「订阅源 / 安装更新」两个页签 + 卡片式布局，提交后原地提示

注意：program guide 与检查更新仍用默认 UA，不跟源走。
