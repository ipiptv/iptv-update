TV直播 电视版（Android TV）源码  v4.9.13  versionCode 501
=====================================================

包名 tv.live，minSdk 21 / targetSdk 28，Kotlin + Gradle 工程。
Android Studio 打开，或 ./gradlew assembleRelease（需 JDK 17）。

v4.9.13 变更（修复「填了 UA 的源在黑屏」）：
- 新增 ExoPlayer 2.19.1（core/hls/ui）作为第二播放引擎
- 只有源填了自定义 UA 时才用它：数据层 DefaultHttpDataSource 统一 setUserAgent，
  m3u8 与每个分片请求都带同一个 UA（MediaPlayer 做不到这点）
- 没填 UA 的源继续走原 VideoView，行为与旧版一致
- ExoPlayer 报错先去掉 UA 重试，再换线路，最后换频道
- 加载圈、5 秒超时换源、分辨率显示、退出/续播逻辑两种播放器都接上了

依赖需要联网拉取（ExoPlayer 未打进本地离线缓存时，首次构建去掉 --offline）。
