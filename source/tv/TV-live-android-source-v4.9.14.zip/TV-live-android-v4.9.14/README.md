TV直播 电视版（Android TV）源码  v4.9.14  versionCode 502
=====================================================

包名 tv.live，minSdk 21 / targetSdk 28，Kotlin + Gradle 工程。
Android Studio 打开，或 ./gradlew assembleRelease（需 JDK 17）。

v4.9.14 修复：
- 设置首页点「订阅源管理」「检查更新」都跳进「分组管理」的 bug
  原因：设置列表焦点被 RecyclerView 抢走，settingsPos 不跟随高亮；
  现改为列表条目不获焦、方向键统一由 Activity 处理
- 设置首页分发改为按菜单文字匹配，不再依赖 payload 下标

v4.9.13：填了自定义 UA 的源改用 ExoPlayer（m3u8 与分片统一带 UA）
