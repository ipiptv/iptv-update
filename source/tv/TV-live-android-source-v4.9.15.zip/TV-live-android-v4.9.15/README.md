TV直播 电视版（Android TV）源码  v4.9.15  versionCode 503
=====================================================

包名 tv.live，minSdk 21 / targetSdk 28，Kotlin + Gradle 工程。
Android Studio 打开，或 ./gradlew assembleRelease（需 JDK 17；首次构建需联网拉 ExoPlayer）。

v4.9.15 新功能：
- 多源同开：订阅源管理里可以同时启用多个源（OK 开/关），启用源的分组合并到一级菜单
  · 同名同分组的频道自动合成多线路（跨源线路一起参与自动换源）
  · 每个源单独缓存，某个源拉失败就用它自己的缓存兜底
  · 每条线路记住所属源，拉取与播放都用该源的 UA
- 强制更新：启动 6 秒后查版本清单，isForce=true 且版本更高时弹出不可取消的更新框

v4.9.14：修复设置菜单点错页面；v4.9.13：自定义 UA 源改用 ExoPlayer。
