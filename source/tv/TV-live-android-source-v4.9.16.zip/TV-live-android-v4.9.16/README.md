TV直播 电视版（Android TV）源码  v4.9.16  versionCode 504
=====================================================

包名 tv.live，minSdk 21 / targetSdk 28，Kotlin + Gradle。
Android Studio 打开，或 ./gradlew assembleRelease（需 JDK 17，首次需联网拉 ExoPlayer）。

v4.9.16：
- 手机配源页支持粘贴：输入框允许长按选择/粘贴，新增「从剪贴板粘贴地址」按钮，
  粘贴整段分享文本时自动抠出 http(s) 链接
- 多源切换卡顿优化：缓存解析结果按文件时间戳复用，合并放后台线程，
  频道没被移除时不重播

v4.9.15：多源同开 + 启动强制更新；v4.9.14：设置菜单修复；v4.9.13：UA 源改 ExoPlayer。
