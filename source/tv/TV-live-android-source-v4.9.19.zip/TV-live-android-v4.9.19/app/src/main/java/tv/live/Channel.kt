package tv.live

data class Channel(
    val name: String,
    val group: String = "未分组",
    val urls: MutableList<String> = mutableListOf()
) {
    /** 全局连续频道编号，构建列表时统一赋值 */
    var number: Int = 0
    /** 每条线路来自哪个订阅源，与 urls 一一对应（决定拉取/播放用哪个 UA） */
    val sourceIds: MutableList<String> = mutableListOf()
    /** 每条线路实际使用的 UA（与 urls 一一对应，空串表示用默认 UA），合并时就定死，播放时不再反查 */
    val uaList: MutableList<String> = mutableListOf()
}
