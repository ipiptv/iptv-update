package tv.live

import android.content.Context
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.InputStream
import java.io.OutputStream
import java.net.ServerSocket
import java.net.Socket
import java.net.URLDecoder

/**
 * 局域网配置服务：电视上开一个极简 HTTP 服务，
 * 手机扫码打开网页即可添加订阅源 / 直接上传新版安装包。
 */
class ConfigServer(
    private val context: Context,
    private val port: Int = 8888,
    private val onSourceUpdated: (name: String, url: String, ua: String, setCurrent: Boolean) -> Unit,
    /** 手机端点了“立即检查更新”：让电视马上去下载安装 */
    private val onUpdateNow: () -> Unit = {},
    /** 手机把 APK 直接传到电视上：参数为落地的本地文件 */
    private val onApkUploaded: (File) -> Unit = {}
) {

    private var serverSocket: ServerSocket? = null
    private var thread: Thread? = null

    @Volatile
    private var running = false

    fun start() {
        if (running) return
        running = true
        thread = Thread {
            try {
                val ss = ServerSocket(port)
                serverSocket = ss
                while (running) {
                    val client = try {
                        ss.accept()
                    } catch (e: Exception) {
                        break
                    }
                    try {
                        handle(client)
                    } catch (e: Exception) {
                        // 单个请求异常不影响服务
                    } finally {
                        try { client.close() } catch (e: Exception) { }
                    }
                }
            } catch (e: Exception) {
                // 端口占用等
            }
        }.also { it.isDaemon = true; it.start() }
    }

    fun stop() {
        running = false
        try { serverSocket?.close() } catch (e: Exception) { }
        serverSocket = null
        thread?.interrupt()
        thread = null
    }

    private fun sourceListText(): String {
        val list = SourceStore.load(context)
        val cur = SourceStore.currentId(context)
        return list.joinToString("") { s ->
            val mark = if (s.id == cur) "● " else "○ "
            "<div class='cur'>$mark<b>${escape(s.name)}</b> · ${escape(s.url)}</div>"
        }
    }

    private fun currentUpdateUrl(): String =
        context.getSharedPreferences("tv", Context.MODE_PRIVATE).getString("update_url", "") ?: ""

    private fun escape(t: String): String = t
        .replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    private fun handle(client: Socket) {
        val input = client.getInputStream()

        // 按字节读请求头，避免二进制 body 被字符流吞掉
        val headBuf = ByteArrayOutputStream()
        var last4 = 0
        var b = input.read()
        while (b >= 0 && headBuf.size() < 16 * 1024) {
            headBuf.write(b)
            last4 = (last4 shl 8) or (b and 0xFF)
            if (last4 == 0x0D0A0D0A) break // \r\n\r\n
            b = input.read()
        }
        val head = String(headBuf.toByteArray(), Charsets.ISO_8859_1)
        val lines = head.split("\r\n")
        if (lines.isEmpty()) return
        val parts = lines[0].split(" ")
        if (parts.size < 2) return
        val method = parts[0]
        val path = parts[1]

        var contentLength = 0
        var contentType = ""
        lines.drop(1).forEach { l ->
            val lower = l.lowercase()
            if (lower.startsWith("content-length:")) contentLength = l.substringAfter(":").trim().toIntOrNull() ?: 0
            if (lower.startsWith("content-type:")) contentType = l.substringAfter(":").trim()
        }

        val body: ByteArray = if (method == "POST" && contentLength > 0) {
            readFully(input, contentLength)
        } else ByteArray(0)

        val out = client.getOutputStream()

        when {
            method == "POST" && path.startsWith("/save") && !path.startsWith("/saveUpdate") -> {
                val bodyText = String(body, Charsets.UTF_8)
                val url = parseField(bodyText, "url")
                val name = parseField(bodyText, "name")?.takeIf { it.isNotBlank() } ?: "我的源"
                val ua = parseField(bodyText, "ua")?.trim().orEmpty()
                val setCurrent = bodyText.contains("current=on") || bodyText.contains("current=1")
                if (url.isNullOrBlank() || !url.startsWith("http")) {
                    writeHtml(out, page("保存失败", "地址无效，请填写以 http 开头的 m3u 链接", tab = "source"))
                } else {
                    onSourceUpdated(name, url, ua, setCurrent)
                    writeHtml(out, page("已添加：${escape(name)}", "已加入订阅源列表，下面能看到它。", tab = "source"))
                }
            }
            method == "POST" && path.startsWith("/saveUpdate") -> {
                val bodyText = String(body, Charsets.UTF_8)
                val apk = parseField(bodyText, "apkurl")
                if (apk.isNullOrBlank() || !apk.startsWith("http")) {
                    writeHtml(out, page("保存失败", "安装包地址无效，请填写以 http 开头的直链", updateUrl = apk ?: "", tab = "update"))
                } else {
                    context.getSharedPreferences("tv", Context.MODE_PRIVATE)
                        .edit().putString("update_url", apk.trim()).apply()
                    val trigger = bodyText.contains("now=on") || bodyText.contains("now=1")
                    if (trigger) {
                        onUpdateNow()
                        writeHtml(out, page("已开始更新", "电视正在下载新版本，稍后会弹出安装确认，请在电视上点「安装」", updateUrl = apk.trim(), tab = "update"))
                    } else {
                        writeHtml(out, page("已保存", "安装包地址已保存，可在电视「设置 → 关于 → 检查更新」里直接下载安装", updateUrl = apk.trim(), tab = "update"))
                    }
                }
            }
            method == "POST" && path.startsWith("/uploadApk") -> {
                val boundary = contentType.substringAfter("boundary=", "").trim().trim('"')
                val picked = if (contentType.contains("multipart/form-data") && boundary.isNotEmpty())
                    extractFilePart(body, boundary) else null
                if (picked == null) {
                    writeHtml(out, page("上传失败", "没有收到安装包，请重新选择文件再上传", updateUrl = currentUpdateUrl(), tab = "update"))
                } else {
                    val (fileName, bytes) = picked
                    if (bytes.size <= 0) {
                        writeHtml(out, page("上传失败", "文件为空，请重新选择", updateUrl = currentUpdateUrl(), tab = "update"))
                    } else {
                        val safe = fileName.substringAfterLast('/').substringAfterLast('\\')
                            .replace(Regex("[^0-9A-Za-z._\\u4e00-\\u9fa5-]"), "_")
                        val target = File(context.cacheDir, if (safe.lowercase().endsWith(".apk")) safe else "upload.apk")
                        target.writeBytes(bytes)
                        onApkUploaded(target)
                        writeHtml(out, page(
                            "已收到安装包",
                            "已收到 ${escape(target.name)}（${bytes.size / 1024} KB），正在打开安装器，请在电视上点「安装」",
                            updateUrl = currentUpdateUrl()
                        ))
                    }
                }
            }
            else -> writeHtml(out, page("", "", updateUrl = currentUpdateUrl(), tab = if (path.contains("tab=update")) "update" else "source"))
        }
    }

    /** 严格读满 contentLength 字节（二进制安全） */
    private fun readFully(input: InputStream, length: Int): ByteArray {
        val buf = ByteArray(length)
        var total = 0
        while (total < length) {
            val n = input.read(buf, total, length - total)
            if (n <= 0) break
            total += n
        }
        return if (total == length) buf else buf.copyOf(total)
    }

    /** 从 multipart body 里取出文件字段：返回（文件名，文件字节） */
    private fun extractFilePart(body: ByteArray, boundary: String): Pair<String, ByteArray>? {
        val fnMark = "filename=\"".toByteArray(Charsets.ISO_8859_1)
        val fnIdx = indexOf(body, fnMark) ?: return null
        val nameStart = fnIdx + fnMark.size
        var nameEnd = nameStart
        while (nameEnd < body.size && body[nameEnd] != '"'.code.toByte()) nameEnd++
        val fileName = String(body, nameStart, nameEnd - nameStart, Charsets.UTF_8)

        val dataStart = (indexOf(body, "\r\n\r\n".toByteArray(Charsets.ISO_8859_1), fnIdx) ?: return null) + 4
        val endMark = "\r\n--$boundary".toByteArray(Charsets.ISO_8859_1)
        val dataEnd = indexOf(body, endMark, dataStart) ?: body.size
        if (dataEnd <= dataStart) return null
        val data = body.copyOfRange(dataStart, dataEnd)
        return Pair(fileName, data)
    }

    private fun indexOf(hay: ByteArray, needle: ByteArray, from: Int = 0): Int? {
        if (needle.isEmpty() || hay.size < needle.size) return null
        var i = from.coerceAtLeast(0)
        while (i <= hay.size - needle.size) {
            var j = 0
            while (j < needle.size && hay[i + j] == needle[j]) j++
            if (j == needle.size) return i
            i++
        }
        return null
    }

    private fun parseField(body: String, key: String): String? {
        val pair = body.split("&").firstOrNull { it.startsWith("$key=") } ?: return null
        return try {
            URLDecoder.decode(pair.substringAfter("$key="), "UTF-8").trim()
        } catch (e: Exception) {
            null
        }
    }

    private fun writeHtml(out: OutputStream, html: String) {
        val bytes = html.toByteArray(Charsets.UTF_8)
        val header = "HTTP/1.1 200 OK\r\n" +
            "Content-Type: text/html; charset=utf-8\r\n" +
            "Content-Length: ${bytes.size}\r\n" +
            "Connection: close\r\n\r\n"
        out.write(header.toByteArray(Charsets.UTF_8))
        out.write(bytes)
        out.flush()
    }

    private fun page(title: String, message: String, updateUrl: String = "", tab: String = "source"): String {
        val banner = if (message.isEmpty()) "" else
            """<div class="msg"><b>${escape(title)}</b><span>$message</span></div>"""
        val onSource = if (tab == "update") "" else " on"
        val onUpdate = if (tab == "update") " on" else ""
        val listBody = sourceListText().ifBlank { """<div class="hint">还没有其它源</div>""" }
        return """<!DOCTYPE html>
<html lang="zh">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<title>TV 订阅源</title>
<style>
*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;}
body{margin:0;padding:16px 16px 108px;background:#0b0d10;color:#e8eaed;
     font:15px/1.5 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,"PingFang SC","Microsoft YaHei",sans-serif;
     -webkit-text-size-adjust:100%;}
h1{font-size:19px;margin:2px 0 4px;font-weight:600;}
.sub{color:#9aa0a6;font-size:13px;margin-bottom:14px;}
.tabs{display:flex;gap:6px;background:#14181f;border:1px solid #242932;border-radius:12px;padding:5px;margin-bottom:14px;}
.tabs a{flex:1;text-align:center;padding:10px 0;border-radius:8px;color:#9aa0a6;text-decoration:none;font-size:14px;}
.tabs a.on{background:#1f6feb;color:#fff;}
.card{background:#14181f;border:1px solid #242932;border-radius:14px;padding:16px;margin-bottom:14px;}
.card h2{font-size:15px;margin:0 0 4px;font-weight:600;}
label{display:block;font-size:12px;color:#9aa0a6;margin:14px 0 6px;}
input[type=text],input[type=file]{display:block;width:100%;padding:13px;border-radius:10px;border:1px solid #242932;
     background:#0f1318;color:#fff;font-size:16px;outline:none;}
input[type=text]:focus{border-color:#1f6feb;}
input[type=text]::placeholder{color:#5c636b;}
/* 手机端要能长按选择、粘贴：明确放开选中与长按菜单 */
input,textarea,select{-webkit-user-select:text;user-select:text;-webkit-touch-callout:default;}
body{-webkit-user-select:text;user-select:text;}
.paste{margin-top:8px;padding:10px 14px;border-radius:10px;border:1px solid #2a3240;background:#191f27;
   color:#cfd6de;font-size:14px;}
.sw{display:flex;align-items:center;justify-content:space-between;margin-top:16px;padding:12px 14px;
    background:#0f1318;border:1px solid #242932;border-radius:10px;}
.sw span{font-size:14px;}
.sw input{width:22px;height:22px;}
.msg{display:flex;flex-direction:column;gap:3px;background:#0d2a17;border:1px solid #1f6f4a;border-radius:12px;
     padding:12px 14px;margin-bottom:14px;font-size:13px;color:#8fe0ab;}
.msg b{font-size:14px;color:#b7f5cf;}
.src{display:flex;align-items:flex-start;gap:10px;padding:12px 14px;border:1px solid #242932;
     border-radius:10px;margin-top:10px;background:#0f1318;}
.src .nm{font-size:14px;font-weight:600;margin-bottom:3px;}
.src .u{font-size:12px;color:#9aa0a6;word-break:break-all;display:-webkit-box;-webkit-line-clamp:2;
     -webkit-box-orient:vertical;overflow:hidden;}
.badge{flex:0 0 auto;font-size:11px;padding:3px 8px;border-radius:999px;background:#12240f;color:#7ee2a8;border:1px solid #2ea04355;}
.submit{position:fixed;left:16px;right:16px;bottom:calc(16px + env(safe-area-inset-bottom));padding:15px;
     border:0;border-radius:12px;background:#1f6feb;color:#fff;font-size:16px;font-weight:600;}
.hint{font-size:12px;color:#7c8288;margin-top:10px;line-height:1.6;}
details summary{font-size:13px;color:#9aa0a6;cursor:pointer;padding:8px 0;}
</style>
</head>
<body>
  <h1>TV 订阅源</h1>
  <div class="sub">手机与电视连同一个 WiFi，改完立刻生效</div>
  <div class="tabs">
    <a class="tab$onSource" href="/">订阅源</a>
    <a class="tab$onUpdate" href="/?tab=update">安装更新</a>
  </div>
  $banner
  ${if (tab == "update") """<form method="post" action="/uploadApk" enctype="multipart/form-data">
    <div class="card">
      <h2>上传安装包</h2>
      <label>选择 APK 文件</label>
      <input type="file" name="apk" accept=".apk">
      <div class="hint">上传后电视会弹出系统安装确认，用遥控器点「安装」即可覆盖。</div>
    </div>
    <button class="submit" type="submit">上传到电视并安装</button>
  </form>
  <div class="card">
    <details>
      <summary>或者：填安装包直链地址</summary>
      <form method="post" action="/saveUpdate">
        <label>新版安装包地址（.apk 直链）</label>
        <input type="text" name="apkurl" inputmode="url" autocapitalize="off" autocorrect="off" spellcheck="false"
               autocomplete="off" value="${escape(updateUrl)}" placeholder="https://example.com/TV-latest.apk">
        <button type="button" class="paste" onclick="pasteInto(this)">从剪贴板粘贴地址</button>
        <div class="sw"><span>保存后立即下载安装</span><input type="checkbox" name="now" checked></div>
        <button class="submit" type="submit">保存并检查更新</button>
      </form>
    </details>
  </div>""" else """<form method="post" action="/save">
    <div class="card">
      <h2>添加订阅源</h2>
      <label>源名称（可留空）</label>
      <input type="text" name="name" inputmode="text" autocapitalize="off" autocorrect="off" spellcheck="false"
             placeholder="例如：我的源">
      <label>订阅源地址（m3u / m3u8 列表）</label>
      <input type="text" name="url" inputmode="url" autocapitalize="off" autocorrect="off" spellcheck="false"
             autocomplete="off" placeholder="https://example.com/list.m3u">
      <button type="button" class="paste" onclick="pasteInto(this)">从剪贴板粘贴地址</button>
      <label>UA（可留空，留空用默认）</label>
      <input type="text" name="ua" inputmode="text" autocapitalize="off" autocorrect="off" spellcheck="false"
             placeholder="默认：${SourceStore.DEFAULT_UA}">
      <div class="sw"><span>立即切换使用这个源</span><input type="checkbox" name="current" checked></div>
    </div>
    <button class="submit" type="submit">添加到电视</button>
  </form>
  <div class="card">
    <h2>电视上已有的源</h2>
    $listBody
  </div>"""}
<script>
// 粘贴增强：点输入框自动全选，长按粘贴直接覆盖；从分享文本里自动抠出链接
function pasteInto(btn){
  var el = btn.parentNode.querySelector('input[type=text]');
  if(!el) return;
  var put = function(t){
    if(!t) return;
    var m = t.match(/https?:\/\/[^\s'"<>]+/);
    el.value = m ? m[0].trim() : t.trim();
    el.focus();
  };
  if(navigator.clipboard && navigator.clipboard.readText){
    navigator.clipboard.readText().then(put).catch(function(){
      el.focus(); el.select();
      alert('浏览器不允许直接读剪贴板：长按输入框，选择「粘贴」即可');
    });
  } else {
    el.focus(); el.select();
    alert('长按输入框，选择「粘贴」即可');
  }
}
(function(){
  var ins = document.querySelectorAll('input[type=text]');
  for(var i=0;i<ins.length;i++){
    (function(el){
      el.addEventListener('focus', function(){ try{ el.select(); }catch(e){} });
      el.addEventListener('paste', function(ev){
        var t = '';
        try{
          t = (ev.clipboardData || window.clipboardData).getData('text') || '';
        }catch(e){}
        if(!t) return;
        var m = t.match(/https?:\/\/[^\s'"<>]+/);
        if(m){ ev.preventDefault(); el.value = m[0].trim(); }
      });
    })(ins[i]);
  }
})();
</script>
</body>
</html>"""
    }
}
