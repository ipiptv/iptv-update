package a;

import java.lang.reflect.Array;
import java.util.Set;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public e f0a;

    /* renamed from: b, reason: collision with root package name */
    public e f1b;

    /* renamed from: c, reason: collision with root package name */
    public g f2c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ b f3d;

    public a(b bVar) {
        this.f3d = bVar;
    }

    public static boolean c(Set set, Object obj) {
        if (set == obj) {
            return true;
        }
        if (obj instanceof Set) {
            Set set2 = (Set) obj;
            try {
                if (set.size() == set2.size()) {
                    if (set.containsAll(set2)) {
                        return true;
                    }
                }
                return false;
            } catch (ClassCastException | NullPointerException unused) {
            }
        }
        return false;
    }

    public final Object a(int i2, int i3) {
        return this.f3d.f27b[(i2 << 1) + i3];
    }

    public final void b(int i2) {
        this.f3d.h(i2);
    }

    public final Object[] d(Object[] objArr, int i2) {
        int i3 = this.f3d.f28c;
        if (objArr.length < i3) {
            objArr = (Object[]) Array.newInstance(objArr.getClass().getComponentType(), i3);
        }
        for (int i4 = 0; i4 < i3; i4++) {
            objArr[i4] = a(i4, i2);
        }
        if (objArr.length > i3) {
            objArr[i3] = null;
        }
        return objArr;
    }
}
