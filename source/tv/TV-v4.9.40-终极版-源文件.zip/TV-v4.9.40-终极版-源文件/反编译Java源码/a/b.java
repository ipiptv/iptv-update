package a;

import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Map;
import java.util.Set;

/* loaded from: classes.dex */
public final class b extends h implements Map {

    /* renamed from: h, reason: collision with root package name */
    public a f4h;

    @Override // java.util.Map
    public final Set entrySet() {
        if (this.f4h == null) {
            this.f4h = new a(this);
        }
        a aVar = this.f4h;
        if (aVar.f0a == null) {
            aVar.f0a = new e(aVar, 0);
        }
        return aVar.f0a;
    }

    @Override // java.util.Map
    public final Set keySet() {
        if (this.f4h == null) {
            this.f4h = new a(this);
        }
        a aVar = this.f4h;
        if (aVar.f1b == null) {
            aVar.f1b = new e(aVar, 1);
        }
        return aVar.f1b;
    }

    @Override // java.util.Map
    public final void putAll(Map map) {
        int size = map.size() + this.f28c;
        int i2 = this.f28c;
        int[] iArr = this.f26a;
        if (iArr.length < size) {
            Object[] objArr = this.f27b;
            a(size);
            if (this.f28c > 0) {
                System.arraycopy(iArr, 0, this.f26a, 0, i2);
                System.arraycopy(objArr, 0, this.f27b, 0, i2 << 1);
            }
            h.c(iArr, objArr, i2);
        }
        if (this.f28c != i2) {
            throw new ConcurrentModificationException();
        }
        for (Map.Entry entry : map.entrySet()) {
            put(entry.getKey(), entry.getValue());
        }
    }

    @Override // java.util.Map
    public final Collection values() {
        if (this.f4h == null) {
            this.f4h = new a(this);
        }
        a aVar = this.f4h;
        if (aVar.f2c == null) {
            aVar.f2c = new g(aVar);
        }
        return aVar.f2c;
    }
}
