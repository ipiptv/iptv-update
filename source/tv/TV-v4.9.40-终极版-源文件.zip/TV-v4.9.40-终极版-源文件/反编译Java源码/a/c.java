package a;

/* loaded from: classes.dex */
public final class c implements Cloneable {

    /* renamed from: e, reason: collision with root package name */
    public static final Object f5e = new Object();

    /* renamed from: a, reason: collision with root package name */
    public boolean f6a = false;

    /* renamed from: b, reason: collision with root package name */
    public long[] f7b;

    /* renamed from: c, reason: collision with root package name */
    public Object[] f8c;

    /* renamed from: d, reason: collision with root package name */
    public int f9d;

    public c() {
        int i2;
        int i3 = 4;
        while (true) {
            i2 = 80;
            if (i3 >= 32) {
                break;
            }
            int i4 = (1 << i3) - 12;
            if (80 <= i4) {
                i2 = i4;
                break;
            }
            i3++;
        }
        int i5 = i2 / 8;
        this.f7b = new long[i5];
        this.f8c = new Object[i5];
        this.f9d = 0;
    }

    public final void a() {
        int i2 = this.f9d;
        long[] jArr = this.f7b;
        Object[] objArr = this.f8c;
        int i3 = 0;
        for (int i4 = 0; i4 < i2; i4++) {
            Object obj = objArr[i4];
            if (obj != f5e) {
                if (i4 != i3) {
                    jArr[i3] = jArr[i4];
                    objArr[i3] = obj;
                    objArr[i4] = null;
                }
                i3++;
            }
        }
        this.f6a = false;
        this.f9d = i3;
    }

    public final Object clone() {
        try {
            c cVar = (c) super.clone();
            cVar.f7b = (long[]) this.f7b.clone();
            cVar.f8c = (Object[]) this.f8c.clone();
            return cVar;
        } catch (CloneNotSupportedException e2) {
            throw new AssertionError(e2);
        }
    }

    public final String toString() {
        if (this.f6a) {
            a();
        }
        int i2 = this.f9d;
        if (i2 <= 0) {
            return "{}";
        }
        StringBuilder sb = new StringBuilder(i2 * 28);
        sb.append('{');
        for (int i3 = 0; i3 < this.f9d; i3++) {
            if (i3 > 0) {
                sb.append(", ");
            }
            if (this.f6a) {
                a();
            }
            sb.append(this.f7b[i3]);
            sb.append('=');
            if (this.f6a) {
                a();
            }
            Object obj = this.f8c[i3];
            if (obj != this) {
                sb.append(obj);
            } else {
                sb.append("(this Map)");
            }
        }
        sb.append('}');
        return sb.toString();
    }
}
