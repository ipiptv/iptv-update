package a;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public final class d implements Iterator {

    /* renamed from: a, reason: collision with root package name */
    public final int f10a;

    /* renamed from: b, reason: collision with root package name */
    public int f11b;

    /* renamed from: c, reason: collision with root package name */
    public int f12c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f13d = false;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ a f14e;

    public d(a aVar, int i2) {
        this.f14e = aVar;
        this.f10a = i2;
        this.f11b = aVar.f3d.f28c;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f12c < this.f11b;
    }

    @Override // java.util.Iterator
    public final Object next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        Object a2 = this.f14e.a(this.f12c, this.f10a);
        this.f12c++;
        this.f13d = true;
        return a2;
    }

    @Override // java.util.Iterator
    public final void remove() {
        if (!this.f13d) {
            throw new IllegalStateException();
        }
        int i2 = this.f12c - 1;
        this.f12c = i2;
        this.f11b--;
        this.f13d = false;
        this.f14e.b(i2);
    }
}
