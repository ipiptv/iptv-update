package a;

import java.util.Collection;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

/* loaded from: classes.dex */
public final class e implements Set {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f15a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ a f16b;

    public /* synthetic */ e(a aVar, int i2) {
        this.f15a = i2;
        this.f16b = aVar;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean add(Object obj) {
        switch (this.f15a) {
            case 0:
                throw new UnsupportedOperationException();
            default:
                throw new UnsupportedOperationException();
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean addAll(Collection collection) {
        switch (this.f15a) {
            case 0:
                a aVar = this.f16b;
                int i2 = aVar.f3d.f28c;
                Iterator it = collection.iterator();
                while (true) {
                    boolean hasNext = it.hasNext();
                    b bVar = aVar.f3d;
                    if (!hasNext) {
                        return i2 != bVar.f28c;
                    }
                    Map.Entry entry = (Map.Entry) it.next();
                    bVar.put(entry.getKey(), entry.getValue());
                }
            default:
                throw new UnsupportedOperationException();
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final void clear() {
        int i2 = this.f15a;
        a aVar = this.f16b;
        switch (i2) {
            case 0:
                aVar.f3d.clear();
                break;
            default:
                aVar.f3d.clear();
                break;
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean contains(Object obj) {
        int i2 = this.f15a;
        boolean z2 = true;
        a aVar = this.f16b;
        switch (i2) {
            case 0:
                if (!(obj instanceof Map.Entry)) {
                    return false;
                }
                Map.Entry entry = (Map.Entry) obj;
                int e2 = aVar.f3d.e(entry.getKey());
                if (e2 < 0) {
                    return false;
                }
                Object a2 = aVar.a(e2, 1);
                Object value = entry.getValue();
                if (a2 != value && (a2 == null || !a2.equals(value))) {
                    z2 = false;
                }
                return z2;
            default:
                return aVar.f3d.e(obj) >= 0;
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean containsAll(Collection collection) {
        switch (this.f15a) {
            case 0:
                Iterator it = collection.iterator();
                while (it.hasNext()) {
                    if (!contains(it.next())) {
                        break;
                    }
                }
                break;
            default:
                b bVar = this.f16b.f3d;
                Iterator it2 = collection.iterator();
                while (it2.hasNext()) {
                    if (!bVar.containsKey(it2.next())) {
                        break;
                    }
                }
                break;
        }
        return true;
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean equals(Object obj) {
        switch (this.f15a) {
        }
        return a.c(this, obj);
    }

    @Override // java.util.Set, java.util.Collection
    public final int hashCode() {
        int i2 = this.f15a;
        a aVar = this.f16b;
        switch (i2) {
            case 0:
                int i3 = 0;
                for (int i4 = aVar.f3d.f28c - 1; i4 >= 0; i4--) {
                    Object a2 = aVar.a(i4, 0);
                    Object a3 = aVar.a(i4, 1);
                    i3 += (a2 == null ? 0 : a2.hashCode()) ^ (a3 == null ? 0 : a3.hashCode());
                }
                return i3;
            default:
                int i5 = 0;
                for (int i6 = aVar.f3d.f28c - 1; i6 >= 0; i6--) {
                    Object a4 = aVar.a(i6, 0);
                    i5 += a4 == null ? 0 : a4.hashCode();
                }
                return i5;
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean isEmpty() {
        int i2 = this.f15a;
        a aVar = this.f16b;
        switch (i2) {
            case 0:
                if (aVar.f3d.f28c == 0) {
                }
                break;
            default:
                if (aVar.f3d.f28c == 0) {
                }
                break;
        }
        return false;
    }

    @Override // java.util.Set, java.util.Collection, java.lang.Iterable
    public final Iterator iterator() {
        int i2 = this.f15a;
        a aVar = this.f16b;
        switch (i2) {
            case 0:
                return new f(aVar);
            default:
                return new d(aVar, 0);
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean remove(Object obj) {
        switch (this.f15a) {
            case 0:
                throw new UnsupportedOperationException();
            default:
                a aVar = this.f16b;
                int e2 = aVar.f3d.e(obj);
                if (e2 < 0) {
                    return false;
                }
                aVar.b(e2);
                return true;
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean removeAll(Collection collection) {
        switch (this.f15a) {
            case 0:
                throw new UnsupportedOperationException();
            default:
                b bVar = this.f16b.f3d;
                int i2 = bVar.f28c;
                Iterator it = collection.iterator();
                while (it.hasNext()) {
                    bVar.remove(it.next());
                }
                return i2 != bVar.f28c;
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final boolean retainAll(Collection collection) {
        switch (this.f15a) {
            case 0:
                throw new UnsupportedOperationException();
            default:
                b bVar = this.f16b.f3d;
                int i2 = bVar.f28c;
                Iterator it = ((e) bVar.keySet()).iterator();
                while (it.hasNext()) {
                    if (!collection.contains(it.next())) {
                        it.remove();
                    }
                }
                return i2 != bVar.f28c;
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final int size() {
        int i2 = this.f15a;
        a aVar = this.f16b;
        switch (i2) {
        }
        return aVar.f3d.f28c;
    }

    @Override // java.util.Set, java.util.Collection
    public final Object[] toArray() {
        switch (this.f15a) {
            case 0:
                throw new UnsupportedOperationException();
            default:
                a aVar = this.f16b;
                int i2 = aVar.f3d.f28c;
                Object[] objArr = new Object[i2];
                for (int i3 = 0; i3 < i2; i3++) {
                    objArr[i3] = aVar.a(i3, 0);
                }
                return objArr;
        }
    }

    @Override // java.util.Set, java.util.Collection
    public final Object[] toArray(Object[] objArr) {
        switch (this.f15a) {
            case 0:
                throw new UnsupportedOperationException();
            default:
                return this.f16b.d(objArr, 0);
        }
    }
}
