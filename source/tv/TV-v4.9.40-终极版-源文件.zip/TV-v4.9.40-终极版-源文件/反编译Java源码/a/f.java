package a;

import java.util.Iterator;
import java.util.Map;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public final class f implements Iterator, Map.Entry {

    /* renamed from: a, reason: collision with root package name */
    public int f17a;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ a f20d;

    /* renamed from: c, reason: collision with root package name */
    public boolean f19c = false;

    /* renamed from: b, reason: collision with root package name */
    public int f18b = -1;

    public f(a aVar) {
        this.f20d = aVar;
        this.f17a = aVar.f3d.f28c - 1;
    }

    @Override // java.util.Map.Entry
    public final boolean equals(Object obj) {
        if (!this.f19c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        if (!(obj instanceof Map.Entry)) {
            return false;
        }
        Map.Entry entry = (Map.Entry) obj;
        Object key = entry.getKey();
        int i2 = this.f18b;
        a aVar = this.f20d;
        Object a2 = aVar.a(i2, 0);
        if (!(key == a2 || (key != null && key.equals(a2)))) {
            return false;
        }
        Object value = entry.getValue();
        Object a3 = aVar.a(this.f18b, 1);
        return value == a3 || (value != null && value.equals(a3));
    }

    @Override // java.util.Map.Entry
    public final Object getKey() {
        if (!this.f19c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        return this.f20d.a(this.f18b, 0);
    }

    @Override // java.util.Map.Entry
    public final Object getValue() {
        if (!this.f19c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        return this.f20d.a(this.f18b, 1);
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        return this.f18b < this.f17a;
    }

    @Override // java.util.Map.Entry
    public final int hashCode() {
        if (!this.f19c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        int i2 = this.f18b;
        a aVar = this.f20d;
        Object a2 = aVar.a(i2, 0);
        Object a3 = aVar.a(this.f18b, 1);
        return (a2 == null ? 0 : a2.hashCode()) ^ (a3 != null ? a3.hashCode() : 0);
    }

    @Override // java.util.Iterator
    public final Object next() {
        if (!hasNext()) {
            throw new NoSuchElementException();
        }
        this.f18b++;
        this.f19c = true;
        return this;
    }

    @Override // java.util.Iterator
    public final void remove() {
        if (!this.f19c) {
            throw new IllegalStateException();
        }
        this.f20d.b(this.f18b);
        this.f18b--;
        this.f17a--;
        this.f19c = false;
    }

    @Override // java.util.Map.Entry
    public final Object setValue(Object obj) {
        if (!this.f19c) {
            throw new IllegalStateException("This container does not support retaining Map.Entry objects");
        }
        int i2 = (this.f18b << 1) + 1;
        Object[] objArr = this.f20d.f3d.f27b;
        Object obj2 = objArr[i2];
        objArr[i2] = obj;
        return obj2;
    }

    public final String toString() {
        return getKey() + "=" + getValue();
    }
}
