package androidx.core.app;

import android.app.PendingIntent;
import android.os.Parcel;
import android.text.TextUtils;
import androidx.core.graphics.drawable.IconCompat;
import m.a;
import m.b;
import m.c;

/* loaded from: classes.dex */
public class RemoteActionCompatParcelizer {
    public static RemoteActionCompat read(a aVar) {
        RemoteActionCompat remoteActionCompat = new RemoteActionCompat();
        c cVar = remoteActionCompat.f30a;
        if (aVar.e(1)) {
            cVar = aVar.h();
        }
        remoteActionCompat.f30a = (IconCompat) cVar;
        CharSequence charSequence = remoteActionCompat.f31b;
        if (aVar.e(2)) {
            charSequence = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((b) aVar).f499e);
        }
        remoteActionCompat.f31b = charSequence;
        CharSequence charSequence2 = remoteActionCompat.f32c;
        if (aVar.e(3)) {
            charSequence2 = (CharSequence) TextUtils.CHAR_SEQUENCE_CREATOR.createFromParcel(((b) aVar).f499e);
        }
        remoteActionCompat.f32c = charSequence2;
        remoteActionCompat.f33d = (PendingIntent) aVar.g(remoteActionCompat.f33d, 4);
        boolean z2 = remoteActionCompat.f34e;
        if (aVar.e(5)) {
            z2 = ((b) aVar).f499e.readInt() != 0;
        }
        remoteActionCompat.f34e = z2;
        boolean z3 = remoteActionCompat.f35f;
        if (aVar.e(6)) {
            z3 = ((b) aVar).f499e.readInt() != 0;
        }
        remoteActionCompat.f35f = z3;
        return remoteActionCompat;
    }

    public static void write(RemoteActionCompat remoteActionCompat, a aVar) {
        aVar.getClass();
        IconCompat iconCompat = remoteActionCompat.f30a;
        aVar.i(1);
        aVar.j(iconCompat);
        CharSequence charSequence = remoteActionCompat.f31b;
        aVar.i(2);
        Parcel parcel = ((b) aVar).f499e;
        TextUtils.writeToParcel(charSequence, parcel, 0);
        CharSequence charSequence2 = remoteActionCompat.f32c;
        aVar.i(3);
        TextUtils.writeToParcel(charSequence2, parcel, 0);
        PendingIntent pendingIntent = remoteActionCompat.f33d;
        aVar.i(4);
        parcel.writeParcelable(pendingIntent, 0);
        boolean z2 = remoteActionCompat.f34e;
        aVar.i(5);
        parcel.writeInt(z2 ? 1 : 0);
        boolean z3 = remoteActionCompat.f35f;
        aVar.i(6);
        parcel.writeInt(z3 ? 1 : 0);
    }
}
