package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcelable;
import androidx.versionedparcelable.CustomVersionedParcelable;

/* loaded from: classes.dex */
public class IconCompat extends CustomVersionedParcelable {

    /* renamed from: k, reason: collision with root package name */
    public static final PorterDuff.Mode f41k = PorterDuff.Mode.SRC_IN;

    /* renamed from: b, reason: collision with root package name */
    public Object f43b;

    /* renamed from: j, reason: collision with root package name */
    public String f51j;

    /* renamed from: a, reason: collision with root package name */
    public int f42a = -1;

    /* renamed from: c, reason: collision with root package name */
    public byte[] f44c = null;

    /* renamed from: d, reason: collision with root package name */
    public Parcelable f45d = null;

    /* renamed from: e, reason: collision with root package name */
    public int f46e = 0;

    /* renamed from: f, reason: collision with root package name */
    public int f47f = 0;

    /* renamed from: g, reason: collision with root package name */
    public ColorStateList f48g = null;

    /* renamed from: h, reason: collision with root package name */
    public PorterDuff.Mode f49h = f41k;

    /* renamed from: i, reason: collision with root package name */
    public String f50i = null;

    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    /* JADX WARN: Removed duplicated region for block: B:37:0x00f5  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0105  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.String toString() {
        /*
            Method dump skipped, instructions count: 314
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.core.graphics.drawable.IconCompat.toString():java.lang.String");
    }
}
