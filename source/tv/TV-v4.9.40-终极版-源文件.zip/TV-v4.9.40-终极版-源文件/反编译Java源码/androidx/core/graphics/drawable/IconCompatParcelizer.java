package androidx.core.graphics.drawable;

import android.content.res.ColorStateList;
import android.graphics.PorterDuff;
import android.os.Parcel;
import android.os.Parcelable;
import java.nio.charset.Charset;
import m.a;
import m.b;
import tv.live.MainActivity;
import tv.live.ManageType;

/* loaded from: classes.dex */
public class IconCompatParcelizer {
    /* JADX WARN: Can't fix incorrect switch cases order, some code will duplicate */
    public static IconCompat read(a aVar) {
        Parcelable parcelable;
        IconCompat iconCompat = new IconCompat();
        iconCompat.f42a = aVar.f(iconCompat.f42a, 1);
        byte[] bArr = iconCompat.f44c;
        if (aVar.e(2)) {
            Parcel parcel = ((b) aVar).f499e;
            int readInt = parcel.readInt();
            if (readInt < 0) {
                bArr = null;
            } else {
                byte[] bArr2 = new byte[readInt];
                parcel.readByteArray(bArr2);
                bArr = bArr2;
            }
        }
        iconCompat.f44c = bArr;
        iconCompat.f45d = aVar.g(iconCompat.f45d, 3);
        iconCompat.f46e = aVar.f(iconCompat.f46e, 4);
        iconCompat.f47f = aVar.f(iconCompat.f47f, 5);
        iconCompat.f48g = (ColorStateList) aVar.g(iconCompat.f48g, 6);
        String str = iconCompat.f50i;
        if (aVar.e(7)) {
            str = ((b) aVar).f499e.readString();
        }
        iconCompat.f50i = str;
        String str2 = iconCompat.f51j;
        if (aVar.e(8)) {
            str2 = ((b) aVar).f499e.readString();
        }
        iconCompat.f51j = str2;
        iconCompat.f49h = PorterDuff.Mode.valueOf(iconCompat.f50i);
        switch (iconCompat.f42a) {
            case -1:
                parcelable = iconCompat.f45d;
                if (parcelable == null) {
                    throw new IllegalArgumentException("Invalid icon");
                }
                iconCompat.f43b = parcelable;
                return iconCompat;
            case 0:
            default:
                return iconCompat;
            case 1:
            case MainActivity.TIMEOUT_DEFAULT_SEC /* 5 */:
                parcelable = iconCompat.f45d;
                if (parcelable == null) {
                    byte[] bArr3 = iconCompat.f44c;
                    iconCompat.f43b = bArr3;
                    iconCompat.f42a = 3;
                    iconCompat.f46e = 0;
                    iconCompat.f47f = bArr3.length;
                    return iconCompat;
                }
                iconCompat.f43b = parcelable;
                return iconCompat;
            case ManageType.GROUP /* 2 */:
            case ManageType.INFO /* 4 */:
            case 6:
                String str3 = new String(iconCompat.f44c, Charset.forName("UTF-16"));
                iconCompat.f43b = str3;
                if (iconCompat.f42a == 2 && iconCompat.f51j == null) {
                    iconCompat.f51j = str3.split(":", -1)[0];
                }
                return iconCompat;
            case ManageType.NAV /* 3 */:
                iconCompat.f43b = iconCompat.f44c;
                return iconCompat;
        }
    }

    public static void write(IconCompat iconCompat, a aVar) {
        aVar.getClass();
        iconCompat.f50i = iconCompat.f49h.name();
        switch (iconCompat.f42a) {
            case -1:
            case 1:
            case MainActivity.TIMEOUT_DEFAULT_SEC /* 5 */:
                iconCompat.f45d = (Parcelable) iconCompat.f43b;
                break;
            case ManageType.GROUP /* 2 */:
                iconCompat.f44c = ((String) iconCompat.f43b).getBytes(Charset.forName("UTF-16"));
                break;
            case ManageType.NAV /* 3 */:
                iconCompat.f44c = (byte[]) iconCompat.f43b;
                break;
            case ManageType.INFO /* 4 */:
            case 6:
                iconCompat.f44c = iconCompat.f43b.toString().getBytes(Charset.forName("UTF-16"));
                break;
        }
        int i2 = iconCompat.f42a;
        if (-1 != i2) {
            aVar.i(1);
            ((b) aVar).f499e.writeInt(i2);
        }
        byte[] bArr = iconCompat.f44c;
        if (bArr != null) {
            aVar.i(2);
            int length = bArr.length;
            Parcel parcel = ((b) aVar).f499e;
            parcel.writeInt(length);
            parcel.writeByteArray(bArr);
        }
        Parcelable parcelable = iconCompat.f45d;
        if (parcelable != null) {
            aVar.i(3);
            ((b) aVar).f499e.writeParcelable(parcelable, 0);
        }
        int i3 = iconCompat.f46e;
        if (i3 != 0) {
            aVar.i(4);
            ((b) aVar).f499e.writeInt(i3);
        }
        int i4 = iconCompat.f47f;
        if (i4 != 0) {
            aVar.i(5);
            ((b) aVar).f499e.writeInt(i4);
        }
        ColorStateList colorStateList = iconCompat.f48g;
        if (colorStateList != null) {
            aVar.i(6);
            ((b) aVar).f499e.writeParcelable(colorStateList, 0);
        }
        String str = iconCompat.f50i;
        if (str != null) {
            aVar.i(7);
            ((b) aVar).f499e.writeString(str);
        }
        String str2 = iconCompat.f51j;
        if (str2 != null) {
            aVar.i(8);
            ((b) aVar).f499e.writeString(str2);
        }
    }
}
