package androidx.lifecycle;

/* loaded from: classes.dex */
class SingleGeneratedAdapterObserver {
}
