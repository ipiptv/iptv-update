package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseIntArray;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import java.lang.reflect.Field;

/* loaded from: classes.dex */
public class GridLayoutManager extends LinearLayoutManager {
    public boolean D;
    public int E;
    public int[] F;
    public View[] G;
    public final SparseIntArray H;
    public final SparseIntArray I;
    public final v J;
    public final Rect K;

    public GridLayoutManager(Context context, AttributeSet attributeSet, int i2, int i3) {
        super(context, attributeSet, i2, i3);
        this.D = false;
        this.E = -1;
        this.H = new SparseIntArray();
        this.I = new SparseIntArray();
        v vVar = new v();
        this.J = vVar;
        this.K = new Rect();
        int i4 = t0.D(context, attributeSet, i2, i3).f304b;
        if (i4 == this.E) {
            return;
        }
        this.D = true;
        if (i4 < 1) {
            throw new IllegalArgumentException("Span count should be at least 1. Provided " + i4);
        }
        this.E = i4;
        vVar.b();
        h0();
    }

    @Override // androidx.recyclerview.widget.t0
    public final int E(a1 a1Var, e1 e1Var) {
        if (this.f52o == 0) {
            return this.E;
        }
        if (e1Var.b() < 1) {
            return 0;
        }
        return Y0(e1Var.b() - 1, a1Var, e1Var) + 1;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final View F0(a1 a1Var, e1 e1Var, boolean z2, boolean z3) {
        int i2;
        int i3;
        int u2 = u();
        int i4 = 1;
        if (z3) {
            i3 = u() - 1;
            i2 = -1;
            i4 = -1;
        } else {
            i2 = u2;
            i3 = 0;
        }
        int b2 = e1Var.b();
        z0();
        int h2 = this.q.h();
        int f2 = this.q.f();
        View view = null;
        View view2 = null;
        while (i3 != i2) {
            View t2 = t(i3);
            int C = t0.C(t2);
            if (C >= 0 && C < b2 && Z0(C, a1Var, e1Var) == 0) {
                if (((u0) t2.getLayoutParams()).c()) {
                    if (view2 == null) {
                        view2 = t2;
                    }
                } else {
                    if (this.q.d(t2) < f2 && this.q.b(t2) >= h2) {
                        return t2;
                    }
                    if (view == null) {
                        view = t2;
                    }
                }
            }
            i3 += i4;
        }
        return view != null ? view : view2;
    }

    /* JADX WARN: Removed duplicated region for block: B:37:0x00ae  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x00b1  */
    @Override // androidx.recyclerview.widget.LinearLayoutManager
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void L0(androidx.recyclerview.widget.a1 r20, androidx.recyclerview.widget.e1 r21, androidx.recyclerview.widget.a0 r22, androidx.recyclerview.widget.z r23) {
        /*
            Method dump skipped, instructions count: 648
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.GridLayoutManager.L0(androidx.recyclerview.widget.a1, androidx.recyclerview.widget.e1, androidx.recyclerview.widget.a0, androidx.recyclerview.widget.z):void");
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void M0(a1 a1Var, e1 e1Var, y yVar, int i2) {
        c1();
        if (e1Var.b() > 0 && !e1Var.f159f) {
            boolean z2 = i2 == 1;
            int Z0 = Z0(yVar.f357b, a1Var, e1Var);
            if (z2) {
                while (Z0 > 0) {
                    int i3 = yVar.f357b;
                    if (i3 <= 0) {
                        break;
                    }
                    int i4 = i3 - 1;
                    yVar.f357b = i4;
                    Z0 = Z0(i4, a1Var, e1Var);
                }
            } else {
                int b2 = e1Var.b() - 1;
                int i5 = yVar.f357b;
                while (i5 < b2) {
                    int i6 = i5 + 1;
                    int Z02 = Z0(i6, a1Var, e1Var);
                    if (Z02 <= Z0) {
                        break;
                    }
                    i5 = i6;
                    Z0 = Z02;
                }
                yVar.f357b = i5;
            }
        }
        View[] viewArr = this.G;
        if (viewArr == null || viewArr.length != this.E) {
            this.G = new View[this.E];
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:69:0x00df, code lost:
    
        if (r13 == (r2 > r15)) goto L66;
     */
    /* JADX WARN: Code restructure failed: missing block: B:85:0x010e, code lost:
    
        if (r13 == (r2 > r8)) goto L83;
     */
    /* JADX WARN: Removed duplicated region for block: B:54:0x0119  */
    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.t0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final android.view.View N(android.view.View r23, int r24, androidx.recyclerview.widget.a1 r25, androidx.recyclerview.widget.e1 r26) {
        /*
            Method dump skipped, instructions count: 345
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.GridLayoutManager.N(android.view.View, int, androidx.recyclerview.widget.a1, androidx.recyclerview.widget.e1):android.view.View");
    }

    @Override // androidx.recyclerview.widget.t0
    public final void P(a1 a1Var, e1 e1Var, h.o oVar) {
        super.P(a1Var, e1Var, oVar);
        oVar.f473a.setClassName(GridView.class.getName());
    }

    @Override // androidx.recyclerview.widget.t0
    public final void R(a1 a1Var, e1 e1Var, View view, h.o oVar) {
        int i2;
        int i3;
        ViewGroup.LayoutParams layoutParams = view.getLayoutParams();
        if (!(layoutParams instanceof w)) {
            Q(view, oVar);
            return;
        }
        w wVar = (w) layoutParams;
        int Y0 = Y0(wVar.a(), a1Var, e1Var);
        int i4 = 1;
        if (this.f52o == 0) {
            int i5 = wVar.f345e;
            i4 = wVar.f346f;
            i3 = 1;
            i2 = Y0;
            Y0 = i5;
        } else {
            i2 = wVar.f345e;
            i3 = wVar.f346f;
        }
        oVar.d(h.n.a(Y0, i4, i2, i3));
    }

    @Override // androidx.recyclerview.widget.t0
    public final void S(int i2, int i3) {
        v vVar = this.J;
        vVar.b();
        vVar.f344b.clear();
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void S0(boolean z2) {
        if (z2) {
            throw new UnsupportedOperationException("GridLayoutManager does not support stack from end. Consider using reverse layout");
        }
        super.S0(false);
    }

    @Override // androidx.recyclerview.widget.t0
    public final void T() {
        v vVar = this.J;
        vVar.b();
        vVar.f344b.clear();
    }

    @Override // androidx.recyclerview.widget.t0
    public final void U(int i2, int i3) {
        v vVar = this.J;
        vVar.b();
        vVar.f344b.clear();
    }

    @Override // androidx.recyclerview.widget.t0
    public final void V(int i2, int i3) {
        v vVar = this.J;
        vVar.b();
        vVar.f344b.clear();
    }

    @Override // androidx.recyclerview.widget.t0
    public final void W(int i2, int i3) {
        v vVar = this.J;
        vVar.b();
        vVar.f344b.clear();
    }

    public final void W0(int i2) {
        int i3;
        int[] iArr = this.F;
        int i4 = this.E;
        if (iArr == null || iArr.length != i4 + 1 || iArr[iArr.length - 1] != i2) {
            iArr = new int[i4 + 1];
        }
        int i5 = 0;
        iArr[0] = 0;
        int i6 = i2 / i4;
        int i7 = i2 % i4;
        int i8 = 0;
        for (int i9 = 1; i9 <= i4; i9++) {
            i5 += i7;
            if (i5 <= 0 || i4 - i5 >= i7) {
                i3 = i6;
            } else {
                i3 = i6 + 1;
                i5 -= i4;
            }
            i8 += i3;
            iArr[i9] = i8;
        }
        this.F = iArr;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.t0
    public final void X(a1 a1Var, e1 e1Var) {
        boolean z2 = e1Var.f159f;
        SparseIntArray sparseIntArray = this.I;
        SparseIntArray sparseIntArray2 = this.H;
        if (z2) {
            int u2 = u();
            for (int i2 = 0; i2 < u2; i2++) {
                w wVar = (w) t(i2).getLayoutParams();
                int a2 = wVar.a();
                sparseIntArray2.put(a2, wVar.f346f);
                sparseIntArray.put(a2, wVar.f345e);
            }
        }
        super.X(a1Var, e1Var);
        sparseIntArray2.clear();
        sparseIntArray.clear();
    }

    public final int X0(int i2, int i3) {
        if (this.f52o != 1 || !K0()) {
            int[] iArr = this.F;
            return iArr[i3 + i2] - iArr[i2];
        }
        int[] iArr2 = this.F;
        int i4 = this.E;
        return iArr2[i4 - i2] - iArr2[(i4 - i2) - i3];
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.t0
    public final void Y(e1 e1Var) {
        super.Y(e1Var);
        this.D = false;
    }

    public final int Y0(int i2, a1 a1Var, e1 e1Var) {
        boolean z2 = e1Var.f159f;
        v vVar = this.J;
        if (!z2) {
            int i3 = this.E;
            vVar.getClass();
            return v.a(i2, i3);
        }
        int b2 = a1Var.b(i2);
        if (b2 != -1) {
            int i4 = this.E;
            vVar.getClass();
            return v.a(b2, i4);
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. " + i2);
        return 0;
    }

    public final int Z0(int i2, a1 a1Var, e1 e1Var) {
        boolean z2 = e1Var.f159f;
        v vVar = this.J;
        if (!z2) {
            int i3 = this.E;
            vVar.getClass();
            return i2 % i3;
        }
        int i4 = this.I.get(i2, -1);
        if (i4 != -1) {
            return i4;
        }
        int b2 = a1Var.b(i2);
        if (b2 != -1) {
            int i5 = this.E;
            vVar.getClass();
            return b2 % i5;
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i2);
        return 0;
    }

    public final int a1(int i2, a1 a1Var, e1 e1Var) {
        boolean z2 = e1Var.f159f;
        v vVar = this.J;
        if (!z2) {
            vVar.getClass();
            return 1;
        }
        int i3 = this.H.get(i2, -1);
        if (i3 != -1) {
            return i3;
        }
        if (a1Var.b(i2) != -1) {
            vVar.getClass();
            return 1;
        }
        Log.w("GridLayoutManager", "Cannot find span size for pre layout position. It is not cached, not in the adapter. Pos:" + i2);
        return 1;
    }

    public final void b1(View view, int i2, boolean z2) {
        int i3;
        int i4;
        w wVar = (w) view.getLayoutParams();
        Rect rect = wVar.f340b;
        int i5 = rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams) wVar).topMargin + ((ViewGroup.MarginLayoutParams) wVar).bottomMargin;
        int i6 = rect.left + rect.right + ((ViewGroup.MarginLayoutParams) wVar).leftMargin + ((ViewGroup.MarginLayoutParams) wVar).rightMargin;
        int X0 = X0(wVar.f345e, wVar.f346f);
        if (this.f52o == 1) {
            i4 = t0.v(X0, i2, i6, ((ViewGroup.MarginLayoutParams) wVar).width, false);
            i3 = t0.v(this.q.i(), this.f327l, i5, ((ViewGroup.MarginLayoutParams) wVar).height, true);
        } else {
            int v2 = t0.v(X0, i2, i5, ((ViewGroup.MarginLayoutParams) wVar).height, false);
            int v3 = t0.v(this.q.i(), this.f326k, i6, ((ViewGroup.MarginLayoutParams) wVar).width, true);
            i3 = v2;
            i4 = v3;
        }
        u0 u0Var = (u0) view.getLayoutParams();
        if (z2 ? s0(view, i4, i3, u0Var) : q0(view, i4, i3, u0Var)) {
            view.measure(i4, i3);
        }
    }

    public final void c1() {
        int y2;
        int B;
        if (this.f52o == 1) {
            y2 = this.f328m - A();
            B = z();
        } else {
            y2 = this.f329n - y();
            B = B();
        }
        W0(y2 - B);
    }

    @Override // androidx.recyclerview.widget.t0
    public final boolean e(u0 u0Var) {
        return u0Var instanceof w;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.t0
    public final int i0(int i2, a1 a1Var, e1 e1Var) {
        c1();
        View[] viewArr = this.G;
        if (viewArr == null || viewArr.length != this.E) {
            this.G = new View[this.E];
        }
        return super.i0(i2, a1Var, e1Var);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.t0
    public final int j(e1 e1Var) {
        return w0(e1Var);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.t0
    public final int k(e1 e1Var) {
        return x0(e1Var);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.t0
    public final int k0(int i2, a1 a1Var, e1 e1Var) {
        c1();
        View[] viewArr = this.G;
        if (viewArr == null || viewArr.length != this.E) {
            this.G = new View[this.E];
        }
        return super.k0(i2, a1Var, e1Var);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.t0
    public final int m(e1 e1Var) {
        return w0(e1Var);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.t0
    public final int n(e1 e1Var) {
        return x0(e1Var);
    }

    @Override // androidx.recyclerview.widget.t0
    public final void n0(Rect rect, int i2, int i3) {
        int f2;
        int f3;
        if (this.F == null) {
            super.n0(rect, i2, i3);
        }
        int A = A() + z();
        int y2 = y() + B();
        if (this.f52o == 1) {
            int height = rect.height() + y2;
            RecyclerView recyclerView = this.f317b;
            Field field = g.v.f448a;
            f3 = t0.f(i3, height, g.j.d(recyclerView));
            int[] iArr = this.F;
            f2 = t0.f(i2, iArr[iArr.length - 1] + A, g.j.e(this.f317b));
        } else {
            int width = rect.width() + A;
            RecyclerView recyclerView2 = this.f317b;
            Field field2 = g.v.f448a;
            f2 = t0.f(i2, width, g.j.e(recyclerView2));
            int[] iArr2 = this.F;
            f3 = t0.f(i3, iArr2[iArr2.length - 1] + y2, g.j.d(this.f317b));
        }
        this.f317b.setMeasuredDimension(f2, f3);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.t0
    public final u0 q() {
        return this.f52o == 0 ? new w(-2, -1) : new w(-1, -2);
    }

    @Override // androidx.recyclerview.widget.t0
    public final u0 r(Context context, AttributeSet attributeSet) {
        return new w(context, attributeSet);
    }

    @Override // androidx.recyclerview.widget.t0
    public final u0 s(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new w((ViewGroup.MarginLayoutParams) layoutParams) : new w(layoutParams);
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager, androidx.recyclerview.widget.t0
    public final boolean t0() {
        return this.f61y == null && !this.D;
    }

    @Override // androidx.recyclerview.widget.LinearLayoutManager
    public final void u0(e1 e1Var, a0 a0Var, s sVar) {
        int i2 = this.E;
        for (int i3 = 0; i3 < this.E; i3++) {
            int i4 = a0Var.f114d;
            if (!(i4 >= 0 && i4 < e1Var.b()) || i2 <= 0) {
                return;
            }
            sVar.a(a0Var.f114d, Math.max(0, a0Var.f117g));
            this.J.getClass();
            i2--;
            a0Var.f114d += a0Var.f115e;
        }
    }

    @Override // androidx.recyclerview.widget.t0
    public final int w(a1 a1Var, e1 e1Var) {
        if (this.f52o == 1) {
            return this.E;
        }
        if (e1Var.b() < 1) {
            return 0;
        }
        return Y0(e1Var.b() - 1, a1Var, e1Var) + 1;
    }
}
