package androidx.recyclerview.widget;

import android.annotation.SuppressLint;
import android.content.Context;
import android.graphics.Rect;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.lang.reflect.Field;

/* loaded from: classes.dex */
public class LinearLayoutManager extends t0 {
    public final z A;
    public final int B;
    public final int[] C;

    /* renamed from: o, reason: collision with root package name */
    public int f52o;

    /* renamed from: p, reason: collision with root package name */
    public a0 f53p;
    public d0 q;

    /* renamed from: r, reason: collision with root package name */
    public boolean f54r;

    /* renamed from: s, reason: collision with root package name */
    public boolean f55s;

    /* renamed from: t, reason: collision with root package name */
    public boolean f56t;

    /* renamed from: u, reason: collision with root package name */
    public boolean f57u;

    /* renamed from: v, reason: collision with root package name */
    public final boolean f58v;

    /* renamed from: w, reason: collision with root package name */
    public int f59w;

    /* renamed from: x, reason: collision with root package name */
    public int f60x;

    /* renamed from: y, reason: collision with root package name */
    public c0 f61y;

    /* renamed from: z, reason: collision with root package name */
    public final y f62z;

    public LinearLayoutManager() {
        this.f52o = 1;
        this.f55s = false;
        this.f56t = false;
        this.f57u = false;
        this.f58v = true;
        this.f59w = -1;
        this.f60x = Integer.MIN_VALUE;
        this.f61y = null;
        this.f62z = new y();
        this.A = new z();
        this.B = 2;
        this.C = new int[2];
        R0(1);
        b(null);
        if (this.f55s) {
            this.f55s = false;
            h0();
        }
    }

    public final int A0(a1 a1Var, a0 a0Var, e1 e1Var, boolean z2) {
        int i2 = a0Var.f113c;
        int i3 = a0Var.f117g;
        if (i3 != Integer.MIN_VALUE) {
            if (i2 < 0) {
                a0Var.f117g = i3 + i2;
            }
            N0(a1Var, a0Var);
        }
        int i4 = a0Var.f113c + a0Var.f118h;
        while (true) {
            if (!a0Var.f122l && i4 <= 0) {
                break;
            }
            int i5 = a0Var.f114d;
            if (!(i5 >= 0 && i5 < e1Var.b())) {
                break;
            }
            z zVar = this.A;
            zVar.f365a = 0;
            zVar.f366b = false;
            zVar.f367c = false;
            zVar.f368d = false;
            L0(a1Var, e1Var, a0Var, zVar);
            if (!zVar.f366b) {
                int i6 = a0Var.f112b;
                int i7 = zVar.f365a;
                a0Var.f112b = (a0Var.f116f * i7) + i6;
                if (!zVar.f367c || a0Var.f121k != null || !e1Var.f159f) {
                    a0Var.f113c -= i7;
                    i4 -= i7;
                }
                int i8 = a0Var.f117g;
                if (i8 != Integer.MIN_VALUE) {
                    int i9 = i8 + i7;
                    a0Var.f117g = i9;
                    int i10 = a0Var.f113c;
                    if (i10 < 0) {
                        a0Var.f117g = i9 + i10;
                    }
                    N0(a1Var, a0Var);
                }
                if (z2 && zVar.f368d) {
                    break;
                }
            } else {
                break;
            }
        }
        return i2 - a0Var.f113c;
    }

    public final View B0(boolean z2) {
        int u2;
        int i2;
        if (this.f56t) {
            i2 = u();
            u2 = 0;
        } else {
            u2 = u() - 1;
            i2 = -1;
        }
        return E0(u2, i2, z2);
    }

    public final View C0(boolean z2) {
        int u2;
        int i2;
        if (this.f56t) {
            u2 = -1;
            i2 = u() - 1;
        } else {
            u2 = u();
            i2 = 0;
        }
        return E0(i2, u2, z2);
    }

    public final View D0(int i2, int i3) {
        int i4;
        int i5;
        z0();
        if ((i3 > i2 ? (char) 1 : i3 < i2 ? (char) 65535 : (char) 0) == 0) {
            return t(i2);
        }
        if (this.q.d(t(i2)) < this.q.h()) {
            i4 = 16644;
            i5 = 16388;
        } else {
            i4 = 4161;
            i5 = 4097;
        }
        return (this.f52o == 0 ? this.f318c : this.f319d).g(i2, i3, i4, i5);
    }

    public final View E0(int i2, int i3, boolean z2) {
        z0();
        return (this.f52o == 0 ? this.f318c : this.f319d).g(i2, i3, z2 ? 24579 : 320, 320);
    }

    public View F0(a1 a1Var, e1 e1Var, boolean z2, boolean z3) {
        int i2;
        int i3;
        int i4;
        z0();
        int u2 = u();
        if (z3) {
            i3 = u() - 1;
            i2 = -1;
            i4 = -1;
        } else {
            i2 = u2;
            i3 = 0;
            i4 = 1;
        }
        int b2 = e1Var.b();
        int h2 = this.q.h();
        int f2 = this.q.f();
        View view = null;
        View view2 = null;
        View view3 = null;
        while (i3 != i2) {
            View t2 = t(i3);
            int C = t0.C(t2);
            int d2 = this.q.d(t2);
            int b3 = this.q.b(t2);
            if (C >= 0 && C < b2) {
                if (!((u0) t2.getLayoutParams()).c()) {
                    boolean z4 = b3 <= h2 && d2 < h2;
                    boolean z5 = d2 >= f2 && b3 > f2;
                    if (!z4 && !z5) {
                        return t2;
                    }
                    if (z2) {
                        if (!z5) {
                            if (view != null) {
                            }
                            view = t2;
                        }
                        view2 = t2;
                    } else {
                        if (!z4) {
                            if (view != null) {
                            }
                            view = t2;
                        }
                        view2 = t2;
                    }
                } else if (view3 == null) {
                    view3 = t2;
                }
            }
            i3 += i4;
        }
        return view != null ? view : view2 != null ? view2 : view3;
    }

    @Override // androidx.recyclerview.widget.t0
    public final boolean G() {
        return true;
    }

    public final int G0(int i2, a1 a1Var, e1 e1Var, boolean z2) {
        int f2;
        int f3 = this.q.f() - i2;
        if (f3 <= 0) {
            return 0;
        }
        int i3 = -Q0(-f3, a1Var, e1Var);
        int i4 = i2 + i3;
        if (!z2 || (f2 = this.q.f() - i4) <= 0) {
            return i3;
        }
        this.q.l(f2);
        return f2 + i3;
    }

    public final int H0(int i2, a1 a1Var, e1 e1Var, boolean z2) {
        int h2;
        int h3 = i2 - this.q.h();
        if (h3 <= 0) {
            return 0;
        }
        int i3 = -Q0(h3, a1Var, e1Var);
        int i4 = i2 + i3;
        if (!z2 || (h2 = i4 - this.q.h()) <= 0) {
            return i3;
        }
        this.q.l(-h2);
        return i3 - h2;
    }

    public final View I0() {
        return t(this.f56t ? 0 : u() - 1);
    }

    public final View J0() {
        return t(this.f56t ? u() - 1 : 0);
    }

    public final boolean K0() {
        RecyclerView recyclerView = this.f317b;
        Field field = g.v.f448a;
        return g.k.d(recyclerView) == 1;
    }

    public void L0(a1 a1Var, e1 e1Var, a0 a0Var, z zVar) {
        int m2;
        int i2;
        int i3;
        int i4;
        int z2;
        int i5;
        View b2 = a0Var.b(a1Var);
        if (b2 == null) {
            zVar.f366b = true;
            return;
        }
        u0 u0Var = (u0) b2.getLayoutParams();
        if (a0Var.f121k == null) {
            if (this.f56t == (a0Var.f116f == -1)) {
                a(b2, -1, false);
            } else {
                a(b2, 0, false);
            }
        } else {
            if (this.f56t == (a0Var.f116f == -1)) {
                a(b2, -1, true);
            } else {
                a(b2, 0, true);
            }
        }
        u0 u0Var2 = (u0) b2.getLayoutParams();
        Rect J = this.f317b.J(b2);
        int i6 = J.left + J.right + 0;
        int i7 = J.top + J.bottom + 0;
        int v2 = t0.v(this.f328m, this.f326k, A() + z() + ((ViewGroup.MarginLayoutParams) u0Var2).leftMargin + ((ViewGroup.MarginLayoutParams) u0Var2).rightMargin + i6, ((ViewGroup.MarginLayoutParams) u0Var2).width, c());
        int v3 = t0.v(this.f329n, this.f327l, y() + B() + ((ViewGroup.MarginLayoutParams) u0Var2).topMargin + ((ViewGroup.MarginLayoutParams) u0Var2).bottomMargin + i7, ((ViewGroup.MarginLayoutParams) u0Var2).height, d());
        if (q0(b2, v2, v3, u0Var2)) {
            b2.measure(v2, v3);
        }
        zVar.f365a = this.q.c(b2);
        if (this.f52o == 1) {
            if (K0()) {
                i4 = this.f328m - A();
                z2 = i4 - this.q.m(b2);
            } else {
                z2 = z();
                i4 = this.q.m(b2) + z2;
            }
            int i8 = a0Var.f116f;
            i3 = a0Var.f112b;
            if (i8 == -1) {
                i5 = z2;
                m2 = i3;
                i3 -= zVar.f365a;
            } else {
                i5 = z2;
                m2 = zVar.f365a + i3;
            }
            i2 = i5;
        } else {
            int B = B();
            m2 = this.q.m(b2) + B;
            int i9 = a0Var.f116f;
            int i10 = a0Var.f112b;
            if (i9 == -1) {
                i2 = i10 - zVar.f365a;
                i4 = i10;
                i3 = B;
            } else {
                int i11 = zVar.f365a + i10;
                i2 = i10;
                i3 = B;
                i4 = i11;
            }
        }
        t0.I(b2, i2, i3, i4, m2);
        if (u0Var.c() || u0Var.b()) {
            zVar.f367c = true;
        }
        zVar.f368d = b2.hasFocusable();
    }

    @Override // androidx.recyclerview.widget.t0
    public final void M(RecyclerView recyclerView) {
    }

    public void M0(a1 a1Var, e1 e1Var, y yVar, int i2) {
    }

    @Override // androidx.recyclerview.widget.t0
    public View N(View view, int i2, a1 a1Var, e1 e1Var) {
        int y0;
        P0();
        if (u() == 0 || (y0 = y0(i2)) == Integer.MIN_VALUE) {
            return null;
        }
        z0();
        T0(y0, (int) (this.q.i() * 0.33333334f), false, e1Var);
        a0 a0Var = this.f53p;
        a0Var.f117g = Integer.MIN_VALUE;
        a0Var.f111a = false;
        A0(a1Var, a0Var, e1Var, true);
        View D0 = y0 == -1 ? this.f56t ? D0(u() - 1, -1) : D0(0, u()) : this.f56t ? D0(0, u()) : D0(u() - 1, -1);
        View J0 = y0 == -1 ? J0() : I0();
        if (!J0.hasFocusable()) {
            return D0;
        }
        if (D0 == null) {
            return null;
        }
        return J0;
    }

    public final void N0(a1 a1Var, a0 a0Var) {
        if (!a0Var.f111a || a0Var.f122l) {
            return;
        }
        int i2 = a0Var.f117g;
        int i3 = a0Var.f119i;
        if (a0Var.f116f == -1) {
            int u2 = u();
            if (i2 < 0) {
                return;
            }
            int e2 = (this.q.e() - i2) + i3;
            if (this.f56t) {
                for (int i4 = 0; i4 < u2; i4++) {
                    View t2 = t(i4);
                    if (this.q.d(t2) < e2 || this.q.k(t2) < e2) {
                        O0(a1Var, 0, i4);
                        return;
                    }
                }
                return;
            }
            int i5 = u2 - 1;
            for (int i6 = i5; i6 >= 0; i6--) {
                View t3 = t(i6);
                if (this.q.d(t3) < e2 || this.q.k(t3) < e2) {
                    O0(a1Var, i5, i6);
                    return;
                }
            }
            return;
        }
        if (i2 < 0) {
            return;
        }
        int i7 = i2 - i3;
        int u3 = u();
        if (!this.f56t) {
            for (int i8 = 0; i8 < u3; i8++) {
                View t4 = t(i8);
                if (this.q.b(t4) > i7 || this.q.j(t4) > i7) {
                    O0(a1Var, 0, i8);
                    return;
                }
            }
            return;
        }
        int i9 = u3 - 1;
        for (int i10 = i9; i10 >= 0; i10--) {
            View t5 = t(i10);
            if (this.q.b(t5) > i7 || this.q.j(t5) > i7) {
                O0(a1Var, i9, i10);
                return;
            }
        }
    }

    @Override // androidx.recyclerview.widget.t0
    public final void O(AccessibilityEvent accessibilityEvent) {
        super.O(accessibilityEvent);
        if (u() > 0) {
            View E0 = E0(0, u(), false);
            accessibilityEvent.setFromIndex(E0 == null ? -1 : t0.C(E0));
            View E02 = E0(u() - 1, -1, false);
            accessibilityEvent.setToIndex(E02 != null ? t0.C(E02) : -1);
        }
    }

    public final void O0(a1 a1Var, int i2, int i3) {
        if (i2 == i3) {
            return;
        }
        if (i3 <= i2) {
            while (i2 > i3) {
                View t2 = t(i2);
                f0(i2);
                a1Var.h(t2);
                i2--;
            }
            return;
        }
        while (true) {
            i3--;
            if (i3 < i2) {
                return;
            }
            View t3 = t(i3);
            f0(i3);
            a1Var.h(t3);
        }
    }

    public final void P0() {
        this.f56t = (this.f52o == 1 || !K0()) ? this.f55s : !this.f55s;
    }

    public final int Q0(int i2, a1 a1Var, e1 e1Var) {
        if (u() == 0 || i2 == 0) {
            return 0;
        }
        z0();
        this.f53p.f111a = true;
        int i3 = i2 > 0 ? 1 : -1;
        int abs = Math.abs(i2);
        T0(i3, abs, true, e1Var);
        a0 a0Var = this.f53p;
        int A0 = A0(a1Var, a0Var, e1Var, false) + a0Var.f117g;
        if (A0 < 0) {
            return 0;
        }
        if (abs > A0) {
            i2 = i3 * A0;
        }
        this.q.l(-i2);
        this.f53p.f120j = i2;
        return i2;
    }

    public final void R0(int i2) {
        if (i2 != 0 && i2 != 1) {
            throw new IllegalArgumentException("invalid orientation:" + i2);
        }
        b(null);
        if (i2 != this.f52o || this.q == null) {
            d0 a2 = e0.a(this, i2);
            this.q = a2;
            this.f62z.f356a = a2;
            this.f52o = i2;
            h0();
        }
    }

    public void S0(boolean z2) {
        b(null);
        if (this.f57u == z2) {
            return;
        }
        this.f57u = z2;
        h0();
    }

    public final void T0(int i2, int i3, boolean z2, e1 e1Var) {
        int h2;
        int y2;
        this.f53p.f122l = this.q.g() == 0 && this.q.e() == 0;
        this.f53p.f116f = i2;
        int[] iArr = this.C;
        iArr[0] = 0;
        iArr[1] = 0;
        e1Var.getClass();
        int i4 = this.f53p.f116f;
        iArr[0] = 0;
        iArr[1] = 0;
        int max = Math.max(0, 0);
        int max2 = Math.max(0, iArr[1]);
        boolean z3 = i2 == 1;
        a0 a0Var = this.f53p;
        int i5 = z3 ? max2 : max;
        a0Var.f118h = i5;
        if (!z3) {
            max = max2;
        }
        a0Var.f119i = max;
        if (z3) {
            d0 d0Var = this.q;
            int i6 = d0Var.f144d;
            t0 t0Var = d0Var.f151a;
            switch (i6) {
                case 0:
                    y2 = t0Var.A();
                    break;
                default:
                    y2 = t0Var.y();
                    break;
            }
            a0Var.f118h = y2 + i5;
            View I0 = I0();
            a0 a0Var2 = this.f53p;
            a0Var2.f115e = this.f56t ? -1 : 1;
            int C = t0.C(I0);
            a0 a0Var3 = this.f53p;
            a0Var2.f114d = C + a0Var3.f115e;
            a0Var3.f112b = this.q.b(I0);
            h2 = this.q.b(I0) - this.q.f();
        } else {
            View J0 = J0();
            a0 a0Var4 = this.f53p;
            a0Var4.f118h = this.q.h() + a0Var4.f118h;
            a0 a0Var5 = this.f53p;
            a0Var5.f115e = this.f56t ? 1 : -1;
            int C2 = t0.C(J0);
            a0 a0Var6 = this.f53p;
            a0Var5.f114d = C2 + a0Var6.f115e;
            a0Var6.f112b = this.q.d(J0);
            h2 = (-this.q.d(J0)) + this.q.h();
        }
        a0 a0Var7 = this.f53p;
        a0Var7.f113c = i3;
        if (z2) {
            a0Var7.f113c = i3 - h2;
        }
        a0Var7.f117g = h2;
    }

    public final void U0(int i2, int i3) {
        this.f53p.f113c = this.q.f() - i3;
        a0 a0Var = this.f53p;
        a0Var.f115e = this.f56t ? -1 : 1;
        a0Var.f114d = i2;
        a0Var.f116f = 1;
        a0Var.f112b = i3;
        a0Var.f117g = Integer.MIN_VALUE;
    }

    public final void V0(int i2, int i3) {
        this.f53p.f113c = i3 - this.q.h();
        a0 a0Var = this.f53p;
        a0Var.f114d = i2;
        a0Var.f115e = this.f56t ? 1 : -1;
        a0Var.f116f = -1;
        a0Var.f112b = i3;
        a0Var.f117g = Integer.MIN_VALUE;
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:152:0x019a  */
    /* JADX WARN: Removed duplicated region for block: B:169:0x0239  */
    /* JADX WARN: Type inference failed for: r4v2 */
    /* JADX WARN: Type inference failed for: r4v3, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r4v4 */
    @Override // androidx.recyclerview.widget.t0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void X(androidx.recyclerview.widget.a1 r18, androidx.recyclerview.widget.e1 r19) {
        /*
            Method dump skipped, instructions count: 1146
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.LinearLayoutManager.X(androidx.recyclerview.widget.a1, androidx.recyclerview.widget.e1):void");
    }

    @Override // androidx.recyclerview.widget.t0
    public void Y(e1 e1Var) {
        this.f61y = null;
        this.f59w = -1;
        this.f60x = Integer.MIN_VALUE;
        this.f62z.c();
    }

    @Override // androidx.recyclerview.widget.t0
    public final void Z(Parcelable parcelable) {
        if (parcelable instanceof c0) {
            c0 c0Var = (c0) parcelable;
            this.f61y = c0Var;
            if (this.f59w != -1) {
                c0Var.f138a = -1;
            }
            h0();
        }
    }

    @Override // androidx.recyclerview.widget.t0
    public final Parcelable a0() {
        c0 c0Var = this.f61y;
        if (c0Var != null) {
            return new c0(c0Var);
        }
        c0 c0Var2 = new c0();
        if (u() > 0) {
            z0();
            boolean z2 = this.f54r ^ this.f56t;
            c0Var2.f140c = z2;
            if (z2) {
                View I0 = I0();
                c0Var2.f139b = this.q.f() - this.q.b(I0);
                c0Var2.f138a = t0.C(I0);
            } else {
                View J0 = J0();
                c0Var2.f138a = t0.C(J0);
                c0Var2.f139b = this.q.d(J0) - this.q.h();
            }
        } else {
            c0Var2.f138a = -1;
        }
        return c0Var2;
    }

    @Override // androidx.recyclerview.widget.t0
    public final void b(String str) {
        RecyclerView recyclerView;
        if (this.f61y != null || (recyclerView = this.f317b) == null) {
            return;
        }
        recyclerView.h(str);
    }

    @Override // androidx.recyclerview.widget.t0
    public final boolean c() {
        return this.f52o == 0;
    }

    @Override // androidx.recyclerview.widget.t0
    public final boolean d() {
        return this.f52o == 1;
    }

    @Override // androidx.recyclerview.widget.t0
    public final void g(int i2, int i3, e1 e1Var, s sVar) {
        if (this.f52o != 0) {
            i2 = i3;
        }
        if (u() == 0 || i2 == 0) {
            return;
        }
        z0();
        T0(i2 > 0 ? 1 : -1, Math.abs(i2), true, e1Var);
        u0(e1Var, this.f53p, sVar);
    }

    /* JADX WARN: Removed duplicated region for block: B:9:0x0024  */
    @Override // androidx.recyclerview.widget.t0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void h(int r7, androidx.recyclerview.widget.s r8) {
        /*
            r6 = this;
            androidx.recyclerview.widget.c0 r0 = r6.f61y
            r1 = 1
            r2 = -1
            r3 = 0
            if (r0 == 0) goto L13
            int r4 = r0.f138a
            if (r4 < 0) goto Ld
            r5 = 1
            goto Le
        Ld:
            r5 = 0
        Le:
            if (r5 == 0) goto L13
            boolean r0 = r0.f140c
            goto L22
        L13:
            r6.P0()
            boolean r0 = r6.f56t
            int r4 = r6.f59w
            if (r4 != r2) goto L22
            if (r0 == 0) goto L21
            int r4 = r7 + (-1)
            goto L22
        L21:
            r4 = 0
        L22:
            if (r0 == 0) goto L25
            r1 = -1
        L25:
            r0 = 0
        L26:
            int r2 = r6.B
            if (r0 >= r2) goto L35
            if (r4 < 0) goto L35
            if (r4 >= r7) goto L35
            r8.a(r4, r3)
            int r4 = r4 + r1
            int r0 = r0 + 1
            goto L26
        L35:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.LinearLayoutManager.h(int, androidx.recyclerview.widget.s):void");
    }

    @Override // androidx.recyclerview.widget.t0
    public final int i(e1 e1Var) {
        return v0(e1Var);
    }

    @Override // androidx.recyclerview.widget.t0
    public int i0(int i2, a1 a1Var, e1 e1Var) {
        if (this.f52o == 1) {
            return 0;
        }
        return Q0(i2, a1Var, e1Var);
    }

    @Override // androidx.recyclerview.widget.t0
    public int j(e1 e1Var) {
        return w0(e1Var);
    }

    @Override // androidx.recyclerview.widget.t0
    public final void j0(int i2) {
        this.f59w = i2;
        this.f60x = Integer.MIN_VALUE;
        c0 c0Var = this.f61y;
        if (c0Var != null) {
            c0Var.f138a = -1;
        }
        h0();
    }

    @Override // androidx.recyclerview.widget.t0
    public int k(e1 e1Var) {
        return x0(e1Var);
    }

    @Override // androidx.recyclerview.widget.t0
    public int k0(int i2, a1 a1Var, e1 e1Var) {
        if (this.f52o == 0) {
            return 0;
        }
        return Q0(i2, a1Var, e1Var);
    }

    @Override // androidx.recyclerview.widget.t0
    public final int l(e1 e1Var) {
        return v0(e1Var);
    }

    @Override // androidx.recyclerview.widget.t0
    public int m(e1 e1Var) {
        return w0(e1Var);
    }

    @Override // androidx.recyclerview.widget.t0
    public int n(e1 e1Var) {
        return x0(e1Var);
    }

    @Override // androidx.recyclerview.widget.t0
    public final View p(int i2) {
        int u2 = u();
        if (u2 == 0) {
            return null;
        }
        int C = i2 - t0.C(t(0));
        if (C >= 0 && C < u2) {
            View t2 = t(C);
            if (t0.C(t2) == i2) {
                return t2;
            }
        }
        return super.p(i2);
    }

    @Override // androidx.recyclerview.widget.t0
    public u0 q() {
        return new u0(-2, -2);
    }

    @Override // androidx.recyclerview.widget.t0
    public final boolean r0() {
        boolean z2;
        if (this.f327l == 1073741824 || this.f326k == 1073741824) {
            return false;
        }
        int u2 = u();
        int i2 = 0;
        while (true) {
            if (i2 >= u2) {
                z2 = false;
                break;
            }
            ViewGroup.LayoutParams layoutParams = t(i2).getLayoutParams();
            if (layoutParams.width < 0 && layoutParams.height < 0) {
                z2 = true;
                break;
            }
            i2++;
        }
        return z2;
    }

    @Override // androidx.recyclerview.widget.t0
    public boolean t0() {
        return this.f61y == null && this.f54r == this.f57u;
    }

    public void u0(e1 e1Var, a0 a0Var, s sVar) {
        int i2 = a0Var.f114d;
        if (i2 < 0 || i2 >= e1Var.b()) {
            return;
        }
        sVar.a(i2, Math.max(0, a0Var.f117g));
    }

    public final int v0(e1 e1Var) {
        if (u() == 0) {
            return 0;
        }
        z0();
        d0 d0Var = this.q;
        boolean z2 = !this.f58v;
        return b0.d.n(e1Var, d0Var, C0(z2), B0(z2), this, this.f58v);
    }

    public final int w0(e1 e1Var) {
        if (u() == 0) {
            return 0;
        }
        z0();
        d0 d0Var = this.q;
        boolean z2 = !this.f58v;
        return b0.d.o(e1Var, d0Var, C0(z2), B0(z2), this, this.f58v, this.f56t);
    }

    public final int x0(e1 e1Var) {
        if (u() == 0) {
            return 0;
        }
        z0();
        d0 d0Var = this.q;
        boolean z2 = !this.f58v;
        return b0.d.p(e1Var, d0Var, C0(z2), B0(z2), this, this.f58v);
    }

    public final int y0(int i2) {
        return i2 != 1 ? i2 != 2 ? i2 != 17 ? i2 != 33 ? i2 != 66 ? (i2 == 130 && this.f52o == 1) ? 1 : Integer.MIN_VALUE : this.f52o == 0 ? 1 : Integer.MIN_VALUE : this.f52o == 1 ? -1 : Integer.MIN_VALUE : this.f52o == 0 ? -1 : Integer.MIN_VALUE : (this.f52o != 1 && K0()) ? -1 : 1 : (this.f52o != 1 && K0()) ? 1 : -1;
    }

    public final void z0() {
        if (this.f53p == null) {
            this.f53p = new a0();
        }
    }

    @SuppressLint({"UnknownNullness"})
    public LinearLayoutManager(Context context, AttributeSet attributeSet, int i2, int i3) {
        this.f52o = 1;
        this.f55s = false;
        this.f56t = false;
        this.f57u = false;
        this.f58v = true;
        this.f59w = -1;
        this.f60x = Integer.MIN_VALUE;
        this.f61y = null;
        this.f62z = new y();
        this.A = new z();
        this.B = 2;
        this.C = new int[2];
        s0 D = t0.D(context, attributeSet, i2, i3);
        R0(D.f303a);
        boolean z2 = D.f305c;
        b(null);
        if (z2 != this.f55s) {
            this.f55s = z2;
            h0();
        }
        S0(D.f306d);
    }
}
