package androidx.recyclerview.widget;

import android.R;
import android.animation.LayoutTransition;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Rect;
import android.graphics.RectF;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Build;
import android.os.Parcelable;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.util.Log;
import android.util.SparseArray;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.view.ViewConfiguration;
import android.view.ViewGroup;
import android.view.ViewParent;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityManager;
import android.view.animation.Interpolator;
import android.widget.EdgeEffect;
import android.widget.OverScroller;
import java.lang.ref.WeakReference;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public class RecyclerView extends ViewGroup {
    public static final int[] A0 = {R.attr.nestedScrollingEnabled};
    public static final float B0 = (float) (Math.log(0.78d) / Math.log(0.9d));
    public static final boolean C0;
    public static final boolean D0;
    public static final boolean E0;
    public static final Class[] F0;
    public static final g0 G0;
    public static final f1 H0;
    public static boolean y0 = false;
    public static boolean z0 = false;
    public boolean A;
    public final AccessibilityManager B;
    public boolean C;
    public boolean D;
    public int E;
    public int F;
    public m0 G;
    public EdgeEffect H;
    public EdgeEffect I;
    public EdgeEffect J;
    public EdgeEffect K;
    public o0 L;
    public int M;
    public int N;
    public VelocityTracker O;
    public int P;
    public int Q;
    public int R;
    public int S;
    public int T;
    public final int U;
    public final int V;
    public final float W;

    /* renamed from: a, reason: collision with root package name */
    public final float f63a;

    /* renamed from: a0, reason: collision with root package name */
    public final float f64a0;

    /* renamed from: b, reason: collision with root package name */
    public final c1 f65b;

    /* renamed from: b0, reason: collision with root package name */
    public boolean f66b0;

    /* renamed from: c, reason: collision with root package name */
    public final a1 f67c;

    /* renamed from: c0, reason: collision with root package name */
    public final h1 f68c0;

    /* renamed from: d, reason: collision with root package name */
    public d1 f69d;

    /* renamed from: d0, reason: collision with root package name */
    public u f70d0;

    /* renamed from: e, reason: collision with root package name */
    public b f71e;

    /* renamed from: e0, reason: collision with root package name */
    public final s f72e0;

    /* renamed from: f, reason: collision with root package name */
    public e f73f;

    /* renamed from: f0, reason: collision with root package name */
    public final e1 f74f0;

    /* renamed from: g, reason: collision with root package name */
    public final t1 f75g;

    /* renamed from: g0, reason: collision with root package name */
    public x0 f76g0;

    /* renamed from: h, reason: collision with root package name */
    public boolean f77h;

    /* renamed from: h0, reason: collision with root package name */
    public ArrayList f78h0;

    /* renamed from: i, reason: collision with root package name */
    public final f0 f79i;
    public boolean i0;

    /* renamed from: j, reason: collision with root package name */
    public final Rect f80j;
    public boolean j0;

    /* renamed from: k, reason: collision with root package name */
    public final Rect f81k;
    public final p0 k0;

    /* renamed from: l, reason: collision with root package name */
    public final RectF f82l;
    public boolean l0;

    /* renamed from: m, reason: collision with root package name */
    public i0 f83m;
    public k1 m0;

    /* renamed from: n, reason: collision with root package name */
    public t0 f84n;
    public final int[] n0;

    /* renamed from: o, reason: collision with root package name */
    public final ArrayList f85o;
    public g.f o0;

    /* renamed from: p, reason: collision with root package name */
    public final ArrayList f86p;
    public final int[] p0;
    public final ArrayList q;
    public final int[] q0;

    /* renamed from: r, reason: collision with root package name */
    public w0 f87r;
    public final int[] r0;

    /* renamed from: s, reason: collision with root package name */
    public boolean f88s;
    public final ArrayList s0;

    /* renamed from: t, reason: collision with root package name */
    public boolean f89t;
    public final f0 t0;

    /* renamed from: u, reason: collision with root package name */
    public boolean f90u;
    public boolean u0;

    /* renamed from: v, reason: collision with root package name */
    public int f91v;
    public int v0;

    /* renamed from: w, reason: collision with root package name */
    public boolean f92w;
    public int w0;

    /* renamed from: x, reason: collision with root package name */
    public boolean f93x;
    public final p0 x0;

    /* renamed from: y, reason: collision with root package name */
    public boolean f94y;

    /* renamed from: z, reason: collision with root package name */
    public int f95z;

    static {
        C0 = Build.VERSION.SDK_INT >= 23;
        D0 = true;
        E0 = true;
        Class cls = Integer.TYPE;
        F0 = new Class[]{Context.class, AttributeSet.class, cls, cls};
        G0 = new g0();
        H0 = new f1();
    }

    /* JADX WARN: Can't wrap try/catch for region: R(9:(1:43)(11:82|(1:84)|45|46|47|(1:49)(1:66)|50|51|52|53|54)|46|47|(0)(0)|50|51|52|53|54) */
    /* JADX WARN: Code restructure failed: missing block: B:56:0x029e, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:59:0x02a0, code lost:
    
        r0 = r4.getConstructor(new java.lang.Class[0]);
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x02a6, code lost:
    
        r15 = null;
     */
    /* JADX WARN: Code restructure failed: missing block: B:62:0x02b5, code lost:
    
        r0 = move-exception;
     */
    /* JADX WARN: Code restructure failed: missing block: B:63:0x02b6, code lost:
    
        r0.initCause(r0);
     */
    /* JADX WARN: Code restructure failed: missing block: B:64:0x02d6, code lost:
    
        throw new java.lang.IllegalStateException(r20.getPositionDescription() + ": Error creating LayoutManager " + r3, r0);
     */
    /* JADX WARN: Removed duplicated region for block: B:49:0x0269 A[Catch: ClassCastException -> 0x02d7, IllegalAccessException -> 0x02f6, InstantiationException -> 0x0315, InvocationTargetException -> 0x0332, ClassNotFoundException -> 0x034f, TryCatch #4 {ClassCastException -> 0x02d7, ClassNotFoundException -> 0x034f, IllegalAccessException -> 0x02f6, InstantiationException -> 0x0315, InvocationTargetException -> 0x0332, blocks: (B:47:0x0263, B:49:0x0269, B:50:0x0276, B:52:0x0280, B:54:0x02a7, B:59:0x02a0, B:63:0x02b6, B:64:0x02d6, B:66:0x0272), top: B:46:0x0263 }] */
    /* JADX WARN: Removed duplicated region for block: B:66:0x0272 A[Catch: ClassCastException -> 0x02d7, IllegalAccessException -> 0x02f6, InstantiationException -> 0x0315, InvocationTargetException -> 0x0332, ClassNotFoundException -> 0x034f, TryCatch #4 {ClassCastException -> 0x02d7, ClassNotFoundException -> 0x034f, IllegalAccessException -> 0x02f6, InstantiationException -> 0x0315, InvocationTargetException -> 0x0332, blocks: (B:47:0x0263, B:49:0x0269, B:50:0x0276, B:52:0x0280, B:54:0x02a7, B:59:0x02a0, B:63:0x02b6, B:64:0x02d6, B:66:0x0272), top: B:46:0x0263 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public RecyclerView(android.content.Context r19, android.util.AttributeSet r20) {
        /*
            Method dump skipped, instructions count: 926
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.<init>(android.content.Context, android.util.AttributeSet):void");
    }

    public static RecyclerView D(View view) {
        if (!(view instanceof ViewGroup)) {
            return null;
        }
        if (view instanceof RecyclerView) {
            return (RecyclerView) view;
        }
        ViewGroup viewGroup = (ViewGroup) view;
        int childCount = viewGroup.getChildCount();
        for (int i2 = 0; i2 < childCount; i2++) {
            RecyclerView D = D(viewGroup.getChildAt(i2));
            if (D != null) {
                return D;
            }
        }
        return null;
    }

    public static i1 I(View view) {
        if (view == null) {
            return null;
        }
        return ((u0) view.getLayoutParams()).f339a;
    }

    private g.f getScrollingChildHelper() {
        if (this.o0 == null) {
            this.o0 = new g.f(this);
        }
        return this.o0;
    }

    public static void i(i1 i1Var) {
        WeakReference<RecyclerView> weakReference = i1Var.mNestedRecyclerView;
        if (weakReference != null) {
            Object obj = weakReference.get();
            while (true) {
                for (View view = (View) obj; view != null; view = null) {
                    if (view == i1Var.itemView) {
                        return;
                    }
                    obj = view.getParent();
                    if (obj instanceof View) {
                        break;
                    }
                }
                i1Var.mNestedRecyclerView = null;
                return;
            }
        }
    }

    public static int l(int i2, EdgeEffect edgeEffect, EdgeEffect edgeEffect2, int i3) {
        if (i2 > 0 && edgeEffect != null && b0.d.w(edgeEffect) != B0) {
            int round = Math.round(b0.d.A(edgeEffect, ((-i2) * 4.0f) / i3, 0.5f) * ((-i3) / 4.0f));
            if (round != i2) {
                edgeEffect.finish();
            }
            return i2 - round;
        }
        if (i2 >= 0 || edgeEffect2 == null || b0.d.w(edgeEffect2) == B0) {
            return i2;
        }
        float f2 = i3;
        int round2 = Math.round(b0.d.A(edgeEffect2, (i2 * 4.0f) / f2, 0.5f) * (f2 / 4.0f));
        if (round2 != i2) {
            edgeEffect2.finish();
        }
        return i2 - round2;
    }

    public static void setDebugAssertionsEnabled(boolean z2) {
        y0 = z2;
    }

    public static void setVerboseLoggingEnabled(boolean z2) {
        z0 = z2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:11:?, code lost:
    
        return r3;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final android.view.View A(android.view.View r3) {
        /*
            r2 = this;
        L0:
            android.view.ViewParent r0 = r3.getParent()
            if (r0 == 0) goto L10
            if (r0 == r2) goto L10
            boolean r1 = r0 instanceof android.view.View
            if (r1 == 0) goto L10
            r3 = r0
            android.view.View r3 = (android.view.View) r3
            goto L0
        L10:
            if (r0 != r2) goto L13
            goto L14
        L13:
            r3 = 0
        L14:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.A(android.view.View):android.view.View");
    }

    /* JADX WARN: Code restructure failed: missing block: B:26:0x005c, code lost:
    
        if (r7 == 2) goto L16;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean B(android.view.MotionEvent r13) {
        /*
            r12 = this;
            int r0 = r13.getAction()
            java.util.ArrayList r1 = r12.q
            int r2 = r1.size()
            r3 = 0
            r4 = 0
        Lc:
            if (r4 >= r2) goto L6c
            java.lang.Object r5 = r1.get(r4)
            androidx.recyclerview.widget.w0 r5 = (androidx.recyclerview.widget.w0) r5
            r6 = r5
            androidx.recyclerview.widget.q r6 = (androidx.recyclerview.widget.q) r6
            int r7 = r6.f287v
            r8 = 1
            r9 = 2
            if (r7 != r8) goto L5c
            float r7 = r13.getX()
            float r10 = r13.getY()
            boolean r7 = r6.b(r7, r10)
            float r10 = r13.getX()
            float r11 = r13.getY()
            boolean r10 = r6.a(r10, r11)
            int r11 = r13.getAction()
            if (r11 != 0) goto L60
            if (r7 != 0) goto L3f
            if (r10 == 0) goto L60
        L3f:
            if (r10 == 0) goto L4c
            r6.f288w = r8
            float r7 = r13.getX()
            int r7 = (int) r7
            float r7 = (float) r7
            r6.f282p = r7
            goto L58
        L4c:
            if (r7 == 0) goto L58
            r6.f288w = r9
            float r7 = r13.getY()
            int r7 = (int) r7
            float r7 = (float) r7
            r6.f279m = r7
        L58:
            r6.d(r9)
            goto L5e
        L5c:
            if (r7 != r9) goto L60
        L5e:
            r6 = 1
            goto L61
        L60:
            r6 = 0
        L61:
            if (r6 == 0) goto L69
            r6 = 3
            if (r0 == r6) goto L69
            r12.f87r = r5
            return r8
        L69:
            int r4 = r4 + 1
            goto Lc
        L6c:
            return r3
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.B(android.view.MotionEvent):boolean");
    }

    public final void C(int[] iArr) {
        int e2 = this.f73f.e();
        if (e2 == 0) {
            iArr[0] = -1;
            iArr[1] = -1;
            return;
        }
        int i2 = Integer.MAX_VALUE;
        int i3 = Integer.MIN_VALUE;
        for (int i4 = 0; i4 < e2; i4++) {
            i1 I = I(this.f73f.d(i4));
            if (!I.shouldIgnore()) {
                int layoutPosition = I.getLayoutPosition();
                if (layoutPosition < i2) {
                    i2 = layoutPosition;
                }
                if (layoutPosition > i3) {
                    i3 = layoutPosition;
                }
            }
        }
        iArr[0] = i2;
        iArr[1] = i3;
    }

    public final i1 E(int i2) {
        i1 i1Var = null;
        if (this.C) {
            return null;
        }
        int h2 = this.f73f.h();
        for (int i3 = 0; i3 < h2; i3++) {
            i1 I = I(this.f73f.g(i3));
            if (I != null && !I.isRemoved() && F(I) == i2) {
                if (!this.f73f.j(I.itemView)) {
                    return I;
                }
                i1Var = I;
            }
        }
        return i1Var;
    }

    public final int F(i1 i1Var) {
        if (i1Var.hasAnyOfTheFlags(524) || !i1Var.isBound()) {
            return -1;
        }
        b bVar = this.f71e;
        int i2 = i1Var.mPosition;
        ArrayList arrayList = bVar.f132b;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            a aVar = (a) arrayList.get(i3);
            int i4 = aVar.f107a;
            if (i4 != 1) {
                if (i4 == 2) {
                    int i5 = aVar.f108b;
                    if (i5 <= i2) {
                        int i6 = aVar.f110d;
                        if (i5 + i6 > i2) {
                            return -1;
                        }
                        i2 -= i6;
                    } else {
                        continue;
                    }
                } else if (i4 == 8) {
                    int i7 = aVar.f108b;
                    if (i7 == i2) {
                        i2 = aVar.f110d;
                    } else {
                        if (i7 < i2) {
                            i2--;
                        }
                        if (aVar.f110d <= i2) {
                            i2++;
                        }
                    }
                }
            } else if (aVar.f108b <= i2) {
                i2 += aVar.f110d;
            }
        }
        return i2;
    }

    public final long G(i1 i1Var) {
        return this.f83m.hasStableIds() ? i1Var.getItemId() : i1Var.mPosition;
    }

    public final i1 H(View view) {
        ViewParent parent = view.getParent();
        if (parent == null || parent == this) {
            return I(view);
        }
        throw new IllegalArgumentException("View " + view + " is not a direct child of " + this);
    }

    public final Rect J(View view) {
        u0 u0Var = (u0) view.getLayoutParams();
        boolean z2 = u0Var.f341c;
        Rect rect = u0Var.f340b;
        if (!z2) {
            return rect;
        }
        if (this.f74f0.f159f && (u0Var.b() || u0Var.f339a.isInvalid())) {
            return rect;
        }
        rect.set(0, 0, 0, 0);
        ArrayList arrayList = this.f86p;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            Rect rect2 = this.f80j;
            rect2.set(0, 0, 0, 0);
            ((q0) arrayList.get(i2)).getClass();
            ((u0) view.getLayoutParams()).a();
            rect2.set(0, 0, 0, 0);
            rect.left += rect2.left;
            rect.top += rect2.top;
            rect.right += rect2.right;
            rect.bottom += rect2.bottom;
        }
        u0Var.f341c = false;
        return rect;
    }

    public final boolean K() {
        return this.E > 0;
    }

    public final void L() {
        int h2 = this.f73f.h();
        for (int i2 = 0; i2 < h2; i2++) {
            ((u0) this.f73f.g(i2).getLayoutParams()).f341c = true;
        }
        ArrayList arrayList = this.f67c.f125c;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            u0 u0Var = (u0) ((i1) arrayList.get(i3)).itemView.getLayoutParams();
            if (u0Var != null) {
                u0Var.f341c = true;
            }
        }
    }

    public final void M(int i2, int i3, boolean z2) {
        int i4 = i2 + i3;
        int h2 = this.f73f.h();
        for (int i5 = 0; i5 < h2; i5++) {
            i1 I = I(this.f73f.g(i5));
            if (I != null && !I.shouldIgnore()) {
                int i6 = I.mPosition;
                if (i6 >= i4) {
                    if (z0) {
                        Log.d("RecyclerView", "offsetPositionRecordsForRemove attached child " + i5 + " holder " + I + " now at position " + (I.mPosition - i3));
                    }
                    I.offsetPosition(-i3, z2);
                } else if (i6 >= i2) {
                    if (z0) {
                        Log.d("RecyclerView", "offsetPositionRecordsForRemove attached child " + i5 + " holder " + I + " now REMOVED");
                    }
                    I.flagRemovedAndOffsetPosition(i2 - 1, -i3, z2);
                }
                this.f74f0.f158e = true;
            }
        }
        a1 a1Var = this.f67c;
        ArrayList arrayList = a1Var.f125c;
        int size = arrayList.size();
        while (true) {
            size--;
            if (size < 0) {
                requestLayout();
                return;
            }
            i1 i1Var = (i1) arrayList.get(size);
            if (i1Var != null) {
                int i7 = i1Var.mPosition;
                if (i7 >= i4) {
                    if (z0) {
                        Log.d("RecyclerView", "offsetPositionRecordsForRemove cached " + size + " holder " + i1Var + " now at position " + (i1Var.mPosition - i3));
                    }
                    i1Var.offsetPosition(-i3, z2);
                } else if (i7 >= i2) {
                    i1Var.addFlags(8);
                    a1Var.g(size);
                }
            }
        }
    }

    public final void N() {
        this.E++;
    }

    public final void O(boolean z2) {
        int i2;
        int i3 = this.E - 1;
        this.E = i3;
        if (i3 < 1) {
            if (y0 && i3 < 0) {
                throw new IllegalStateException(c.b(this, new StringBuilder("layout or scroll counter cannot go below zero.Some calls are not matching")));
            }
            this.E = 0;
            if (z2) {
                int i4 = this.f95z;
                this.f95z = 0;
                if (i4 != 0) {
                    AccessibilityManager accessibilityManager = this.B;
                    if (accessibilityManager != null && accessibilityManager.isEnabled()) {
                        AccessibilityEvent obtain = AccessibilityEvent.obtain();
                        obtain.setEventType(2048);
                        h.b.b(obtain, i4);
                        sendAccessibilityEventUnchecked(obtain);
                    }
                }
                ArrayList arrayList = this.s0;
                for (int size = arrayList.size() - 1; size >= 0; size--) {
                    i1 i1Var = (i1) arrayList.get(size);
                    if (i1Var.itemView.getParent() == this && !i1Var.shouldIgnore() && (i2 = i1Var.mPendingAccessibilityState) != -1) {
                        View view = i1Var.itemView;
                        Field field = g.v.f448a;
                        g.j.s(view, i2);
                        i1Var.mPendingAccessibilityState = -1;
                    }
                }
                arrayList.clear();
            }
        }
    }

    public final void P(MotionEvent motionEvent) {
        int actionIndex = motionEvent.getActionIndex();
        if (motionEvent.getPointerId(actionIndex) == this.N) {
            int i2 = actionIndex == 0 ? 1 : 0;
            this.N = motionEvent.getPointerId(i2);
            int x2 = (int) (motionEvent.getX(i2) + 0.5f);
            this.R = x2;
            this.P = x2;
            int y2 = (int) (motionEvent.getY(i2) + 0.5f);
            this.S = y2;
            this.Q = y2;
        }
    }

    public final void Q() {
        if (this.l0 || !this.f88s) {
            return;
        }
        Field field = g.v.f448a;
        g.j.m(this, this.t0);
        this.l0 = true;
    }

    public final void R() {
        boolean z2;
        boolean z3 = false;
        if (this.C) {
            b bVar = this.f71e;
            bVar.l(bVar.f132b);
            bVar.l(bVar.f133c);
            bVar.f136f = 0;
            if (this.D) {
                this.f84n.T();
            }
        }
        if (this.L != null && this.f84n.t0()) {
            this.f71e.j();
        } else {
            this.f71e.c();
        }
        boolean z4 = this.i0 || this.j0;
        boolean z5 = this.f90u && this.L != null && ((z2 = this.C) || z4 || this.f84n.f320e) && (!z2 || this.f83m.hasStableIds());
        e1 e1Var = this.f74f0;
        e1Var.f162i = z5;
        if (z5 && z4 && !this.C) {
            if (this.L != null && this.f84n.t0()) {
                z3 = true;
            }
        }
        e1Var.f163j = z3;
    }

    public final void S(boolean z2) {
        this.D = z2 | this.D;
        this.C = true;
        int h2 = this.f73f.h();
        for (int i2 = 0; i2 < h2; i2++) {
            i1 I = I(this.f73f.g(i2));
            if (I != null && !I.shouldIgnore()) {
                I.addFlags(6);
            }
        }
        L();
        a1 a1Var = this.f67c;
        ArrayList arrayList = a1Var.f125c;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            i1 i1Var = (i1) arrayList.get(i3);
            if (i1Var != null) {
                i1Var.addFlags(6);
                i1Var.addChangePayload(null);
            }
        }
        i0 i0Var = a1Var.f130h.f83m;
        if (i0Var == null || !i0Var.hasStableIds()) {
            a1Var.f();
        }
    }

    public final void T(i1 i1Var, n0 n0Var) {
        i1Var.setFlags(0, 8192);
        boolean z2 = this.f74f0.f160g;
        t1 t1Var = this.f75g;
        if (z2 && i1Var.isUpdated() && !i1Var.isRemoved() && !i1Var.shouldIgnore()) {
            t1Var.b(G(i1Var), i1Var);
        }
        t1Var.d(i1Var, n0Var);
    }

    public final int U(float f2, int i2) {
        float A;
        EdgeEffect edgeEffect;
        float height = f2 / getHeight();
        float width = i2 / getWidth();
        EdgeEffect edgeEffect2 = this.H;
        float f3 = B0;
        if (edgeEffect2 == null || b0.d.w(edgeEffect2) == B0) {
            EdgeEffect edgeEffect3 = this.J;
            if (edgeEffect3 != null && b0.d.w(edgeEffect3) != B0) {
                if (canScrollHorizontally(1)) {
                    edgeEffect = this.J;
                    edgeEffect.onRelease();
                } else {
                    A = b0.d.A(this.J, width, height);
                    if (b0.d.w(this.J) == B0) {
                        this.J.onRelease();
                    }
                    f3 = A;
                }
            }
            return Math.round(f3 * getWidth());
        }
        if (canScrollHorizontally(-1)) {
            edgeEffect = this.H;
            edgeEffect.onRelease();
        } else {
            A = -b0.d.A(this.H, -width, 1.0f - height);
            if (b0.d.w(this.H) == B0) {
                this.H.onRelease();
            }
            f3 = A;
        }
        invalidate();
        return Math.round(f3 * getWidth());
    }

    public final int V(float f2, int i2) {
        float A;
        EdgeEffect edgeEffect;
        float width = f2 / getWidth();
        float height = i2 / getHeight();
        EdgeEffect edgeEffect2 = this.I;
        float f3 = B0;
        if (edgeEffect2 == null || b0.d.w(edgeEffect2) == B0) {
            EdgeEffect edgeEffect3 = this.K;
            if (edgeEffect3 != null && b0.d.w(edgeEffect3) != B0) {
                if (canScrollVertically(1)) {
                    edgeEffect = this.K;
                    edgeEffect.onRelease();
                } else {
                    A = b0.d.A(this.K, height, 1.0f - width);
                    if (b0.d.w(this.K) == B0) {
                        this.K.onRelease();
                    }
                    f3 = A;
                }
            }
            return Math.round(f3 * getHeight());
        }
        if (canScrollVertically(-1)) {
            edgeEffect = this.I;
            edgeEffect.onRelease();
        } else {
            A = -b0.d.A(this.I, -height, width);
            if (b0.d.w(this.I) == B0) {
                this.I.onRelease();
            }
            f3 = A;
        }
        invalidate();
        return Math.round(f3 * getHeight());
    }

    public final void W(View view, View view2) {
        View view3 = view2 != null ? view2 : view;
        int width = view3.getWidth();
        int height = view3.getHeight();
        Rect rect = this.f80j;
        rect.set(0, 0, width, height);
        ViewGroup.LayoutParams layoutParams = view3.getLayoutParams();
        if (layoutParams instanceof u0) {
            u0 u0Var = (u0) layoutParams;
            if (!u0Var.f341c) {
                int i2 = rect.left;
                Rect rect2 = u0Var.f340b;
                rect.left = i2 - rect2.left;
                rect.right += rect2.right;
                rect.top -= rect2.top;
                rect.bottom += rect2.bottom;
            }
        }
        if (view2 != null) {
            offsetDescendantRectToMyCoords(view2, rect);
            offsetRectIntoDescendantCoords(view, rect);
        }
        this.f84n.g0(this, view, this.f80j, !this.f90u, view2 == null);
    }

    public final void X() {
        VelocityTracker velocityTracker = this.O;
        if (velocityTracker != null) {
            velocityTracker.clear();
        }
        boolean z2 = false;
        f0(0);
        EdgeEffect edgeEffect = this.H;
        if (edgeEffect != null) {
            edgeEffect.onRelease();
            z2 = this.H.isFinished();
        }
        EdgeEffect edgeEffect2 = this.I;
        if (edgeEffect2 != null) {
            edgeEffect2.onRelease();
            z2 |= this.I.isFinished();
        }
        EdgeEffect edgeEffect3 = this.J;
        if (edgeEffect3 != null) {
            edgeEffect3.onRelease();
            z2 |= this.J.isFinished();
        }
        EdgeEffect edgeEffect4 = this.K;
        if (edgeEffect4 != null) {
            edgeEffect4.onRelease();
            z2 |= this.K.isFinished();
        }
        if (z2) {
            Field field = g.v.f448a;
            g.j.k(this);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:24:0x00d6  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0109  */
    /* JADX WARN: Removed duplicated region for block: B:32:0x00ec  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean Y(int r19, int r20, android.view.MotionEvent r21, int r22) {
        /*
            Method dump skipped, instructions count: 308
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.Y(int, int, android.view.MotionEvent, int):boolean");
    }

    public final void Z(int i2, int i3, int[] iArr) {
        i1 i1Var;
        d0();
        N();
        int i4 = e.b.f393a;
        e.a.a("RV Scroll");
        e1 e1Var = this.f74f0;
        z(e1Var);
        a1 a1Var = this.f67c;
        int i0 = i2 != 0 ? this.f84n.i0(i2, a1Var, e1Var) : 0;
        int k0 = i3 != 0 ? this.f84n.k0(i3, a1Var, e1Var) : 0;
        e.a.b();
        int e2 = this.f73f.e();
        for (int i5 = 0; i5 < e2; i5++) {
            View d2 = this.f73f.d(i5);
            i1 H = H(d2);
            if (H != null && (i1Var = H.mShadowingHolder) != null) {
                View view = i1Var.itemView;
                int left = d2.getLeft();
                int top = d2.getTop();
                if (left != view.getLeft() || top != view.getTop()) {
                    view.layout(left, top, view.getWidth() + left, view.getHeight() + top);
                }
            }
        }
        O(true);
        e0(false);
        if (iArr != null) {
            iArr[0] = i0;
            iArr[1] = k0;
        }
    }

    public final void a0(int i2) {
        if (this.f93x) {
            return;
        }
        setScrollState(0);
        h1 h1Var = this.f68c0;
        h1Var.f191g.removeCallbacks(h1Var);
        h1Var.f187c.abortAnimation();
        t0 t0Var = this.f84n;
        if (t0Var == null) {
            Log.e("RecyclerView", "Cannot scroll to position a LayoutManager set. Call setLayoutManager with a non-null argument.");
        } else {
            t0Var.j0(i2);
            awakenScrollBars();
        }
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void addFocusables(ArrayList arrayList, int i2, int i3) {
        t0 t0Var = this.f84n;
        if (t0Var != null) {
            t0Var.getClass();
        }
        super.addFocusables(arrayList, i2, i3);
    }

    public final boolean b0(EdgeEffect edgeEffect, int i2, int i3) {
        if (i2 > 0) {
            return true;
        }
        float w2 = b0.d.w(edgeEffect) * i3;
        float abs = Math.abs(-i2) * 0.35f;
        float f2 = this.f63a * 0.015f;
        double log = Math.log(abs / f2);
        double d2 = B0;
        return ((float) (Math.exp((d2 / (d2 - 1.0d)) * log) * ((double) f2))) < w2;
    }

    public final void c0(int i2, int i3, boolean z2) {
        t0 t0Var = this.f84n;
        if (t0Var == null) {
            Log.e("RecyclerView", "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.f93x) {
            return;
        }
        int i4 = !t0Var.c() ? 0 : i2;
        int i5 = !this.f84n.d() ? 0 : i3;
        if (i4 == 0 && i5 == 0) {
            return;
        }
        if (z2) {
            int i6 = i4 != 0 ? 1 : 0;
            if (i5 != 0) {
                i6 |= 2;
            }
            getScrollingChildHelper().d(i6, 1);
        }
        h1 h1Var = this.f68c0;
        RecyclerView recyclerView = h1Var.f191g;
        int abs = Math.abs(i4);
        int abs2 = Math.abs(i5);
        boolean z3 = abs > abs2;
        int width = z3 ? recyclerView.getWidth() : recyclerView.getHeight();
        if (!z3) {
            abs = abs2;
        }
        int min = Math.min((int) (((abs / width) + 1.0f) * 300.0f), 2000);
        Interpolator interpolator = h1Var.f188d;
        g0 g0Var = G0;
        if (interpolator != g0Var) {
            h1Var.f188d = g0Var;
            h1Var.f187c = new OverScroller(recyclerView.getContext(), g0Var);
        }
        h1Var.f186b = 0;
        h1Var.f185a = 0;
        recyclerView.setScrollState(2);
        h1Var.f187c.startScroll(0, 0, i4, i5, min);
        if (Build.VERSION.SDK_INT < 23) {
            h1Var.f187c.computeScrollOffset();
        }
        if (h1Var.f189e) {
            h1Var.f190f = true;
            return;
        }
        RecyclerView recyclerView2 = h1Var.f191g;
        recyclerView2.removeCallbacks(h1Var);
        Field field = g.v.f448a;
        g.j.m(recyclerView2, h1Var);
    }

    @Override // android.view.ViewGroup
    public final boolean checkLayoutParams(ViewGroup.LayoutParams layoutParams) {
        return (layoutParams instanceof u0) && this.f84n.e((u0) layoutParams);
    }

    @Override // android.view.View
    public final int computeHorizontalScrollExtent() {
        t0 t0Var = this.f84n;
        if (t0Var != null && t0Var.c()) {
            return this.f84n.i(this.f74f0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollOffset() {
        t0 t0Var = this.f84n;
        if (t0Var != null && t0Var.c()) {
            return this.f84n.j(this.f74f0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeHorizontalScrollRange() {
        t0 t0Var = this.f84n;
        if (t0Var != null && t0Var.c()) {
            return this.f84n.k(this.f74f0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollExtent() {
        t0 t0Var = this.f84n;
        if (t0Var != null && t0Var.d()) {
            return this.f84n.l(this.f74f0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollOffset() {
        t0 t0Var = this.f84n;
        if (t0Var != null && t0Var.d()) {
            return this.f84n.m(this.f74f0);
        }
        return 0;
    }

    @Override // android.view.View
    public final int computeVerticalScrollRange() {
        t0 t0Var = this.f84n;
        if (t0Var != null && t0Var.d()) {
            return this.f84n.n(this.f74f0);
        }
        return 0;
    }

    public final void d0() {
        int i2 = this.f91v + 1;
        this.f91v = i2;
        if (i2 != 1 || this.f93x) {
            return;
        }
        this.f92w = false;
    }

    @Override // android.view.View
    public final boolean dispatchNestedFling(float f2, float f3, boolean z2) {
        ViewParent c2;
        g.f scrollingChildHelper = getScrollingChildHelper();
        if (!scrollingChildHelper.f426d || (c2 = scrollingChildHelper.c(0)) == null) {
            return false;
        }
        try {
            return g.b0.a(c2, scrollingChildHelper.f425c, f2, f3, z2);
        } catch (AbstractMethodError e2) {
            Log.e("ViewParentCompat", "ViewParent " + c2 + " does not implement interface method onNestedFling", e2);
            return false;
        }
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreFling(float f2, float f3) {
        ViewParent c2;
        g.f scrollingChildHelper = getScrollingChildHelper();
        if (!scrollingChildHelper.f426d || (c2 = scrollingChildHelper.c(0)) == null) {
            return false;
        }
        try {
            return g.b0.b(c2, scrollingChildHelper.f425c, f2, f3);
        } catch (AbstractMethodError e2) {
            Log.e("ViewParentCompat", "ViewParent " + c2 + " does not implement interface method onNestedPreFling", e2);
            return false;
        }
    }

    @Override // android.view.View
    public final boolean dispatchNestedPreScroll(int i2, int i3, int[] iArr, int[] iArr2) {
        return getScrollingChildHelper().a(i2, i3, iArr, iArr2, 0);
    }

    @Override // android.view.View
    public final boolean dispatchNestedScroll(int i2, int i3, int i4, int i5, int[] iArr) {
        return getScrollingChildHelper().b(i2, i3, i4, i5, iArr, 0, null);
    }

    @Override // android.view.View
    public final boolean dispatchPopulateAccessibilityEvent(AccessibilityEvent accessibilityEvent) {
        onPopulateAccessibilityEvent(accessibilityEvent);
        return true;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchRestoreInstanceState(SparseArray sparseArray) {
        dispatchThawSelfOnly(sparseArray);
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void dispatchSaveInstanceState(SparseArray sparseArray) {
        dispatchFreezeSelfOnly(sparseArray);
    }

    @Override // android.view.View
    public final void draw(Canvas canvas) {
        boolean z2;
        float f2;
        float f3;
        int i2;
        super.draw(canvas);
        ArrayList arrayList = this.f86p;
        int size = arrayList.size();
        boolean z3 = false;
        int i3 = 0;
        while (true) {
            if (i3 >= size) {
                break;
            }
            q qVar = (q) ((q0) arrayList.get(i3));
            if (qVar.q != qVar.f284s.getWidth() || qVar.f283r != qVar.f284s.getHeight()) {
                qVar.q = qVar.f284s.getWidth();
                qVar.f283r = qVar.f284s.getHeight();
                qVar.d(0);
            } else if (qVar.A != 0) {
                if (qVar.f285t) {
                    int i4 = qVar.q;
                    int i5 = qVar.f271e;
                    int i6 = i4 - i5;
                    int i7 = qVar.f278l;
                    int i8 = qVar.f277k;
                    int i9 = i7 - (i8 / 2);
                    StateListDrawable stateListDrawable = qVar.f269c;
                    stateListDrawable.setBounds(0, 0, i5, i8);
                    int i10 = qVar.f283r;
                    Drawable drawable = qVar.f270d;
                    drawable.setBounds(0, 0, qVar.f272f, i10);
                    RecyclerView recyclerView = qVar.f284s;
                    Field field = g.v.f448a;
                    if (g.k.d(recyclerView) == 1) {
                        drawable.draw(canvas);
                        canvas.translate(i5, i9);
                        canvas.scale(-1.0f, 1.0f);
                        stateListDrawable.draw(canvas);
                        canvas.scale(-1.0f, 1.0f);
                        i2 = -i5;
                    } else {
                        canvas.translate(i6, B0);
                        drawable.draw(canvas);
                        canvas.translate(B0, i9);
                        stateListDrawable.draw(canvas);
                        i2 = -i6;
                    }
                    canvas.translate(i2, -i9);
                }
                if (qVar.f286u) {
                    int i11 = qVar.f283r;
                    int i12 = qVar.f275i;
                    int i13 = i11 - i12;
                    int i14 = qVar.f281o;
                    int i15 = qVar.f280n;
                    int i16 = i14 - (i15 / 2);
                    StateListDrawable stateListDrawable2 = qVar.f273g;
                    stateListDrawable2.setBounds(0, 0, i15, i12);
                    int i17 = qVar.q;
                    Drawable drawable2 = qVar.f274h;
                    drawable2.setBounds(0, 0, i17, qVar.f276j);
                    canvas.translate(B0, i13);
                    drawable2.draw(canvas);
                    canvas.translate(i16, B0);
                    stateListDrawable2.draw(canvas);
                    canvas.translate(-i16, -i13);
                }
            }
            i3++;
        }
        EdgeEffect edgeEffect = this.H;
        if (edgeEffect == null || edgeEffect.isFinished()) {
            z2 = false;
        } else {
            int save = canvas.save();
            int paddingBottom = this.f77h ? getPaddingBottom() : 0;
            canvas.rotate(270.0f);
            canvas.translate((-getHeight()) + paddingBottom, B0);
            EdgeEffect edgeEffect2 = this.H;
            z2 = edgeEffect2 != null && edgeEffect2.draw(canvas);
            canvas.restoreToCount(save);
        }
        EdgeEffect edgeEffect3 = this.I;
        if (edgeEffect3 != null && !edgeEffect3.isFinished()) {
            int save2 = canvas.save();
            if (this.f77h) {
                canvas.translate(getPaddingLeft(), getPaddingTop());
            }
            EdgeEffect edgeEffect4 = this.I;
            z2 |= edgeEffect4 != null && edgeEffect4.draw(canvas);
            canvas.restoreToCount(save2);
        }
        EdgeEffect edgeEffect5 = this.J;
        if (edgeEffect5 != null && !edgeEffect5.isFinished()) {
            int save3 = canvas.save();
            int width = getWidth();
            int paddingTop = this.f77h ? getPaddingTop() : 0;
            canvas.rotate(90.0f);
            canvas.translate(paddingTop, -width);
            EdgeEffect edgeEffect6 = this.J;
            z2 |= edgeEffect6 != null && edgeEffect6.draw(canvas);
            canvas.restoreToCount(save3);
        }
        EdgeEffect edgeEffect7 = this.K;
        if (edgeEffect7 != null && !edgeEffect7.isFinished()) {
            int save4 = canvas.save();
            canvas.rotate(180.0f);
            if (this.f77h) {
                f2 = getPaddingRight() + (-getWidth());
                f3 = getPaddingBottom() + (-getHeight());
            } else {
                f2 = -getWidth();
                f3 = -getHeight();
            }
            canvas.translate(f2, f3);
            EdgeEffect edgeEffect8 = this.K;
            if (edgeEffect8 != null && edgeEffect8.draw(canvas)) {
                z3 = true;
            }
            z2 |= z3;
            canvas.restoreToCount(save4);
        }
        if ((z2 || this.L == null || arrayList.size() <= 0 || !this.L.f()) ? z2 : true) {
            Field field2 = g.v.f448a;
            g.j.k(this);
        }
    }

    @Override // android.view.ViewGroup
    public final boolean drawChild(Canvas canvas, View view, long j2) {
        return super.drawChild(canvas, view, j2);
    }

    public final void e0(boolean z2) {
        if (this.f91v < 1) {
            if (y0) {
                throw new IllegalStateException(c.b(this, new StringBuilder("stopInterceptRequestLayout was called more times than startInterceptRequestLayout.")));
            }
            this.f91v = 1;
        }
        if (!z2 && !this.f93x) {
            this.f92w = false;
        }
        if (this.f91v == 1) {
            if (z2 && this.f92w && !this.f93x && this.f84n != null && this.f83m != null) {
                o();
            }
            if (!this.f93x) {
                this.f92w = false;
            }
        }
        this.f91v--;
    }

    public final void f0(int i2) {
        getScrollingChildHelper().e(i2);
    }

    /* JADX WARN: Code restructure failed: missing block: B:103:0x0192, code lost:
    
        if ((r3 * r1) >= 0) goto L136;
     */
    /* JADX WARN: Code restructure failed: missing block: B:90:0x0163, code lost:
    
        if (r6 > 0) goto L135;
     */
    /* JADX WARN: Code restructure failed: missing block: B:93:0x017a, code lost:
    
        if (r3 > 0) goto L135;
     */
    /* JADX WARN: Code restructure failed: missing block: B:94:0x017d, code lost:
    
        if (r6 < 0) goto L135;
     */
    /* JADX WARN: Code restructure failed: missing block: B:95:0x0180, code lost:
    
        if (r3 < 0) goto L135;
     */
    /* JADX WARN: Code restructure failed: missing block: B:99:0x0189, code lost:
    
        if ((r3 * r1) <= 0) goto L136;
     */
    /* JADX WARN: Removed duplicated region for block: B:117:0x019a  */
    /* JADX WARN: Removed duplicated region for block: B:119:? A[RETURN, SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:26:0x005e  */
    /* JADX WARN: Removed duplicated region for block: B:28:0x0063  */
    /* JADX WARN: Removed duplicated region for block: B:31:0x0069  */
    /* JADX WARN: Removed duplicated region for block: B:34:0x0074  */
    /* JADX WARN: Removed duplicated region for block: B:35:0x0076  */
    /* JADX WARN: Removed duplicated region for block: B:36:0x006c  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0060  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x0079  */
    @Override // android.view.ViewGroup, android.view.ViewParent
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final android.view.View focusSearch(android.view.View r14, int r15) {
        /*
            Method dump skipped, instructions count: 415
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.focusSearch(android.view.View, int):android.view.View");
    }

    public final void g(i1 i1Var) {
        View view = i1Var.itemView;
        boolean z2 = view.getParent() == this;
        this.f67c.l(H(view));
        if (i1Var.isTmpDetached()) {
            this.f73f.b(view, -1, view.getLayoutParams(), true);
            return;
        }
        e eVar = this.f73f;
        if (!z2) {
            eVar.a(view, -1, true);
            return;
        }
        int indexOfChild = eVar.f146a.f260a.indexOfChild(view);
        if (indexOfChild >= 0) {
            eVar.f147b.h(indexOfChild);
            eVar.i(view);
        } else {
            throw new IllegalArgumentException("view is not a child, cannot hide " + view);
        }
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateDefaultLayoutParams() {
        t0 t0Var = this.f84n;
        if (t0Var != null) {
            return t0Var.q();
        }
        throw new IllegalStateException(c.b(this, new StringBuilder("RecyclerView has no LayoutManager")));
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(AttributeSet attributeSet) {
        t0 t0Var = this.f84n;
        if (t0Var != null) {
            return t0Var.r(getContext(), attributeSet);
        }
        throw new IllegalStateException(c.b(this, new StringBuilder("RecyclerView has no LayoutManager")));
    }

    @Override // android.view.ViewGroup, android.view.View
    public CharSequence getAccessibilityClassName() {
        return "androidx.recyclerview.widget.RecyclerView";
    }

    public i0 getAdapter() {
        return this.f83m;
    }

    @Override // android.view.View
    public int getBaseline() {
        t0 t0Var = this.f84n;
        if (t0Var == null) {
            return super.getBaseline();
        }
        t0Var.getClass();
        return -1;
    }

    @Override // android.view.ViewGroup
    public final int getChildDrawingOrder(int i2, int i3) {
        return super.getChildDrawingOrder(i2, i3);
    }

    @Override // android.view.ViewGroup
    public boolean getClipToPadding() {
        return this.f77h;
    }

    public k1 getCompatAccessibilityDelegate() {
        return this.m0;
    }

    public m0 getEdgeEffectFactory() {
        return this.G;
    }

    public o0 getItemAnimator() {
        return this.L;
    }

    public int getItemDecorationCount() {
        return this.f86p.size();
    }

    public t0 getLayoutManager() {
        return this.f84n;
    }

    public int getMaxFlingVelocity() {
        return this.V;
    }

    public int getMinFlingVelocity() {
        return this.U;
    }

    public long getNanoTime() {
        if (E0) {
            return System.nanoTime();
        }
        return 0L;
    }

    public v0 getOnFlingListener() {
        return null;
    }

    public boolean getPreserveFocusAfterLayout() {
        return this.f66b0;
    }

    public z0 getRecycledViewPool() {
        return this.f67c.c();
    }

    public int getScrollState() {
        return this.M;
    }

    public final void h(String str) {
        if (K()) {
            if (str != null) {
                throw new IllegalStateException(str);
            }
            throw new IllegalStateException(c.b(this, new StringBuilder("Cannot call this method while RecyclerView is computing a layout or scrolling")));
        }
        if (this.F > 0) {
            Log.w("RecyclerView", "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame.", new IllegalStateException(c.b(this, new StringBuilder(""))));
        }
    }

    @Override // android.view.View
    public final boolean hasNestedScrollingParent() {
        return getScrollingChildHelper().c(0) != null;
    }

    @Override // android.view.View
    public final boolean isAttachedToWindow() {
        return this.f88s;
    }

    @Override // android.view.ViewGroup
    public final boolean isLayoutSuppressed() {
        return this.f93x;
    }

    @Override // android.view.View
    public final boolean isNestedScrollingEnabled() {
        return getScrollingChildHelper().f426d;
    }

    public final void j() {
        int h2 = this.f73f.h();
        for (int i2 = 0; i2 < h2; i2++) {
            i1 I = I(this.f73f.g(i2));
            if (!I.shouldIgnore()) {
                I.clearOldPosition();
            }
        }
        a1 a1Var = this.f67c;
        ArrayList arrayList = a1Var.f125c;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            ((i1) arrayList.get(i3)).clearOldPosition();
        }
        ArrayList arrayList2 = a1Var.f123a;
        int size2 = arrayList2.size();
        for (int i4 = 0; i4 < size2; i4++) {
            ((i1) arrayList2.get(i4)).clearOldPosition();
        }
        ArrayList arrayList3 = a1Var.f124b;
        if (arrayList3 != null) {
            int size3 = arrayList3.size();
            for (int i5 = 0; i5 < size3; i5++) {
                ((i1) a1Var.f124b.get(i5)).clearOldPosition();
            }
        }
    }

    public final void k(int i2, int i3) {
        boolean z2;
        EdgeEffect edgeEffect = this.H;
        if (edgeEffect == null || edgeEffect.isFinished() || i2 <= 0) {
            z2 = false;
        } else {
            this.H.onRelease();
            z2 = this.H.isFinished();
        }
        EdgeEffect edgeEffect2 = this.J;
        if (edgeEffect2 != null && !edgeEffect2.isFinished() && i2 < 0) {
            this.J.onRelease();
            z2 |= this.J.isFinished();
        }
        EdgeEffect edgeEffect3 = this.I;
        if (edgeEffect3 != null && !edgeEffect3.isFinished() && i3 > 0) {
            this.I.onRelease();
            z2 |= this.I.isFinished();
        }
        EdgeEffect edgeEffect4 = this.K;
        if (edgeEffect4 != null && !edgeEffect4.isFinished() && i3 < 0) {
            this.K.onRelease();
            z2 |= this.K.isFinished();
        }
        if (z2) {
            Field field = g.v.f448a;
            g.j.k(this);
        }
    }

    public final void m() {
        if (!this.f90u || this.C) {
            int i2 = e.b.f393a;
            e.a.a("RV FullInvalidate");
            o();
            e.a.b();
            return;
        }
        if (this.f71e.g()) {
            b bVar = this.f71e;
            int i3 = bVar.f136f;
            boolean z2 = false;
            if ((4 & i3) != 0) {
                if (!((i3 & 11) != 0)) {
                    int i4 = e.b.f393a;
                    e.a.a("RV PartialInvalidate");
                    d0();
                    N();
                    this.f71e.j();
                    if (!this.f92w) {
                        int e2 = this.f73f.e();
                        int i5 = 0;
                        while (true) {
                            if (i5 < e2) {
                                i1 I = I(this.f73f.d(i5));
                                if (I != null && !I.shouldIgnore() && I.isUpdated()) {
                                    z2 = true;
                                    break;
                                }
                                i5++;
                            } else {
                                break;
                            }
                        }
                        if (z2) {
                            o();
                        } else {
                            this.f71e.b();
                        }
                    }
                    e0(true);
                    O(true);
                    e.a.b();
                }
            }
            if (bVar.g()) {
                int i6 = e.b.f393a;
                e.a.a("RV FullInvalidate");
                o();
                e.a.b();
            }
        }
    }

    public final void n(int i2, int i3) {
        int paddingRight = getPaddingRight() + getPaddingLeft();
        Field field = g.v.f448a;
        setMeasuredDimension(t0.f(i2, paddingRight, g.j.e(this)), t0.f(i3, getPaddingBottom() + getPaddingTop(), g.j.d(this)));
    }

    /* JADX WARN: Code restructure failed: missing block: B:186:0x03a2, code lost:
    
        if (r18.f73f.j(getFocusedChild()) == false) goto L257;
     */
    /* JADX WARN: Removed duplicated region for block: B:151:0x0301  */
    /* JADX WARN: Removed duplicated region for block: B:153:0x0304 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:160:0x0331  */
    /* JADX WARN: Removed duplicated region for block: B:163:0x033a  */
    /* JADX WARN: Removed duplicated region for block: B:170:0x0367  */
    /* JADX WARN: Removed duplicated region for block: B:185:0x0398  */
    /* JADX WARN: Removed duplicated region for block: B:216:0x0455  */
    /* JADX WARN: Removed duplicated region for block: B:226:0x0417  */
    /* JADX WARN: Removed duplicated region for block: B:23:0x0093  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void o() {
        /*
            Method dump skipped, instructions count: 1140
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.o():void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:17:0x0052, code lost:
    
        if (r1 >= 30.0f) goto L22;
     */
    @Override // android.view.ViewGroup, android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void onAttachedToWindow() {
        /*
            r5 = this;
            super.onAttachedToWindow()
            r0 = 0
            r5.E = r0
            r1 = 1
            r5.f88s = r1
            boolean r2 = r5.f90u
            if (r2 == 0) goto L15
            boolean r2 = r5.isLayoutRequested()
            if (r2 != 0) goto L15
            r2 = 1
            goto L16
        L15:
            r2 = 0
        L16:
            r5.f90u = r2
            androidx.recyclerview.widget.a1 r2 = r5.f67c
            r2.d()
            androidx.recyclerview.widget.t0 r2 = r5.f84n
            if (r2 == 0) goto L23
            r2.f321f = r1
        L23:
            r5.l0 = r0
            boolean r0 = androidx.recyclerview.widget.RecyclerView.E0
            if (r0 == 0) goto L80
            java.lang.ThreadLocal r0 = androidx.recyclerview.widget.u.f333e
            java.lang.Object r1 = r0.get()
            androidx.recyclerview.widget.u r1 = (androidx.recyclerview.widget.u) r1
            r5.f70d0 = r1
            if (r1 != 0) goto L63
            androidx.recyclerview.widget.u r1 = new androidx.recyclerview.widget.u
            r1.<init>()
            r5.f70d0 = r1
            java.lang.reflect.Field r1 = g.v.f448a
            android.view.Display r1 = g.k.b(r5)
            boolean r2 = r5.isInEditMode()
            if (r2 != 0) goto L55
            if (r1 == 0) goto L55
            float r1 = r1.getRefreshRate()
            r2 = 1106247680(0x41f00000, float:30.0)
            int r2 = (r1 > r2 ? 1 : (r1 == r2 ? 0 : -1))
            if (r2 < 0) goto L55
            goto L57
        L55:
            r1 = 1114636288(0x42700000, float:60.0)
        L57:
            androidx.recyclerview.widget.u r2 = r5.f70d0
            r3 = 1315859240(0x4e6e6b28, float:1.0E9)
            float r3 = r3 / r1
            long r3 = (long) r3
            r2.f337c = r3
            r0.set(r2)
        L63:
            androidx.recyclerview.widget.u r0 = r5.f70d0
            r0.getClass()
            boolean r1 = androidx.recyclerview.widget.RecyclerView.y0
            java.util.ArrayList r0 = r0.f335a
            if (r1 == 0) goto L7d
            boolean r1 = r0.contains(r5)
            if (r1 != 0) goto L75
            goto L7d
        L75:
            java.lang.IllegalStateException r0 = new java.lang.IllegalStateException
            java.lang.String r1 = "RecyclerView already present in worker list!"
            r0.<init>(r1)
            throw r0
        L7d:
            r0.add(r5)
        L80:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.onAttachedToWindow():void");
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onDetachedFromWindow() {
        a1 a1Var;
        u uVar;
        super.onDetachedFromWindow();
        o0 o0Var = this.L;
        if (o0Var != null) {
            o0Var.e();
        }
        int i2 = 0;
        setScrollState(0);
        h1 h1Var = this.f68c0;
        h1Var.f191g.removeCallbacks(h1Var);
        h1Var.f187c.abortAnimation();
        this.f88s = false;
        t0 t0Var = this.f84n;
        if (t0Var != null) {
            t0Var.f321f = false;
            t0Var.M(this);
        }
        this.s0.clear();
        removeCallbacks(this.t0);
        this.f75g.getClass();
        while (s1.f307d.a() != null) {
        }
        int i3 = 0;
        while (true) {
            a1Var = this.f67c;
            ArrayList arrayList = a1Var.f125c;
            if (i3 >= arrayList.size()) {
                break;
            }
            b0.d.g(((i1) arrayList.get(i3)).itemView);
            i3++;
        }
        a1Var.e(a1Var.f130h.f83m, false);
        g.z zVar = new g.z(i2, this);
        while (zVar.hasNext()) {
            View view = (View) zVar.next();
            j.a aVar = (j.a) view.getTag(tv.live.R.id.pooling_container_listener_holder_tag);
            if (aVar == null) {
                aVar = new j.a();
                view.setTag(tv.live.R.id.pooling_container_listener_holder_tag, aVar);
            }
            ArrayList arrayList2 = aVar.f490a;
            int x2 = b0.d.x(arrayList2);
            if (-1 < x2) {
                c.c(arrayList2.get(x2));
                throw null;
            }
        }
        if (!E0 || (uVar = this.f70d0) == null) {
            return;
        }
        boolean remove = uVar.f335a.remove(this);
        if (y0 && !remove) {
            throw new IllegalStateException("RecyclerView removal failed!");
        }
        this.f70d0 = null;
    }

    @Override // android.view.View
    public final void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        ArrayList arrayList = this.f86p;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            ((q0) arrayList.get(i2)).getClass();
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:20:0x0068  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x007a  */
    /* JADX WARN: Removed duplicated region for block: B:25:0x0083  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean onGenericMotionEvent(android.view.MotionEvent r16) {
        /*
            Method dump skipped, instructions count: 243
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.onGenericMotionEvent(android.view.MotionEvent):boolean");
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // android.view.ViewGroup
    public final boolean onInterceptTouchEvent(MotionEvent motionEvent) {
        boolean z2;
        boolean z3;
        if (this.f93x) {
            return false;
        }
        this.f87r = null;
        if (B(motionEvent)) {
            X();
            setScrollState(0);
            return true;
        }
        t0 t0Var = this.f84n;
        if (t0Var == null) {
            return false;
        }
        boolean c2 = t0Var.c();
        boolean d2 = this.f84n.d();
        if (this.O == null) {
            this.O = VelocityTracker.obtain();
        }
        this.O.addMovement(motionEvent);
        int actionMasked = motionEvent.getActionMasked();
        int actionIndex = motionEvent.getActionIndex();
        if (actionMasked == 0) {
            if (this.f94y) {
                this.f94y = false;
            }
            this.N = motionEvent.getPointerId(0);
            int x2 = (int) (motionEvent.getX() + 0.5f);
            this.R = x2;
            this.P = x2;
            int y2 = (int) (motionEvent.getY() + 0.5f);
            this.S = y2;
            this.Q = y2;
            EdgeEffect edgeEffect = this.H;
            if (edgeEffect == null || b0.d.w(edgeEffect) == B0 || canScrollHorizontally(-1)) {
                z2 = false;
            } else {
                b0.d.A(this.H, B0, 1.0f - (motionEvent.getY() / getHeight()));
                z2 = true;
            }
            EdgeEffect edgeEffect2 = this.J;
            if (edgeEffect2 != null && b0.d.w(edgeEffect2) != B0 && !canScrollHorizontally(1)) {
                b0.d.A(this.J, B0, motionEvent.getY() / getHeight());
                z2 = true;
            }
            EdgeEffect edgeEffect3 = this.I;
            if (edgeEffect3 != null && b0.d.w(edgeEffect3) != B0 && !canScrollVertically(-1)) {
                b0.d.A(this.I, B0, motionEvent.getX() / getWidth());
                z2 = true;
            }
            EdgeEffect edgeEffect4 = this.K;
            if (edgeEffect4 != null && b0.d.w(edgeEffect4) != B0 && !canScrollVertically(1)) {
                b0.d.A(this.K, B0, 1.0f - (motionEvent.getX() / getWidth()));
                z2 = true;
            }
            if (z2 || this.M == 2) {
                getParent().requestDisallowInterceptTouchEvent(true);
                setScrollState(1);
                f0(1);
            }
            int[] iArr = this.q0;
            iArr[1] = 0;
            iArr[0] = 0;
            int i2 = c2;
            if (d2) {
                i2 = (c2 ? 1 : 0) | 2;
            }
            getScrollingChildHelper().d(i2, 0);
        } else if (actionMasked == 1) {
            this.O.clear();
            f0(0);
        } else if (actionMasked == 2) {
            int findPointerIndex = motionEvent.findPointerIndex(this.N);
            if (findPointerIndex < 0) {
                Log.e("RecyclerView", "Error processing scroll; pointer index for id " + this.N + " not found. Did any MotionEvents get skipped?");
                return false;
            }
            int x3 = (int) (motionEvent.getX(findPointerIndex) + 0.5f);
            int y3 = (int) (motionEvent.getY(findPointerIndex) + 0.5f);
            if (this.M != 1) {
                int i3 = x3 - this.P;
                int i4 = y3 - this.Q;
                if (c2 == 0 || Math.abs(i3) <= this.T) {
                    z3 = false;
                } else {
                    this.R = x3;
                    z3 = true;
                }
                if (d2 && Math.abs(i4) > this.T) {
                    this.S = y3;
                    z3 = true;
                }
                if (z3) {
                    setScrollState(1);
                }
            }
        } else if (actionMasked == 3) {
            X();
            setScrollState(0);
        } else if (actionMasked == 5) {
            this.N = motionEvent.getPointerId(actionIndex);
            int x4 = (int) (motionEvent.getX(actionIndex) + 0.5f);
            this.R = x4;
            this.P = x4;
            int y4 = (int) (motionEvent.getY(actionIndex) + 0.5f);
            this.S = y4;
            this.Q = y4;
        } else if (actionMasked == 6) {
            P(motionEvent);
        }
        return this.M == 1;
    }

    @Override // android.view.ViewGroup, android.view.View
    public final void onLayout(boolean z2, int i2, int i3, int i4, int i5) {
        int i6 = e.b.f393a;
        e.a.a("RV OnLayout");
        o();
        e.a.b();
        this.f90u = true;
    }

    @Override // android.view.View
    public final void onMeasure(int i2, int i3) {
        t0 t0Var = this.f84n;
        if (t0Var == null) {
            n(i2, i3);
            return;
        }
        boolean G = t0Var.G();
        boolean z2 = false;
        e1 e1Var = this.f74f0;
        if (G) {
            int mode = View.MeasureSpec.getMode(i2);
            int mode2 = View.MeasureSpec.getMode(i3);
            this.f84n.f317b.n(i2, i3);
            if (mode == 1073741824 && mode2 == 1073741824) {
                z2 = true;
            }
            this.u0 = z2;
            if (z2 || this.f83m == null) {
                return;
            }
            if (e1Var.f156c == 1) {
                p();
            }
            this.f84n.m0(i2, i3);
            e1Var.f161h = true;
            q();
            this.f84n.o0(i2, i3);
            if (this.f84n.r0()) {
                this.f84n.m0(View.MeasureSpec.makeMeasureSpec(getMeasuredWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(getMeasuredHeight(), 1073741824));
                e1Var.f161h = true;
                q();
                this.f84n.o0(i2, i3);
            }
            this.v0 = getMeasuredWidth();
            this.w0 = getMeasuredHeight();
            return;
        }
        if (this.f89t) {
            this.f84n.f317b.n(i2, i3);
            return;
        }
        if (this.A) {
            d0();
            N();
            R();
            O(true);
            if (e1Var.f163j) {
                e1Var.f159f = true;
            } else {
                this.f71e.c();
                e1Var.f159f = false;
            }
            this.A = false;
            e0(false);
        } else if (e1Var.f163j) {
            setMeasuredDimension(getMeasuredWidth(), getMeasuredHeight());
            return;
        }
        i0 i0Var = this.f83m;
        if (i0Var != null) {
            e1Var.f157d = i0Var.getItemCount();
        } else {
            e1Var.f157d = 0;
        }
        d0();
        this.f84n.f317b.n(i2, i3);
        e0(false);
        e1Var.f159f = false;
    }

    @Override // android.view.ViewGroup
    public final boolean onRequestFocusInDescendants(int i2, Rect rect) {
        if (K()) {
            return false;
        }
        return super.onRequestFocusInDescendants(i2, rect);
    }

    @Override // android.view.View
    public final void onRestoreInstanceState(Parcelable parcelable) {
        if (!(parcelable instanceof d1)) {
            super.onRestoreInstanceState(parcelable);
            return;
        }
        d1 d1Var = (d1) parcelable;
        this.f69d = d1Var;
        super.onRestoreInstanceState(d1Var.f493a);
        requestLayout();
    }

    @Override // android.view.View
    public final Parcelable onSaveInstanceState() {
        d1 d1Var = new d1(super.onSaveInstanceState());
        d1 d1Var2 = this.f69d;
        if (d1Var2 != null) {
            d1Var.f145c = d1Var2.f145c;
        } else {
            t0 t0Var = this.f84n;
            d1Var.f145c = t0Var != null ? t0Var.a0() : null;
        }
        return d1Var;
    }

    @Override // android.view.View
    public final void onSizeChanged(int i2, int i3, int i4, int i5) {
        super.onSizeChanged(i2, i3, i4, i5);
        if (i2 == i4 && i3 == i5) {
            return;
        }
        this.K = null;
        this.I = null;
        this.J = null;
        this.H = null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:105:0x0408, code lost:
    
        if (r0 != false) goto L234;
     */
    /* JADX WARN: Code restructure failed: missing block: B:143:0x03ce, code lost:
    
        if (r3 == 0) goto L231;
     */
    /* JADX WARN: Code restructure failed: missing block: B:215:0x00e2, code lost:
    
        if (r14 >= 0) goto L46;
     */
    /* JADX WARN: Code restructure failed: missing block: B:228:0x013a, code lost:
    
        if (r12 >= 0) goto L60;
     */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Removed duplicated region for block: B:128:0x036d  */
    /* JADX WARN: Removed duplicated region for block: B:139:0x03b2 A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:141:0x03ca A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:147:0x03d9  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x021c  */
    /* JADX WARN: Removed duplicated region for block: B:60:0x0230  */
    @Override // android.view.View
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean onTouchEvent(android.view.MotionEvent r21) {
        /*
            Method dump skipped, instructions count: 1091
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.RecyclerView.onTouchEvent(android.view.MotionEvent):boolean");
    }

    public final void p() {
        int id;
        View A;
        e1 e1Var = this.f74f0;
        e1Var.a(1);
        z(e1Var);
        e1Var.f161h = false;
        d0();
        t1 t1Var = this.f75g;
        t1Var.e();
        N();
        R();
        i1 i1Var = null;
        View focusedChild = (this.f66b0 && hasFocus() && this.f83m != null) ? getFocusedChild() : null;
        if (focusedChild != null && (A = A(focusedChild)) != null) {
            i1Var = H(A);
        }
        if (i1Var == null) {
            e1Var.f165l = -1L;
            e1Var.f164k = -1;
            e1Var.f166m = -1;
        } else {
            e1Var.f165l = this.f83m.hasStableIds() ? i1Var.getItemId() : -1L;
            e1Var.f164k = this.C ? -1 : i1Var.isRemoved() ? i1Var.mOldPosition : i1Var.getAbsoluteAdapterPosition();
            View view = i1Var.itemView;
            loop3: while (true) {
                id = view.getId();
                while (!view.isFocused() && (view instanceof ViewGroup) && view.hasFocus()) {
                    view = ((ViewGroup) view).getFocusedChild();
                    if (view.getId() != -1) {
                        break;
                    }
                }
            }
            e1Var.f166m = id;
        }
        e1Var.f160g = e1Var.f162i && this.j0;
        this.j0 = false;
        this.i0 = false;
        e1Var.f159f = e1Var.f163j;
        e1Var.f157d = this.f83m.getItemCount();
        C(this.n0);
        if (e1Var.f162i) {
            int e2 = this.f73f.e();
            for (int i2 = 0; i2 < e2; i2++) {
                i1 I = I(this.f73f.d(i2));
                if (!I.shouldIgnore() && (!I.isInvalid() || this.f83m.hasStableIds())) {
                    o0 o0Var = this.L;
                    o0.b(I);
                    I.getUnmodifiedPayloads();
                    o0Var.getClass();
                    n0 n0Var = new n0();
                    n0Var.a(I);
                    t1Var.d(I, n0Var);
                    if (e1Var.f160g && I.isUpdated() && !I.isRemoved() && !I.shouldIgnore() && !I.isInvalid()) {
                        t1Var.b(G(I), I);
                    }
                }
            }
        }
        if (e1Var.f163j) {
            int h2 = this.f73f.h();
            for (int i3 = 0; i3 < h2; i3++) {
                i1 I2 = I(this.f73f.g(i3));
                if (y0 && I2.mPosition == -1 && !I2.isRemoved()) {
                    throw new IllegalStateException(c.b(this, new StringBuilder("view holder cannot have position -1 unless it is removed")));
                }
                if (!I2.shouldIgnore()) {
                    I2.saveOldPosition();
                }
            }
            boolean z2 = e1Var.f158e;
            e1Var.f158e = false;
            this.f84n.X(this.f67c, e1Var);
            e1Var.f158e = z2;
            for (int i4 = 0; i4 < this.f73f.e(); i4++) {
                i1 I3 = I(this.f73f.d(i4));
                if (!I3.shouldIgnore()) {
                    s1 s1Var = (s1) ((a.h) t1Var.f331b).get(I3);
                    if (!((s1Var == null || (s1Var.f308a & 4) == 0) ? false : true)) {
                        o0.b(I3);
                        boolean hasAnyOfTheFlags = I3.hasAnyOfTheFlags(8192);
                        o0 o0Var2 = this.L;
                        I3.getUnmodifiedPayloads();
                        o0Var2.getClass();
                        n0 n0Var2 = new n0();
                        n0Var2.a(I3);
                        if (hasAnyOfTheFlags) {
                            T(I3, n0Var2);
                        } else {
                            s1 s1Var2 = (s1) ((a.h) t1Var.f331b).get(I3);
                            if (s1Var2 == null) {
                                s1Var2 = s1.a();
                                ((a.h) t1Var.f331b).put(I3, s1Var2);
                            }
                            s1Var2.f308a |= 2;
                            s1Var2.f309b = n0Var2;
                        }
                    }
                }
            }
        }
        j();
        O(true);
        e0(false);
        e1Var.f156c = 2;
    }

    public final void q() {
        d0();
        N();
        e1 e1Var = this.f74f0;
        e1Var.a(6);
        this.f71e.c();
        e1Var.f157d = this.f83m.getItemCount();
        e1Var.f155b = 0;
        if (this.f69d != null && this.f83m.canRestoreState()) {
            Parcelable parcelable = this.f69d.f145c;
            if (parcelable != null) {
                this.f84n.Z(parcelable);
            }
            this.f69d = null;
        }
        e1Var.f159f = false;
        this.f84n.X(this.f67c, e1Var);
        e1Var.f158e = false;
        e1Var.f162i = e1Var.f162i && this.L != null;
        e1Var.f156c = 4;
        O(true);
        e0(false);
    }

    public final boolean r(int i2, int i3, int[] iArr, int[] iArr2, int i4) {
        return getScrollingChildHelper().a(i2, i3, iArr, iArr2, i4);
    }

    @Override // android.view.ViewGroup
    public final void removeDetachedView(View view, boolean z2) {
        i1 I = I(view);
        if (I != null) {
            if (I.isTmpDetached()) {
                I.clearTmpDetachFlag();
            } else if (!I.shouldIgnore()) {
                StringBuilder sb = new StringBuilder("Called removeDetachedView with a view which is not flagged as tmp detached.");
                sb.append(I);
                throw new IllegalArgumentException(c.b(this, sb));
            }
        } else if (y0) {
            StringBuilder sb2 = new StringBuilder("No ViewHolder found for child: ");
            sb2.append(view);
            throw new IllegalArgumentException(c.b(this, sb2));
        }
        view.clearAnimation();
        i1 I2 = I(view);
        i0 i0Var = this.f83m;
        if (i0Var != null && I2 != null) {
            i0Var.onViewDetachedFromWindow(I2);
        }
        super.removeDetachedView(view, z2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestChildFocus(View view, View view2) {
        this.f84n.getClass();
        if (!K() && view2 != null) {
            W(view, view2);
        }
        super.requestChildFocus(view, view2);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final boolean requestChildRectangleOnScreen(View view, Rect rect, boolean z2) {
        return this.f84n.g0(this, view, rect, z2, false);
    }

    @Override // android.view.ViewGroup, android.view.ViewParent
    public final void requestDisallowInterceptTouchEvent(boolean z2) {
        ArrayList arrayList = this.q;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            ((w0) arrayList.get(i2)).getClass();
        }
        super.requestDisallowInterceptTouchEvent(z2);
    }

    @Override // android.view.View, android.view.ViewParent
    public final void requestLayout() {
        if (this.f91v != 0 || this.f93x) {
            this.f92w = true;
        } else {
            super.requestLayout();
        }
    }

    public final void s(int i2, int i3, int i4, int i5, int[] iArr, int i6, int[] iArr2) {
        getScrollingChildHelper().b(i2, i3, i4, i5, iArr, i6, iArr2);
    }

    @Override // android.view.View
    public final void scrollBy(int i2, int i3) {
        t0 t0Var = this.f84n;
        if (t0Var == null) {
            Log.e("RecyclerView", "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument.");
            return;
        }
        if (this.f93x) {
            return;
        }
        boolean c2 = t0Var.c();
        boolean d2 = this.f84n.d();
        if (c2 || d2) {
            if (!c2) {
                i2 = 0;
            }
            if (!d2) {
                i3 = 0;
            }
            Y(i2, i3, null, 0);
        }
    }

    @Override // android.view.View
    public final void scrollTo(int i2, int i3) {
        Log.w("RecyclerView", "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead");
    }

    @Override // android.view.View, android.view.accessibility.AccessibilityEventSource
    public final void sendAccessibilityEventUnchecked(AccessibilityEvent accessibilityEvent) {
        if (K()) {
            int a2 = accessibilityEvent != null ? h.b.a(accessibilityEvent) : 0;
            this.f95z |= a2 != 0 ? a2 : 0;
            r1 = 1;
        }
        if (r1 != 0) {
            return;
        }
        super.sendAccessibilityEventUnchecked(accessibilityEvent);
    }

    public void setAccessibilityDelegateCompat(k1 k1Var) {
        this.m0 = k1Var;
        g.v.b(this, k1Var);
    }

    public void setAdapter(i0 i0Var) {
        setLayoutFrozen(false);
        i0 i0Var2 = this.f83m;
        c1 c1Var = this.f65b;
        if (i0Var2 != null) {
            i0Var2.unregisterAdapterDataObserver(c1Var);
            this.f83m.onDetachedFromRecyclerView(this);
        }
        o0 o0Var = this.L;
        if (o0Var != null) {
            o0Var.e();
        }
        t0 t0Var = this.f84n;
        a1 a1Var = this.f67c;
        if (t0Var != null) {
            t0Var.c0(a1Var);
            this.f84n.d0(a1Var);
        }
        a1Var.f123a.clear();
        a1Var.f();
        b bVar = this.f71e;
        bVar.l(bVar.f132b);
        bVar.l(bVar.f133c);
        bVar.f136f = 0;
        i0 i0Var3 = this.f83m;
        this.f83m = i0Var;
        if (i0Var != null) {
            i0Var.registerAdapterDataObserver(c1Var);
            i0Var.onAttachedToRecyclerView(this);
        }
        t0 t0Var2 = this.f84n;
        if (t0Var2 != null) {
            t0Var2.L();
        }
        i0 i0Var4 = this.f83m;
        a1Var.f123a.clear();
        a1Var.f();
        a1Var.e(i0Var3, true);
        z0 c2 = a1Var.c();
        if (i0Var3 != null) {
            c2.f370b--;
        }
        if (c2.f370b == 0) {
            int i2 = 0;
            while (true) {
                SparseArray sparseArray = c2.f369a;
                if (i2 >= sparseArray.size()) {
                    break;
                }
                y0 y0Var = (y0) sparseArray.valueAt(i2);
                Iterator it = y0Var.f361a.iterator();
                while (it.hasNext()) {
                    b0.d.g(((i1) it.next()).itemView);
                }
                y0Var.f361a.clear();
                i2++;
            }
        }
        if (i0Var4 != null) {
            c2.f370b++;
        }
        a1Var.d();
        this.f74f0.f158e = true;
        S(false);
        requestLayout();
    }

    public void setChildDrawingOrderCallback(l0 l0Var) {
        if (l0Var == null) {
            return;
        }
        setChildrenDrawingOrderEnabled(false);
    }

    @Override // android.view.ViewGroup
    public void setClipToPadding(boolean z2) {
        if (z2 != this.f77h) {
            this.K = null;
            this.I = null;
            this.J = null;
            this.H = null;
        }
        this.f77h = z2;
        super.setClipToPadding(z2);
        if (this.f90u) {
            requestLayout();
        }
    }

    public void setEdgeEffectFactory(m0 m0Var) {
        m0Var.getClass();
        this.G = m0Var;
        this.K = null;
        this.I = null;
        this.J = null;
        this.H = null;
    }

    public void setHasFixedSize(boolean z2) {
        this.f89t = z2;
    }

    public void setItemAnimator(o0 o0Var) {
        o0 o0Var2 = this.L;
        if (o0Var2 != null) {
            o0Var2.e();
            this.L.f243a = null;
        }
        this.L = o0Var;
        if (o0Var != null) {
            o0Var.f243a = this.k0;
        }
    }

    public void setItemViewCacheSize(int i2) {
        a1 a1Var = this.f67c;
        a1Var.f127e = i2;
        a1Var.m();
    }

    @Deprecated
    public void setLayoutFrozen(boolean z2) {
        suppressLayout(z2);
    }

    public void setLayoutManager(t0 t0Var) {
        p0 p0Var;
        RecyclerView recyclerView;
        if (t0Var == this.f84n) {
            return;
        }
        int i2 = 0;
        setScrollState(0);
        h1 h1Var = this.f68c0;
        h1Var.f191g.removeCallbacks(h1Var);
        h1Var.f187c.abortAnimation();
        t0 t0Var2 = this.f84n;
        a1 a1Var = this.f67c;
        if (t0Var2 != null) {
            o0 o0Var = this.L;
            if (o0Var != null) {
                o0Var.e();
            }
            this.f84n.c0(a1Var);
            this.f84n.d0(a1Var);
            a1Var.f123a.clear();
            a1Var.f();
            if (this.f88s) {
                t0 t0Var3 = this.f84n;
                t0Var3.f321f = false;
                t0Var3.M(this);
            }
            this.f84n.p0(null);
            this.f84n = null;
        } else {
            a1Var.f123a.clear();
            a1Var.f();
        }
        e eVar = this.f73f;
        eVar.f147b.g();
        ArrayList arrayList = eVar.f148c;
        int size = arrayList.size();
        while (true) {
            size--;
            p0Var = eVar.f146a;
            if (size < 0) {
                break;
            }
            View view = (View) arrayList.get(size);
            p0Var.getClass();
            i1 I = I(view);
            if (I != null) {
                I.onLeftHiddenState(p0Var.f260a);
            }
            arrayList.remove(size);
        }
        int c2 = p0Var.c();
        while (true) {
            recyclerView = p0Var.f260a;
            if (i2 >= c2) {
                break;
            }
            View childAt = recyclerView.getChildAt(i2);
            recyclerView.getClass();
            i1 I2 = I(childAt);
            i0 i0Var = recyclerView.f83m;
            if (i0Var != null && I2 != null) {
                i0Var.onViewDetachedFromWindow(I2);
            }
            childAt.clearAnimation();
            i2++;
        }
        recyclerView.removeAllViews();
        this.f84n = t0Var;
        if (t0Var != null) {
            if (t0Var.f317b != null) {
                StringBuilder sb = new StringBuilder("LayoutManager ");
                sb.append(t0Var);
                sb.append(" is already attached to a RecyclerView:");
                throw new IllegalArgumentException(c.b(t0Var.f317b, sb));
            }
            t0Var.p0(this);
            if (this.f88s) {
                this.f84n.f321f = true;
            }
        }
        a1Var.m();
        requestLayout();
    }

    @Override // android.view.ViewGroup
    @Deprecated
    public void setLayoutTransition(LayoutTransition layoutTransition) {
        if (layoutTransition != null) {
            throw new IllegalArgumentException("Providing a LayoutTransition into RecyclerView is not supported. Please use setItemAnimator() instead for animating changes to the items in this RecyclerView");
        }
        super.setLayoutTransition(null);
    }

    @Override // android.view.View
    public void setNestedScrollingEnabled(boolean z2) {
        g.f scrollingChildHelper = getScrollingChildHelper();
        if (scrollingChildHelper.f426d) {
            Field field = g.v.f448a;
            g.n.z(scrollingChildHelper.f425c);
        }
        scrollingChildHelper.f426d = z2;
    }

    public void setOnFlingListener(v0 v0Var) {
    }

    @Deprecated
    public void setOnScrollListener(x0 x0Var) {
        this.f76g0 = x0Var;
    }

    public void setPreserveFocusAfterLayout(boolean z2) {
        this.f66b0 = z2;
    }

    public void setRecycledViewPool(z0 z0Var) {
        a1 a1Var = this.f67c;
        RecyclerView recyclerView = a1Var.f130h;
        a1Var.e(recyclerView.f83m, false);
        if (a1Var.f129g != null) {
            r2.f370b--;
        }
        a1Var.f129g = z0Var;
        if (z0Var != null && recyclerView.getAdapter() != null) {
            a1Var.f129g.f370b++;
        }
        a1Var.d();
    }

    @Deprecated
    public void setRecyclerListener(b1 b1Var) {
    }

    public void setScrollState(int i2) {
        if (i2 == this.M) {
            return;
        }
        if (z0) {
            Log.d("RecyclerView", "setting scroll state to " + i2 + " from " + this.M, new Exception());
        }
        this.M = i2;
        if (i2 != 2) {
            h1 h1Var = this.f68c0;
            h1Var.f191g.removeCallbacks(h1Var);
            h1Var.f187c.abortAnimation();
        }
        t0 t0Var = this.f84n;
        if (t0Var != null) {
            t0Var.b0(i2);
        }
        ArrayList arrayList = this.f78h0;
        if (arrayList == null) {
            return;
        }
        int size = arrayList.size();
        while (true) {
            size--;
            if (size < 0) {
                return;
            } else {
                ((x0) this.f78h0.get(size)).getClass();
            }
        }
    }

    public void setScrollingTouchSlop(int i2) {
        int scaledTouchSlop;
        ViewConfiguration viewConfiguration = ViewConfiguration.get(getContext());
        if (i2 != 0) {
            if (i2 == 1) {
                scaledTouchSlop = viewConfiguration.getScaledPagingTouchSlop();
                this.T = scaledTouchSlop;
            } else {
                Log.w("RecyclerView", "setScrollingTouchSlop(): bad argument constant " + i2 + "; using default value");
            }
        }
        scaledTouchSlop = viewConfiguration.getScaledTouchSlop();
        this.T = scaledTouchSlop;
    }

    public void setViewCacheExtension(g1 g1Var) {
        this.f67c.getClass();
    }

    @Override // android.view.View
    public final boolean startNestedScroll(int i2) {
        return getScrollingChildHelper().d(i2, 0);
    }

    @Override // android.view.View
    public final void stopNestedScroll() {
        getScrollingChildHelper().e(0);
    }

    @Override // android.view.ViewGroup
    public final void suppressLayout(boolean z2) {
        if (z2 != this.f93x) {
            h("Do not suppressLayout in layout or scroll");
            if (!z2) {
                this.f93x = false;
                if (this.f92w && this.f84n != null && this.f83m != null) {
                    requestLayout();
                }
                this.f92w = false;
                return;
            }
            long uptimeMillis = SystemClock.uptimeMillis();
            onTouchEvent(MotionEvent.obtain(uptimeMillis, uptimeMillis, 3, B0, B0, 0));
            this.f93x = true;
            this.f94y = true;
            setScrollState(0);
            h1 h1Var = this.f68c0;
            h1Var.f191g.removeCallbacks(h1Var);
            h1Var.f187c.abortAnimation();
        }
    }

    public final void t(int i2, int i3) {
        this.F++;
        int scrollX = getScrollX();
        int scrollY = getScrollY();
        onScrollChanged(scrollX, scrollY, scrollX - i2, scrollY - i3);
        x0 x0Var = this.f76g0;
        if (x0Var != null) {
            x0Var.a(this);
        }
        ArrayList arrayList = this.f78h0;
        if (arrayList != null) {
            int size = arrayList.size();
            while (true) {
                size--;
                if (size < 0) {
                    break;
                } else {
                    ((x0) this.f78h0.get(size)).a(this);
                }
            }
        }
        this.F--;
    }

    public final void u() {
        int measuredWidth;
        int measuredHeight;
        if (this.K != null) {
            return;
        }
        ((f1) this.G).getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.K = edgeEffect;
        if (this.f77h) {
            measuredWidth = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
            measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
        } else {
            measuredWidth = getMeasuredWidth();
            measuredHeight = getMeasuredHeight();
        }
        edgeEffect.setSize(measuredWidth, measuredHeight);
    }

    public final void v() {
        int measuredHeight;
        int measuredWidth;
        if (this.H != null) {
            return;
        }
        ((f1) this.G).getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.H = edgeEffect;
        if (this.f77h) {
            measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
            measuredWidth = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
        } else {
            measuredHeight = getMeasuredHeight();
            measuredWidth = getMeasuredWidth();
        }
        edgeEffect.setSize(measuredHeight, measuredWidth);
    }

    public final void w() {
        int measuredHeight;
        int measuredWidth;
        if (this.J != null) {
            return;
        }
        ((f1) this.G).getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.J = edgeEffect;
        if (this.f77h) {
            measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
            measuredWidth = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
        } else {
            measuredHeight = getMeasuredHeight();
            measuredWidth = getMeasuredWidth();
        }
        edgeEffect.setSize(measuredHeight, measuredWidth);
    }

    public final void x() {
        int measuredWidth;
        int measuredHeight;
        if (this.I != null) {
            return;
        }
        ((f1) this.G).getClass();
        EdgeEffect edgeEffect = new EdgeEffect(getContext());
        this.I = edgeEffect;
        if (this.f77h) {
            measuredWidth = (getMeasuredWidth() - getPaddingLeft()) - getPaddingRight();
            measuredHeight = (getMeasuredHeight() - getPaddingTop()) - getPaddingBottom();
        } else {
            measuredWidth = getMeasuredWidth();
            measuredHeight = getMeasuredHeight();
        }
        edgeEffect.setSize(measuredWidth, measuredHeight);
    }

    public final String y() {
        return " " + super.toString() + ", adapter:" + this.f83m + ", layout:" + this.f84n + ", context:" + getContext();
    }

    public final void z(e1 e1Var) {
        if (getScrollState() != 2) {
            e1Var.getClass();
            return;
        }
        OverScroller overScroller = this.f68c0.f187c;
        overScroller.getFinalX();
        overScroller.getCurrX();
        e1Var.getClass();
        overScroller.getFinalY();
        overScroller.getCurrY();
    }

    @Override // android.view.ViewGroup
    public final ViewGroup.LayoutParams generateLayoutParams(ViewGroup.LayoutParams layoutParams) {
        t0 t0Var = this.f84n;
        if (t0Var != null) {
            return t0Var.s(layoutParams);
        }
        throw new IllegalStateException(c.b(this, new StringBuilder("RecyclerView has no LayoutManager")));
    }
}
