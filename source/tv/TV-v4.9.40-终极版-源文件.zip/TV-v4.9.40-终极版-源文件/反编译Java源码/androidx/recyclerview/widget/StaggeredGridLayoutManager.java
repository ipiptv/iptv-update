package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.BitSet;
import java.util.List;

/* loaded from: classes.dex */
public class StaggeredGridLayoutManager extends t0 {
    public final t1 A;
    public final int B;
    public boolean C;
    public boolean D;
    public o1 E;
    public final Rect F;
    public final l1 G;
    public final boolean H;
    public int[] I;
    public final m J;

    /* renamed from: o, reason: collision with root package name */
    public int f96o;

    /* renamed from: p, reason: collision with root package name */
    public p1[] f97p;
    public e0 q;

    /* renamed from: r, reason: collision with root package name */
    public e0 f98r;

    /* renamed from: s, reason: collision with root package name */
    public int f99s;

    /* renamed from: t, reason: collision with root package name */
    public int f100t;

    /* renamed from: u, reason: collision with root package name */
    public final x f101u;

    /* renamed from: v, reason: collision with root package name */
    public boolean f102v;

    /* renamed from: x, reason: collision with root package name */
    public BitSet f104x;

    /* renamed from: w, reason: collision with root package name */
    public boolean f103w = false;

    /* renamed from: y, reason: collision with root package name */
    public int f105y = -1;

    /* renamed from: z, reason: collision with root package name */
    public int f106z = Integer.MIN_VALUE;

    public StaggeredGridLayoutManager(Context context, AttributeSet attributeSet, int i2, int i3) {
        this.f96o = -1;
        this.f102v = false;
        t1 t1Var = new t1(1);
        this.A = t1Var;
        this.B = 2;
        this.F = new Rect();
        this.G = new l1(this);
        this.H = true;
        this.J = new m(1, this);
        s0 D = t0.D(context, attributeSet, i2, i3);
        int i4 = D.f303a;
        if (i4 != 0 && i4 != 1) {
            throw new IllegalArgumentException("invalid orientation.");
        }
        b(null);
        if (i4 != this.f99s) {
            this.f99s = i4;
            e0 e0Var = this.q;
            this.q = this.f98r;
            this.f98r = e0Var;
            h0();
        }
        int i5 = D.f304b;
        b(null);
        if (i5 != this.f96o) {
            t1Var.e();
            h0();
            this.f96o = i5;
            this.f104x = new BitSet(this.f96o);
            this.f97p = new p1[this.f96o];
            for (int i6 = 0; i6 < this.f96o; i6++) {
                this.f97p[i6] = new p1(this, i6);
            }
            h0();
        }
        boolean z2 = D.f305c;
        b(null);
        o1 o1Var = this.E;
        if (o1Var != null && o1Var.f256h != z2) {
            o1Var.f256h = z2;
        }
        this.f102v = z2;
        h0();
        this.f101u = new x();
        this.q = e0.a(this, this.f99s);
        this.f98r = e0.a(this, 1 - this.f99s);
    }

    public static int V0(int i2, int i3, int i4) {
        if (i3 == 0 && i4 == 0) {
            return i2;
        }
        int mode = View.MeasureSpec.getMode(i2);
        return (mode == Integer.MIN_VALUE || mode == 1073741824) ? View.MeasureSpec.makeMeasureSpec(Math.max(0, (View.MeasureSpec.getSize(i2) - i3) - i4), mode) : i2;
    }

    public final View A0(boolean z2) {
        int h2 = this.q.h();
        int f2 = this.q.f();
        int u2 = u();
        View view = null;
        for (int i2 = 0; i2 < u2; i2++) {
            View t2 = t(i2);
            int d2 = this.q.d(t2);
            if (this.q.b(t2) > h2 && d2 < f2) {
                if (d2 >= h2 || !z2) {
                    return t2;
                }
                if (view == null) {
                    view = t2;
                }
            }
        }
        return view;
    }

    public final void B0(a1 a1Var, e1 e1Var, boolean z2) {
        int f2;
        int F0 = F0(Integer.MIN_VALUE);
        if (F0 != Integer.MIN_VALUE && (f2 = this.q.f() - F0) > 0) {
            int i2 = f2 - (-R0(-f2, a1Var, e1Var));
            if (!z2 || i2 <= 0) {
                return;
            }
            this.q.l(i2);
        }
    }

    public final void C0(a1 a1Var, e1 e1Var, boolean z2) {
        int h2;
        int G0 = G0(Integer.MAX_VALUE);
        if (G0 != Integer.MAX_VALUE && (h2 = G0 - this.q.h()) > 0) {
            int R0 = h2 - R0(h2, a1Var, e1Var);
            if (!z2 || R0 <= 0) {
                return;
            }
            this.q.l(-R0);
        }
    }

    public final int D0() {
        if (u() == 0) {
            return 0;
        }
        return t0.C(t(0));
    }

    public final int E0() {
        int u2 = u();
        if (u2 == 0) {
            return 0;
        }
        return t0.C(t(u2 - 1));
    }

    public final int F0(int i2) {
        int f2 = this.f97p[0].f(i2);
        for (int i3 = 1; i3 < this.f96o; i3++) {
            int f3 = this.f97p[i3].f(i2);
            if (f3 > f2) {
                f2 = f3;
            }
        }
        return f2;
    }

    @Override // androidx.recyclerview.widget.t0
    public final boolean G() {
        return this.B != 0;
    }

    public final int G0(int i2) {
        int i3 = this.f97p[0].i(i2);
        for (int i4 = 1; i4 < this.f96o; i4++) {
            int i5 = this.f97p[i4].i(i2);
            if (i5 < i3) {
                i3 = i5;
            }
        }
        return i3;
    }

    /* JADX WARN: Removed duplicated region for block: B:11:0x0025  */
    /* JADX WARN: Removed duplicated region for block: B:16:0x003b A[RETURN] */
    /* JADX WARN: Removed duplicated region for block: B:18:0x003c  */
    /* JADX WARN: Removed duplicated region for block: B:27:0x0036  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void H0(int r8, int r9, int r10) {
        /*
            r7 = this;
            boolean r0 = r7.f103w
            if (r0 == 0) goto L9
            int r0 = r7.E0()
            goto Ld
        L9:
            int r0 = r7.D0()
        Ld:
            r1 = 8
            if (r10 != r1) goto L1a
            if (r8 >= r9) goto L16
            int r2 = r9 + 1
            goto L1c
        L16:
            int r2 = r8 + 1
            r3 = r9
            goto L1d
        L1a:
            int r2 = r8 + r9
        L1c:
            r3 = r8
        L1d:
            androidx.recyclerview.widget.t1 r4 = r7.A
            r4.h(r3)
            r5 = 1
            if (r10 == r5) goto L36
            r6 = 2
            if (r10 == r6) goto L32
            if (r10 == r1) goto L2b
            goto L39
        L2b:
            r4.k(r8, r5)
            r4.j(r9, r5)
            goto L39
        L32:
            r4.k(r8, r9)
            goto L39
        L36:
            r4.j(r8, r9)
        L39:
            if (r2 > r0) goto L3c
            return
        L3c:
            boolean r8 = r7.f103w
            if (r8 == 0) goto L45
            int r8 = r7.D0()
            goto L49
        L45:
            int r8 = r7.E0()
        L49:
            if (r3 > r8) goto L4e
            r7.h0()
        L4e:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.H0(int, int, int):void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:43:0x00cb, code lost:
    
        if (r10 == r11) goto L51;
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00e1, code lost:
    
        r10 = false;
     */
    /* JADX WARN: Code restructure failed: missing block: B:60:0x00df, code lost:
    
        r10 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:65:0x00dd, code lost:
    
        if (r10 == r11) goto L51;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final android.view.View I0() {
        /*
            Method dump skipped, instructions count: 258
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.I0():android.view.View");
    }

    @Override // androidx.recyclerview.widget.t0
    public final void J(int i2) {
        super.J(i2);
        for (int i3 = 0; i3 < this.f96o; i3++) {
            p1 p1Var = this.f97p[i3];
            int i4 = p1Var.f262b;
            if (i4 != Integer.MIN_VALUE) {
                p1Var.f262b = i4 + i2;
            }
            int i5 = p1Var.f263c;
            if (i5 != Integer.MIN_VALUE) {
                p1Var.f263c = i5 + i2;
            }
        }
    }

    public final boolean J0() {
        RecyclerView recyclerView = this.f317b;
        Field field = g.v.f448a;
        return g.k.d(recyclerView) == 1;
    }

    @Override // androidx.recyclerview.widget.t0
    public final void K(int i2) {
        super.K(i2);
        for (int i3 = 0; i3 < this.f96o; i3++) {
            p1 p1Var = this.f97p[i3];
            int i4 = p1Var.f262b;
            if (i4 != Integer.MIN_VALUE) {
                p1Var.f262b = i4 + i2;
            }
            int i5 = p1Var.f263c;
            if (i5 != Integer.MIN_VALUE) {
                p1Var.f263c = i5 + i2;
            }
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:122:0x0189, code lost:
    
        if (r16.f103w != false) goto L110;
     */
    /* JADX WARN: Code restructure failed: missing block: B:123:0x0199, code lost:
    
        r11 = 65535;
     */
    /* JADX WARN: Code restructure failed: missing block: B:133:0x019b, code lost:
    
        r11 = 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:138:0x0197, code lost:
    
        if ((r11 < D0()) != r16.f103w) goto L109;
     */
    /* JADX WARN: Code restructure failed: missing block: B:274:0x0408, code lost:
    
        if (u0() != false) goto L268;
     */
    /* JADX WARN: Removed duplicated region for block: B:62:0x01d6  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void K0(androidx.recyclerview.widget.a1 r17, androidx.recyclerview.widget.e1 r18, boolean r19) {
        /*
            Method dump skipped, instructions count: 1062
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.K0(androidx.recyclerview.widget.a1, androidx.recyclerview.widget.e1, boolean):void");
    }

    @Override // androidx.recyclerview.widget.t0
    public final void L() {
        this.A.e();
        for (int i2 = 0; i2 < this.f96o; i2++) {
            this.f97p[i2].b();
        }
    }

    public final boolean L0(int i2) {
        if (this.f99s == 0) {
            return (i2 == -1) != this.f103w;
        }
        return ((i2 == -1) == this.f103w) == J0();
    }

    @Override // androidx.recyclerview.widget.t0
    public final void M(RecyclerView recyclerView) {
        RecyclerView recyclerView2 = this.f317b;
        if (recyclerView2 != null) {
            recyclerView2.removeCallbacks(this.J);
        }
        for (int i2 = 0; i2 < this.f96o; i2++) {
            this.f97p[i2].b();
        }
        recyclerView.requestLayout();
    }

    public final void M0(int i2) {
        int D0;
        int i3;
        if (i2 > 0) {
            D0 = E0();
            i3 = 1;
        } else {
            D0 = D0();
            i3 = -1;
        }
        x xVar = this.f101u;
        xVar.f347a = true;
        T0(D0);
        S0(i3);
        xVar.f349c = D0 + xVar.f350d;
        xVar.f348b = Math.abs(i2);
    }

    /* JADX WARN: Code restructure failed: missing block: B:114:0x004a, code lost:
    
        if (r8.f99s == 1) goto L54;
     */
    /* JADX WARN: Code restructure failed: missing block: B:117:0x004f, code lost:
    
        if (r8.f99s == 0) goto L54;
     */
    /* JADX WARN: Code restructure failed: missing block: B:121:0x005e, code lost:
    
        if (J0() == false) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:125:0x006a, code lost:
    
        if (J0() == false) goto L54;
     */
    @Override // androidx.recyclerview.widget.t0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final android.view.View N(android.view.View r9, int r10, androidx.recyclerview.widget.a1 r11, androidx.recyclerview.widget.e1 r12) {
        /*
            Method dump skipped, instructions count: 345
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.N(android.view.View, int, androidx.recyclerview.widget.a1, androidx.recyclerview.widget.e1):android.view.View");
    }

    /* JADX WARN: Code restructure failed: missing block: B:8:0x0011, code lost:
    
        if (r6.f351e == (-1)) goto L11;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void N0(androidx.recyclerview.widget.a1 r5, androidx.recyclerview.widget.x r6) {
        /*
            r4 = this;
            boolean r0 = r6.f347a
            if (r0 == 0) goto L7c
            boolean r0 = r6.f355i
            if (r0 == 0) goto La
            goto L7c
        La:
            int r0 = r6.f348b
            r1 = -1
            if (r0 != 0) goto L1f
            int r0 = r6.f351e
            if (r0 != r1) goto L19
        L13:
            int r6 = r6.f353g
        L15:
            r4.O0(r6, r5)
            goto L7c
        L19:
            int r6 = r6.f352f
        L1b:
            r4.P0(r6, r5)
            goto L7c
        L1f:
            int r0 = r6.f351e
            r2 = 0
            r3 = 1
            if (r0 != r1) goto L50
            int r0 = r6.f352f
            androidx.recyclerview.widget.p1[] r1 = r4.f97p
            r1 = r1[r2]
            int r1 = r1.i(r0)
        L2f:
            int r2 = r4.f96o
            if (r3 >= r2) goto L41
            androidx.recyclerview.widget.p1[] r2 = r4.f97p
            r2 = r2[r3]
            int r2 = r2.i(r0)
            if (r2 <= r1) goto L3e
            r1 = r2
        L3e:
            int r3 = r3 + 1
            goto L2f
        L41:
            int r0 = r0 - r1
            if (r0 >= 0) goto L45
            goto L13
        L45:
            int r1 = r6.f353g
            int r6 = r6.f348b
            int r6 = java.lang.Math.min(r0, r6)
            int r6 = r1 - r6
            goto L15
        L50:
            int r0 = r6.f353g
            androidx.recyclerview.widget.p1[] r1 = r4.f97p
            r1 = r1[r2]
            int r1 = r1.f(r0)
        L5a:
            int r2 = r4.f96o
            if (r3 >= r2) goto L6c
            androidx.recyclerview.widget.p1[] r2 = r4.f97p
            r2 = r2[r3]
            int r2 = r2.f(r0)
            if (r2 >= r1) goto L69
            r1 = r2
        L69:
            int r3 = r3 + 1
            goto L5a
        L6c:
            int r0 = r6.f353g
            int r1 = r1 - r0
            if (r1 >= 0) goto L72
            goto L19
        L72:
            int r0 = r6.f352f
            int r6 = r6.f348b
            int r6 = java.lang.Math.min(r1, r6)
            int r6 = r6 + r0
            goto L1b
        L7c:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.StaggeredGridLayoutManager.N0(androidx.recyclerview.widget.a1, androidx.recyclerview.widget.x):void");
    }

    @Override // androidx.recyclerview.widget.t0
    public final void O(AccessibilityEvent accessibilityEvent) {
        super.O(accessibilityEvent);
        if (u() > 0) {
            View A0 = A0(false);
            View z0 = z0(false);
            if (A0 == null || z0 == null) {
                return;
            }
            int C = t0.C(A0);
            int C2 = t0.C(z0);
            if (C < C2) {
                accessibilityEvent.setFromIndex(C);
                accessibilityEvent.setToIndex(C2);
            } else {
                accessibilityEvent.setFromIndex(C2);
                accessibilityEvent.setToIndex(C);
            }
        }
    }

    public final void O0(int i2, a1 a1Var) {
        for (int u2 = u() - 1; u2 >= 0; u2--) {
            View t2 = t(u2);
            if (this.q.d(t2) < i2 || this.q.k(t2) < i2) {
                return;
            }
            m1 m1Var = (m1) t2.getLayoutParams();
            m1Var.getClass();
            if (m1Var.f233e.f261a.size() == 1) {
                return;
            }
            p1 p1Var = m1Var.f233e;
            ArrayList arrayList = p1Var.f261a;
            int size = arrayList.size();
            View view = (View) arrayList.remove(size - 1);
            m1 h2 = p1.h(view);
            h2.f233e = null;
            if (h2.c() || h2.b()) {
                p1Var.f264d -= p1Var.f266f.q.c(view);
            }
            if (size == 1) {
                p1Var.f262b = Integer.MIN_VALUE;
            }
            p1Var.f263c = Integer.MIN_VALUE;
            e0(t2, a1Var);
        }
    }

    public final void P0(int i2, a1 a1Var) {
        while (u() > 0) {
            View t2 = t(0);
            if (this.q.b(t2) > i2 || this.q.j(t2) > i2) {
                return;
            }
            m1 m1Var = (m1) t2.getLayoutParams();
            m1Var.getClass();
            if (m1Var.f233e.f261a.size() == 1) {
                return;
            }
            p1 p1Var = m1Var.f233e;
            ArrayList arrayList = p1Var.f261a;
            View view = (View) arrayList.remove(0);
            m1 h2 = p1.h(view);
            h2.f233e = null;
            if (arrayList.size() == 0) {
                p1Var.f263c = Integer.MIN_VALUE;
            }
            if (h2.c() || h2.b()) {
                p1Var.f264d -= p1Var.f266f.q.c(view);
            }
            p1Var.f262b = Integer.MIN_VALUE;
            e0(t2, a1Var);
        }
    }

    public final void Q0() {
        this.f103w = (this.f99s == 1 || !J0()) ? this.f102v : !this.f102v;
    }

    public final int R0(int i2, a1 a1Var, e1 e1Var) {
        if (u() == 0 || i2 == 0) {
            return 0;
        }
        M0(i2);
        x xVar = this.f101u;
        int y0 = y0(a1Var, xVar, e1Var);
        if (xVar.f348b >= y0) {
            i2 = i2 < 0 ? -y0 : y0;
        }
        this.q.l(-i2);
        this.C = this.f103w;
        xVar.f348b = 0;
        N0(a1Var, xVar);
        return i2;
    }

    @Override // androidx.recyclerview.widget.t0
    public final void S(int i2, int i3) {
        H0(i2, i3, 1);
    }

    public final void S0(int i2) {
        x xVar = this.f101u;
        xVar.f351e = i2;
        xVar.f350d = this.f103w != (i2 == -1) ? -1 : 1;
    }

    @Override // androidx.recyclerview.widget.t0
    public final void T() {
        this.A.e();
        h0();
    }

    public final void T0(int i2) {
        x xVar = this.f101u;
        boolean z2 = false;
        xVar.f348b = 0;
        xVar.f349c = i2;
        RecyclerView recyclerView = this.f317b;
        if (recyclerView != null && recyclerView.f77h) {
            xVar.f352f = this.q.h() - 0;
            xVar.f353g = this.q.f() + 0;
        } else {
            xVar.f353g = this.q.e() + 0;
            xVar.f352f = 0;
        }
        xVar.f354h = false;
        xVar.f347a = true;
        if (this.q.g() == 0 && this.q.e() == 0) {
            z2 = true;
        }
        xVar.f355i = z2;
    }

    @Override // androidx.recyclerview.widget.t0
    public final void U(int i2, int i3) {
        H0(i2, i3, 8);
    }

    public final void U0(p1 p1Var, int i2, int i3) {
        int i4 = p1Var.f264d;
        if (i2 == -1) {
            int i5 = p1Var.f262b;
            if (i5 == Integer.MIN_VALUE) {
                View view = (View) p1Var.f261a.get(0);
                m1 h2 = p1.h(view);
                p1Var.f262b = p1Var.f266f.q.d(view);
                h2.getClass();
                i5 = p1Var.f262b;
            }
            if (i5 + i4 > i3) {
                return;
            }
        } else {
            int i6 = p1Var.f263c;
            if (i6 == Integer.MIN_VALUE) {
                p1Var.a();
                i6 = p1Var.f263c;
            }
            if (i6 - i4 < i3) {
                return;
            }
        }
        this.f104x.set(p1Var.f265e, false);
    }

    @Override // androidx.recyclerview.widget.t0
    public final void V(int i2, int i3) {
        H0(i2, i3, 2);
    }

    @Override // androidx.recyclerview.widget.t0
    public final void W(int i2, int i3) {
        H0(i2, i3, 4);
    }

    @Override // androidx.recyclerview.widget.t0
    public final void X(a1 a1Var, e1 e1Var) {
        K0(a1Var, e1Var, true);
    }

    @Override // androidx.recyclerview.widget.t0
    public final void Y(e1 e1Var) {
        this.f105y = -1;
        this.f106z = Integer.MIN_VALUE;
        this.E = null;
        this.G.a();
    }

    @Override // androidx.recyclerview.widget.t0
    public final void Z(Parcelable parcelable) {
        if (parcelable instanceof o1) {
            o1 o1Var = (o1) parcelable;
            this.E = o1Var;
            if (this.f105y != -1) {
                o1Var.f252d = null;
                o1Var.f251c = 0;
                o1Var.f249a = -1;
                o1Var.f250b = -1;
                o1Var.f252d = null;
                o1Var.f251c = 0;
                o1Var.f253e = 0;
                o1Var.f254f = null;
                o1Var.f255g = null;
            }
            h0();
        }
    }

    @Override // androidx.recyclerview.widget.t0
    public final Parcelable a0() {
        int i2;
        int h2;
        int[] iArr;
        o1 o1Var = this.E;
        if (o1Var != null) {
            return new o1(o1Var);
        }
        o1 o1Var2 = new o1();
        o1Var2.f256h = this.f102v;
        o1Var2.f257i = this.C;
        o1Var2.f258j = this.D;
        t1 t1Var = this.A;
        if (t1Var == null || (iArr = (int[]) t1Var.f331b) == null) {
            o1Var2.f253e = 0;
        } else {
            o1Var2.f254f = iArr;
            o1Var2.f253e = iArr.length;
            o1Var2.f255g = (List) t1Var.f332c;
        }
        if (u() > 0) {
            o1Var2.f249a = this.C ? E0() : D0();
            View z0 = this.f103w ? z0(true) : A0(true);
            o1Var2.f250b = z0 != null ? t0.C(z0) : -1;
            int i3 = this.f96o;
            o1Var2.f251c = i3;
            o1Var2.f252d = new int[i3];
            for (int i4 = 0; i4 < this.f96o; i4++) {
                if (this.C) {
                    i2 = this.f97p[i4].f(Integer.MIN_VALUE);
                    if (i2 != Integer.MIN_VALUE) {
                        h2 = this.q.f();
                        i2 -= h2;
                        o1Var2.f252d[i4] = i2;
                    } else {
                        o1Var2.f252d[i4] = i2;
                    }
                } else {
                    i2 = this.f97p[i4].i(Integer.MIN_VALUE);
                    if (i2 != Integer.MIN_VALUE) {
                        h2 = this.q.h();
                        i2 -= h2;
                        o1Var2.f252d[i4] = i2;
                    } else {
                        o1Var2.f252d[i4] = i2;
                    }
                }
            }
        } else {
            o1Var2.f249a = -1;
            o1Var2.f250b = -1;
            o1Var2.f251c = 0;
        }
        return o1Var2;
    }

    @Override // androidx.recyclerview.widget.t0
    public final void b(String str) {
        RecyclerView recyclerView;
        if (this.E != null || (recyclerView = this.f317b) == null) {
            return;
        }
        recyclerView.h(str);
    }

    @Override // androidx.recyclerview.widget.t0
    public final void b0(int i2) {
        if (i2 == 0) {
            u0();
        }
    }

    @Override // androidx.recyclerview.widget.t0
    public final boolean c() {
        return this.f99s == 0;
    }

    @Override // androidx.recyclerview.widget.t0
    public final boolean d() {
        return this.f99s == 1;
    }

    @Override // androidx.recyclerview.widget.t0
    public final boolean e(u0 u0Var) {
        return u0Var instanceof m1;
    }

    @Override // androidx.recyclerview.widget.t0
    public final void g(int i2, int i3, e1 e1Var, s sVar) {
        x xVar;
        int f2;
        int i4;
        if (this.f99s != 0) {
            i2 = i3;
        }
        if (u() == 0 || i2 == 0) {
            return;
        }
        M0(i2);
        int[] iArr = this.I;
        if (iArr == null || iArr.length < this.f96o) {
            this.I = new int[this.f96o];
        }
        int i5 = 0;
        int i6 = 0;
        while (true) {
            int i7 = this.f96o;
            xVar = this.f101u;
            if (i5 >= i7) {
                break;
            }
            if (xVar.f350d == -1) {
                f2 = xVar.f352f;
                i4 = this.f97p[i5].i(f2);
            } else {
                f2 = this.f97p[i5].f(xVar.f353g);
                i4 = xVar.f353g;
            }
            int i8 = f2 - i4;
            if (i8 >= 0) {
                this.I[i6] = i8;
                i6++;
            }
            i5++;
        }
        Arrays.sort(this.I, 0, i6);
        for (int i9 = 0; i9 < i6; i9++) {
            int i10 = xVar.f349c;
            if (!(i10 >= 0 && i10 < e1Var.b())) {
                return;
            }
            sVar.a(xVar.f349c, this.I[i9]);
            xVar.f349c += xVar.f350d;
        }
    }

    @Override // androidx.recyclerview.widget.t0
    public final int i(e1 e1Var) {
        return v0(e1Var);
    }

    @Override // androidx.recyclerview.widget.t0
    public final int i0(int i2, a1 a1Var, e1 e1Var) {
        return R0(i2, a1Var, e1Var);
    }

    @Override // androidx.recyclerview.widget.t0
    public final int j(e1 e1Var) {
        return w0(e1Var);
    }

    @Override // androidx.recyclerview.widget.t0
    public final void j0(int i2) {
        o1 o1Var = this.E;
        if (o1Var != null && o1Var.f249a != i2) {
            o1Var.f252d = null;
            o1Var.f251c = 0;
            o1Var.f249a = -1;
            o1Var.f250b = -1;
        }
        this.f105y = i2;
        this.f106z = Integer.MIN_VALUE;
        h0();
    }

    @Override // androidx.recyclerview.widget.t0
    public final int k(e1 e1Var) {
        return x0(e1Var);
    }

    @Override // androidx.recyclerview.widget.t0
    public final int k0(int i2, a1 a1Var, e1 e1Var) {
        return R0(i2, a1Var, e1Var);
    }

    @Override // androidx.recyclerview.widget.t0
    public final int l(e1 e1Var) {
        return v0(e1Var);
    }

    @Override // androidx.recyclerview.widget.t0
    public final int m(e1 e1Var) {
        return w0(e1Var);
    }

    @Override // androidx.recyclerview.widget.t0
    public final int n(e1 e1Var) {
        return x0(e1Var);
    }

    @Override // androidx.recyclerview.widget.t0
    public final void n0(Rect rect, int i2, int i3) {
        int f2;
        int f3;
        int A = A() + z();
        int y2 = y() + B();
        if (this.f99s == 1) {
            int height = rect.height() + y2;
            RecyclerView recyclerView = this.f317b;
            Field field = g.v.f448a;
            f3 = t0.f(i3, height, g.j.d(recyclerView));
            f2 = t0.f(i2, (this.f100t * this.f96o) + A, g.j.e(this.f317b));
        } else {
            int width = rect.width() + A;
            RecyclerView recyclerView2 = this.f317b;
            Field field2 = g.v.f448a;
            f2 = t0.f(i2, width, g.j.e(recyclerView2));
            f3 = t0.f(i3, (this.f100t * this.f96o) + y2, g.j.d(this.f317b));
        }
        this.f317b.setMeasuredDimension(f2, f3);
    }

    @Override // androidx.recyclerview.widget.t0
    public final u0 q() {
        return this.f99s == 0 ? new m1(-2, -1) : new m1(-1, -2);
    }

    @Override // androidx.recyclerview.widget.t0
    public final u0 r(Context context, AttributeSet attributeSet) {
        return new m1(context, attributeSet);
    }

    @Override // androidx.recyclerview.widget.t0
    public final u0 s(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof ViewGroup.MarginLayoutParams ? new m1((ViewGroup.MarginLayoutParams) layoutParams) : new m1(layoutParams);
    }

    @Override // androidx.recyclerview.widget.t0
    public final boolean t0() {
        return this.E == null;
    }

    public final boolean u0() {
        int D0;
        if (u() != 0 && this.B != 0 && this.f321f) {
            if (this.f103w) {
                D0 = E0();
                D0();
            } else {
                D0 = D0();
                E0();
            }
            if (D0 == 0 && I0() != null) {
                this.A.e();
                this.f320e = true;
                h0();
                return true;
            }
        }
        return false;
    }

    public final int v0(e1 e1Var) {
        if (u() == 0) {
            return 0;
        }
        e0 e0Var = this.q;
        boolean z2 = this.H;
        return b0.d.n(e1Var, e0Var, A0(!z2), z0(!z2), this, this.H);
    }

    public final int w0(e1 e1Var) {
        if (u() == 0) {
            return 0;
        }
        e0 e0Var = this.q;
        boolean z2 = this.H;
        return b0.d.o(e1Var, e0Var, A0(!z2), z0(!z2), this, this.H, this.f103w);
    }

    public final int x0(e1 e1Var) {
        if (u() == 0) {
            return 0;
        }
        e0 e0Var = this.q;
        boolean z2 = this.H;
        return b0.d.p(e1Var, e0Var, A0(!z2), z0(!z2), this, this.H);
    }

    /* JADX WARN: Type inference failed for: r8v0 */
    /* JADX WARN: Type inference failed for: r8v1, types: [boolean, int] */
    /* JADX WARN: Type inference failed for: r8v31 */
    public final int y0(a1 a1Var, x xVar, e1 e1Var) {
        p1 p1Var;
        ?? r8;
        int v2;
        int i2;
        int v3;
        int i3;
        int c2;
        int h2;
        int c3;
        int i4;
        int i5;
        int i6;
        int i7 = 1;
        this.f104x.set(0, this.f96o, true);
        x xVar2 = this.f101u;
        int i8 = xVar2.f355i ? xVar.f351e == 1 ? Integer.MAX_VALUE : Integer.MIN_VALUE : xVar.f351e == 1 ? xVar.f353g + xVar.f348b : xVar.f352f - xVar.f348b;
        int i9 = xVar.f351e;
        for (int i10 = 0; i10 < this.f96o; i10++) {
            if (!this.f97p[i10].f261a.isEmpty()) {
                U0(this.f97p[i10], i9, i8);
            }
        }
        int f2 = this.f103w ? this.q.f() : this.q.h();
        boolean z2 = false;
        while (true) {
            int i11 = xVar.f349c;
            if (!(i11 >= 0 && i11 < e1Var.b()) || (!xVar2.f355i && this.f104x.isEmpty())) {
                break;
            }
            View view = a1Var.k(xVar.f349c, Long.MAX_VALUE).itemView;
            xVar.f349c += xVar.f350d;
            m1 m1Var = (m1) view.getLayoutParams();
            int a2 = m1Var.a();
            t1 t1Var = this.A;
            int[] iArr = (int[]) t1Var.f331b;
            int i12 = (iArr == null || a2 >= iArr.length) ? -1 : iArr[a2];
            if (i12 == -1) {
                if (L0(xVar.f351e)) {
                    i5 = this.f96o - i7;
                    i4 = -1;
                    i6 = -1;
                } else {
                    i4 = this.f96o;
                    i5 = 0;
                    i6 = 1;
                }
                p1 p1Var2 = null;
                if (xVar.f351e == i7) {
                    int h3 = this.q.h();
                    int i13 = Integer.MAX_VALUE;
                    while (i5 != i4) {
                        p1 p1Var3 = this.f97p[i5];
                        int f3 = p1Var3.f(h3);
                        if (f3 < i13) {
                            i13 = f3;
                            p1Var2 = p1Var3;
                        }
                        i5 += i6;
                    }
                } else {
                    int f4 = this.q.f();
                    int i14 = Integer.MIN_VALUE;
                    while (i5 != i4) {
                        p1 p1Var4 = this.f97p[i5];
                        int i15 = p1Var4.i(f4);
                        if (i15 > i14) {
                            p1Var2 = p1Var4;
                            i14 = i15;
                        }
                        i5 += i6;
                    }
                }
                p1Var = p1Var2;
                t1Var.f(a2);
                ((int[]) t1Var.f331b)[a2] = p1Var.f265e;
            } else {
                p1Var = this.f97p[i12];
            }
            m1Var.f233e = p1Var;
            if (xVar.f351e == 1) {
                r8 = 0;
                a(view, -1, false);
            } else {
                r8 = 0;
                a(view, 0, false);
            }
            if (this.f99s == 1) {
                v2 = t0.v(this.f100t, this.f326k, r8, ((ViewGroup.MarginLayoutParams) m1Var).width, r8);
                v3 = t0.v(this.f329n, this.f327l, y() + B(), ((ViewGroup.MarginLayoutParams) m1Var).height, true);
                i2 = 0;
            } else {
                v2 = t0.v(this.f328m, this.f326k, A() + z(), ((ViewGroup.MarginLayoutParams) m1Var).width, true);
                i2 = 0;
                v3 = t0.v(this.f100t, this.f327l, 0, ((ViewGroup.MarginLayoutParams) m1Var).height, false);
            }
            RecyclerView recyclerView = this.f317b;
            Rect rect = this.F;
            if (recyclerView == null) {
                rect.set(i2, i2, i2, i2);
            } else {
                rect.set(recyclerView.J(view));
            }
            m1 m1Var2 = (m1) view.getLayoutParams();
            int V0 = V0(v2, ((ViewGroup.MarginLayoutParams) m1Var2).leftMargin + rect.left, ((ViewGroup.MarginLayoutParams) m1Var2).rightMargin + rect.right);
            int V02 = V0(v3, ((ViewGroup.MarginLayoutParams) m1Var2).topMargin + rect.top, ((ViewGroup.MarginLayoutParams) m1Var2).bottomMargin + rect.bottom);
            if (q0(view, V0, V02, m1Var2)) {
                view.measure(V0, V02);
            }
            if (xVar.f351e == 1) {
                c2 = p1Var.f(f2);
                i3 = this.q.c(view) + c2;
            } else {
                i3 = p1Var.i(f2);
                c2 = i3 - this.q.c(view);
            }
            int i16 = xVar.f351e;
            p1 p1Var5 = m1Var.f233e;
            p1Var5.getClass();
            if (i16 == 1) {
                m1 m1Var3 = (m1) view.getLayoutParams();
                m1Var3.f233e = p1Var5;
                ArrayList arrayList = p1Var5.f261a;
                arrayList.add(view);
                p1Var5.f263c = Integer.MIN_VALUE;
                if (arrayList.size() == 1) {
                    p1Var5.f262b = Integer.MIN_VALUE;
                }
                if (m1Var3.c() || m1Var3.b()) {
                    p1Var5.f264d = p1Var5.f266f.q.c(view) + p1Var5.f264d;
                }
            } else {
                m1 m1Var4 = (m1) view.getLayoutParams();
                m1Var4.f233e = p1Var5;
                ArrayList arrayList2 = p1Var5.f261a;
                arrayList2.add(0, view);
                p1Var5.f262b = Integer.MIN_VALUE;
                if (arrayList2.size() == 1) {
                    p1Var5.f263c = Integer.MIN_VALUE;
                }
                if (m1Var4.c() || m1Var4.b()) {
                    p1Var5.f264d = p1Var5.f266f.q.c(view) + p1Var5.f264d;
                }
            }
            if (J0() && this.f99s == 1) {
                c3 = this.f98r.f() - (((this.f96o - 1) - p1Var.f265e) * this.f100t);
                h2 = c3 - this.f98r.c(view);
            } else {
                h2 = this.f98r.h() + (p1Var.f265e * this.f100t);
                c3 = this.f98r.c(view) + h2;
            }
            if (this.f99s == 1) {
                int i17 = h2;
                h2 = c2;
                c2 = i17;
                int i18 = c3;
                c3 = i3;
                i3 = i18;
            }
            t0.I(view, c2, h2, i3, c3);
            U0(p1Var, xVar2.f351e, i8);
            N0(a1Var, xVar2);
            if (xVar2.f354h && view.hasFocusable()) {
                this.f104x.set(p1Var.f265e, false);
            }
            i7 = 1;
            z2 = true;
        }
        if (!z2) {
            N0(a1Var, xVar2);
        }
        int h4 = xVar2.f351e == -1 ? this.q.h() - G0(this.q.h()) : F0(this.q.f()) - this.q.f();
        if (h4 > 0) {
            return Math.min(xVar.f348b, h4);
        }
        return 0;
    }

    public final View z0(boolean z2) {
        int h2 = this.q.h();
        int f2 = this.q.f();
        View view = null;
        for (int u2 = u() - 1; u2 >= 0; u2--) {
            View t2 = t(u2);
            int d2 = this.q.d(t2);
            int b2 = this.q.b(t2);
            if (b2 > h2 && d2 < f2) {
                if (b2 <= f2 || !z2) {
                    return t2;
                }
                if (view == null) {
                    view = t2;
                }
            }
        }
        return view;
    }
}
