package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public int f107a;

    /* renamed from: b, reason: collision with root package name */
    public int f108b;

    /* renamed from: c, reason: collision with root package name */
    public Object f109c;

    /* renamed from: d, reason: collision with root package name */
    public int f110d;

    public a(int i2, int i3, int i4, Object obj) {
        this.f107a = i2;
        this.f108b = i3;
        this.f110d = i4;
        this.f109c = obj;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        int i2 = this.f107a;
        if (i2 != aVar.f107a) {
            return false;
        }
        if (i2 == 8 && Math.abs(this.f110d - this.f108b) == 1 && this.f110d == aVar.f108b && this.f108b == aVar.f110d) {
            return true;
        }
        if (this.f110d != aVar.f110d || this.f108b != aVar.f108b) {
            return false;
        }
        Object obj2 = this.f109c;
        Object obj3 = aVar.f109c;
        if (obj2 != null) {
            if (!obj2.equals(obj3)) {
                return false;
            }
        } else if (obj3 != null) {
            return false;
        }
        return true;
    }

    public final int hashCode() {
        return (((this.f107a * 31) + this.f108b) * 31) + this.f110d;
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append(Integer.toHexString(System.identityHashCode(this)));
        sb.append("[");
        int i2 = this.f107a;
        sb.append(i2 != 1 ? i2 != 2 ? i2 != 4 ? i2 != 8 ? "??" : "mv" : "up" : "rm" : "add");
        sb.append(",s:");
        sb.append(this.f108b);
        sb.append("c:");
        sb.append(this.f110d);
        sb.append(",p:");
        sb.append(this.f109c);
        sb.append("]");
        return sb.toString();
    }
}
