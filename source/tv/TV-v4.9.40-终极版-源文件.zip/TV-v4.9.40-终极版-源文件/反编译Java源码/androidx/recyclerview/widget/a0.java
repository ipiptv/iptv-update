package androidx.recyclerview.widget;

import android.view.View;
import java.util.List;

/* loaded from: classes.dex */
public final class a0 {

    /* renamed from: b, reason: collision with root package name */
    public int f112b;

    /* renamed from: c, reason: collision with root package name */
    public int f113c;

    /* renamed from: d, reason: collision with root package name */
    public int f114d;

    /* renamed from: e, reason: collision with root package name */
    public int f115e;

    /* renamed from: f, reason: collision with root package name */
    public int f116f;

    /* renamed from: g, reason: collision with root package name */
    public int f117g;

    /* renamed from: j, reason: collision with root package name */
    public int f120j;

    /* renamed from: l, reason: collision with root package name */
    public boolean f122l;

    /* renamed from: a, reason: collision with root package name */
    public boolean f111a = true;

    /* renamed from: h, reason: collision with root package name */
    public int f118h = 0;

    /* renamed from: i, reason: collision with root package name */
    public int f119i = 0;

    /* renamed from: k, reason: collision with root package name */
    public List f121k = null;

    public final void a(View view) {
        int a2;
        int size = this.f121k.size();
        View view2 = null;
        int i2 = Integer.MAX_VALUE;
        for (int i3 = 0; i3 < size; i3++) {
            View view3 = ((i1) this.f121k.get(i3)).itemView;
            u0 u0Var = (u0) view3.getLayoutParams();
            if (view3 != view && !u0Var.c() && (a2 = (u0Var.a() - this.f114d) * this.f115e) >= 0 && a2 < i2) {
                view2 = view3;
                if (a2 == 0) {
                    break;
                } else {
                    i2 = a2;
                }
            }
        }
        this.f114d = view2 == null ? -1 : ((u0) view2.getLayoutParams()).a();
    }

    public final View b(a1 a1Var) {
        List list = this.f121k;
        if (list == null) {
            View view = a1Var.k(this.f114d, Long.MAX_VALUE).itemView;
            this.f114d += this.f115e;
            return view;
        }
        int size = list.size();
        for (int i2 = 0; i2 < size; i2++) {
            View view2 = ((i1) this.f121k.get(i2)).itemView;
            u0 u0Var = (u0) view2.getLayoutParams();
            if (!u0Var.c() && this.f114d == u0Var.a()) {
                a(view2);
                return view2;
            }
        }
        return null;
    }
}
