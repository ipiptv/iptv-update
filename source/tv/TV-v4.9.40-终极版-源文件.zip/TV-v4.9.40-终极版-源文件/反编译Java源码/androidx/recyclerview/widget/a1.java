package androidx.recyclerview.widget;

import android.util.Log;
import android.util.SparseArray;
import android.view.View;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.Set;

/* loaded from: classes.dex */
public final class a1 {

    /* renamed from: a, reason: collision with root package name */
    public final ArrayList f123a;

    /* renamed from: b, reason: collision with root package name */
    public ArrayList f124b;

    /* renamed from: c, reason: collision with root package name */
    public final ArrayList f125c;

    /* renamed from: d, reason: collision with root package name */
    public final List f126d;

    /* renamed from: e, reason: collision with root package name */
    public int f127e;

    /* renamed from: f, reason: collision with root package name */
    public int f128f;

    /* renamed from: g, reason: collision with root package name */
    public z0 f129g;

    /* renamed from: h, reason: collision with root package name */
    public final /* synthetic */ RecyclerView f130h;

    public a1(RecyclerView recyclerView) {
        this.f130h = recyclerView;
        ArrayList arrayList = new ArrayList();
        this.f123a = arrayList;
        this.f124b = null;
        this.f125c = new ArrayList();
        this.f126d = Collections.unmodifiableList(arrayList);
        this.f127e = 2;
        this.f128f = 2;
    }

    public final void a(i1 i1Var, boolean z2) {
        RecyclerView.i(i1Var);
        View view = i1Var.itemView;
        RecyclerView recyclerView = this.f130h;
        k1 k1Var = recyclerView.m0;
        if (k1Var != null) {
            j1 j1Var = k1Var.f211e;
            g.v.b(view, j1Var instanceof j1 ? (g.c) j1Var.f204e.remove(view) : null);
        }
        if (z2) {
            ArrayList arrayList = recyclerView.f85o;
            if (arrayList.size() > 0) {
                c.c(arrayList.get(0));
                throw null;
            }
            i0 i0Var = recyclerView.f83m;
            if (i0Var != null) {
                i0Var.onViewRecycled(i1Var);
            }
            if (recyclerView.f74f0 != null) {
                recyclerView.f75g.n(i1Var);
            }
            if (RecyclerView.z0) {
                Log.d("RecyclerView", "dispatchViewRecycled: " + i1Var);
            }
        }
        i1Var.mBindingAdapter = null;
        i1Var.mOwnerRecyclerView = null;
        z0 c2 = c();
        c2.getClass();
        int itemViewType = i1Var.getItemViewType();
        ArrayList arrayList2 = c2.a(itemViewType).f361a;
        if (((y0) c2.f369a.get(itemViewType)).f362b <= arrayList2.size()) {
            b0.d.g(i1Var.itemView);
        } else {
            if (RecyclerView.y0 && arrayList2.contains(i1Var)) {
                throw new IllegalArgumentException("this scrap item already exists");
            }
            i1Var.resetInternal();
            arrayList2.add(i1Var);
        }
    }

    public final int b(int i2) {
        RecyclerView recyclerView = this.f130h;
        if (i2 >= 0 && i2 < recyclerView.f74f0.b()) {
            return !recyclerView.f74f0.f159f ? i2 : recyclerView.f71e.f(i2, 0);
        }
        throw new IndexOutOfBoundsException("invalid position " + i2 + ". State item count is " + recyclerView.f74f0.b() + recyclerView.y());
    }

    public final z0 c() {
        if (this.f129g == null) {
            this.f129g = new z0();
            d();
        }
        return this.f129g;
    }

    public final void d() {
        if (this.f129g != null) {
            RecyclerView recyclerView = this.f130h;
            if (recyclerView.f83m == null || !recyclerView.isAttachedToWindow()) {
                return;
            }
            z0 z0Var = this.f129g;
            z0Var.f371c.add(recyclerView.f83m);
        }
    }

    public final void e(i0 i0Var, boolean z2) {
        z0 z0Var = this.f129g;
        if (z0Var == null) {
            return;
        }
        Set set = z0Var.f371c;
        set.remove(i0Var);
        if (set.size() != 0 || z2) {
            return;
        }
        int i2 = 0;
        while (true) {
            SparseArray sparseArray = z0Var.f369a;
            if (i2 >= sparseArray.size()) {
                return;
            }
            ArrayList arrayList = ((y0) sparseArray.get(sparseArray.keyAt(i2))).f361a;
            for (int i3 = 0; i3 < arrayList.size(); i3++) {
                b0.d.g(((i1) arrayList.get(i3)).itemView);
            }
            i2++;
        }
    }

    public final void f() {
        ArrayList arrayList = this.f125c;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            g(size);
        }
        arrayList.clear();
        if (RecyclerView.E0) {
            s sVar = this.f130h.f72e0;
            int[] iArr = sVar.f301c;
            if (iArr != null) {
                Arrays.fill(iArr, -1);
            }
            sVar.f302d = 0;
        }
    }

    public final void g(int i2) {
        if (RecyclerView.z0) {
            Log.d("RecyclerView", "Recycling cached view at index " + i2);
        }
        ArrayList arrayList = this.f125c;
        i1 i1Var = (i1) arrayList.get(i2);
        if (RecyclerView.z0) {
            Log.d("RecyclerView", "CachedViewHolder to be recycled: " + i1Var);
        }
        a(i1Var, true);
        arrayList.remove(i2);
    }

    public final void h(View view) {
        i1 I = RecyclerView.I(view);
        boolean isTmpDetached = I.isTmpDetached();
        RecyclerView recyclerView = this.f130h;
        if (isTmpDetached) {
            recyclerView.removeDetachedView(view, false);
        }
        if (I.isScrap()) {
            I.unScrap();
        } else if (I.wasReturnedFromScrap()) {
            I.clearReturnedFromScrapFlag();
        }
        i(I);
        if (recyclerView.L == null || I.isRecyclable()) {
            return;
        }
        recyclerView.L.d(I);
    }

    public final void i(i1 i1Var) {
        boolean z2;
        boolean z3;
        boolean z4;
        boolean z5;
        boolean isScrap = i1Var.isScrap();
        RecyclerView recyclerView = this.f130h;
        if (isScrap || i1Var.itemView.getParent() != null) {
            StringBuilder sb = new StringBuilder("Scrapped or attached views may not be recycled. isScrap:");
            sb.append(i1Var.isScrap());
            sb.append(" isAttached:");
            sb.append(i1Var.itemView.getParent() != null);
            sb.append(recyclerView.y());
            throw new IllegalArgumentException(sb.toString());
        }
        if (i1Var.isTmpDetached()) {
            StringBuilder sb2 = new StringBuilder("Tmp detached view should be removed from RecyclerView before it can be recycled: ");
            sb2.append(i1Var);
            throw new IllegalArgumentException(c.b(recyclerView, sb2));
        }
        if (i1Var.shouldIgnore()) {
            throw new IllegalArgumentException(c.b(recyclerView, new StringBuilder("Trying to recycle an ignored view holder. You should first call stopIgnoringView(view) before calling recycle.")));
        }
        boolean doesTransientStatePreventRecycling = i1Var.doesTransientStatePreventRecycling();
        i0 i0Var = recyclerView.f83m;
        boolean z6 = i0Var != null && doesTransientStatePreventRecycling && i0Var.onFailedToRecycleView(i1Var);
        boolean z7 = RecyclerView.y0;
        ArrayList arrayList = this.f125c;
        if (z7 && arrayList.contains(i1Var)) {
            StringBuilder sb3 = new StringBuilder("cached view received recycle internal? ");
            sb3.append(i1Var);
            throw new IllegalArgumentException(c.b(recyclerView, sb3));
        }
        if (z6 || i1Var.isRecyclable()) {
            if (this.f128f <= 0 || i1Var.hasAnyOfTheFlags(526)) {
                z2 = false;
            } else {
                int size = arrayList.size();
                if (size >= this.f128f && size > 0) {
                    g(0);
                    size--;
                }
                if (RecyclerView.E0 && size > 0) {
                    int i2 = i1Var.mPosition;
                    s sVar = recyclerView.f72e0;
                    if (sVar.f301c != null) {
                        int i3 = sVar.f302d * 2;
                        for (int i4 = 0; i4 < i3; i4 += 2) {
                            if (sVar.f301c[i4] == i2) {
                                z4 = true;
                                break;
                            }
                        }
                    }
                    z4 = false;
                    if (!z4) {
                        do {
                            size--;
                            if (size < 0) {
                                break;
                            }
                            int i5 = ((i1) arrayList.get(size)).mPosition;
                            if (sVar.f301c != null) {
                                int i6 = sVar.f302d * 2;
                                for (int i7 = 0; i7 < i6; i7 += 2) {
                                    if (sVar.f301c[i7] == i5) {
                                        z5 = true;
                                        break;
                                    }
                                }
                            }
                            z5 = false;
                        } while (z5);
                        size++;
                    }
                }
                arrayList.add(size, i1Var);
                z2 = true;
            }
            if (!z2) {
                a(i1Var, true);
                r1 = true;
            }
            z3 = z2;
        } else {
            if (RecyclerView.z0) {
                Log.d("RecyclerView", "trying to recycle a non-recycleable holder. Hopefully, it will re-visit here. We are still removing it from animation lists" + recyclerView.y());
            }
            z3 = false;
        }
        recyclerView.f75g.n(i1Var);
        if (z3 || r1 || !doesTransientStatePreventRecycling) {
            return;
        }
        b0.d.g(i1Var.itemView);
        i1Var.mBindingAdapter = null;
        i1Var.mOwnerRecyclerView = null;
    }

    /* JADX WARN: Removed duplicated region for block: B:17:0x003d  */
    /* JADX WARN: Removed duplicated region for block: B:19:0x0043  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void j(android.view.View r6) {
        /*
            r5 = this;
            androidx.recyclerview.widget.i1 r6 = androidx.recyclerview.widget.RecyclerView.I(r6)
            r0 = 12
            boolean r0 = r6.hasAnyOfTheFlags(r0)
            androidx.recyclerview.widget.RecyclerView r1 = r5.f130h
            r2 = 0
            if (r0 != 0) goto L54
            boolean r0 = r6.isUpdated()
            if (r0 == 0) goto L54
            androidx.recyclerview.widget.o0 r0 = r1.L
            r3 = 1
            if (r0 == 0) goto L3f
            java.util.List r4 = r6.getUnmodifiedPayloads()
            androidx.recyclerview.widget.l r0 = (androidx.recyclerview.widget.l) r0
            boolean r4 = r4.isEmpty()
            if (r4 == 0) goto L39
            boolean r0 = r0.f213g
            if (r0 == 0) goto L33
            boolean r0 = r6.isInvalid()
            if (r0 == 0) goto L31
            goto L33
        L31:
            r0 = 0
            goto L34
        L33:
            r0 = 1
        L34:
            if (r0 == 0) goto L37
            goto L39
        L37:
            r0 = 0
            goto L3a
        L39:
            r0 = 1
        L3a:
            if (r0 == 0) goto L3d
            goto L3f
        L3d:
            r0 = 0
            goto L40
        L3f:
            r0 = 1
        L40:
            if (r0 == 0) goto L43
            goto L54
        L43:
            java.util.ArrayList r0 = r5.f124b
            if (r0 != 0) goto L4e
            java.util.ArrayList r0 = new java.util.ArrayList
            r0.<init>()
            r5.f124b = r0
        L4e:
            r6.setScrapContainer(r5, r3)
            java.util.ArrayList r0 = r5.f124b
            goto L7f
        L54:
            boolean r0 = r6.isInvalid()
            if (r0 == 0) goto L7a
            boolean r0 = r6.isRemoved()
            if (r0 != 0) goto L7a
            androidx.recyclerview.widget.i0 r0 = r1.f83m
            boolean r0 = r0.hasStableIds()
            if (r0 == 0) goto L69
            goto L7a
        L69:
            java.lang.IllegalArgumentException r6 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r2 = "Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool."
            r0.<init>(r2)
            java.lang.String r0 = androidx.recyclerview.widget.c.b(r1, r0)
            r6.<init>(r0)
            throw r6
        L7a:
            r6.setScrapContainer(r5, r2)
            java.util.ArrayList r0 = r5.f123a
        L7f:
            r0.add(r6)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.a1.j(android.view.View):void");
    }

    /* JADX WARN: Code restructure failed: missing block: B:157:0x030d, code lost:
    
        r8 = r5;
     */
    /* JADX WARN: Code restructure failed: missing block: B:271:0x04a5, code lost:
    
        if ((r11 == 0 || r11 + r9 < r22) == false) goto L257;
     */
    /* JADX WARN: Removed duplicated region for block: B:100:0x0136  */
    /* JADX WARN: Removed duplicated region for block: B:102:0x0145  */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0084  */
    /* JADX WARN: Removed duplicated region for block: B:239:0x054c  */
    /* JADX WARN: Removed duplicated region for block: B:243:0x056a A[ADDED_TO_REGION] */
    /* JADX WARN: Removed duplicated region for block: B:248:0x0551  */
    /* JADX WARN: Removed duplicated region for block: B:311:0x0086  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x01c8  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final androidx.recyclerview.widget.i1 k(int r21, long r22) {
        /*
            Method dump skipped, instructions count: 1443
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.a1.k(int, long):androidx.recyclerview.widget.i1");
    }

    public final void l(i1 i1Var) {
        (i1Var.mInChangeScrap ? this.f124b : this.f123a).remove(i1Var);
        i1Var.mScrapContainer = null;
        i1Var.mInChangeScrap = false;
        i1Var.clearReturnedFromScrapFlag();
    }

    public final void m() {
        t0 t0Var = this.f130h.f84n;
        this.f128f = this.f127e + (t0Var != null ? t0Var.f324i : 0);
        ArrayList arrayList = this.f125c;
        for (int size = arrayList.size() - 1; size >= 0 && arrayList.size() > this.f128f; size--) {
            g(size);
        }
    }
}
