package androidx.recyclerview.widget;

import java.util.ArrayList;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: d, reason: collision with root package name */
    public final p0 f134d;

    /* renamed from: a, reason: collision with root package name */
    public final f.b f131a = new f.b(30);

    /* renamed from: b, reason: collision with root package name */
    public final ArrayList f132b = new ArrayList();

    /* renamed from: c, reason: collision with root package name */
    public final ArrayList f133c = new ArrayList();

    /* renamed from: f, reason: collision with root package name */
    public int f136f = 0;

    /* renamed from: e, reason: collision with root package name */
    public final r0 f135e = new r0(2, this);

    public b(p0 p0Var) {
        this.f134d = p0Var;
    }

    public final boolean a(int i2) {
        ArrayList arrayList = this.f133c;
        int size = arrayList.size();
        for (int i3 = 0; i3 < size; i3++) {
            a aVar = (a) arrayList.get(i3);
            int i4 = aVar.f107a;
            if (i4 == 8) {
                if (f(aVar.f110d, i3 + 1) == i2) {
                    return true;
                }
            } else if (i4 == 1) {
                int i5 = aVar.f108b;
                int i6 = aVar.f110d + i5;
                while (i5 < i6) {
                    if (f(i5, i3 + 1) == i2) {
                        return true;
                    }
                    i5++;
                }
            } else {
                continue;
            }
        }
        return false;
    }

    public final void b() {
        ArrayList arrayList = this.f133c;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            this.f134d.a((a) arrayList.get(i2));
        }
        l(arrayList);
        this.f136f = 0;
    }

    public final void c() {
        b();
        ArrayList arrayList = this.f132b;
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            a aVar = (a) arrayList.get(i2);
            int i3 = aVar.f107a;
            p0 p0Var = this.f134d;
            if (i3 == 1) {
                p0Var.a(aVar);
                p0Var.e(aVar.f108b, aVar.f110d);
            } else if (i3 == 2) {
                p0Var.a(aVar);
                int i4 = aVar.f108b;
                int i5 = aVar.f110d;
                RecyclerView recyclerView = p0Var.f260a;
                recyclerView.M(i4, i5, true);
                recyclerView.i0 = true;
                recyclerView.f74f0.f155b += i5;
            } else if (i3 == 4) {
                p0Var.a(aVar);
                p0Var.d(aVar.f108b, aVar.f110d, aVar.f109c);
            } else if (i3 == 8) {
                p0Var.a(aVar);
                p0Var.f(aVar.f108b, aVar.f110d);
            }
        }
        l(arrayList);
        this.f136f = 0;
    }

    public final void d(a aVar) {
        int i2;
        int i3 = aVar.f107a;
        if (i3 == 1 || i3 == 8) {
            throw new IllegalArgumentException("should not dispatch add or move for pre layout");
        }
        int m2 = m(aVar.f108b, i3);
        int i4 = aVar.f108b;
        int i5 = aVar.f107a;
        if (i5 == 2) {
            i2 = 0;
        } else {
            if (i5 != 4) {
                throw new IllegalArgumentException("op should be remove or update." + aVar);
            }
            i2 = 1;
        }
        int i6 = 1;
        for (int i7 = 1; i7 < aVar.f110d; i7++) {
            int m3 = m((i2 * i7) + aVar.f108b, aVar.f107a);
            int i8 = aVar.f107a;
            if (i8 == 2 ? m3 == m2 : i8 == 4 && m3 == m2 + 1) {
                i6++;
            } else {
                a h2 = h(i8, m2, i6, aVar.f109c);
                e(h2, i4);
                k(h2);
                if (aVar.f107a == 4) {
                    i4 += i6;
                }
                m2 = m3;
                i6 = 1;
            }
        }
        Object obj = aVar.f109c;
        k(aVar);
        if (i6 > 0) {
            a h3 = h(aVar.f107a, m2, i6, obj);
            e(h3, i4);
            k(h3);
        }
    }

    public final void e(a aVar, int i2) {
        p0 p0Var = this.f134d;
        p0Var.a(aVar);
        int i3 = aVar.f107a;
        if (i3 != 2) {
            if (i3 != 4) {
                throw new IllegalArgumentException("only remove and update ops can be dispatched in first pass");
            }
            p0Var.d(i2, aVar.f110d, aVar.f109c);
        } else {
            int i4 = aVar.f110d;
            RecyclerView recyclerView = p0Var.f260a;
            recyclerView.M(i2, i4, true);
            recyclerView.i0 = true;
            recyclerView.f74f0.f155b += i4;
        }
    }

    public final int f(int i2, int i3) {
        ArrayList arrayList = this.f133c;
        int size = arrayList.size();
        while (i3 < size) {
            a aVar = (a) arrayList.get(i3);
            int i4 = aVar.f107a;
            if (i4 == 8) {
                int i5 = aVar.f108b;
                if (i5 == i2) {
                    i2 = aVar.f110d;
                } else {
                    if (i5 < i2) {
                        i2--;
                    }
                    if (aVar.f110d <= i2) {
                        i2++;
                    }
                }
            } else {
                int i6 = aVar.f108b;
                if (i6 > i2) {
                    continue;
                } else if (i4 == 2) {
                    int i7 = aVar.f110d;
                    if (i2 < i6 + i7) {
                        return -1;
                    }
                    i2 -= i7;
                } else if (i4 == 1) {
                    i2 += aVar.f110d;
                }
            }
            i3++;
        }
        return i2;
    }

    public final boolean g() {
        return this.f132b.size() > 0;
    }

    public final a h(int i2, int i3, int i4, Object obj) {
        a aVar = (a) this.f131a.a();
        if (aVar == null) {
            return new a(i2, i3, i4, obj);
        }
        aVar.f107a = i2;
        aVar.f108b = i3;
        aVar.f110d = i4;
        aVar.f109c = obj;
        return aVar;
    }

    public final void i(a aVar) {
        this.f133c.add(aVar);
        int i2 = aVar.f107a;
        p0 p0Var = this.f134d;
        if (i2 == 1) {
            p0Var.e(aVar.f108b, aVar.f110d);
            return;
        }
        if (i2 == 2) {
            int i3 = aVar.f108b;
            int i4 = aVar.f110d;
            RecyclerView recyclerView = p0Var.f260a;
            recyclerView.M(i3, i4, false);
            recyclerView.i0 = true;
            return;
        }
        if (i2 == 4) {
            p0Var.d(aVar.f108b, aVar.f110d, aVar.f109c);
        } else if (i2 == 8) {
            p0Var.f(aVar.f108b, aVar.f110d);
        } else {
            throw new IllegalArgumentException("Unknown update op type for " + aVar);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:68:0x0145, code lost:
    
        if (r4 > r12.f108b) goto L97;
     */
    /* JADX WARN: Code restructure failed: missing block: B:69:0x0176, code lost:
    
        r1.set(r3, r12);
     */
    /* JADX WARN: Code restructure failed: missing block: B:70:0x017d, code lost:
    
        if (r11.f108b == r11.f110d) goto L101;
     */
    /* JADX WARN: Code restructure failed: missing block: B:71:0x017f, code lost:
    
        r1.set(r7, r11);
     */
    /* JADX WARN: Code restructure failed: missing block: B:72:0x0186, code lost:
    
        if (r6 == null) goto L194;
     */
    /* JADX WARN: Code restructure failed: missing block: B:74:0x0188, code lost:
    
        r1.add(r3, r6);
     */
    /* JADX WARN: Code restructure failed: missing block: B:77:0x0183, code lost:
    
        r1.remove(r7);
     */
    /* JADX WARN: Code restructure failed: missing block: B:78:0x0171, code lost:
    
        r11.f110d = r4 - r12.f110d;
     */
    /* JADX WARN: Code restructure failed: missing block: B:90:0x016f, code lost:
    
        if (r4 >= r12.f108b) goto L97;
     */
    /* JADX WARN: Removed duplicated region for block: B:115:0x006c  */
    /* JADX WARN: Removed duplicated region for block: B:118:0x008e  */
    /* JADX WARN: Removed duplicated region for block: B:120:0x009c  */
    /* JADX WARN: Removed duplicated region for block: B:122:0x00a1 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:125:0x0009 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:126:0x0092  */
    /* JADX WARN: Removed duplicated region for block: B:127:0x0071  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x00d1  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x00f2  */
    /* JADX WARN: Removed duplicated region for block: B:55:0x011c A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:91:0x010f A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:94:0x00f7  */
    /* JADX WARN: Removed duplicated region for block: B:97:0x00cc A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void j() {
        /*
            Method dump skipped, instructions count: 648
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.b.j():void");
    }

    public final void k(a aVar) {
        aVar.f109c = null;
        this.f131a.b(aVar);
    }

    public final void l(ArrayList arrayList) {
        int size = arrayList.size();
        for (int i2 = 0; i2 < size; i2++) {
            k((a) arrayList.get(i2));
        }
        arrayList.clear();
    }

    public final int m(int i2, int i3) {
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        ArrayList arrayList = this.f133c;
        for (int size = arrayList.size() - 1; size >= 0; size--) {
            a aVar = (a) arrayList.get(size);
            int i10 = aVar.f107a;
            if (i10 == 8) {
                int i11 = aVar.f108b;
                int i12 = aVar.f110d;
                if (i11 < i12) {
                    i6 = i11;
                    i5 = i12;
                } else {
                    i5 = i11;
                    i6 = i12;
                }
                if (i2 < i6 || i2 > i5) {
                    if (i2 < i11) {
                        if (i3 == 1) {
                            aVar.f108b = i11 + 1;
                            i7 = i12 + 1;
                        } else if (i3 == 2) {
                            aVar.f108b = i11 - 1;
                            i7 = i12 - 1;
                        }
                        aVar.f110d = i7;
                    }
                } else if (i6 == i11) {
                    if (i3 == 1) {
                        i9 = i12 + 1;
                    } else {
                        if (i3 == 2) {
                            i9 = i12 - 1;
                        }
                        i2++;
                    }
                    aVar.f110d = i9;
                    i2++;
                } else {
                    if (i3 == 1) {
                        i8 = i11 + 1;
                    } else {
                        if (i3 == 2) {
                            i8 = i11 - 1;
                        }
                        i2--;
                    }
                    aVar.f108b = i8;
                    i2--;
                }
            } else {
                int i13 = aVar.f108b;
                if (i13 > i2) {
                    if (i3 == 1) {
                        i4 = i13 + 1;
                    } else if (i3 == 2) {
                        i4 = i13 - 1;
                    }
                    aVar.f108b = i4;
                } else if (i10 == 1) {
                    i2 -= aVar.f110d;
                } else if (i10 == 2) {
                    i2 += aVar.f110d;
                }
            }
        }
        for (int size2 = arrayList.size() - 1; size2 >= 0; size2--) {
            a aVar2 = (a) arrayList.get(size2);
            if (aVar2.f107a == 8) {
                int i14 = aVar2.f110d;
                if (i14 != aVar2.f108b && i14 >= 0) {
                }
                arrayList.remove(size2);
                k(aVar2);
            } else {
                if (aVar2.f110d > 0) {
                }
                arrayList.remove(size2);
                k(aVar2);
            }
        }
        return i2;
    }
}
