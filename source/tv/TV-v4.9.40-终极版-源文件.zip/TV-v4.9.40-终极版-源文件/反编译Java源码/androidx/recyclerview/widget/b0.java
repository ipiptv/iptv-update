package androidx.recyclerview.widget;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.versionedparcelable.ParcelImpl;
import tv.live.ManageType;

/* loaded from: classes.dex */
public final class b0 implements Parcelable.Creator {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f137a;

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        switch (this.f137a) {
            case 0:
                return new c0(parcel);
            case 1:
                return new n1(parcel);
            case ManageType.GROUP /* 2 */:
                return new o1(parcel);
            default:
                return new ParcelImpl(parcel);
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i2) {
        switch (this.f137a) {
            case 0:
                return new c0[i2];
            case 1:
                return new n1[i2];
            case ManageType.GROUP /* 2 */:
                return new o1[i2];
            default:
                return new ParcelImpl[i2];
        }
    }
}
