package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public abstract /* synthetic */ class c {
    public static /* synthetic */ int a(int i2) {
        if (i2 == 1) {
            return 1;
        }
        if (i2 == 2) {
            return 0;
        }
        if (i2 == 3) {
            return 3;
        }
        if (i2 == 4) {
            return 2;
        }
        throw null;
    }

    public static String b(RecyclerView recyclerView, StringBuilder sb) {
        sb.append(recyclerView.y());
        return sb.toString();
    }

    public static /* synthetic */ void c(Object obj) {
        if (obj != null) {
            throw new ClassCastException();
        }
    }

    public static /* synthetic */ int d(String str) {
        if (str == null) {
            throw new NullPointerException("Name is null");
        }
        if (str.equals("L")) {
            return 1;
        }
        if (str.equals("M")) {
            return 2;
        }
        if (str.equals("Q")) {
            return 3;
        }
        if (str.equals("H")) {
            return 4;
        }
        throw new IllegalArgumentException("No enum constant com.google.zxing.qrcode.decoder.ErrorCorrectionLevel.".concat(str));
    }
}
