package androidx.recyclerview.widget;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class c0 implements Parcelable {
    public static final Parcelable.Creator<c0> CREATOR = new b0(0);

    /* renamed from: a, reason: collision with root package name */
    public int f138a;

    /* renamed from: b, reason: collision with root package name */
    public int f139b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f140c;

    public c0(Parcel parcel) {
        this.f138a = parcel.readInt();
        this.f139b = parcel.readInt();
        this.f140c = parcel.readInt() == 1;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i2) {
        parcel.writeInt(this.f138a);
        parcel.writeInt(this.f139b);
        parcel.writeInt(this.f140c ? 1 : 0);
    }

    public c0(c0 c0Var) {
        this.f138a = c0Var.f138a;
        this.f139b = c0Var.f139b;
        this.f140c = c0Var.f140c;
    }
}
