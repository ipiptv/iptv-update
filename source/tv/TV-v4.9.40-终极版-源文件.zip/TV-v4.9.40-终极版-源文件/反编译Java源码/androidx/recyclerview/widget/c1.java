package androidx.recyclerview.widget;

import java.lang.reflect.Field;

/* loaded from: classes.dex */
public final class c1 extends k0 {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ RecyclerView f141a;

    public c1(RecyclerView recyclerView) {
        this.f141a = recyclerView;
    }

    public final void a() {
        boolean z2 = RecyclerView.D0;
        RecyclerView recyclerView = this.f141a;
        if (z2 && recyclerView.f89t && recyclerView.f88s) {
            Field field = g.v.f448a;
            g.j.m(recyclerView, recyclerView.f79i);
        } else {
            recyclerView.A = true;
            recyclerView.requestLayout();
        }
    }
}
