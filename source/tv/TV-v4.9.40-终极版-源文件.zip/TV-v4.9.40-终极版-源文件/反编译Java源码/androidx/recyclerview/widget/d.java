package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public final class d {

    /* renamed from: a, reason: collision with root package name */
    public long f142a = 0;

    /* renamed from: b, reason: collision with root package name */
    public d f143b;

    public final void a(int i2) {
        if (i2 < 64) {
            this.f142a &= ~(1 << i2);
            return;
        }
        d dVar = this.f143b;
        if (dVar != null) {
            dVar.a(i2 - 64);
        }
    }

    public final int b(int i2) {
        long j2;
        d dVar = this.f143b;
        if (dVar == null) {
            if (i2 >= 64) {
                j2 = this.f142a;
                return Long.bitCount(j2);
            }
        } else if (i2 >= 64) {
            return Long.bitCount(this.f142a) + dVar.b(i2 - 64);
        }
        j2 = this.f142a & ((1 << i2) - 1);
        return Long.bitCount(j2);
    }

    public final void c() {
        if (this.f143b == null) {
            this.f143b = new d();
        }
    }

    public final boolean d(int i2) {
        if (i2 < 64) {
            return (this.f142a & (1 << i2)) != 0;
        }
        c();
        return this.f143b.d(i2 - 64);
    }

    public final void e(int i2, boolean z2) {
        if (i2 >= 64) {
            c();
            this.f143b.e(i2 - 64, z2);
            return;
        }
        long j2 = this.f142a;
        boolean z3 = (Long.MIN_VALUE & j2) != 0;
        long j3 = (1 << i2) - 1;
        this.f142a = ((j2 & (~j3)) << 1) | (j2 & j3);
        if (z2) {
            h(i2);
        } else {
            a(i2);
        }
        if (z3 || this.f143b != null) {
            c();
            this.f143b.e(0, z3);
        }
    }

    public final boolean f(int i2) {
        if (i2 >= 64) {
            c();
            return this.f143b.f(i2 - 64);
        }
        long j2 = 1 << i2;
        long j3 = this.f142a;
        boolean z2 = (j3 & j2) != 0;
        long j4 = j3 & (~j2);
        this.f142a = j4;
        long j5 = j2 - 1;
        this.f142a = (j4 & j5) | Long.rotateRight((~j5) & j4, 1);
        d dVar = this.f143b;
        if (dVar != null) {
            if (dVar.d(0)) {
                h(63);
            }
            this.f143b.f(0);
        }
        return z2;
    }

    public final void g() {
        this.f142a = 0L;
        d dVar = this.f143b;
        if (dVar != null) {
            dVar.g();
        }
    }

    public final void h(int i2) {
        if (i2 < 64) {
            this.f142a |= 1 << i2;
        } else {
            c();
            this.f143b.h(i2 - 64);
        }
    }

    public final String toString() {
        if (this.f143b == null) {
            return Long.toBinaryString(this.f142a);
        }
        return this.f143b.toString() + "xx" + Long.toBinaryString(this.f142a);
    }
}
