package androidx.recyclerview.widget;

import android.graphics.Rect;
import android.view.View;
import android.view.ViewGroup;

/* loaded from: classes.dex */
public final class d0 extends e0 {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f144d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ d0(t0 t0Var, int i2) {
        super(t0Var);
        this.f144d = i2;
    }

    @Override // androidx.recyclerview.widget.e0
    public final int b(View view) {
        int bottom;
        int i2;
        int i3 = this.f144d;
        t0 t0Var = this.f151a;
        switch (i3) {
            case 0:
                u0 u0Var = (u0) view.getLayoutParams();
                t0Var.getClass();
                bottom = view.getRight() + ((u0) view.getLayoutParams()).f340b.right;
                i2 = ((ViewGroup.MarginLayoutParams) u0Var).rightMargin;
                break;
            default:
                u0 u0Var2 = (u0) view.getLayoutParams();
                t0Var.getClass();
                bottom = view.getBottom() + ((u0) view.getLayoutParams()).f340b.bottom;
                i2 = ((ViewGroup.MarginLayoutParams) u0Var2).bottomMargin;
                break;
        }
        return bottom + i2;
    }

    @Override // androidx.recyclerview.widget.e0
    public final int c(View view) {
        int measuredHeight;
        int i2;
        int i3 = this.f144d;
        t0 t0Var = this.f151a;
        switch (i3) {
            case 0:
                u0 u0Var = (u0) view.getLayoutParams();
                t0Var.getClass();
                Rect rect = ((u0) view.getLayoutParams()).f340b;
                measuredHeight = view.getMeasuredWidth() + rect.left + rect.right + ((ViewGroup.MarginLayoutParams) u0Var).leftMargin;
                i2 = ((ViewGroup.MarginLayoutParams) u0Var).rightMargin;
                break;
            default:
                u0 u0Var2 = (u0) view.getLayoutParams();
                t0Var.getClass();
                Rect rect2 = ((u0) view.getLayoutParams()).f340b;
                measuredHeight = view.getMeasuredHeight() + rect2.top + rect2.bottom + ((ViewGroup.MarginLayoutParams) u0Var2).topMargin;
                i2 = ((ViewGroup.MarginLayoutParams) u0Var2).bottomMargin;
                break;
        }
        return measuredHeight + i2;
    }

    @Override // androidx.recyclerview.widget.e0
    public final int d(View view) {
        int top;
        int i2;
        int i3 = this.f144d;
        t0 t0Var = this.f151a;
        switch (i3) {
            case 0:
                u0 u0Var = (u0) view.getLayoutParams();
                t0Var.getClass();
                top = view.getLeft() - ((u0) view.getLayoutParams()).f340b.left;
                i2 = ((ViewGroup.MarginLayoutParams) u0Var).leftMargin;
                break;
            default:
                u0 u0Var2 = (u0) view.getLayoutParams();
                t0Var.getClass();
                top = view.getTop() - ((u0) view.getLayoutParams()).f340b.top;
                i2 = ((ViewGroup.MarginLayoutParams) u0Var2).topMargin;
                break;
        }
        return top - i2;
    }

    @Override // androidx.recyclerview.widget.e0
    public final int e() {
        int i2 = this.f144d;
        t0 t0Var = this.f151a;
        switch (i2) {
            case 0:
                return t0Var.f328m;
            default:
                return t0Var.f329n;
        }
    }

    @Override // androidx.recyclerview.widget.e0
    public final int f() {
        int i2;
        int y2;
        int i3 = this.f144d;
        t0 t0Var = this.f151a;
        switch (i3) {
            case 0:
                i2 = t0Var.f328m;
                y2 = t0Var.A();
                break;
            default:
                i2 = t0Var.f329n;
                y2 = t0Var.y();
                break;
        }
        return i2 - y2;
    }

    @Override // androidx.recyclerview.widget.e0
    public final int g() {
        int i2 = this.f144d;
        t0 t0Var = this.f151a;
        switch (i2) {
            case 0:
                return t0Var.f326k;
            default:
                return t0Var.f327l;
        }
    }

    @Override // androidx.recyclerview.widget.e0
    public final int h() {
        int i2 = this.f144d;
        t0 t0Var = this.f151a;
        switch (i2) {
            case 0:
                return t0Var.z();
            default:
                return t0Var.B();
        }
    }

    @Override // androidx.recyclerview.widget.e0
    public final int i() {
        int B;
        int y2;
        int i2 = this.f144d;
        t0 t0Var = this.f151a;
        switch (i2) {
            case 0:
                B = t0Var.f328m - t0Var.z();
                y2 = t0Var.A();
                break;
            default:
                B = t0Var.f329n - t0Var.B();
                y2 = t0Var.y();
                break;
        }
        return B - y2;
    }

    @Override // androidx.recyclerview.widget.e0
    public final int j(View view) {
        int i2 = this.f144d;
        Rect rect = this.f153c;
        t0 t0Var = this.f151a;
        switch (i2) {
            case 0:
                t0Var.F(view, rect);
                return rect.right;
            default:
                t0Var.F(view, rect);
                return rect.bottom;
        }
    }

    @Override // androidx.recyclerview.widget.e0
    public final int k(View view) {
        int i2 = this.f144d;
        Rect rect = this.f153c;
        t0 t0Var = this.f151a;
        switch (i2) {
            case 0:
                t0Var.F(view, rect);
                return rect.left;
            default:
                t0Var.F(view, rect);
                return rect.top;
        }
    }

    @Override // androidx.recyclerview.widget.e0
    public final void l(int i2) {
        int i3 = this.f144d;
        t0 t0Var = this.f151a;
        switch (i3) {
            case 0:
                t0Var.J(i2);
                break;
            default:
                t0Var.K(i2);
                break;
        }
    }

    public final int m(View view) {
        int measuredWidth;
        int i2;
        int i3 = this.f144d;
        t0 t0Var = this.f151a;
        switch (i3) {
            case 0:
                u0 u0Var = (u0) view.getLayoutParams();
                t0Var.getClass();
                Rect rect = ((u0) view.getLayoutParams()).f340b;
                measuredWidth = view.getMeasuredHeight() + rect.top + rect.bottom + ((ViewGroup.MarginLayoutParams) u0Var).topMargin;
                i2 = ((ViewGroup.MarginLayoutParams) u0Var).bottomMargin;
                break;
            default:
                u0 u0Var2 = (u0) view.getLayoutParams();
                t0Var.getClass();
                Rect rect2 = ((u0) view.getLayoutParams()).f340b;
                measuredWidth = view.getMeasuredWidth() + rect2.left + rect2.right + ((ViewGroup.MarginLayoutParams) u0Var2).leftMargin;
                i2 = ((ViewGroup.MarginLayoutParams) u0Var2).rightMargin;
                break;
        }
        return measuredWidth + i2;
    }
}
