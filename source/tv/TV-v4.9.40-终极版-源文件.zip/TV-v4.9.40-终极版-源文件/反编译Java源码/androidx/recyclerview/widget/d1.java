package androidx.recyclerview.widget;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public final class d1 extends k.c {
    public static final Parcelable.Creator<d1> CREATOR = new k.b(1);

    /* renamed from: c, reason: collision with root package name */
    public Parcelable f145c;

    public d1(Parcel parcel, ClassLoader classLoader) {
        super(parcel, classLoader);
        this.f145c = parcel.readParcelable(classLoader == null ? t0.class.getClassLoader() : classLoader);
    }

    @Override // k.c, android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i2) {
        parcel.writeParcelable(this.f493a, i2);
        parcel.writeParcelable(this.f145c, 0);
    }
}
