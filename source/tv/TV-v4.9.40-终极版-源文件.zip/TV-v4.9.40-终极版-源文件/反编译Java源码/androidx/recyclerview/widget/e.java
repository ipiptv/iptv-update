package androidx.recyclerview.widget;

import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import java.util.ArrayList;

/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public final p0 f146a;

    /* renamed from: e, reason: collision with root package name */
    public View f150e;

    /* renamed from: d, reason: collision with root package name */
    public int f149d = 0;

    /* renamed from: b, reason: collision with root package name */
    public final d f147b = new d();

    /* renamed from: c, reason: collision with root package name */
    public final ArrayList f148c = new ArrayList();

    public e(p0 p0Var) {
        this.f146a = p0Var;
    }

    public final void a(View view, int i2, boolean z2) {
        p0 p0Var = this.f146a;
        int c2 = i2 < 0 ? p0Var.c() : f(i2);
        this.f147b.e(c2, z2);
        if (z2) {
            i(view);
        }
        RecyclerView recyclerView = p0Var.f260a;
        recyclerView.addView(view, c2);
        i1 I = RecyclerView.I(view);
        i0 i0Var = recyclerView.f83m;
        if (i0Var == null || I == null) {
            return;
        }
        i0Var.onViewAttachedToWindow(I);
    }

    public final void b(View view, int i2, ViewGroup.LayoutParams layoutParams, boolean z2) {
        p0 p0Var = this.f146a;
        int c2 = i2 < 0 ? p0Var.c() : f(i2);
        this.f147b.e(c2, z2);
        if (z2) {
            i(view);
        }
        p0Var.getClass();
        i1 I = RecyclerView.I(view);
        RecyclerView recyclerView = p0Var.f260a;
        if (I != null) {
            if (!I.isTmpDetached() && !I.shouldIgnore()) {
                StringBuilder sb = new StringBuilder("Called attach on a child which is not detached: ");
                sb.append(I);
                throw new IllegalArgumentException(c.b(recyclerView, sb));
            }
            if (RecyclerView.z0) {
                Log.d("RecyclerView", "reAttach " + I);
            }
            I.clearTmpDetachFlag();
        } else if (RecyclerView.y0) {
            StringBuilder sb2 = new StringBuilder("No ViewHolder found for child: ");
            sb2.append(view);
            sb2.append(", index: ");
            sb2.append(c2);
            throw new IllegalArgumentException(c.b(recyclerView, sb2));
        }
        recyclerView.attachViewToParent(view, c2, layoutParams);
    }

    public final void c(int i2) {
        int f2 = f(i2);
        this.f147b.f(f2);
        p0 p0Var = this.f146a;
        View childAt = p0Var.f260a.getChildAt(f2);
        RecyclerView recyclerView = p0Var.f260a;
        if (childAt != null) {
            i1 I = RecyclerView.I(childAt);
            if (I != null) {
                if (I.isTmpDetached() && !I.shouldIgnore()) {
                    StringBuilder sb = new StringBuilder("called detach on an already detached child ");
                    sb.append(I);
                    throw new IllegalArgumentException(c.b(recyclerView, sb));
                }
                if (RecyclerView.z0) {
                    Log.d("RecyclerView", "tmpDetach " + I);
                }
                I.addFlags(256);
            }
        } else if (RecyclerView.y0) {
            StringBuilder sb2 = new StringBuilder("No view at offset ");
            sb2.append(f2);
            throw new IllegalArgumentException(c.b(recyclerView, sb2));
        }
        recyclerView.detachViewFromParent(f2);
    }

    public final View d(int i2) {
        return this.f146a.f260a.getChildAt(f(i2));
    }

    public final int e() {
        return this.f146a.c() - this.f148c.size();
    }

    public final int f(int i2) {
        if (i2 < 0) {
            return -1;
        }
        int c2 = this.f146a.c();
        int i3 = i2;
        while (i3 < c2) {
            d dVar = this.f147b;
            int b2 = i2 - (i3 - dVar.b(i3));
            if (b2 == 0) {
                while (dVar.d(i3)) {
                    i3++;
                }
                return i3;
            }
            i3 += b2;
        }
        return -1;
    }

    public final View g(int i2) {
        return this.f146a.f260a.getChildAt(i2);
    }

    public final int h() {
        return this.f146a.c();
    }

    public final void i(View view) {
        this.f148c.add(view);
        p0 p0Var = this.f146a;
        p0Var.getClass();
        i1 I = RecyclerView.I(view);
        if (I != null) {
            I.onEnteredHiddenState(p0Var.f260a);
        }
    }

    public final boolean j(View view) {
        return this.f148c.contains(view);
    }

    public final void k(View view) {
        if (this.f148c.remove(view)) {
            p0 p0Var = this.f146a;
            p0Var.getClass();
            i1 I = RecyclerView.I(view);
            if (I != null) {
                I.onLeftHiddenState(p0Var.f260a);
            }
        }
    }

    public final String toString() {
        return this.f147b.toString() + ", hidden list:" + this.f148c.size();
    }
}
