package androidx.recyclerview.widget;

import android.graphics.Rect;
import android.view.View;

/* loaded from: classes.dex */
public abstract class e0 {

    /* renamed from: a, reason: collision with root package name */
    public final t0 f151a;

    /* renamed from: b, reason: collision with root package name */
    public int f152b = Integer.MIN_VALUE;

    /* renamed from: c, reason: collision with root package name */
    public final Rect f153c = new Rect();

    public e0(t0 t0Var) {
        this.f151a = t0Var;
    }

    public static d0 a(t0 t0Var, int i2) {
        if (i2 == 0) {
            return new d0(t0Var, 0);
        }
        int i3 = 1;
        if (i2 == 1) {
            return new d0(t0Var, i3);
        }
        throw new IllegalArgumentException("invalid orientation");
    }

    public abstract int b(View view);

    public abstract int c(View view);

    public abstract int d(View view);

    public abstract int e();

    public abstract int f();

    public abstract int g();

    public abstract int h();

    public abstract int i();

    public abstract int j(View view);

    public abstract int k(View view);

    public abstract void l(int i2);
}
