package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public final class e1 {

    /* renamed from: a, reason: collision with root package name */
    public int f154a = 0;

    /* renamed from: b, reason: collision with root package name */
    public int f155b = 0;

    /* renamed from: c, reason: collision with root package name */
    public int f156c = 1;

    /* renamed from: d, reason: collision with root package name */
    public int f157d = 0;

    /* renamed from: e, reason: collision with root package name */
    public boolean f158e = false;

    /* renamed from: f, reason: collision with root package name */
    public boolean f159f = false;

    /* renamed from: g, reason: collision with root package name */
    public boolean f160g = false;

    /* renamed from: h, reason: collision with root package name */
    public boolean f161h = false;

    /* renamed from: i, reason: collision with root package name */
    public boolean f162i = false;

    /* renamed from: j, reason: collision with root package name */
    public boolean f163j = false;

    /* renamed from: k, reason: collision with root package name */
    public int f164k;

    /* renamed from: l, reason: collision with root package name */
    public long f165l;

    /* renamed from: m, reason: collision with root package name */
    public int f166m;

    public final void a(int i2) {
        if ((this.f156c & i2) != 0) {
            return;
        }
        throw new IllegalStateException("Layout state should be one of " + Integer.toBinaryString(i2) + " but it is " + Integer.toBinaryString(this.f156c));
    }

    public final int b() {
        return this.f159f ? this.f154a - this.f155b : this.f157d;
    }

    public final String toString() {
        return "State{mTargetPosition=-1, mData=null, mItemCount=" + this.f157d + ", mIsMeasuring=" + this.f161h + ", mPreviousLayoutItemCount=" + this.f154a + ", mDeletedInvisibleItemCountSincePreviousLayout=" + this.f155b + ", mStructureChanged=" + this.f158e + ", mInPreLayout=" + this.f159f + ", mRunSimpleAnimations=" + this.f162i + ", mRunPredictiveAnimations=" + this.f163j + '}';
    }
}
