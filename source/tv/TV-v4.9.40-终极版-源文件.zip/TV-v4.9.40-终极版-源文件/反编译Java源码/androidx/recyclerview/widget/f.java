package androidx.recyclerview.widget;

import android.view.View;
import android.view.ViewPropertyAnimator;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public final class f implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f167a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ ArrayList f168b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ l f169c;

    public /* synthetic */ f(l lVar, ArrayList arrayList, int i2) {
        this.f167a = i2;
        this.f169c = lVar;
        this.f168b = arrayList;
    }

    @Override // java.lang.Runnable
    public final void run() {
        long j2;
        int i2 = this.f167a;
        l lVar = this.f169c;
        ArrayList arrayList = this.f168b;
        switch (i2) {
            case 0:
                Iterator it = arrayList.iterator();
                while (it.hasNext()) {
                    k kVar = (k) it.next();
                    i1 i1Var = kVar.f205a;
                    lVar.getClass();
                    View view = i1Var.itemView;
                    int i3 = kVar.f208d - kVar.f206b;
                    int i4 = kVar.f209e - kVar.f207c;
                    if (i3 != 0) {
                        view.animate().translationX(RecyclerView.B0);
                    }
                    if (i4 != 0) {
                        view.animate().translationY(RecyclerView.B0);
                    }
                    ViewPropertyAnimator animate = view.animate();
                    lVar.f222p.add(i1Var);
                    animate.setDuration(lVar.f247e).setListener(new h(lVar, i1Var, i3, view, i4, animate)).start();
                }
                arrayList.clear();
                lVar.f219m.remove(arrayList);
                break;
            case 1:
                Iterator it2 = arrayList.iterator();
                while (it2.hasNext()) {
                    j jVar = (j) it2.next();
                    lVar.getClass();
                    i1 i1Var2 = jVar.f197a;
                    View view2 = i1Var2 == null ? null : i1Var2.itemView;
                    i1 i1Var3 = jVar.f198b;
                    View view3 = i1Var3 != null ? i1Var3.itemView : null;
                    ArrayList arrayList2 = lVar.f223r;
                    long j3 = lVar.f248f;
                    if (view2 != null) {
                        ViewPropertyAnimator duration = view2.animate().setDuration(j3);
                        arrayList2.add(jVar.f197a);
                        duration.translationX(jVar.f201e - jVar.f199c);
                        duration.translationY(jVar.f202f - jVar.f200d);
                        j2 = j3;
                        duration.alpha(RecyclerView.B0).setListener(new i(lVar, jVar, duration, view2, 0)).start();
                    } else {
                        j2 = j3;
                    }
                    if (view3 != null) {
                        ViewPropertyAnimator animate2 = view3.animate();
                        arrayList2.add(jVar.f198b);
                        animate2.translationX(RecyclerView.B0).translationY(RecyclerView.B0).setDuration(j2).alpha(1.0f).setListener(new i(lVar, jVar, animate2, view3, 1)).start();
                    }
                }
                arrayList.clear();
                lVar.f220n.remove(arrayList);
                break;
            default:
                Iterator it3 = arrayList.iterator();
                while (it3.hasNext()) {
                    i1 i1Var4 = (i1) it3.next();
                    lVar.getClass();
                    View view4 = i1Var4.itemView;
                    ViewPropertyAnimator animate3 = view4.animate();
                    lVar.f221o.add(i1Var4);
                    animate3.alpha(1.0f).setDuration(lVar.f245c).setListener(new g(lVar, i1Var4, view4, animate3)).start();
                }
                arrayList.clear();
                lVar.f218l.remove(arrayList);
                break;
        }
    }
}
