package androidx.recyclerview.widget;

import android.view.View;
import android.view.ViewPropertyAnimator;
import java.lang.reflect.Field;
import java.util.ArrayList;
import java.util.Iterator;

/* loaded from: classes.dex */
public final class f0 implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f170a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ RecyclerView f171b;

    public /* synthetic */ f0(RecyclerView recyclerView, int i2) {
        this.f170a = i2;
        this.f171b = recyclerView;
    }

    @Override // java.lang.Runnable
    public final void run() {
        boolean z2;
        int i2 = this.f170a;
        RecyclerView recyclerView = this.f171b;
        switch (i2) {
            case 0:
                if (recyclerView.f90u && !recyclerView.isLayoutRequested()) {
                    if (!recyclerView.f88s) {
                        recyclerView.requestLayout();
                        break;
                    } else if (!recyclerView.f93x) {
                        recyclerView.m();
                        break;
                    } else {
                        recyclerView.f92w = true;
                        break;
                    }
                }
                break;
            default:
                o0 o0Var = recyclerView.L;
                if (o0Var != null) {
                    l lVar = (l) o0Var;
                    ArrayList arrayList = lVar.f214h;
                    boolean z3 = !arrayList.isEmpty();
                    ArrayList arrayList2 = lVar.f216j;
                    boolean z4 = !arrayList2.isEmpty();
                    ArrayList arrayList3 = lVar.f217k;
                    boolean z5 = !arrayList3.isEmpty();
                    ArrayList arrayList4 = lVar.f215i;
                    boolean z6 = !arrayList4.isEmpty();
                    if (z3 || z4 || z6 || z5) {
                        Iterator it = arrayList.iterator();
                        while (true) {
                            boolean hasNext = it.hasNext();
                            long j2 = lVar.f246d;
                            if (hasNext) {
                                i1 i1Var = (i1) it.next();
                                View view = i1Var.itemView;
                                ViewPropertyAnimator animate = view.animate();
                                lVar.q.add(i1Var);
                                animate.setDuration(j2).alpha(RecyclerView.B0).setListener(new g(lVar, i1Var, animate, view)).start();
                                it = it;
                            } else {
                                arrayList.clear();
                                if (z4) {
                                    ArrayList arrayList5 = new ArrayList();
                                    arrayList5.addAll(arrayList2);
                                    lVar.f219m.add(arrayList5);
                                    arrayList2.clear();
                                    f fVar = new f(lVar, arrayList5, 0);
                                    if (z3) {
                                        View view2 = ((k) arrayList5.get(0)).f205a.itemView;
                                        Field field = g.v.f448a;
                                        g.j.n(view2, fVar, j2);
                                    } else {
                                        fVar.run();
                                    }
                                }
                                if (z5) {
                                    ArrayList arrayList6 = new ArrayList();
                                    arrayList6.addAll(arrayList3);
                                    lVar.f220n.add(arrayList6);
                                    arrayList3.clear();
                                    f fVar2 = new f(lVar, arrayList6, 1);
                                    if (z3) {
                                        View view3 = ((j) arrayList6.get(0)).f197a.itemView;
                                        Field field2 = g.v.f448a;
                                        g.j.n(view3, fVar2, j2);
                                    } else {
                                        fVar2.run();
                                    }
                                }
                                if (z6) {
                                    ArrayList arrayList7 = new ArrayList();
                                    arrayList7.addAll(arrayList4);
                                    lVar.f218l.add(arrayList7);
                                    arrayList4.clear();
                                    f fVar3 = new f(lVar, arrayList7, 2);
                                    if (z3 || z4 || z5) {
                                        if (!z3) {
                                            j2 = 0;
                                        }
                                        long max = Math.max(z4 ? lVar.f247e : 0L, z5 ? lVar.f248f : 0L) + j2;
                                        z2 = false;
                                        View view4 = ((i1) arrayList7.get(0)).itemView;
                                        Field field3 = g.v.f448a;
                                        g.j.n(view4, fVar3, max);
                                        recyclerView.l0 = z2;
                                        break;
                                    } else {
                                        fVar3.run();
                                    }
                                }
                            }
                        }
                    }
                }
                z2 = false;
                recyclerView.l0 = z2;
        }
    }
}
