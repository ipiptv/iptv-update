package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewPropertyAnimator;

/* loaded from: classes.dex */
public final class g extends AnimatorListenerAdapter {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f172a = 1;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ i1 f173b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ View f174c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ ViewPropertyAnimator f175d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ l f176e;

    public g(l lVar, i1 i1Var, View view, ViewPropertyAnimator viewPropertyAnimator) {
        this.f176e = lVar;
        this.f173b = i1Var;
        this.f174c = view;
        this.f175d = viewPropertyAnimator;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationCancel(Animator animator) {
        switch (this.f172a) {
            case 1:
                this.f174c.setAlpha(1.0f);
                break;
            default:
                super.onAnimationCancel(animator);
                break;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        int i2 = this.f172a;
        i1 i1Var = this.f173b;
        l lVar = this.f176e;
        ViewPropertyAnimator viewPropertyAnimator = this.f175d;
        switch (i2) {
            case 0:
                viewPropertyAnimator.setListener(null);
                this.f174c.setAlpha(1.0f);
                lVar.c(i1Var);
                lVar.q.remove(i1Var);
                lVar.i();
                break;
            default:
                viewPropertyAnimator.setListener(null);
                lVar.c(i1Var);
                lVar.f221o.remove(i1Var);
                lVar.i();
                break;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationStart(Animator animator) {
        int i2 = this.f172a;
        l lVar = this.f176e;
        switch (i2) {
            case 0:
                lVar.getClass();
                break;
            default:
                lVar.getClass();
                break;
        }
    }

    public g(l lVar, i1 i1Var, ViewPropertyAnimator viewPropertyAnimator, View view) {
        this.f176e = lVar;
        this.f173b = i1Var;
        this.f175d = viewPropertyAnimator;
        this.f174c = view;
    }
}
