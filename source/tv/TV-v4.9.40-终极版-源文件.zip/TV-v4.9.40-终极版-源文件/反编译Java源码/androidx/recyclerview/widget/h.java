package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewPropertyAnimator;

/* loaded from: classes.dex */
public final class h extends AnimatorListenerAdapter {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ i1 f177a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f178b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ View f179c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f180d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ ViewPropertyAnimator f181e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ l f182f;

    public h(l lVar, i1 i1Var, int i2, View view, int i3, ViewPropertyAnimator viewPropertyAnimator) {
        this.f182f = lVar;
        this.f177a = i1Var;
        this.f178b = i2;
        this.f179c = view;
        this.f180d = i3;
        this.f181e = viewPropertyAnimator;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationCancel(Animator animator) {
        int i2 = this.f178b;
        View view = this.f179c;
        if (i2 != 0) {
            view.setTranslationX(RecyclerView.B0);
        }
        if (this.f180d != 0) {
            view.setTranslationY(RecyclerView.B0);
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        this.f181e.setListener(null);
        l lVar = this.f182f;
        i1 i1Var = this.f177a;
        lVar.c(i1Var);
        lVar.f222p.remove(i1Var);
        lVar.i();
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationStart(Animator animator) {
        this.f182f.getClass();
    }
}
