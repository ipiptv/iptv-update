package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public enum h0 {
    ALLOW,
    /* JADX INFO: Fake field, exist only in values array */
    PREVENT_WHEN_EMPTY,
    /* JADX INFO: Fake field, exist only in values array */
    PREVENT
}
