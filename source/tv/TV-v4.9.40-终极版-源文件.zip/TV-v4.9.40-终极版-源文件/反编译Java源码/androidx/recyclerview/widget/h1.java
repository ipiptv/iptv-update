package androidx.recyclerview.widget;

import android.view.animation.Interpolator;
import android.widget.OverScroller;
import java.lang.reflect.Field;
import java.util.Arrays;

/* loaded from: classes.dex */
public final class h1 implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public int f185a;

    /* renamed from: b, reason: collision with root package name */
    public int f186b;

    /* renamed from: c, reason: collision with root package name */
    public OverScroller f187c;

    /* renamed from: d, reason: collision with root package name */
    public Interpolator f188d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f189e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f190f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ RecyclerView f191g;

    public h1(RecyclerView recyclerView) {
        this.f191g = recyclerView;
        g0 g0Var = RecyclerView.G0;
        this.f188d = g0Var;
        this.f189e = false;
        this.f190f = false;
        this.f187c = new OverScroller(recyclerView.getContext(), g0Var);
    }

    public final void a(int i2, int i3) {
        RecyclerView recyclerView = this.f191g;
        recyclerView.setScrollState(2);
        this.f186b = 0;
        this.f185a = 0;
        Interpolator interpolator = this.f188d;
        g0 g0Var = RecyclerView.G0;
        if (interpolator != g0Var) {
            this.f188d = g0Var;
            this.f187c = new OverScroller(recyclerView.getContext(), g0Var);
        }
        this.f187c.fling(0, 0, i2, i3, Integer.MIN_VALUE, Integer.MAX_VALUE, Integer.MIN_VALUE, Integer.MAX_VALUE);
        if (this.f189e) {
            this.f190f = true;
            return;
        }
        recyclerView.removeCallbacks(this);
        Field field = g.v.f448a;
        g.j.m(recyclerView, this);
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i2;
        int i3;
        int i4;
        int i5;
        boolean awakenScrollBars;
        RecyclerView recyclerView = this.f191g;
        if (recyclerView.f84n == null) {
            recyclerView.removeCallbacks(this);
            this.f187c.abortAnimation();
            return;
        }
        this.f190f = false;
        this.f189e = true;
        recyclerView.m();
        OverScroller overScroller = this.f187c;
        if (overScroller.computeScrollOffset()) {
            int currX = overScroller.getCurrX();
            int currY = overScroller.getCurrY();
            int i6 = currX - this.f185a;
            int i7 = currY - this.f186b;
            this.f185a = currX;
            this.f186b = currY;
            int l2 = RecyclerView.l(i6, recyclerView.H, recyclerView.J, recyclerView.getWidth());
            int l3 = RecyclerView.l(i7, recyclerView.I, recyclerView.K, recyclerView.getHeight());
            int[] iArr = recyclerView.r0;
            iArr[0] = 0;
            iArr[1] = 0;
            boolean r2 = recyclerView.r(l2, l3, iArr, null, 1);
            int[] iArr2 = recyclerView.r0;
            if (r2) {
                l2 -= iArr2[0];
                l3 -= iArr2[1];
            }
            if (recyclerView.getOverScrollMode() != 2) {
                recyclerView.k(l2, l3);
            }
            if (recyclerView.f83m != null) {
                iArr2[0] = 0;
                iArr2[1] = 0;
                recyclerView.Z(l2, l3, iArr2);
                int i8 = iArr2[0];
                int i9 = iArr2[1];
                recyclerView.f84n.getClass();
                i5 = i8;
                i2 = l2 - i8;
                i3 = l3 - i9;
                i4 = i9;
            } else {
                i2 = l2;
                i3 = l3;
                i4 = 0;
                i5 = 0;
            }
            if (!recyclerView.f86p.isEmpty()) {
                recyclerView.invalidate();
            }
            int[] iArr3 = recyclerView.r0;
            iArr3[0] = 0;
            iArr3[1] = 0;
            int i10 = i4;
            recyclerView.s(i5, i4, i2, i3, null, 1, iArr3);
            int i11 = i2 - iArr2[0];
            int i12 = i3 - iArr2[1];
            if (i5 != 0 || i10 != 0) {
                recyclerView.t(i5, i10);
            }
            awakenScrollBars = recyclerView.awakenScrollBars();
            if (!awakenScrollBars) {
                recyclerView.invalidate();
            }
            boolean z2 = overScroller.isFinished() || (((overScroller.getCurrX() == overScroller.getFinalX()) || i11 != 0) && ((overScroller.getCurrY() == overScroller.getFinalY()) || i12 != 0));
            recyclerView.f84n.getClass();
            if (z2) {
                if (recyclerView.getOverScrollMode() != 2) {
                    int currVelocity = (int) overScroller.getCurrVelocity();
                    int i13 = i11 < 0 ? -currVelocity : i11 > 0 ? currVelocity : 0;
                    if (i12 < 0) {
                        currVelocity = -currVelocity;
                    } else if (i12 <= 0) {
                        currVelocity = 0;
                    }
                    if (i13 < 0) {
                        recyclerView.v();
                        if (recyclerView.H.isFinished()) {
                            recyclerView.H.onAbsorb(-i13);
                        }
                    } else if (i13 > 0) {
                        recyclerView.w();
                        if (recyclerView.J.isFinished()) {
                            recyclerView.J.onAbsorb(i13);
                        }
                    }
                    if (currVelocity < 0) {
                        recyclerView.x();
                        if (recyclerView.I.isFinished()) {
                            recyclerView.I.onAbsorb(-currVelocity);
                        }
                    } else if (currVelocity > 0) {
                        recyclerView.u();
                        if (recyclerView.K.isFinished()) {
                            recyclerView.K.onAbsorb(currVelocity);
                        }
                    }
                    if (i13 != 0 || currVelocity != 0) {
                        Field field = g.v.f448a;
                        g.j.k(recyclerView);
                    }
                }
                if (RecyclerView.E0) {
                    s sVar = recyclerView.f72e0;
                    int[] iArr4 = sVar.f301c;
                    if (iArr4 != null) {
                        Arrays.fill(iArr4, -1);
                    }
                    sVar.f302d = 0;
                }
            } else {
                if (this.f189e) {
                    this.f190f = true;
                } else {
                    recyclerView.removeCallbacks(this);
                    Field field2 = g.v.f448a;
                    g.j.m(recyclerView, this);
                }
                u uVar = recyclerView.f70d0;
                if (uVar != null) {
                    uVar.a(recyclerView, i5, i10);
                }
            }
        }
        recyclerView.f84n.getClass();
        this.f189e = false;
        if (!this.f190f) {
            recyclerView.setScrollState(0);
            recyclerView.f0(1);
        } else {
            recyclerView.removeCallbacks(this);
            Field field3 = g.v.f448a;
            g.j.m(recyclerView, this);
        }
    }
}
