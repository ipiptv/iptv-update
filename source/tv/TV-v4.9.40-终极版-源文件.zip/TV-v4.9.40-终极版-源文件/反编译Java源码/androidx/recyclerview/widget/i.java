package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.view.View;
import android.view.ViewPropertyAnimator;

/* loaded from: classes.dex */
public final class i extends AnimatorListenerAdapter {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f192a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ j f193b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ ViewPropertyAnimator f194c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ View f195d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ l f196e;

    public /* synthetic */ i(l lVar, j jVar, ViewPropertyAnimator viewPropertyAnimator, View view, int i2) {
        this.f192a = i2;
        this.f196e = lVar;
        this.f193b = jVar;
        this.f194c = viewPropertyAnimator;
        this.f195d = view;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        int i2 = this.f192a;
        l lVar = this.f196e;
        j jVar = this.f193b;
        View view = this.f195d;
        ViewPropertyAnimator viewPropertyAnimator = this.f194c;
        switch (i2) {
            case 0:
                viewPropertyAnimator.setListener(null);
                view.setAlpha(1.0f);
                view.setTranslationX(RecyclerView.B0);
                view.setTranslationY(RecyclerView.B0);
                lVar.c(jVar.f197a);
                lVar.f223r.remove(jVar.f197a);
                lVar.i();
                break;
            default:
                viewPropertyAnimator.setListener(null);
                view.setAlpha(1.0f);
                view.setTranslationX(RecyclerView.B0);
                view.setTranslationY(RecyclerView.B0);
                lVar.c(jVar.f198b);
                lVar.f223r.remove(jVar.f198b);
                lVar.i();
                break;
        }
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationStart(Animator animator) {
        int i2 = this.f192a;
        l lVar = this.f196e;
        j jVar = this.f193b;
        switch (i2) {
            case 0:
                i1 i1Var = jVar.f197a;
                lVar.getClass();
                break;
            default:
                i1 i1Var2 = jVar.f198b;
                lVar.getClass();
                break;
        }
    }
}
