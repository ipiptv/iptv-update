package androidx.recyclerview.widget;

import android.view.View;
import android.view.ViewGroup;
import java.lang.reflect.Field;
import java.util.List;

/* loaded from: classes.dex */
public abstract class i0 {
    private final j0 mObservable = new j0();
    private boolean mHasStableIds = false;
    private h0 mStateRestorationPolicy = h0.ALLOW;

    public final void bindViewHolder(i1 i1Var, int i2) {
        boolean z2 = i1Var.mBindingAdapter == null;
        if (z2) {
            i1Var.mPosition = i2;
            if (hasStableIds()) {
                i1Var.mItemId = getItemId(i2);
            }
            i1Var.setFlags(1, 519);
            int i3 = e.b.f393a;
            e.a.a("RV OnBindView");
        }
        i1Var.mBindingAdapter = this;
        if (RecyclerView.y0) {
            if (i1Var.itemView.getParent() == null) {
                View view = i1Var.itemView;
                Field field = g.v.f448a;
                if (g.l.b(view) != i1Var.isTmpDetached()) {
                    throw new IllegalStateException("Temp-detached state out of sync with reality. holder.isTmpDetached(): " + i1Var.isTmpDetached() + ", attached to window: " + g.l.b(i1Var.itemView) + ", holder: " + i1Var);
                }
            }
            if (i1Var.itemView.getParent() == null) {
                View view2 = i1Var.itemView;
                Field field2 = g.v.f448a;
                if (g.l.b(view2)) {
                    throw new IllegalStateException("Attempting to bind attached holder with no parent (AKA temp detached): " + i1Var);
                }
            }
        }
        onBindViewHolder(i1Var, i2, i1Var.getUnmodifiedPayloads());
        if (z2) {
            i1Var.clearPayload();
            ViewGroup.LayoutParams layoutParams = i1Var.itemView.getLayoutParams();
            if (layoutParams instanceof u0) {
                ((u0) layoutParams).f341c = true;
            }
            int i4 = e.b.f393a;
            e.a.b();
        }
    }

    public boolean canRestoreState() {
        int ordinal = this.mStateRestorationPolicy.ordinal();
        return ordinal != 1 ? ordinal != 2 : getItemCount() > 0;
    }

    public final i1 createViewHolder(ViewGroup viewGroup, int i2) {
        try {
            int i3 = e.b.f393a;
            e.a.a("RV CreateView");
            i1 onCreateViewHolder = onCreateViewHolder(viewGroup, i2);
            if (onCreateViewHolder.itemView.getParent() != null) {
                throw new IllegalStateException("ViewHolder views must not be attached when created. Ensure that you are not passing 'true' to the attachToRoot parameter of LayoutInflater.inflate(..., boolean attachToRoot)");
            }
            onCreateViewHolder.mItemViewType = i2;
            e.a.b();
            return onCreateViewHolder;
        } catch (Throwable th) {
            int i4 = e.b.f393a;
            e.a.b();
            throw th;
        }
    }

    public int findRelativeAdapterPositionIn(i0 i0Var, i1 i1Var, int i2) {
        if (i0Var == this) {
            return i2;
        }
        return -1;
    }

    public abstract int getItemCount();

    public long getItemId(int i2) {
        return -1L;
    }

    public int getItemViewType(int i2) {
        return 0;
    }

    public final h0 getStateRestorationPolicy() {
        return this.mStateRestorationPolicy;
    }

    public final boolean hasObservers() {
        return this.mObservable.a();
    }

    public final boolean hasStableIds() {
        return this.mHasStableIds;
    }

    public final void notifyDataSetChanged() {
        this.mObservable.b();
    }

    public final void notifyItemChanged(int i2) {
        this.mObservable.d(i2, 1, null);
    }

    public final void notifyItemInserted(int i2) {
        this.mObservable.e(i2, 1);
    }

    public final void notifyItemMoved(int i2, int i3) {
        this.mObservable.c(i2, i3);
    }

    public final void notifyItemRangeChanged(int i2, int i3) {
        this.mObservable.d(i2, i3, null);
    }

    public final void notifyItemRangeInserted(int i2, int i3) {
        this.mObservable.e(i2, i3);
    }

    public final void notifyItemRangeRemoved(int i2, int i3) {
        this.mObservable.f(i2, i3);
    }

    public final void notifyItemRemoved(int i2) {
        this.mObservable.f(i2, 1);
    }

    public void onAttachedToRecyclerView(RecyclerView recyclerView) {
    }

    public abstract void onBindViewHolder(i1 i1Var, int i2);

    public void onBindViewHolder(i1 i1Var, int i2, List<Object> list) {
        onBindViewHolder(i1Var, i2);
    }

    public abstract i1 onCreateViewHolder(ViewGroup viewGroup, int i2);

    public void onDetachedFromRecyclerView(RecyclerView recyclerView) {
    }

    public boolean onFailedToRecycleView(i1 i1Var) {
        return false;
    }

    public void onViewAttachedToWindow(i1 i1Var) {
    }

    public void onViewDetachedFromWindow(i1 i1Var) {
    }

    public void onViewRecycled(i1 i1Var) {
    }

    public void registerAdapterDataObserver(k0 k0Var) {
        this.mObservable.registerObserver(k0Var);
    }

    public void setHasStableIds(boolean z2) {
        if (hasObservers()) {
            throw new IllegalStateException("Cannot change whether this adapter has stable IDs while the adapter has registered observers.");
        }
        this.mHasStableIds = z2;
    }

    public void setStateRestorationPolicy(h0 h0Var) {
        this.mStateRestorationPolicy = h0Var;
        this.mObservable.g();
    }

    public void unregisterAdapterDataObserver(k0 k0Var) {
        this.mObservable.unregisterObserver(k0Var);
    }

    public final void notifyItemChanged(int i2, Object obj) {
        this.mObservable.d(i2, 1, obj);
    }

    public final void notifyItemRangeChanged(int i2, int i3, Object obj) {
        this.mObservable.d(i2, i3, obj);
    }
}
