package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public final class j {

    /* renamed from: a, reason: collision with root package name */
    public i1 f197a;

    /* renamed from: b, reason: collision with root package name */
    public i1 f198b;

    /* renamed from: c, reason: collision with root package name */
    public final int f199c;

    /* renamed from: d, reason: collision with root package name */
    public final int f200d;

    /* renamed from: e, reason: collision with root package name */
    public final int f201e;

    /* renamed from: f, reason: collision with root package name */
    public final int f202f;

    public j(i1 i1Var, i1 i1Var2, int i2, int i3, int i4, int i5) {
        this.f197a = i1Var;
        this.f198b = i1Var2;
        this.f199c = i2;
        this.f200d = i3;
        this.f201e = i4;
        this.f202f = i5;
    }

    public final String toString() {
        return "ChangeInfo{oldHolder=" + this.f197a + ", newHolder=" + this.f198b + ", fromX=" + this.f199c + ", fromY=" + this.f200d + ", toX=" + this.f201e + ", toY=" + this.f202f + '}';
    }
}
