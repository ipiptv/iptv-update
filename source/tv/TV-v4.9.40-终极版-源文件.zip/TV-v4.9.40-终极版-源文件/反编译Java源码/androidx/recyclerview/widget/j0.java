package androidx.recyclerview.widget;

import android.database.Observable;
import java.util.ArrayList;

/* loaded from: classes.dex */
public final class j0 extends Observable {
    public final boolean a() {
        return !((Observable) this).mObservers.isEmpty();
    }

    public final void b() {
        for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
            RecyclerView recyclerView = ((c1) ((k0) ((Observable) this).mObservers.get(size))).f141a;
            recyclerView.h(null);
            recyclerView.f74f0.f158e = true;
            recyclerView.S(true);
            if (!recyclerView.f71e.g()) {
                recyclerView.requestLayout();
            }
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:12:0x0040 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:9:0x003d  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void c(int r8, int r9) {
        /*
            r7 = this;
            java.util.ArrayList r0 = r7.mObservers
            int r0 = r0.size()
            r1 = 1
            int r0 = r0 - r1
        L8:
            if (r0 < 0) goto L43
            java.util.ArrayList r2 = r7.mObservers
            java.lang.Object r2 = r2.get(r0)
            androidx.recyclerview.widget.k0 r2 = (androidx.recyclerview.widget.k0) r2
            androidx.recyclerview.widget.c1 r2 = (androidx.recyclerview.widget.c1) r2
            androidx.recyclerview.widget.RecyclerView r3 = r2.f141a
            r4 = 0
            r3.h(r4)
            androidx.recyclerview.widget.b r3 = r3.f71e
            r3.getClass()
            if (r8 != r9) goto L22
            goto L3a
        L22:
            java.util.ArrayList r5 = r3.f132b
            r6 = 8
            androidx.recyclerview.widget.a r4 = r3.h(r6, r8, r9, r4)
            r5.add(r4)
            int r4 = r3.f136f
            r4 = r4 | r6
            r3.f136f = r4
            int r3 = r5.size()
            if (r3 != r1) goto L3a
            r3 = 1
            goto L3b
        L3a:
            r3 = 0
        L3b:
            if (r3 == 0) goto L40
            r2.a()
        L40:
            int r0 = r0 + (-1)
            goto L8
        L43:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.j0.c(int, int):void");
    }

    public final void d(int i2, int i3, Object obj) {
        for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
            c1 c1Var = (c1) ((k0) ((Observable) this).mObservers.get(size));
            RecyclerView recyclerView = c1Var.f141a;
            recyclerView.h(null);
            b bVar = recyclerView.f71e;
            boolean z2 = false;
            if (i3 < 1) {
                bVar.getClass();
            } else {
                ArrayList arrayList = bVar.f132b;
                arrayList.add(bVar.h(4, i2, i3, obj));
                bVar.f136f = 4 | bVar.f136f;
                if (arrayList.size() == 1) {
                    z2 = true;
                }
            }
            if (z2) {
                c1Var.a();
            }
        }
    }

    public final void e(int i2, int i3) {
        for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
            c1 c1Var = (c1) ((k0) ((Observable) this).mObservers.get(size));
            RecyclerView recyclerView = c1Var.f141a;
            recyclerView.h(null);
            b bVar = recyclerView.f71e;
            boolean z2 = false;
            if (i3 < 1) {
                bVar.getClass();
            } else {
                ArrayList arrayList = bVar.f132b;
                arrayList.add(bVar.h(1, i2, i3, null));
                bVar.f136f |= 1;
                if (arrayList.size() == 1) {
                    z2 = true;
                }
            }
            if (z2) {
                c1Var.a();
            }
        }
    }

    public final void f(int i2, int i3) {
        for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
            c1 c1Var = (c1) ((k0) ((Observable) this).mObservers.get(size));
            RecyclerView recyclerView = c1Var.f141a;
            recyclerView.h(null);
            b bVar = recyclerView.f71e;
            boolean z2 = false;
            if (i3 < 1) {
                bVar.getClass();
            } else {
                ArrayList arrayList = bVar.f132b;
                arrayList.add(bVar.h(2, i2, i3, null));
                bVar.f136f |= 2;
                if (arrayList.size() == 1) {
                    z2 = true;
                }
            }
            if (z2) {
                c1Var.a();
            }
        }
    }

    public final void g() {
        i0 i0Var;
        for (int size = ((Observable) this).mObservers.size() - 1; size >= 0; size--) {
            RecyclerView recyclerView = ((c1) ((k0) ((Observable) this).mObservers.get(size))).f141a;
            if (recyclerView.f69d != null && (i0Var = recyclerView.f83m) != null && i0Var.canRestoreState()) {
                recyclerView.requestLayout();
            }
        }
    }
}
