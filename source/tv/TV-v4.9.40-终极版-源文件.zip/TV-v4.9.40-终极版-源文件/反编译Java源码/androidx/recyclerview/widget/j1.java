package androidx.recyclerview.widget;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import java.util.WeakHashMap;

/* loaded from: classes.dex */
public final class j1 extends g.c {

    /* renamed from: d, reason: collision with root package name */
    public final k1 f203d;

    /* renamed from: e, reason: collision with root package name */
    public final WeakHashMap f204e = new WeakHashMap();

    public j1(k1 k1Var) {
        this.f203d = k1Var;
    }

    @Override // g.c
    public final boolean a(View view, AccessibilityEvent accessibilityEvent) {
        g.c cVar = (g.c) this.f204e.get(view);
        return cVar != null ? cVar.a(view, accessibilityEvent) : super.a(view, accessibilityEvent);
    }

    @Override // g.c
    public final g.d0 b(View view) {
        g.c cVar = (g.c) this.f204e.get(view);
        return cVar != null ? cVar.b(view) : super.b(view);
    }

    @Override // g.c
    public final void c(View view, AccessibilityEvent accessibilityEvent) {
        g.c cVar = (g.c) this.f204e.get(view);
        if (cVar != null) {
            cVar.c(view, accessibilityEvent);
        } else {
            super.c(view, accessibilityEvent);
        }
    }

    @Override // g.c
    public final void d(View view, h.o oVar) {
        k1 k1Var = this.f203d;
        RecyclerView recyclerView = k1Var.f210d;
        if (!(!recyclerView.f90u || recyclerView.C || recyclerView.f71e.g())) {
            RecyclerView recyclerView2 = k1Var.f210d;
            if (recyclerView2.getLayoutManager() != null) {
                recyclerView2.getLayoutManager().Q(view, oVar);
                g.c cVar = (g.c) this.f204e.get(view);
                if (cVar != null) {
                    cVar.d(view, oVar);
                    return;
                }
            }
        }
        this.f409a.onInitializeAccessibilityNodeInfo(view, oVar.f473a);
    }

    @Override // g.c
    public final void e(View view, AccessibilityEvent accessibilityEvent) {
        g.c cVar = (g.c) this.f204e.get(view);
        if (cVar != null) {
            cVar.e(view, accessibilityEvent);
        } else {
            super.e(view, accessibilityEvent);
        }
    }

    @Override // g.c
    public final boolean f(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
        g.c cVar = (g.c) this.f204e.get(viewGroup);
        return cVar != null ? cVar.f(viewGroup, view, accessibilityEvent) : super.f(viewGroup, view, accessibilityEvent);
    }

    @Override // g.c
    public final boolean g(View view, int i2, Bundle bundle) {
        k1 k1Var = this.f203d;
        RecyclerView recyclerView = k1Var.f210d;
        if (!(!recyclerView.f90u || recyclerView.C || recyclerView.f71e.g())) {
            RecyclerView recyclerView2 = k1Var.f210d;
            if (recyclerView2.getLayoutManager() != null) {
                g.c cVar = (g.c) this.f204e.get(view);
                if (cVar != null) {
                    if (cVar.g(view, i2, bundle)) {
                        return true;
                    }
                } else if (super.g(view, i2, bundle)) {
                    return true;
                }
                a1 a1Var = recyclerView2.getLayoutManager().f317b.f67c;
                return false;
            }
        }
        return super.g(view, i2, bundle);
    }

    @Override // g.c
    public final void h(View view, int i2) {
        g.c cVar = (g.c) this.f204e.get(view);
        if (cVar != null) {
            cVar.h(view, i2);
        } else {
            super.h(view, i2);
        }
    }

    @Override // g.c
    public final void i(View view, AccessibilityEvent accessibilityEvent) {
        g.c cVar = (g.c) this.f204e.get(view);
        if (cVar != null) {
            cVar.i(view, accessibilityEvent);
        } else {
            super.i(view, accessibilityEvent);
        }
    }
}
