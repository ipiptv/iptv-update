package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public final class k {

    /* renamed from: a, reason: collision with root package name */
    public final i1 f205a;

    /* renamed from: b, reason: collision with root package name */
    public final int f206b;

    /* renamed from: c, reason: collision with root package name */
    public final int f207c;

    /* renamed from: d, reason: collision with root package name */
    public final int f208d;

    /* renamed from: e, reason: collision with root package name */
    public final int f209e;

    public k(i1 i1Var, int i2, int i3, int i4, int i5) {
        this.f205a = i1Var;
        this.f206b = i2;
        this.f207c = i3;
        this.f208d = i4;
        this.f209e = i5;
    }
}
