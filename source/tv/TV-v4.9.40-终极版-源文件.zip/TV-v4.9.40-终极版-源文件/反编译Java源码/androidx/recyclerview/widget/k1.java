package androidx.recyclerview.widget;

import android.view.View;
import android.view.accessibility.AccessibilityEvent;

/* loaded from: classes.dex */
public final class k1 extends g.c {

    /* renamed from: d, reason: collision with root package name */
    public final RecyclerView f210d;

    /* renamed from: e, reason: collision with root package name */
    public final j1 f211e;

    public k1(RecyclerView recyclerView) {
        this.f210d = recyclerView;
        j1 j1Var = this.f211e;
        this.f211e = j1Var == null ? new j1(this) : j1Var;
    }

    @Override // g.c
    public final void c(View view, AccessibilityEvent accessibilityEvent) {
        super.c(view, accessibilityEvent);
        if (view instanceof RecyclerView) {
            RecyclerView recyclerView = this.f210d;
            if (!recyclerView.f90u || recyclerView.C || recyclerView.f71e.g()) {
                return;
            }
            RecyclerView recyclerView2 = (RecyclerView) view;
            if (recyclerView2.getLayoutManager() != null) {
                recyclerView2.getLayoutManager().O(accessibilityEvent);
            }
        }
    }

    @Override // g.c
    public final void d(View view, h.o oVar) {
        this.f409a.onInitializeAccessibilityNodeInfo(view, oVar.f473a);
        RecyclerView recyclerView = this.f210d;
        if ((!recyclerView.f90u || recyclerView.C || recyclerView.f71e.g()) || recyclerView.getLayoutManager() == null) {
            return;
        }
        t0 layoutManager = recyclerView.getLayoutManager();
        RecyclerView recyclerView2 = layoutManager.f317b;
        layoutManager.P(recyclerView2.f67c, recyclerView2.f74f0, oVar);
    }

    /* JADX WARN: Removed duplicated region for block: B:27:0x00b3 A[ADDED_TO_REGION] */
    @Override // g.c
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean g(android.view.View r6, int r7, android.os.Bundle r8) {
        /*
            r5 = this;
            boolean r6 = super.g(r6, r7, r8)
            r8 = 1
            if (r6 == 0) goto L8
            return r8
        L8:
            androidx.recyclerview.widget.RecyclerView r6 = r5.f210d
            boolean r0 = r6.f90u
            r1 = 0
            if (r0 == 0) goto L1e
            boolean r0 = r6.C
            if (r0 != 0) goto L1e
            androidx.recyclerview.widget.b r0 = r6.f71e
            boolean r0 = r0.g()
            if (r0 == 0) goto L1c
            goto L1e
        L1c:
            r0 = 0
            goto L1f
        L1e:
            r0 = 1
        L1f:
            if (r0 != 0) goto Lbd
            androidx.recyclerview.widget.t0 r0 = r6.getLayoutManager()
            if (r0 == 0) goto Lbd
            androidx.recyclerview.widget.t0 r6 = r6.getLayoutManager()
            androidx.recyclerview.widget.RecyclerView r0 = r6.f317b
            androidx.recyclerview.widget.a1 r0 = r0.f67c
            int r0 = r6.f329n
            int r2 = r6.f328m
            android.graphics.Rect r3 = new android.graphics.Rect
            r3.<init>()
            androidx.recyclerview.widget.RecyclerView r4 = r6.f317b
            android.graphics.Matrix r4 = r4.getMatrix()
            boolean r4 = r4.isIdentity()
            if (r4 == 0) goto L54
            androidx.recyclerview.widget.RecyclerView r4 = r6.f317b
            boolean r4 = r4.getGlobalVisibleRect(r3)
            if (r4 == 0) goto L54
            int r0 = r3.height()
            int r2 = r3.width()
        L54:
            r3 = 4096(0x1000, float:5.74E-42)
            if (r7 == r3) goto L89
            r3 = 8192(0x2000, float:1.14794E-41)
            if (r7 == r3) goto L5f
            r7 = 0
        L5d:
            r0 = 0
            goto Lb1
        L5f:
            androidx.recyclerview.widget.RecyclerView r7 = r6.f317b
            r3 = -1
            boolean r7 = r7.canScrollVertically(r3)
            if (r7 == 0) goto L74
            int r7 = r6.B()
            int r0 = r0 - r7
            int r7 = r6.y()
            int r0 = r0 - r7
            int r7 = -r0
            goto L75
        L74:
            r7 = 0
        L75:
            androidx.recyclerview.widget.RecyclerView r0 = r6.f317b
            boolean r0 = r0.canScrollHorizontally(r3)
            if (r0 == 0) goto L5d
            int r0 = r6.z()
            int r2 = r2 - r0
            int r0 = r6.A()
            int r2 = r2 - r0
            int r0 = -r2
            goto Lb1
        L89:
            androidx.recyclerview.widget.RecyclerView r7 = r6.f317b
            boolean r7 = r7.canScrollVertically(r8)
            if (r7 == 0) goto L9d
            int r7 = r6.B()
            int r0 = r0 - r7
            int r7 = r6.y()
            int r0 = r0 - r7
            r7 = r0
            goto L9e
        L9d:
            r7 = 0
        L9e:
            androidx.recyclerview.widget.RecyclerView r0 = r6.f317b
            boolean r0 = r0.canScrollHorizontally(r8)
            if (r0 == 0) goto L5d
            int r0 = r6.z()
            int r2 = r2 - r0
            int r0 = r6.A()
            int r0 = r2 - r0
        Lb1:
            if (r7 != 0) goto Lb7
            if (r0 != 0) goto Lb7
            r8 = 0
            goto Lbc
        Lb7:
            androidx.recyclerview.widget.RecyclerView r6 = r6.f317b
            r6.c0(r0, r7, r8)
        Lbc:
            return r8
        Lbd:
            return r1
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.k1.g(android.view.View, int, android.os.Bundle):boolean");
    }
}
