package androidx.recyclerview.widget;

import android.animation.TimeInterpolator;
import android.animation.ValueAnimator;
import android.view.View;
import java.util.ArrayList;

/* loaded from: classes.dex */
public final class l extends o0 {

    /* renamed from: s, reason: collision with root package name */
    public static TimeInterpolator f212s;

    /* renamed from: g, reason: collision with root package name */
    public final boolean f213g = true;

    /* renamed from: h, reason: collision with root package name */
    public final ArrayList f214h = new ArrayList();

    /* renamed from: i, reason: collision with root package name */
    public final ArrayList f215i = new ArrayList();

    /* renamed from: j, reason: collision with root package name */
    public final ArrayList f216j = new ArrayList();

    /* renamed from: k, reason: collision with root package name */
    public final ArrayList f217k = new ArrayList();

    /* renamed from: l, reason: collision with root package name */
    public final ArrayList f218l = new ArrayList();

    /* renamed from: m, reason: collision with root package name */
    public final ArrayList f219m = new ArrayList();

    /* renamed from: n, reason: collision with root package name */
    public final ArrayList f220n = new ArrayList();

    /* renamed from: o, reason: collision with root package name */
    public final ArrayList f221o = new ArrayList();

    /* renamed from: p, reason: collision with root package name */
    public final ArrayList f222p = new ArrayList();
    public final ArrayList q = new ArrayList();

    /* renamed from: r, reason: collision with root package name */
    public final ArrayList f223r = new ArrayList();

    public static void h(ArrayList arrayList) {
        int size = arrayList.size();
        while (true) {
            size--;
            if (size < 0) {
                return;
            } else {
                ((i1) arrayList.get(size)).itemView.animate().cancel();
            }
        }
    }

    @Override // androidx.recyclerview.widget.o0
    public final boolean a(i1 i1Var, i1 i1Var2, n0 n0Var, n0 n0Var2) {
        int i2;
        int i3;
        int i4 = n0Var.f235a;
        int i5 = n0Var.f236b;
        if (i1Var2.shouldIgnore()) {
            int i6 = n0Var.f235a;
            i3 = n0Var.f236b;
            i2 = i6;
        } else {
            i2 = n0Var2.f235a;
            i3 = n0Var2.f236b;
        }
        if (i1Var == i1Var2) {
            return g(i1Var, i4, i5, i2, i3);
        }
        float translationX = i1Var.itemView.getTranslationX();
        float translationY = i1Var.itemView.getTranslationY();
        float alpha = i1Var.itemView.getAlpha();
        l(i1Var);
        i1Var.itemView.setTranslationX(translationX);
        i1Var.itemView.setTranslationY(translationY);
        i1Var.itemView.setAlpha(alpha);
        l(i1Var2);
        i1Var2.itemView.setTranslationX(-((int) ((i2 - i4) - translationX)));
        i1Var2.itemView.setTranslationY(-((int) ((i3 - i5) - translationY)));
        i1Var2.itemView.setAlpha(RecyclerView.B0);
        this.f217k.add(new j(i1Var, i1Var2, i4, i5, i2, i3));
        return true;
    }

    @Override // androidx.recyclerview.widget.o0
    public final void d(i1 i1Var) {
        View view = i1Var.itemView;
        view.animate().cancel();
        ArrayList arrayList = this.f216j;
        int size = arrayList.size();
        while (true) {
            size--;
            if (size < 0) {
                break;
            }
            if (((k) arrayList.get(size)).f205a == i1Var) {
                view.setTranslationY(RecyclerView.B0);
                view.setTranslationX(RecyclerView.B0);
                c(i1Var);
                arrayList.remove(size);
            }
        }
        j(i1Var, this.f217k);
        if (this.f214h.remove(i1Var)) {
            view.setAlpha(1.0f);
            c(i1Var);
        }
        if (this.f215i.remove(i1Var)) {
            view.setAlpha(1.0f);
            c(i1Var);
        }
        ArrayList arrayList2 = this.f220n;
        int size2 = arrayList2.size();
        while (true) {
            size2--;
            if (size2 < 0) {
                break;
            }
            ArrayList arrayList3 = (ArrayList) arrayList2.get(size2);
            j(i1Var, arrayList3);
            if (arrayList3.isEmpty()) {
                arrayList2.remove(size2);
            }
        }
        ArrayList arrayList4 = this.f219m;
        int size3 = arrayList4.size();
        while (true) {
            size3--;
            if (size3 < 0) {
                break;
            }
            ArrayList arrayList5 = (ArrayList) arrayList4.get(size3);
            int size4 = arrayList5.size();
            while (true) {
                size4--;
                if (size4 < 0) {
                    break;
                }
                if (((k) arrayList5.get(size4)).f205a == i1Var) {
                    view.setTranslationY(RecyclerView.B0);
                    view.setTranslationX(RecyclerView.B0);
                    c(i1Var);
                    arrayList5.remove(size4);
                    if (arrayList5.isEmpty()) {
                        arrayList4.remove(size3);
                    }
                }
            }
        }
        ArrayList arrayList6 = this.f218l;
        int size5 = arrayList6.size();
        while (true) {
            size5--;
            if (size5 < 0) {
                this.q.remove(i1Var);
                this.f221o.remove(i1Var);
                this.f223r.remove(i1Var);
                this.f222p.remove(i1Var);
                i();
                return;
            }
            ArrayList arrayList7 = (ArrayList) arrayList6.get(size5);
            if (arrayList7.remove(i1Var)) {
                view.setAlpha(1.0f);
                c(i1Var);
                if (arrayList7.isEmpty()) {
                    arrayList6.remove(size5);
                }
            }
        }
    }

    @Override // androidx.recyclerview.widget.o0
    public final void e() {
        ArrayList arrayList = this.f216j;
        int size = arrayList.size();
        while (true) {
            size--;
            if (size < 0) {
                break;
            }
            k kVar = (k) arrayList.get(size);
            View view = kVar.f205a.itemView;
            view.setTranslationY(RecyclerView.B0);
            view.setTranslationX(RecyclerView.B0);
            c(kVar.f205a);
            arrayList.remove(size);
        }
        ArrayList arrayList2 = this.f214h;
        int size2 = arrayList2.size();
        while (true) {
            size2--;
            if (size2 < 0) {
                break;
            }
            c((i1) arrayList2.get(size2));
            arrayList2.remove(size2);
        }
        ArrayList arrayList3 = this.f215i;
        int size3 = arrayList3.size();
        while (true) {
            size3--;
            if (size3 < 0) {
                break;
            }
            i1 i1Var = (i1) arrayList3.get(size3);
            i1Var.itemView.setAlpha(1.0f);
            c(i1Var);
            arrayList3.remove(size3);
        }
        ArrayList arrayList4 = this.f217k;
        int size4 = arrayList4.size();
        while (true) {
            size4--;
            if (size4 < 0) {
                break;
            }
            j jVar = (j) arrayList4.get(size4);
            i1 i1Var2 = jVar.f197a;
            if (i1Var2 != null) {
                k(jVar, i1Var2);
            }
            i1 i1Var3 = jVar.f198b;
            if (i1Var3 != null) {
                k(jVar, i1Var3);
            }
        }
        arrayList4.clear();
        if (f()) {
            ArrayList arrayList5 = this.f219m;
            int size5 = arrayList5.size();
            while (true) {
                size5--;
                if (size5 < 0) {
                    break;
                }
                ArrayList arrayList6 = (ArrayList) arrayList5.get(size5);
                int size6 = arrayList6.size();
                while (true) {
                    size6--;
                    if (size6 >= 0) {
                        k kVar2 = (k) arrayList6.get(size6);
                        View view2 = kVar2.f205a.itemView;
                        view2.setTranslationY(RecyclerView.B0);
                        view2.setTranslationX(RecyclerView.B0);
                        c(kVar2.f205a);
                        arrayList6.remove(size6);
                        if (arrayList6.isEmpty()) {
                            arrayList5.remove(arrayList6);
                        }
                    }
                }
            }
            ArrayList arrayList7 = this.f218l;
            int size7 = arrayList7.size();
            while (true) {
                size7--;
                if (size7 < 0) {
                    break;
                }
                ArrayList arrayList8 = (ArrayList) arrayList7.get(size7);
                int size8 = arrayList8.size();
                while (true) {
                    size8--;
                    if (size8 >= 0) {
                        i1 i1Var4 = (i1) arrayList8.get(size8);
                        i1Var4.itemView.setAlpha(1.0f);
                        c(i1Var4);
                        arrayList8.remove(size8);
                        if (arrayList8.isEmpty()) {
                            arrayList7.remove(arrayList8);
                        }
                    }
                }
            }
            ArrayList arrayList9 = this.f220n;
            int size9 = arrayList9.size();
            while (true) {
                size9--;
                if (size9 < 0) {
                    break;
                }
                ArrayList arrayList10 = (ArrayList) arrayList9.get(size9);
                int size10 = arrayList10.size();
                while (true) {
                    size10--;
                    if (size10 >= 0) {
                        j jVar2 = (j) arrayList10.get(size10);
                        i1 i1Var5 = jVar2.f197a;
                        if (i1Var5 != null) {
                            k(jVar2, i1Var5);
                        }
                        i1 i1Var6 = jVar2.f198b;
                        if (i1Var6 != null) {
                            k(jVar2, i1Var6);
                        }
                        if (arrayList10.isEmpty()) {
                            arrayList9.remove(arrayList10);
                        }
                    }
                }
            }
            h(this.q);
            h(this.f222p);
            h(this.f221o);
            h(this.f223r);
            ArrayList arrayList11 = this.f244b;
            if (arrayList11.size() <= 0) {
                arrayList11.clear();
            } else {
                c.c(arrayList11.get(0));
                throw null;
            }
        }
    }

    @Override // androidx.recyclerview.widget.o0
    public final boolean f() {
        return (this.f215i.isEmpty() && this.f217k.isEmpty() && this.f216j.isEmpty() && this.f214h.isEmpty() && this.f222p.isEmpty() && this.q.isEmpty() && this.f221o.isEmpty() && this.f223r.isEmpty() && this.f219m.isEmpty() && this.f218l.isEmpty() && this.f220n.isEmpty()) ? false : true;
    }

    public final boolean g(i1 i1Var, int i2, int i3, int i4, int i5) {
        View view = i1Var.itemView;
        int translationX = i2 + ((int) view.getTranslationX());
        int translationY = i3 + ((int) i1Var.itemView.getTranslationY());
        l(i1Var);
        int i6 = i4 - translationX;
        int i7 = i5 - translationY;
        if (i6 == 0 && i7 == 0) {
            c(i1Var);
            return false;
        }
        if (i6 != 0) {
            view.setTranslationX(-i6);
        }
        if (i7 != 0) {
            view.setTranslationY(-i7);
        }
        this.f216j.add(new k(i1Var, translationX, translationY, i4, i5));
        return true;
    }

    public final void i() {
        if (f()) {
            return;
        }
        ArrayList arrayList = this.f244b;
        if (arrayList.size() <= 0) {
            arrayList.clear();
        } else {
            c.c(arrayList.get(0));
            throw null;
        }
    }

    public final void j(i1 i1Var, ArrayList arrayList) {
        int size = arrayList.size();
        while (true) {
            size--;
            if (size < 0) {
                return;
            }
            j jVar = (j) arrayList.get(size);
            if (k(jVar, i1Var) && jVar.f197a == null && jVar.f198b == null) {
                arrayList.remove(jVar);
            }
        }
    }

    public final boolean k(j jVar, i1 i1Var) {
        if (jVar.f198b == i1Var) {
            jVar.f198b = null;
        } else {
            if (jVar.f197a != i1Var) {
                return false;
            }
            jVar.f197a = null;
        }
        i1Var.itemView.setAlpha(1.0f);
        i1Var.itemView.setTranslationX(RecyclerView.B0);
        i1Var.itemView.setTranslationY(RecyclerView.B0);
        c(i1Var);
        return true;
    }

    public final void l(i1 i1Var) {
        if (f212s == null) {
            f212s = new ValueAnimator().getInterpolator();
        }
        i1Var.itemView.animate().setInterpolator(f212s);
        d(i1Var);
    }
}
