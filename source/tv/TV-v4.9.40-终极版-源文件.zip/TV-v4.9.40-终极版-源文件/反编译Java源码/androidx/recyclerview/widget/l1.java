package androidx.recyclerview.widget;

import java.util.Arrays;

/* loaded from: classes.dex */
public final class l1 {

    /* renamed from: a, reason: collision with root package name */
    public int f224a;

    /* renamed from: b, reason: collision with root package name */
    public int f225b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f226c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f227d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f228e;

    /* renamed from: f, reason: collision with root package name */
    public int[] f229f;

    /* renamed from: g, reason: collision with root package name */
    public final /* synthetic */ StaggeredGridLayoutManager f230g;

    public l1(StaggeredGridLayoutManager staggeredGridLayoutManager) {
        this.f230g = staggeredGridLayoutManager;
        a();
    }

    public final void a() {
        this.f224a = -1;
        this.f225b = Integer.MIN_VALUE;
        this.f226c = false;
        this.f227d = false;
        this.f228e = false;
        int[] iArr = this.f229f;
        if (iArr != null) {
            Arrays.fill(iArr, -1);
        }
    }
}
