package androidx.recyclerview.widget;

import android.animation.ValueAnimator;
import tv.live.M3UParser;

/* loaded from: classes.dex */
public final class m implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f231a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f232b;

    public /* synthetic */ m(int i2, Object obj) {
        this.f231a = i2;
        this.f232b = obj;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i2 = this.f231a;
        Object obj = this.f232b;
        switch (i2) {
            case 0:
                q qVar = (q) obj;
                int i3 = qVar.A;
                ValueAnimator valueAnimator = qVar.f291z;
                if (i3 == 1) {
                    valueAnimator.cancel();
                } else if (i3 != 2) {
                }
                qVar.A = 3;
                valueAnimator.setFloatValues(((Float) valueAnimator.getAnimatedValue()).floatValue(), RecyclerView.B0);
                valueAnimator.setDuration(M3UParser.MAX_URLS_PER_CHANNEL);
                valueAnimator.start();
                break;
            default:
                ((StaggeredGridLayoutManager) obj).u0();
                break;
        }
    }
}
