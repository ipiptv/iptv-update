package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public final class m1 extends u0 {

    /* renamed from: e, reason: collision with root package name */
    public p1 f233e;
}
