package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public final class n extends x0 {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ q f234a;

    public n(q qVar) {
        this.f234a = qVar;
    }

    @Override // androidx.recyclerview.widget.x0
    public final void a(RecyclerView recyclerView) {
        int computeHorizontalScrollOffset = recyclerView.computeHorizontalScrollOffset();
        int computeVerticalScrollOffset = recyclerView.computeVerticalScrollOffset();
        q qVar = this.f234a;
        int computeVerticalScrollRange = qVar.f284s.computeVerticalScrollRange();
        int i2 = qVar.f283r;
        int i3 = computeVerticalScrollRange - i2;
        int i4 = qVar.f267a;
        qVar.f285t = i3 > 0 && i2 >= i4;
        int computeHorizontalScrollRange = qVar.f284s.computeHorizontalScrollRange();
        int i5 = qVar.q;
        boolean z2 = computeHorizontalScrollRange - i5 > 0 && i5 >= i4;
        qVar.f286u = z2;
        boolean z3 = qVar.f285t;
        if (!z3 && !z2) {
            if (qVar.f287v != 0) {
                qVar.d(0);
                return;
            }
            return;
        }
        if (z3) {
            float f2 = i2;
            qVar.f278l = (int) ((((f2 / 2.0f) + computeVerticalScrollOffset) * f2) / computeVerticalScrollRange);
            qVar.f277k = Math.min(i2, (i2 * i2) / computeVerticalScrollRange);
        }
        if (qVar.f286u) {
            float f3 = computeHorizontalScrollOffset;
            float f4 = i5;
            qVar.f281o = (int) ((((f4 / 2.0f) + f3) * f4) / computeHorizontalScrollRange);
            qVar.f280n = Math.min(i5, (i5 * i5) / computeHorizontalScrollRange);
        }
        int i6 = qVar.f287v;
        if (i6 == 0 || i6 == 1) {
            qVar.d(1);
        }
    }
}
