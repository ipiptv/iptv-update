package androidx.recyclerview.widget;

import android.view.View;

/* loaded from: classes.dex */
public final class n0 {

    /* renamed from: a, reason: collision with root package name */
    public int f235a;

    /* renamed from: b, reason: collision with root package name */
    public int f236b;

    public n0(int i2, int i3) {
        this.f235a = i2;
        this.f236b = i3;
    }

    public void a(i1 i1Var) {
        View view = i1Var.itemView;
        this.f235a = view.getLeft();
        this.f236b = view.getTop();
        view.getRight();
        view.getBottom();
    }
}
