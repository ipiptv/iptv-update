package androidx.recyclerview.widget;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.Arrays;

/* loaded from: classes.dex */
public final class n1 implements Parcelable {
    public static final Parcelable.Creator<n1> CREATOR = new b0(1);

    /* renamed from: a, reason: collision with root package name */
    public int f237a;

    /* renamed from: b, reason: collision with root package name */
    public int f238b;

    /* renamed from: c, reason: collision with root package name */
    public int[] f239c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f240d;

    public n1(Parcel parcel) {
        this.f237a = parcel.readInt();
        this.f238b = parcel.readInt();
        this.f240d = parcel.readInt() == 1;
        int readInt = parcel.readInt();
        if (readInt > 0) {
            int[] iArr = new int[readInt];
            this.f239c = iArr;
            parcel.readIntArray(iArr);
        }
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    public final String toString() {
        return "FullSpanItem{mPosition=" + this.f237a + ", mGapDir=" + this.f238b + ", mHasUnwantedGapAfter=" + this.f240d + ", mGapPerSpan=" + Arrays.toString(this.f239c) + '}';
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i2) {
        parcel.writeInt(this.f237a);
        parcel.writeInt(this.f238b);
        parcel.writeInt(this.f240d ? 1 : 0);
        int[] iArr = this.f239c;
        if (iArr == null || iArr.length <= 0) {
            parcel.writeInt(0);
        } else {
            parcel.writeInt(iArr.length);
            parcel.writeIntArray(this.f239c);
        }
    }
}
