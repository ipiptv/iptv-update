package androidx.recyclerview.widget;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;

/* loaded from: classes.dex */
public final class o extends AnimatorListenerAdapter {

    /* renamed from: a, reason: collision with root package name */
    public boolean f241a = false;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ q f242b;

    public o(q qVar) {
        this.f242b = qVar;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationCancel(Animator animator) {
        this.f241a = true;
    }

    @Override // android.animation.AnimatorListenerAdapter, android.animation.Animator.AnimatorListener
    public final void onAnimationEnd(Animator animator) {
        if (this.f241a) {
            this.f241a = false;
            return;
        }
        q qVar = this.f242b;
        if (((Float) qVar.f291z.getAnimatedValue()).floatValue() == RecyclerView.B0) {
            qVar.A = 0;
            qVar.d(0);
        } else {
            qVar.A = 2;
            qVar.f284s.invalidate();
        }
    }
}
