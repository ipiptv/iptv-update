package androidx.recyclerview.widget;

import java.util.ArrayList;

/* loaded from: classes.dex */
public abstract class o0 {

    /* renamed from: a, reason: collision with root package name */
    public p0 f243a = null;

    /* renamed from: b, reason: collision with root package name */
    public final ArrayList f244b = new ArrayList();

    /* renamed from: c, reason: collision with root package name */
    public final long f245c = 120;

    /* renamed from: d, reason: collision with root package name */
    public final long f246d = 120;

    /* renamed from: e, reason: collision with root package name */
    public final long f247e = 250;

    /* renamed from: f, reason: collision with root package name */
    public final long f248f = 250;

    public static void b(i1 i1Var) {
        int i2 = i1Var.mFlags & 14;
        if (!i1Var.isInvalid() && (i2 & 4) == 0) {
            i1Var.getOldPosition();
            i1Var.getAbsoluteAdapterPosition();
        }
    }

    public abstract boolean a(i1 i1Var, i1 i1Var2, n0 n0Var, n0 n0Var2);

    /* JADX WARN: Removed duplicated region for block: B:19:0x0063  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void c(androidx.recyclerview.widget.i1 r10) {
        /*
            r9 = this;
            androidx.recyclerview.widget.p0 r0 = r9.f243a
            if (r0 == 0) goto Lad
            r1 = 1
            r10.setIsRecyclable(r1)
            androidx.recyclerview.widget.i1 r2 = r10.mShadowedHolder
            r3 = 0
            if (r2 == 0) goto L13
            androidx.recyclerview.widget.i1 r2 = r10.mShadowingHolder
            if (r2 != 0) goto L13
            r10.mShadowedHolder = r3
        L13:
            r10.mShadowingHolder = r3
            boolean r2 = r10.shouldBeKeptAsChild()
            if (r2 != 0) goto Lad
            android.view.View r2 = r10.itemView
            androidx.recyclerview.widget.RecyclerView r0 = r0.f260a
            r0.d0()
            androidx.recyclerview.widget.e r3 = r0.f73f
            androidx.recyclerview.widget.d r4 = r3.f147b
            androidx.recyclerview.widget.p0 r5 = r3.f146a
            int r6 = r3.f149d
            r7 = 0
            if (r6 != r1) goto L3a
            android.view.View r1 = r3.f150e
            if (r1 != r2) goto L32
            goto L60
        L32:
            java.lang.IllegalStateException r10 = new java.lang.IllegalStateException
            java.lang.String r0 = "Cannot call removeViewIfHidden within removeView(At) for a different view"
            r10.<init>(r0)
            throw r10
        L3a:
            r8 = 2
            if (r6 == r8) goto La5
            r3.f149d = r8     // Catch: java.lang.Throwable -> La1
            androidx.recyclerview.widget.RecyclerView r6 = r5.f260a     // Catch: java.lang.Throwable -> La1
            int r6 = r6.indexOfChild(r2)     // Catch: java.lang.Throwable -> La1
            r8 = -1
            if (r6 != r8) goto L4c
            r3.k(r2)     // Catch: java.lang.Throwable -> La1
            goto L5b
        L4c:
            boolean r8 = r4.d(r6)     // Catch: java.lang.Throwable -> La1
            if (r8 == 0) goto L5e
            r4.f(r6)     // Catch: java.lang.Throwable -> La1
            r3.k(r2)     // Catch: java.lang.Throwable -> La1
            r5.g(r6)     // Catch: java.lang.Throwable -> La1
        L5b:
            r3.f149d = r7
            goto L61
        L5e:
            r3.f149d = r7
        L60:
            r1 = 0
        L61:
            if (r1 == 0) goto L8e
            androidx.recyclerview.widget.i1 r3 = androidx.recyclerview.widget.RecyclerView.I(r2)
            androidx.recyclerview.widget.a1 r4 = r0.f67c
            r4.l(r3)
            r4.i(r3)
            boolean r3 = androidx.recyclerview.widget.RecyclerView.z0
            if (r3 == 0) goto L8e
            java.lang.StringBuilder r3 = new java.lang.StringBuilder
            java.lang.String r4 = "after removing animated view: "
            r3.<init>(r4)
            r3.append(r2)
            java.lang.String r2 = ", "
            r3.append(r2)
            r3.append(r0)
            java.lang.String r2 = r3.toString()
            java.lang.String r3 = "RecyclerView"
            android.util.Log.d(r3, r2)
        L8e:
            r2 = r1 ^ 1
            r0.e0(r2)
            if (r1 != 0) goto Lad
            boolean r1 = r10.isTmpDetached()
            if (r1 == 0) goto Lad
            android.view.View r10 = r10.itemView
            r0.removeDetachedView(r10, r7)
            goto Lad
        La1:
            r10 = move-exception
            r3.f149d = r7
            throw r10
        La5:
            java.lang.IllegalStateException r10 = new java.lang.IllegalStateException
            java.lang.String r0 = "Cannot call removeViewIfHidden within removeViewIfHidden"
            r10.<init>(r0)
            throw r10
        Lad:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.o0.c(androidx.recyclerview.widget.i1):void");
    }

    public abstract void d(i1 i1Var);

    public abstract void e();

    public abstract boolean f();
}
