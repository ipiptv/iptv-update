package androidx.recyclerview.widget;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.List;

/* loaded from: classes.dex */
public final class o1 implements Parcelable {
    public static final Parcelable.Creator<o1> CREATOR = new b0(2);

    /* renamed from: a, reason: collision with root package name */
    public int f249a;

    /* renamed from: b, reason: collision with root package name */
    public int f250b;

    /* renamed from: c, reason: collision with root package name */
    public int f251c;

    /* renamed from: d, reason: collision with root package name */
    public int[] f252d;

    /* renamed from: e, reason: collision with root package name */
    public int f253e;

    /* renamed from: f, reason: collision with root package name */
    public int[] f254f;

    /* renamed from: g, reason: collision with root package name */
    public List f255g;

    /* renamed from: h, reason: collision with root package name */
    public boolean f256h;

    /* renamed from: i, reason: collision with root package name */
    public boolean f257i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f258j;

    public o1(Parcel parcel) {
        this.f249a = parcel.readInt();
        this.f250b = parcel.readInt();
        int readInt = parcel.readInt();
        this.f251c = readInt;
        if (readInt > 0) {
            int[] iArr = new int[readInt];
            this.f252d = iArr;
            parcel.readIntArray(iArr);
        }
        int readInt2 = parcel.readInt();
        this.f253e = readInt2;
        if (readInt2 > 0) {
            int[] iArr2 = new int[readInt2];
            this.f254f = iArr2;
            parcel.readIntArray(iArr2);
        }
        this.f256h = parcel.readInt() == 1;
        this.f257i = parcel.readInt() == 1;
        this.f258j = parcel.readInt() == 1;
        this.f255g = parcel.readArrayList(n1.class.getClassLoader());
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public final void writeToParcel(Parcel parcel, int i2) {
        parcel.writeInt(this.f249a);
        parcel.writeInt(this.f250b);
        parcel.writeInt(this.f251c);
        if (this.f251c > 0) {
            parcel.writeIntArray(this.f252d);
        }
        parcel.writeInt(this.f253e);
        if (this.f253e > 0) {
            parcel.writeIntArray(this.f254f);
        }
        parcel.writeInt(this.f256h ? 1 : 0);
        parcel.writeInt(this.f257i ? 1 : 0);
        parcel.writeInt(this.f258j ? 1 : 0);
        parcel.writeList(this.f255g);
    }

    public o1(o1 o1Var) {
        this.f251c = o1Var.f251c;
        this.f249a = o1Var.f249a;
        this.f250b = o1Var.f250b;
        this.f252d = o1Var.f252d;
        this.f253e = o1Var.f253e;
        this.f254f = o1Var.f254f;
        this.f256h = o1Var.f256h;
        this.f257i = o1Var.f257i;
        this.f258j = o1Var.f258j;
        this.f255g = o1Var.f255g;
    }
}
