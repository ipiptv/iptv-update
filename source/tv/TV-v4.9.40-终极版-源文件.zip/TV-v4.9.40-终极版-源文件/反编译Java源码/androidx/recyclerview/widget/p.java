package androidx.recyclerview.widget;

import android.animation.ValueAnimator;

/* loaded from: classes.dex */
public final class p implements ValueAnimator.AnimatorUpdateListener {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ q f259a;

    public p(q qVar) {
        this.f259a = qVar;
    }

    @Override // android.animation.ValueAnimator.AnimatorUpdateListener
    public final void onAnimationUpdate(ValueAnimator valueAnimator) {
        int floatValue = (int) (((Float) valueAnimator.getAnimatedValue()).floatValue() * 255.0f);
        q qVar = this.f259a;
        qVar.f269c.setAlpha(floatValue);
        qVar.f270d.setAlpha(floatValue);
        qVar.f284s.invalidate();
    }
}
