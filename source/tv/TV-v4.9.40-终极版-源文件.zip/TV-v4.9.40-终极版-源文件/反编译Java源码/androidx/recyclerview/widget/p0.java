package androidx.recyclerview.widget;

import android.util.Log;
import android.view.View;
import java.util.ArrayList;

/* loaded from: classes.dex */
public final class p0 {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ RecyclerView f260a;

    public /* synthetic */ p0(RecyclerView recyclerView) {
        this.f260a = recyclerView;
    }

    public final void a(a aVar) {
        int i2 = aVar.f107a;
        RecyclerView recyclerView = this.f260a;
        if (i2 == 1) {
            recyclerView.f84n.S(aVar.f108b, aVar.f110d);
            return;
        }
        if (i2 == 2) {
            recyclerView.f84n.V(aVar.f108b, aVar.f110d);
        } else if (i2 == 4) {
            recyclerView.f84n.W(aVar.f108b, aVar.f110d);
        } else {
            if (i2 != 8) {
                return;
            }
            recyclerView.f84n.U(aVar.f108b, aVar.f110d);
        }
    }

    public final i1 b(int i2) {
        RecyclerView recyclerView = this.f260a;
        int h2 = recyclerView.f73f.h();
        int i3 = 0;
        i1 i1Var = null;
        while (true) {
            if (i3 >= h2) {
                break;
            }
            i1 I = RecyclerView.I(recyclerView.f73f.g(i3));
            if (I != null && !I.isRemoved() && I.mPosition == i2) {
                if (!recyclerView.f73f.j(I.itemView)) {
                    i1Var = I;
                    break;
                }
                i1Var = I;
            }
            i3++;
        }
        if (i1Var == null) {
            return null;
        }
        if (!recyclerView.f73f.j(i1Var.itemView)) {
            return i1Var;
        }
        if (RecyclerView.z0) {
            Log.d("RecyclerView", "assuming view holder cannot be find because it is hidden");
        }
        return null;
    }

    public final int c() {
        return this.f260a.getChildCount();
    }

    public final void d(int i2, int i3, Object obj) {
        int i4;
        int i5;
        RecyclerView recyclerView = this.f260a;
        int h2 = recyclerView.f73f.h();
        int i6 = i3 + i2;
        for (int i7 = 0; i7 < h2; i7++) {
            View g2 = recyclerView.f73f.g(i7);
            i1 I = RecyclerView.I(g2);
            if (I != null && !I.shouldIgnore() && (i5 = I.mPosition) >= i2 && i5 < i6) {
                I.addFlags(2);
                I.addChangePayload(obj);
                ((u0) g2.getLayoutParams()).f341c = true;
            }
        }
        a1 a1Var = recyclerView.f67c;
        ArrayList arrayList = a1Var.f125c;
        int size = arrayList.size();
        while (true) {
            size--;
            if (size < 0) {
                recyclerView.j0 = true;
                return;
            }
            i1 i1Var = (i1) arrayList.get(size);
            if (i1Var != null && (i4 = i1Var.mPosition) >= i2 && i4 < i6) {
                i1Var.addFlags(2);
                a1Var.g(size);
            }
        }
    }

    public final void e(int i2, int i3) {
        RecyclerView recyclerView = this.f260a;
        int h2 = recyclerView.f73f.h();
        for (int i4 = 0; i4 < h2; i4++) {
            i1 I = RecyclerView.I(recyclerView.f73f.g(i4));
            if (I != null && !I.shouldIgnore() && I.mPosition >= i2) {
                if (RecyclerView.z0) {
                    Log.d("RecyclerView", "offsetPositionRecordsForInsert attached child " + i4 + " holder " + I + " now at position " + (I.mPosition + i3));
                }
                I.offsetPosition(i3, false);
                recyclerView.f74f0.f158e = true;
            }
        }
        ArrayList arrayList = recyclerView.f67c.f125c;
        int size = arrayList.size();
        for (int i5 = 0; i5 < size; i5++) {
            i1 i1Var = (i1) arrayList.get(i5);
            if (i1Var != null && i1Var.mPosition >= i2) {
                if (RecyclerView.z0) {
                    Log.d("RecyclerView", "offsetPositionRecordsForInsert cached " + i5 + " holder " + i1Var + " now at position " + (i1Var.mPosition + i3));
                }
                i1Var.offsetPosition(i3, false);
            }
        }
        recyclerView.requestLayout();
        recyclerView.i0 = true;
    }

    public final void f(int i2, int i3) {
        int i4;
        int i5;
        int i6;
        int i7;
        int i8;
        int i9;
        int i10;
        int i11;
        RecyclerView recyclerView = this.f260a;
        int h2 = recyclerView.f73f.h();
        if (i2 < i3) {
            i5 = i2;
            i4 = i3;
            i6 = -1;
        } else {
            i4 = i2;
            i5 = i3;
            i6 = 1;
        }
        boolean z2 = false;
        for (int i12 = 0; i12 < h2; i12++) {
            i1 I = RecyclerView.I(recyclerView.f73f.g(i12));
            if (I != null && (i11 = I.mPosition) >= i5 && i11 <= i4) {
                if (RecyclerView.z0) {
                    Log.d("RecyclerView", "offsetPositionRecordsForMove attached child " + i12 + " holder " + I);
                }
                if (I.mPosition == i2) {
                    I.offsetPosition(i3 - i2, false);
                } else {
                    I.offsetPosition(i6, false);
                }
                recyclerView.f74f0.f158e = true;
            }
        }
        a1 a1Var = recyclerView.f67c;
        a1Var.getClass();
        if (i2 < i3) {
            i8 = i2;
            i7 = i3;
            i9 = -1;
        } else {
            i7 = i2;
            i8 = i3;
            i9 = 1;
        }
        ArrayList arrayList = a1Var.f125c;
        int size = arrayList.size();
        int i13 = 0;
        while (i13 < size) {
            i1 i1Var = (i1) arrayList.get(i13);
            if (i1Var != null && (i10 = i1Var.mPosition) >= i8 && i10 <= i7) {
                if (i10 == i2) {
                    i1Var.offsetPosition(i3 - i2, z2);
                } else {
                    i1Var.offsetPosition(i9, z2);
                }
                if (RecyclerView.z0) {
                    Log.d("RecyclerView", "offsetPositionRecordsForMove cached child " + i13 + " holder " + i1Var);
                }
            }
            i13++;
            z2 = false;
        }
        recyclerView.requestLayout();
        recyclerView.i0 = true;
    }

    public final void g(int i2) {
        RecyclerView recyclerView = this.f260a;
        View childAt = recyclerView.getChildAt(i2);
        if (childAt != null) {
            i1 I = RecyclerView.I(childAt);
            i0 i0Var = recyclerView.f83m;
            if (i0Var != null && I != null) {
                i0Var.onViewDetachedFromWindow(I);
            }
            childAt.clearAnimation();
        }
        recyclerView.removeViewAt(i2);
    }
}
