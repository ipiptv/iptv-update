package androidx.recyclerview.widget;

import android.view.View;
import java.util.ArrayList;

/* loaded from: classes.dex */
public final class p1 {

    /* renamed from: a, reason: collision with root package name */
    public final ArrayList f261a = new ArrayList();

    /* renamed from: b, reason: collision with root package name */
    public int f262b = Integer.MIN_VALUE;

    /* renamed from: c, reason: collision with root package name */
    public int f263c = Integer.MIN_VALUE;

    /* renamed from: d, reason: collision with root package name */
    public int f264d = 0;

    /* renamed from: e, reason: collision with root package name */
    public final int f265e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ StaggeredGridLayoutManager f266f;

    public p1(StaggeredGridLayoutManager staggeredGridLayoutManager, int i2) {
        this.f266f = staggeredGridLayoutManager;
        this.f265e = i2;
    }

    public static m1 h(View view) {
        return (m1) view.getLayoutParams();
    }

    public final void a() {
        View view = (View) this.f261a.get(r0.size() - 1);
        m1 h2 = h(view);
        this.f263c = this.f266f.q.b(view);
        h2.getClass();
    }

    public final void b() {
        this.f261a.clear();
        this.f262b = Integer.MIN_VALUE;
        this.f263c = Integer.MIN_VALUE;
        this.f264d = 0;
    }

    public final int c() {
        return this.f266f.f102v ? e(r1.size() - 1, -1) : e(0, this.f261a.size());
    }

    public final int d() {
        return this.f266f.f102v ? e(0, this.f261a.size()) : e(r1.size() - 1, -1);
    }

    public final int e(int i2, int i3) {
        StaggeredGridLayoutManager staggeredGridLayoutManager = this.f266f;
        int h2 = staggeredGridLayoutManager.q.h();
        int f2 = staggeredGridLayoutManager.q.f();
        int i4 = i3 > i2 ? 1 : -1;
        while (i2 != i3) {
            View view = (View) this.f261a.get(i2);
            int d2 = staggeredGridLayoutManager.q.d(view);
            int b2 = staggeredGridLayoutManager.q.b(view);
            boolean z2 = d2 <= f2;
            boolean z3 = b2 >= h2;
            if (z2 && z3 && (d2 < h2 || b2 > f2)) {
                return t0.C(view);
            }
            i2 += i4;
        }
        return -1;
    }

    public final int f(int i2) {
        int i3 = this.f263c;
        if (i3 != Integer.MIN_VALUE) {
            return i3;
        }
        if (this.f261a.size() == 0) {
            return i2;
        }
        a();
        return this.f263c;
    }

    public final View g(int i2, int i3) {
        ArrayList arrayList = this.f261a;
        StaggeredGridLayoutManager staggeredGridLayoutManager = this.f266f;
        View view = null;
        if (i3 != -1) {
            int size = arrayList.size() - 1;
            while (size >= 0) {
                View view2 = (View) arrayList.get(size);
                if ((staggeredGridLayoutManager.f102v && t0.C(view2) >= i2) || ((!staggeredGridLayoutManager.f102v && t0.C(view2) <= i2) || !view2.hasFocusable())) {
                    break;
                }
                size--;
                view = view2;
            }
        } else {
            int size2 = arrayList.size();
            int i4 = 0;
            while (i4 < size2) {
                View view3 = (View) arrayList.get(i4);
                if ((staggeredGridLayoutManager.f102v && t0.C(view3) <= i2) || ((!staggeredGridLayoutManager.f102v && t0.C(view3) >= i2) || !view3.hasFocusable())) {
                    break;
                }
                i4++;
                view = view3;
            }
        }
        return view;
    }

    public final int i(int i2) {
        int i3 = this.f262b;
        if (i3 != Integer.MIN_VALUE) {
            return i3;
        }
        ArrayList arrayList = this.f261a;
        if (arrayList.size() == 0) {
            return i2;
        }
        View view = (View) arrayList.get(0);
        m1 h2 = h(view);
        this.f262b = this.f266f.q.d(view);
        h2.getClass();
        return this.f262b;
    }
}
