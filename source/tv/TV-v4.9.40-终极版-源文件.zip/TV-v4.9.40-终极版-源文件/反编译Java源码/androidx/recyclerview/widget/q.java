package androidx.recyclerview.widget;

import android.R;
import android.animation.ValueAnimator;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.StateListDrawable;
import java.lang.reflect.Field;
import java.util.ArrayList;

/* loaded from: classes.dex */
public final class q extends q0 implements w0 {
    public static final int[] C = {R.attr.state_pressed};
    public static final int[] D = new int[0];
    public int A;
    public final m B;

    /* renamed from: a, reason: collision with root package name */
    public final int f267a;

    /* renamed from: b, reason: collision with root package name */
    public final int f268b;

    /* renamed from: c, reason: collision with root package name */
    public final StateListDrawable f269c;

    /* renamed from: d, reason: collision with root package name */
    public final Drawable f270d;

    /* renamed from: e, reason: collision with root package name */
    public final int f271e;

    /* renamed from: f, reason: collision with root package name */
    public final int f272f;

    /* renamed from: g, reason: collision with root package name */
    public final StateListDrawable f273g;

    /* renamed from: h, reason: collision with root package name */
    public final Drawable f274h;

    /* renamed from: i, reason: collision with root package name */
    public final int f275i;

    /* renamed from: j, reason: collision with root package name */
    public final int f276j;

    /* renamed from: k, reason: collision with root package name */
    public int f277k;

    /* renamed from: l, reason: collision with root package name */
    public int f278l;

    /* renamed from: m, reason: collision with root package name */
    public float f279m;

    /* renamed from: n, reason: collision with root package name */
    public int f280n;

    /* renamed from: o, reason: collision with root package name */
    public int f281o;

    /* renamed from: p, reason: collision with root package name */
    public float f282p;

    /* renamed from: s, reason: collision with root package name */
    public RecyclerView f284s;

    /* renamed from: z, reason: collision with root package name */
    public final ValueAnimator f291z;
    public int q = 0;

    /* renamed from: r, reason: collision with root package name */
    public int f283r = 0;

    /* renamed from: t, reason: collision with root package name */
    public boolean f285t = false;

    /* renamed from: u, reason: collision with root package name */
    public boolean f286u = false;

    /* renamed from: v, reason: collision with root package name */
    public int f287v = 0;

    /* renamed from: w, reason: collision with root package name */
    public int f288w = 0;

    /* renamed from: x, reason: collision with root package name */
    public final int[] f289x = new int[2];

    /* renamed from: y, reason: collision with root package name */
    public final int[] f290y = new int[2];

    public q(RecyclerView recyclerView, StateListDrawable stateListDrawable, Drawable drawable, StateListDrawable stateListDrawable2, Drawable drawable2, int i2, int i3, int i4) {
        ValueAnimator ofFloat = ValueAnimator.ofFloat(RecyclerView.B0, 1.0f);
        this.f291z = ofFloat;
        this.A = 0;
        m mVar = new m(0, this);
        this.B = mVar;
        n nVar = new n(this);
        this.f269c = stateListDrawable;
        this.f270d = drawable;
        this.f273g = stateListDrawable2;
        this.f274h = drawable2;
        this.f271e = Math.max(i2, stateListDrawable.getIntrinsicWidth());
        this.f272f = Math.max(i2, drawable.getIntrinsicWidth());
        this.f275i = Math.max(i2, stateListDrawable2.getIntrinsicWidth());
        this.f276j = Math.max(i2, drawable2.getIntrinsicWidth());
        this.f267a = i3;
        this.f268b = i4;
        stateListDrawable.setAlpha(255);
        drawable.setAlpha(255);
        ofFloat.addListener(new o(this));
        ofFloat.addUpdateListener(new p(this));
        RecyclerView recyclerView2 = this.f284s;
        if (recyclerView2 == recyclerView) {
            return;
        }
        if (recyclerView2 != null) {
            t0 t0Var = recyclerView2.f84n;
            if (t0Var != null) {
                t0Var.b("Cannot remove item decoration during a scroll  or layout");
            }
            ArrayList arrayList = recyclerView2.f86p;
            arrayList.remove(this);
            if (arrayList.isEmpty()) {
                recyclerView2.setWillNotDraw(recyclerView2.getOverScrollMode() == 2);
            }
            recyclerView2.L();
            recyclerView2.requestLayout();
            RecyclerView recyclerView3 = this.f284s;
            recyclerView3.q.remove(this);
            if (recyclerView3.f87r == this) {
                recyclerView3.f87r = null;
            }
            ArrayList arrayList2 = this.f284s.f78h0;
            if (arrayList2 != null) {
                arrayList2.remove(nVar);
            }
            this.f284s.removeCallbacks(mVar);
        }
        this.f284s = recyclerView;
        if (recyclerView != null) {
            t0 t0Var2 = recyclerView.f84n;
            if (t0Var2 != null) {
                t0Var2.b("Cannot add item decoration during a scroll  or layout");
            }
            ArrayList arrayList3 = recyclerView.f86p;
            if (arrayList3.isEmpty()) {
                recyclerView.setWillNotDraw(false);
            }
            arrayList3.add(this);
            recyclerView.L();
            recyclerView.requestLayout();
            this.f284s.q.add(this);
            RecyclerView recyclerView4 = this.f284s;
            if (recyclerView4.f78h0 == null) {
                recyclerView4.f78h0 = new ArrayList();
            }
            recyclerView4.f78h0.add(nVar);
        }
    }

    public final boolean a(float f2, float f3) {
        if (f3 >= this.f283r - this.f275i) {
            int i2 = this.f281o;
            int i3 = this.f280n;
            if (f2 >= i2 - (i3 / 2) && f2 <= (i3 / 2) + i2) {
                return true;
            }
        }
        return false;
    }

    public final boolean b(float f2, float f3) {
        RecyclerView recyclerView = this.f284s;
        Field field = g.v.f448a;
        boolean z2 = g.k.d(recyclerView) == 1;
        int i2 = this.f271e;
        if (z2) {
            if (f2 > i2) {
                return false;
            }
        } else if (f2 < this.q - i2) {
            return false;
        }
        int i3 = this.f278l;
        int i4 = this.f277k / 2;
        return f3 >= ((float) (i3 - i4)) && f3 <= ((float) (i4 + i3));
    }

    public final void c(int i2) {
        RecyclerView recyclerView = this.f284s;
        m mVar = this.B;
        recyclerView.removeCallbacks(mVar);
        this.f284s.postDelayed(mVar, i2);
    }

    public final void d(int i2) {
        int i3;
        StateListDrawable stateListDrawable = this.f269c;
        if (i2 == 2 && this.f287v != 2) {
            stateListDrawable.setState(C);
            this.f284s.removeCallbacks(this.B);
        }
        if (i2 == 0) {
            this.f284s.invalidate();
        } else {
            e();
        }
        if (this.f287v != 2 || i2 == 2) {
            i3 = i2 == 1 ? 1500 : 1200;
            this.f287v = i2;
        }
        stateListDrawable.setState(D);
        c(i3);
        this.f287v = i2;
    }

    public final void e() {
        int i2 = this.A;
        ValueAnimator valueAnimator = this.f291z;
        if (i2 != 0) {
            if (i2 != 3) {
                return;
            } else {
                valueAnimator.cancel();
            }
        }
        this.A = 1;
        valueAnimator.setFloatValues(((Float) valueAnimator.getAnimatedValue()).floatValue(), 1.0f);
        valueAnimator.setDuration(500L);
        valueAnimator.setStartDelay(0L);
        valueAnimator.start();
    }
}
