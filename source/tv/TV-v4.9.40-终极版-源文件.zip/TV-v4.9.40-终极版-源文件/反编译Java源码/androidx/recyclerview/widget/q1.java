package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public final class q1 {

    /* renamed from: a, reason: collision with root package name */
    public int f292a = 0;

    /* renamed from: b, reason: collision with root package name */
    public int f293b;

    /* renamed from: c, reason: collision with root package name */
    public int f294c;

    /* renamed from: d, reason: collision with root package name */
    public int f295d;

    /* renamed from: e, reason: collision with root package name */
    public int f296e;

    public final boolean a() {
        int i2 = this.f292a;
        int i3 = 2;
        if ((i2 & 7) != 0) {
            int i4 = this.f295d;
            int i5 = this.f293b;
            if ((((i4 > i5 ? 1 : i4 == i5 ? 2 : 4) << 0) & i2) == 0) {
                return false;
            }
        }
        if ((i2 & 112) != 0) {
            int i6 = this.f295d;
            int i7 = this.f294c;
            if ((((i6 > i7 ? 1 : i6 == i7 ? 2 : 4) << 4) & i2) == 0) {
                return false;
            }
        }
        if ((i2 & 1792) != 0) {
            int i8 = this.f296e;
            int i9 = this.f293b;
            if ((((i8 > i9 ? 1 : i8 == i9 ? 2 : 4) << 8) & i2) == 0) {
                return false;
            }
        }
        if ((i2 & 28672) != 0) {
            int i10 = this.f296e;
            int i11 = this.f294c;
            if (i10 > i11) {
                i3 = 1;
            } else if (i10 != i11) {
                i3 = 4;
            }
            if ((i2 & (i3 << 12)) == 0) {
                return false;
            }
        }
        return true;
    }
}
