package androidx.recyclerview.widget;

import java.util.Comparator;

/* loaded from: classes.dex */
public final class r implements Comparator {
    /* JADX WARN: Code restructure failed: missing block: B:10:0x0022, code lost:
    
        r1 = -1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:12:?, code lost:
    
        return r1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:16:0x0020, code lost:
    
        if (r0 != false) goto L17;
     */
    /* JADX WARN: Code restructure failed: missing block: B:9:0x0017, code lost:
    
        if (r0 == null) goto L18;
     */
    @Override // java.util.Comparator
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final int compare(java.lang.Object r7, java.lang.Object r8) {
        /*
            r6 = this;
            androidx.recyclerview.widget.t r7 = (androidx.recyclerview.widget.t) r7
            androidx.recyclerview.widget.t r8 = (androidx.recyclerview.widget.t) r8
            androidx.recyclerview.widget.RecyclerView r0 = r7.f314d
            r1 = 1
            r2 = 0
            if (r0 != 0) goto Lc
            r3 = 1
            goto Ld
        Lc:
            r3 = 0
        Ld:
            androidx.recyclerview.widget.RecyclerView r4 = r8.f314d
            if (r4 != 0) goto L13
            r4 = 1
            goto L14
        L13:
            r4 = 0
        L14:
            r5 = -1
            if (r3 == r4) goto L1a
            if (r0 != 0) goto L22
            goto L23
        L1a:
            boolean r0 = r7.f311a
            boolean r3 = r8.f311a
            if (r0 == r3) goto L25
            if (r0 == 0) goto L23
        L22:
            r1 = -1
        L23:
            r2 = r1
            goto L36
        L25:
            int r0 = r8.f312b
            int r1 = r7.f312b
            int r0 = r0 - r1
            if (r0 == 0) goto L2e
            r2 = r0
            goto L36
        L2e:
            int r7 = r7.f313c
            int r8 = r8.f313c
            int r7 = r7 - r8
            if (r7 == 0) goto L36
            r2 = r7
        L36:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.r.compare(java.lang.Object, java.lang.Object):int");
    }
}
