package androidx.recyclerview.widget;

import android.view.View;
import android.view.ViewGroup;
import java.util.Iterator;

/* loaded from: classes.dex */
public final class r0 implements r1, g0.a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f297a;

    /* renamed from: b, reason: collision with root package name */
    public final Object f298b;

    public /* synthetic */ r0(int i2, Object obj) {
        this.f297a = i2;
        this.f298b = obj;
    }

    public int a(View view) {
        int bottom;
        int i2;
        int i3 = this.f297a;
        Object obj = this.f298b;
        switch (i3) {
            case 0:
                u0 u0Var = (u0) view.getLayoutParams();
                ((t0) obj).getClass();
                bottom = view.getRight() + ((u0) view.getLayoutParams()).f340b.right;
                i2 = ((ViewGroup.MarginLayoutParams) u0Var).rightMargin;
                break;
            default:
                u0 u0Var2 = (u0) view.getLayoutParams();
                ((t0) obj).getClass();
                bottom = view.getBottom() + ((u0) view.getLayoutParams()).f340b.bottom;
                i2 = ((ViewGroup.MarginLayoutParams) u0Var2).bottomMargin;
                break;
        }
        return bottom + i2;
    }

    public int b(View view) {
        int top;
        int i2;
        int i3 = this.f297a;
        Object obj = this.f298b;
        switch (i3) {
            case 0:
                u0 u0Var = (u0) view.getLayoutParams();
                ((t0) obj).getClass();
                top = view.getLeft() - ((u0) view.getLayoutParams()).f340b.left;
                i2 = ((ViewGroup.MarginLayoutParams) u0Var).leftMargin;
                break;
            default:
                u0 u0Var2 = (u0) view.getLayoutParams();
                ((t0) obj).getClass();
                top = view.getTop() - ((u0) view.getLayoutParams()).f340b.top;
                i2 = ((ViewGroup.MarginLayoutParams) u0Var2).topMargin;
                break;
        }
        return top - i2;
    }

    public int c() {
        int i2;
        int y2;
        int i3 = this.f297a;
        Object obj = this.f298b;
        switch (i3) {
            case 0:
                t0 t0Var = (t0) obj;
                i2 = t0Var.f328m;
                y2 = t0Var.A();
                break;
            default:
                t0 t0Var2 = (t0) obj;
                i2 = t0Var2.f329n;
                y2 = t0Var2.y();
                break;
        }
        return i2 - y2;
    }

    /* JADX WARN: Multi-variable type inference failed */
    @Override // g0.a
    public Iterator iterator() {
        int i2 = this.f297a;
        Object obj = this.f298b;
        switch (i2) {
            case 0:
                return new g.z(0, (ViewGroup) obj);
            default:
                c0.c cVar = (c0.c) obj;
                b0.d.k(cVar, "block");
                g0.b bVar = new g0.b();
                bVar.f464d = cVar instanceof x.a ? ((x.a) cVar).d(bVar, bVar) : new w.b(bVar, bVar, cVar);
                return bVar;
        }
    }
}
