package androidx.recyclerview.widget;

import java.util.Arrays;

/* loaded from: classes.dex */
public final class s {

    /* renamed from: a, reason: collision with root package name */
    public int f299a;

    /* renamed from: b, reason: collision with root package name */
    public int f300b;

    /* renamed from: c, reason: collision with root package name */
    public int[] f301c;

    /* renamed from: d, reason: collision with root package name */
    public int f302d;

    public final void a(int i2, int i3) {
        if (i2 < 0) {
            throw new IllegalArgumentException("Layout positions must be non-negative");
        }
        if (i3 < 0) {
            throw new IllegalArgumentException("Pixel distance must be non-negative");
        }
        int i4 = this.f302d * 2;
        int[] iArr = this.f301c;
        if (iArr == null) {
            int[] iArr2 = new int[4];
            this.f301c = iArr2;
            Arrays.fill(iArr2, -1);
        } else if (i4 >= iArr.length) {
            int[] iArr3 = new int[i4 * 2];
            this.f301c = iArr3;
            System.arraycopy(iArr, 0, iArr3, 0, iArr.length);
        }
        int[] iArr4 = this.f301c;
        iArr4[i4] = i2;
        iArr4[i4 + 1] = i3;
        this.f302d++;
    }

    public final void b(RecyclerView recyclerView, boolean z2) {
        this.f302d = 0;
        int[] iArr = this.f301c;
        if (iArr != null) {
            Arrays.fill(iArr, -1);
        }
        t0 t0Var = recyclerView.f84n;
        if (recyclerView.f83m == null || t0Var == null || !t0Var.f323h) {
            return;
        }
        if (!z2) {
            if (!(!recyclerView.f90u || recyclerView.C || recyclerView.f71e.g())) {
                t0Var.g(this.f299a, this.f300b, recyclerView.f74f0, this);
            }
        } else if (!recyclerView.f71e.g()) {
            t0Var.h(recyclerView.f83m.getItemCount(), this);
        }
        int i2 = this.f302d;
        if (i2 > t0Var.f324i) {
            t0Var.f324i = i2;
            t0Var.f325j = z2;
            recyclerView.f67c.m();
        }
    }
}
