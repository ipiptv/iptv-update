package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public final class s0 {

    /* renamed from: a, reason: collision with root package name */
    public int f303a;

    /* renamed from: b, reason: collision with root package name */
    public int f304b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f305c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f306d;
}
