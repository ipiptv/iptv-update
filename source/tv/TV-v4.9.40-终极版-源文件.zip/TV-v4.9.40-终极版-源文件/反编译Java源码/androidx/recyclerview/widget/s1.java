package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public final class s1 {

    /* renamed from: d, reason: collision with root package name */
    public static final f.b f307d = new f.b(20);

    /* renamed from: a, reason: collision with root package name */
    public int f308a;

    /* renamed from: b, reason: collision with root package name */
    public n0 f309b;

    /* renamed from: c, reason: collision with root package name */
    public n0 f310c;

    public static s1 a() {
        s1 s1Var = (s1) f307d.a();
        return s1Var == null ? new s1() : s1Var;
    }
}
