package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public final class t {

    /* renamed from: a, reason: collision with root package name */
    public boolean f311a;

    /* renamed from: b, reason: collision with root package name */
    public int f312b;

    /* renamed from: c, reason: collision with root package name */
    public int f313c;

    /* renamed from: d, reason: collision with root package name */
    public RecyclerView f314d;

    /* renamed from: e, reason: collision with root package name */
    public int f315e;
}
