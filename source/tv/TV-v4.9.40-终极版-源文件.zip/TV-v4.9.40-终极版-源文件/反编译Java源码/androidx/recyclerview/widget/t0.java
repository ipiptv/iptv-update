package androidx.recyclerview.widget;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Matrix;
import android.graphics.Rect;
import android.graphics.RectF;
import android.os.Parcelable;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import java.lang.reflect.Field;
import java.util.ArrayList;

/* loaded from: classes.dex */
public abstract class t0 {

    /* renamed from: a, reason: collision with root package name */
    public e f316a;

    /* renamed from: b, reason: collision with root package name */
    public RecyclerView f317b;

    /* renamed from: c, reason: collision with root package name */
    public final t1 f318c;

    /* renamed from: d, reason: collision with root package name */
    public final t1 f319d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f320e;

    /* renamed from: f, reason: collision with root package name */
    public boolean f321f;

    /* renamed from: g, reason: collision with root package name */
    public final boolean f322g;

    /* renamed from: h, reason: collision with root package name */
    public final boolean f323h;

    /* renamed from: i, reason: collision with root package name */
    public int f324i;

    /* renamed from: j, reason: collision with root package name */
    public boolean f325j;

    /* renamed from: k, reason: collision with root package name */
    public int f326k;

    /* renamed from: l, reason: collision with root package name */
    public int f327l;

    /* renamed from: m, reason: collision with root package name */
    public int f328m;

    /* renamed from: n, reason: collision with root package name */
    public int f329n;

    public t0() {
        r0 r0Var = new r0(0, this);
        r0 r0Var2 = new r0(1, this);
        this.f318c = new t1(r0Var);
        this.f319d = new t1(r0Var2);
        this.f320e = false;
        this.f321f = false;
        this.f322g = true;
        this.f323h = true;
    }

    public static int C(View view) {
        return ((u0) view.getLayoutParams()).a();
    }

    public static s0 D(Context context, AttributeSet attributeSet, int i2, int i3) {
        s0 s0Var = new s0();
        TypedArray obtainStyledAttributes = context.obtainStyledAttributes(attributeSet, l.a.f494a, i2, i3);
        s0Var.f303a = obtainStyledAttributes.getInt(0, 1);
        s0Var.f304b = obtainStyledAttributes.getInt(10, 1);
        s0Var.f305c = obtainStyledAttributes.getBoolean(9, false);
        s0Var.f306d = obtainStyledAttributes.getBoolean(11, false);
        obtainStyledAttributes.recycle();
        return s0Var;
    }

    public static boolean H(int i2, int i3, int i4) {
        int mode = View.MeasureSpec.getMode(i3);
        int size = View.MeasureSpec.getSize(i3);
        if (i4 > 0 && i2 != i4) {
            return false;
        }
        if (mode == Integer.MIN_VALUE) {
            return size >= i2;
        }
        if (mode != 0) {
            return mode == 1073741824 && size == i2;
        }
        return true;
    }

    public static void I(View view, int i2, int i3, int i4, int i5) {
        u0 u0Var = (u0) view.getLayoutParams();
        Rect rect = u0Var.f340b;
        view.layout(i2 + rect.left + ((ViewGroup.MarginLayoutParams) u0Var).leftMargin, i3 + rect.top + ((ViewGroup.MarginLayoutParams) u0Var).topMargin, (i4 - rect.right) - ((ViewGroup.MarginLayoutParams) u0Var).rightMargin, (i5 - rect.bottom) - ((ViewGroup.MarginLayoutParams) u0Var).bottomMargin);
    }

    public static int f(int i2, int i3, int i4) {
        int mode = View.MeasureSpec.getMode(i2);
        int size = View.MeasureSpec.getSize(i2);
        return mode != Integer.MIN_VALUE ? mode != 1073741824 ? Math.max(i3, i4) : size : Math.min(size, Math.max(i3, i4));
    }

    /* JADX WARN: Code restructure failed: missing block: B:7:0x0017, code lost:
    
        if (r5 == 1073741824) goto L14;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static int v(int r4, int r5, int r6, int r7, boolean r8) {
        /*
            int r4 = r4 - r6
            r6 = 0
            int r4 = java.lang.Math.max(r6, r4)
            r0 = -2
            r1 = -1
            r2 = -2147483648(0xffffffff80000000, float:-0.0)
            r3 = 1073741824(0x40000000, float:2.0)
            if (r8 == 0) goto L1a
            if (r7 < 0) goto L11
            goto L1c
        L11:
            if (r7 != r1) goto L2f
            if (r5 == r2) goto L21
            if (r5 == 0) goto L2f
            if (r5 == r3) goto L21
            goto L2f
        L1a:
            if (r7 < 0) goto L1f
        L1c:
            r5 = 1073741824(0x40000000, float:2.0)
            goto L31
        L1f:
            if (r7 != r1) goto L23
        L21:
            r7 = r4
            goto L31
        L23:
            if (r7 != r0) goto L2f
            if (r5 == r2) goto L2c
            if (r5 != r3) goto L2a
            goto L2c
        L2a:
            r5 = 0
            goto L21
        L2c:
            r5 = -2147483648(0xffffffff80000000, float:-0.0)
            goto L21
        L2f:
            r5 = 0
            r7 = 0
        L31:
            int r4 = android.view.View.MeasureSpec.makeMeasureSpec(r7, r5)
            return r4
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.t0.v(int, int, int, int, boolean):int");
    }

    public static void x(View view, Rect rect) {
        boolean z2 = RecyclerView.y0;
        u0 u0Var = (u0) view.getLayoutParams();
        Rect rect2 = u0Var.f340b;
        rect.set((view.getLeft() - rect2.left) - ((ViewGroup.MarginLayoutParams) u0Var).leftMargin, (view.getTop() - rect2.top) - ((ViewGroup.MarginLayoutParams) u0Var).topMargin, view.getRight() + rect2.right + ((ViewGroup.MarginLayoutParams) u0Var).rightMargin, view.getBottom() + rect2.bottom + ((ViewGroup.MarginLayoutParams) u0Var).bottomMargin);
    }

    public final int A() {
        RecyclerView recyclerView = this.f317b;
        if (recyclerView != null) {
            return recyclerView.getPaddingRight();
        }
        return 0;
    }

    public final int B() {
        RecyclerView recyclerView = this.f317b;
        if (recyclerView != null) {
            return recyclerView.getPaddingTop();
        }
        return 0;
    }

    public int E(a1 a1Var, e1 e1Var) {
        return -1;
    }

    public final void F(View view, Rect rect) {
        Matrix matrix;
        Rect rect2 = ((u0) view.getLayoutParams()).f340b;
        rect.set(-rect2.left, -rect2.top, view.getWidth() + rect2.right, view.getHeight() + rect2.bottom);
        if (this.f317b != null && (matrix = view.getMatrix()) != null && !matrix.isIdentity()) {
            RectF rectF = this.f317b.f82l;
            rectF.set(rect);
            matrix.mapRect(rectF);
            rect.set((int) Math.floor(rectF.left), (int) Math.floor(rectF.top), (int) Math.ceil(rectF.right), (int) Math.ceil(rectF.bottom));
        }
        rect.offset(view.getLeft(), view.getTop());
    }

    public abstract boolean G();

    public void J(int i2) {
        RecyclerView recyclerView = this.f317b;
        if (recyclerView != null) {
            int e2 = recyclerView.f73f.e();
            for (int i3 = 0; i3 < e2; i3++) {
                recyclerView.f73f.d(i3).offsetLeftAndRight(i2);
            }
        }
    }

    public void K(int i2) {
        RecyclerView recyclerView = this.f317b;
        if (recyclerView != null) {
            int e2 = recyclerView.f73f.e();
            for (int i3 = 0; i3 < e2; i3++) {
                recyclerView.f73f.d(i3).offsetTopAndBottom(i2);
            }
        }
    }

    public void L() {
    }

    public abstract void M(RecyclerView recyclerView);

    public abstract View N(View view, int i2, a1 a1Var, e1 e1Var);

    public void O(AccessibilityEvent accessibilityEvent) {
        RecyclerView recyclerView = this.f317b;
        a1 a1Var = recyclerView.f67c;
        e1 e1Var = recyclerView.f74f0;
        if (recyclerView == null || accessibilityEvent == null) {
            return;
        }
        boolean z2 = true;
        if (!recyclerView.canScrollVertically(1) && !this.f317b.canScrollVertically(-1) && !this.f317b.canScrollHorizontally(-1) && !this.f317b.canScrollHorizontally(1)) {
            z2 = false;
        }
        accessibilityEvent.setScrollable(z2);
        i0 i0Var = this.f317b.f83m;
        if (i0Var != null) {
            accessibilityEvent.setItemCount(i0Var.getItemCount());
        }
    }

    public void P(a1 a1Var, e1 e1Var, h.o oVar) {
        boolean canScrollVertically = this.f317b.canScrollVertically(-1);
        AccessibilityNodeInfo accessibilityNodeInfo = oVar.f473a;
        if (canScrollVertically || this.f317b.canScrollHorizontally(-1)) {
            accessibilityNodeInfo.addAction(8192);
            accessibilityNodeInfo.setScrollable(true);
        }
        if (this.f317b.canScrollVertically(1) || this.f317b.canScrollHorizontally(1)) {
            accessibilityNodeInfo.addAction(4096);
            accessibilityNodeInfo.setScrollable(true);
        }
        accessibilityNodeInfo.setCollectionInfo(AccessibilityNodeInfo.CollectionInfo.obtain(E(a1Var, e1Var), w(a1Var, e1Var), false, 0));
    }

    public final void Q(View view, h.o oVar) {
        i1 I = RecyclerView.I(view);
        if (I == null || I.isRemoved() || this.f316a.j(I.itemView)) {
            return;
        }
        RecyclerView recyclerView = this.f317b;
        R(recyclerView.f67c, recyclerView.f74f0, view, oVar);
    }

    public void R(a1 a1Var, e1 e1Var, View view, h.o oVar) {
    }

    public void S(int i2, int i3) {
    }

    public void T() {
    }

    public void U(int i2, int i3) {
    }

    public void V(int i2, int i3) {
    }

    public void W(int i2, int i3) {
    }

    public abstract void X(a1 a1Var, e1 e1Var);

    public abstract void Y(e1 e1Var);

    public abstract void Z(Parcelable parcelable);

    /* JADX WARN: Removed duplicated region for block: B:18:0x0059  */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0061  */
    /* JADX WARN: Removed duplicated region for block: B:39:0x00bb  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void a(android.view.View r7, int r8, boolean r9) {
        /*
            Method dump skipped, instructions count: 283
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.t0.a(android.view.View, int, boolean):void");
    }

    public abstract Parcelable a0();

    public abstract void b(String str);

    public void b0(int i2) {
    }

    public abstract boolean c();

    public final void c0(a1 a1Var) {
        int u2 = u();
        while (true) {
            u2--;
            if (u2 < 0) {
                return;
            }
            if (!RecyclerView.I(t(u2)).shouldIgnore()) {
                View t2 = t(u2);
                f0(u2);
                a1Var.h(t2);
            }
        }
    }

    public abstract boolean d();

    public final void d0(a1 a1Var) {
        ArrayList arrayList;
        int size = a1Var.f123a.size();
        int i2 = size - 1;
        while (true) {
            arrayList = a1Var.f123a;
            if (i2 < 0) {
                break;
            }
            View view = ((i1) arrayList.get(i2)).itemView;
            i1 I = RecyclerView.I(view);
            if (!I.shouldIgnore()) {
                I.setIsRecyclable(false);
                if (I.isTmpDetached()) {
                    this.f317b.removeDetachedView(view, false);
                }
                o0 o0Var = this.f317b.L;
                if (o0Var != null) {
                    o0Var.d(I);
                }
                I.setIsRecyclable(true);
                i1 I2 = RecyclerView.I(view);
                I2.mScrapContainer = null;
                I2.mInChangeScrap = false;
                I2.clearReturnedFromScrapFlag();
                a1Var.i(I2);
            }
            i2--;
        }
        arrayList.clear();
        ArrayList arrayList2 = a1Var.f124b;
        if (arrayList2 != null) {
            arrayList2.clear();
        }
        if (size > 0) {
            this.f317b.invalidate();
        }
    }

    public boolean e(u0 u0Var) {
        return u0Var != null;
    }

    public final void e0(View view, a1 a1Var) {
        e eVar = this.f316a;
        p0 p0Var = eVar.f146a;
        int i2 = eVar.f149d;
        if (i2 == 1) {
            throw new IllegalStateException("Cannot call removeView(At) within removeView(At)");
        }
        if (i2 == 2) {
            throw new IllegalStateException("Cannot call removeView(At) within removeViewIfHidden");
        }
        try {
            eVar.f149d = 1;
            eVar.f150e = view;
            int indexOfChild = p0Var.f260a.indexOfChild(view);
            if (indexOfChild >= 0) {
                if (eVar.f147b.f(indexOfChild)) {
                    eVar.k(view);
                }
                p0Var.g(indexOfChild);
            }
            eVar.f149d = 0;
            eVar.f150e = null;
            a1Var.h(view);
        } catch (Throwable th) {
            eVar.f149d = 0;
            eVar.f150e = null;
            throw th;
        }
    }

    public final void f0(int i2) {
        if (t(i2) != null) {
            e eVar = this.f316a;
            p0 p0Var = eVar.f146a;
            int i3 = eVar.f149d;
            if (i3 == 1) {
                throw new IllegalStateException("Cannot call removeView(At) within removeView(At)");
            }
            if (i3 == 2) {
                throw new IllegalStateException("Cannot call removeView(At) within removeViewIfHidden");
            }
            try {
                int f2 = eVar.f(i2);
                View childAt = p0Var.f260a.getChildAt(f2);
                if (childAt != null) {
                    eVar.f149d = 1;
                    eVar.f150e = childAt;
                    if (eVar.f147b.f(f2)) {
                        eVar.k(childAt);
                    }
                    p0Var.g(f2);
                }
            } finally {
                eVar.f149d = 0;
                eVar.f150e = null;
            }
        }
    }

    public abstract void g(int i2, int i3, e1 e1Var, s sVar);

    /* JADX WARN: Code restructure failed: missing block: B:19:0x00ad, code lost:
    
        if (r10 == false) goto L33;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean g0(androidx.recyclerview.widget.RecyclerView r9, android.view.View r10, android.graphics.Rect r11, boolean r12, boolean r13) {
        /*
            r8 = this;
            int r0 = r8.z()
            int r1 = r8.B()
            int r2 = r8.f328m
            int r3 = r8.A()
            int r2 = r2 - r3
            int r3 = r8.f329n
            int r4 = r8.y()
            int r3 = r3 - r4
            int r4 = r10.getLeft()
            int r5 = r11.left
            int r4 = r4 + r5
            int r5 = r10.getScrollX()
            int r4 = r4 - r5
            int r5 = r10.getTop()
            int r6 = r11.top
            int r5 = r5 + r6
            int r10 = r10.getScrollY()
            int r5 = r5 - r10
            int r10 = r11.width()
            int r10 = r10 + r4
            int r11 = r11.height()
            int r11 = r11 + r5
            int r4 = r4 - r0
            r0 = 0
            int r6 = java.lang.Math.min(r0, r4)
            int r5 = r5 - r1
            int r1 = java.lang.Math.min(r0, r5)
            int r10 = r10 - r2
            int r2 = java.lang.Math.max(r0, r10)
            int r11 = r11 - r3
            int r11 = java.lang.Math.max(r0, r11)
            androidx.recyclerview.widget.RecyclerView r3 = r8.f317b
            java.lang.reflect.Field r7 = g.v.f448a
            int r3 = g.k.d(r3)
            r7 = 1
            if (r3 != r7) goto L60
            if (r2 == 0) goto L5b
            goto L68
        L5b:
            int r2 = java.lang.Math.max(r6, r10)
            goto L68
        L60:
            if (r6 == 0) goto L63
            goto L67
        L63:
            int r6 = java.lang.Math.min(r4, r2)
        L67:
            r2 = r6
        L68:
            if (r1 == 0) goto L6b
            goto L6f
        L6b:
            int r1 = java.lang.Math.min(r5, r11)
        L6f:
            if (r13 == 0) goto Laf
            android.view.View r10 = r9.getFocusedChild()
            if (r10 != 0) goto L78
            goto Lac
        L78:
            int r11 = r8.z()
            int r13 = r8.B()
            int r3 = r8.f328m
            int r4 = r8.A()
            int r3 = r3 - r4
            int r4 = r8.f329n
            int r5 = r8.y()
            int r4 = r4 - r5
            androidx.recyclerview.widget.RecyclerView r5 = r8.f317b
            android.graphics.Rect r5 = r5.f80j
            x(r10, r5)
            int r10 = r5.left
            int r10 = r10 - r2
            if (r10 >= r3) goto Lac
            int r10 = r5.right
            int r10 = r10 - r2
            if (r10 <= r11) goto Lac
            int r10 = r5.top
            int r10 = r10 - r1
            if (r10 >= r4) goto Lac
            int r10 = r5.bottom
            int r10 = r10 - r1
            if (r10 > r13) goto Laa
            goto Lac
        Laa:
            r10 = 1
            goto Lad
        Lac:
            r10 = 0
        Lad:
            if (r10 == 0) goto Lb4
        Laf:
            if (r2 != 0) goto Lb5
            if (r1 == 0) goto Lb4
            goto Lb5
        Lb4:
            return r0
        Lb5:
            if (r12 == 0) goto Lbb
            r9.scrollBy(r2, r1)
            goto Lbe
        Lbb:
            r9.c0(r2, r1, r0)
        Lbe:
            return r7
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.t0.g0(androidx.recyclerview.widget.RecyclerView, android.view.View, android.graphics.Rect, boolean, boolean):boolean");
    }

    public void h(int i2, s sVar) {
    }

    public final void h0() {
        RecyclerView recyclerView = this.f317b;
        if (recyclerView != null) {
            recyclerView.requestLayout();
        }
    }

    public abstract int i(e1 e1Var);

    public abstract int i0(int i2, a1 a1Var, e1 e1Var);

    public abstract int j(e1 e1Var);

    public abstract void j0(int i2);

    public abstract int k(e1 e1Var);

    public abstract int k0(int i2, a1 a1Var, e1 e1Var);

    public abstract int l(e1 e1Var);

    public final void l0(RecyclerView recyclerView) {
        m0(View.MeasureSpec.makeMeasureSpec(recyclerView.getWidth(), 1073741824), View.MeasureSpec.makeMeasureSpec(recyclerView.getHeight(), 1073741824));
    }

    public abstract int m(e1 e1Var);

    public final void m0(int i2, int i3) {
        this.f328m = View.MeasureSpec.getSize(i2);
        int mode = View.MeasureSpec.getMode(i2);
        this.f326k = mode;
        if (mode == 0 && !RecyclerView.C0) {
            this.f328m = 0;
        }
        this.f329n = View.MeasureSpec.getSize(i3);
        int mode2 = View.MeasureSpec.getMode(i3);
        this.f327l = mode2;
        if (mode2 != 0 || RecyclerView.C0) {
            return;
        }
        this.f329n = 0;
    }

    public abstract int n(e1 e1Var);

    public void n0(Rect rect, int i2, int i3) {
        int A = A() + z() + rect.width();
        int y2 = y() + B() + rect.height();
        RecyclerView recyclerView = this.f317b;
        Field field = g.v.f448a;
        this.f317b.setMeasuredDimension(f(i2, A, g.j.e(recyclerView)), f(i3, y2, g.j.d(this.f317b)));
    }

    public final void o(a1 a1Var) {
        int u2 = u();
        while (true) {
            u2--;
            if (u2 < 0) {
                return;
            }
            View t2 = t(u2);
            i1 I = RecyclerView.I(t2);
            if (I.shouldIgnore()) {
                if (RecyclerView.z0) {
                    Log.d("RecyclerView", "ignoring view " + I);
                }
            } else if (!I.isInvalid() || I.isRemoved() || this.f317b.f83m.hasStableIds()) {
                t(u2);
                this.f316a.c(u2);
                a1Var.j(t2);
                this.f317b.f75g.m(I);
            } else {
                f0(u2);
                a1Var.i(I);
            }
        }
    }

    public final void o0(int i2, int i3) {
        int u2 = u();
        if (u2 == 0) {
            this.f317b.n(i2, i3);
            return;
        }
        int i4 = Integer.MAX_VALUE;
        int i5 = Integer.MAX_VALUE;
        int i6 = Integer.MIN_VALUE;
        int i7 = Integer.MIN_VALUE;
        for (int i8 = 0; i8 < u2; i8++) {
            View t2 = t(i8);
            Rect rect = this.f317b.f80j;
            x(t2, rect);
            int i9 = rect.left;
            if (i9 < i4) {
                i4 = i9;
            }
            int i10 = rect.right;
            if (i10 > i6) {
                i6 = i10;
            }
            int i11 = rect.top;
            if (i11 < i5) {
                i5 = i11;
            }
            int i12 = rect.bottom;
            if (i12 > i7) {
                i7 = i12;
            }
        }
        this.f317b.f80j.set(i4, i5, i6, i7);
        n0(this.f317b.f80j, i2, i3);
    }

    public View p(int i2) {
        int u2 = u();
        for (int i3 = 0; i3 < u2; i3++) {
            View t2 = t(i3);
            i1 I = RecyclerView.I(t2);
            if (I != null && I.getLayoutPosition() == i2 && !I.shouldIgnore() && (this.f317b.f74f0.f159f || !I.isRemoved())) {
                return t2;
            }
        }
        return null;
    }

    public final void p0(RecyclerView recyclerView) {
        int height;
        if (recyclerView == null) {
            this.f317b = null;
            this.f316a = null;
            height = 0;
            this.f328m = 0;
        } else {
            this.f317b = recyclerView;
            this.f316a = recyclerView.f73f;
            this.f328m = recyclerView.getWidth();
            height = recyclerView.getHeight();
        }
        this.f329n = height;
        this.f326k = 1073741824;
        this.f327l = 1073741824;
    }

    public abstract u0 q();

    public final boolean q0(View view, int i2, int i3, u0 u0Var) {
        return (!view.isLayoutRequested() && this.f322g && H(view.getWidth(), i2, ((ViewGroup.MarginLayoutParams) u0Var).width) && H(view.getHeight(), i3, ((ViewGroup.MarginLayoutParams) u0Var).height)) ? false : true;
    }

    public u0 r(Context context, AttributeSet attributeSet) {
        return new u0(context, attributeSet);
    }

    public boolean r0() {
        return false;
    }

    public u0 s(ViewGroup.LayoutParams layoutParams) {
        return layoutParams instanceof u0 ? new u0((u0) layoutParams) : layoutParams instanceof ViewGroup.MarginLayoutParams ? new u0((ViewGroup.MarginLayoutParams) layoutParams) : new u0(layoutParams);
    }

    public final boolean s0(View view, int i2, int i3, u0 u0Var) {
        return (this.f322g && H(view.getMeasuredWidth(), i2, ((ViewGroup.MarginLayoutParams) u0Var).width) && H(view.getMeasuredHeight(), i3, ((ViewGroup.MarginLayoutParams) u0Var).height)) ? false : true;
    }

    public final View t(int i2) {
        e eVar = this.f316a;
        if (eVar != null) {
            return eVar.d(i2);
        }
        return null;
    }

    public abstract boolean t0();

    public final int u() {
        e eVar = this.f316a;
        if (eVar != null) {
            return eVar.e();
        }
        return 0;
    }

    public int w(a1 a1Var, e1 e1Var) {
        return -1;
    }

    public final int y() {
        RecyclerView recyclerView = this.f317b;
        if (recyclerView != null) {
            return recyclerView.getPaddingBottom();
        }
        return 0;
    }

    public final int z() {
        RecyclerView recyclerView = this.f317b;
        if (recyclerView != null) {
            return recyclerView.getPaddingLeft();
        }
        return 0;
    }
}
