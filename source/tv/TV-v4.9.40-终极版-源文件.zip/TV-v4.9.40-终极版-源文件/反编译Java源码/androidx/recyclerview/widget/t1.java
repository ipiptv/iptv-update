package androidx.recyclerview.widget;

import android.view.View;
import java.util.Arrays;
import java.util.List;

/* loaded from: classes.dex */
public final class t1 {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f330a;

    /* renamed from: b, reason: collision with root package name */
    public Object f331b;

    /* renamed from: c, reason: collision with root package name */
    public Object f332c;

    public t1(int i2) {
        this.f330a = i2;
        if (i2 != 1) {
            this.f331b = new a.h();
            this.f332c = new a.c();
        }
    }

    public final void a(i1 i1Var) {
        s1 s1Var = (s1) ((a.h) this.f331b).get(i1Var);
        if (s1Var == null) {
            s1Var = s1.a();
            ((a.h) this.f331b).put(i1Var, s1Var);
        }
        s1Var.f308a |= 1;
    }

    public final void b(long j2, i1 i1Var) {
        a.c cVar = (a.c) this.f332c;
        int d2 = b0.d.d(cVar.f7b, cVar.f9d, j2);
        if (d2 >= 0) {
            cVar.f8c[d2] = i1Var;
            return;
        }
        int i2 = ~d2;
        int i3 = cVar.f9d;
        if (i2 < i3) {
            Object[] objArr = cVar.f8c;
            if (objArr[i2] == a.c.f5e) {
                cVar.f7b[i2] = j2;
                objArr[i2] = i1Var;
                return;
            }
        }
        if (cVar.f6a && i3 >= cVar.f7b.length) {
            cVar.a();
            i2 = ~b0.d.d(cVar.f7b, cVar.f9d, j2);
        }
        int i4 = cVar.f9d;
        if (i4 >= cVar.f7b.length) {
            int i5 = (i4 + 1) * 8;
            int i6 = 4;
            while (true) {
                if (i6 >= 32) {
                    break;
                }
                int i7 = (1 << i6) - 12;
                if (i5 <= i7) {
                    i5 = i7;
                    break;
                }
                i6++;
            }
            int i8 = i5 / 8;
            long[] jArr = new long[i8];
            Object[] objArr2 = new Object[i8];
            long[] jArr2 = cVar.f7b;
            System.arraycopy(jArr2, 0, jArr, 0, jArr2.length);
            Object[] objArr3 = cVar.f8c;
            System.arraycopy(objArr3, 0, objArr2, 0, objArr3.length);
            cVar.f7b = jArr;
            cVar.f8c = objArr2;
        }
        int i9 = cVar.f9d - i2;
        if (i9 != 0) {
            long[] jArr3 = cVar.f7b;
            int i10 = i2 + 1;
            System.arraycopy(jArr3, i2, jArr3, i10, i9);
            Object[] objArr4 = cVar.f8c;
            System.arraycopy(objArr4, i2, objArr4, i10, cVar.f9d - i2);
        }
        cVar.f7b[i2] = j2;
        cVar.f8c[i2] = i1Var;
        cVar.f9d++;
    }

    public final void c(i1 i1Var, n0 n0Var) {
        s1 s1Var = (s1) ((a.h) this.f331b).get(i1Var);
        if (s1Var == null) {
            s1Var = s1.a();
            ((a.h) this.f331b).put(i1Var, s1Var);
        }
        s1Var.f310c = n0Var;
        s1Var.f308a |= 8;
    }

    public final void d(i1 i1Var, n0 n0Var) {
        s1 s1Var = (s1) ((a.h) this.f331b).get(i1Var);
        if (s1Var == null) {
            s1Var = s1.a();
            ((a.h) this.f331b).put(i1Var, s1Var);
        }
        s1Var.f309b = n0Var;
        s1Var.f308a |= 4;
    }

    public final void e() {
        switch (this.f330a) {
            case 0:
                ((a.h) this.f331b).clear();
                a.c cVar = (a.c) this.f332c;
                int i2 = cVar.f9d;
                Object[] objArr = cVar.f8c;
                for (int i3 = 0; i3 < i2; i3++) {
                    objArr[i3] = null;
                }
                cVar.f9d = 0;
                cVar.f6a = false;
                break;
            default:
                int[] iArr = (int[]) this.f331b;
                if (iArr != null) {
                    Arrays.fill(iArr, -1);
                }
                this.f332c = null;
                break;
        }
    }

    public final void f(int i2) {
        Object obj = this.f331b;
        if (((int[]) obj) == null) {
            int[] iArr = new int[Math.max(i2, 10) + 1];
            this.f331b = iArr;
            Arrays.fill(iArr, -1);
        } else if (i2 >= ((int[]) obj).length) {
            int[] iArr2 = (int[]) obj;
            int length = ((int[]) obj).length;
            while (length <= i2) {
                length *= 2;
            }
            int[] iArr3 = new int[length];
            this.f331b = iArr3;
            System.arraycopy(iArr2, 0, iArr3, 0, iArr2.length);
            Object obj2 = this.f331b;
            Arrays.fill((int[]) obj2, iArr2.length, ((int[]) obj2).length, -1);
        }
    }

    public final View g(int i2, int i3, int i4, int i5) {
        int B;
        View t2;
        r0 r0Var = (r0) ((r1) this.f331b);
        int i6 = r0Var.f297a;
        Object obj = r0Var.f298b;
        switch (i6) {
            case 0:
                B = ((t0) obj).z();
                break;
            default:
                B = ((t0) obj).B();
                break;
        }
        int c2 = ((r0) ((r1) this.f331b)).c();
        int i7 = i3 > i2 ? 1 : -1;
        View view = null;
        while (i2 != i3) {
            r0 r0Var2 = (r0) ((r1) this.f331b);
            int i8 = r0Var2.f297a;
            Object obj2 = r0Var2.f298b;
            switch (i8) {
                case 0:
                    t2 = ((t0) obj2).t(i2);
                    break;
                default:
                    t2 = ((t0) obj2).t(i2);
                    break;
            }
            int b2 = ((r0) ((r1) this.f331b)).b(t2);
            int a2 = ((r0) ((r1) this.f331b)).a(t2);
            Object obj3 = this.f332c;
            q1 q1Var = (q1) obj3;
            q1Var.f293b = B;
            q1Var.f294c = c2;
            q1Var.f295d = b2;
            q1Var.f296e = a2;
            if (i4 != 0) {
                ((q1) obj3).f292a = i4 | 0;
                if (((q1) obj3).a()) {
                    return t2;
                }
            }
            if (i5 != 0) {
                Object obj4 = this.f332c;
                ((q1) obj4).f292a = i5 | 0;
                if (((q1) obj4).a()) {
                    view = t2;
                }
            }
            i2 += i7;
        }
        return view;
    }

    /* JADX WARN: Removed duplicated region for block: B:31:0x0074  */
    /* JADX WARN: Removed duplicated region for block: B:33:0x0082  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final int h(int r6) {
        /*
            r5 = this;
            java.lang.Object r0 = r5.f331b
            int[] r0 = (int[]) r0
            r1 = -1
            if (r0 != 0) goto L8
            return r1
        L8:
            int r0 = r0.length
            if (r6 < r0) goto Lc
            return r1
        Lc:
            java.lang.Object r0 = r5.f332c
            r2 = r0
            java.util.List r2 = (java.util.List) r2
            if (r2 != 0) goto L14
            goto L71
        L14:
            java.util.List r0 = (java.util.List) r0
            r2 = 0
            if (r0 != 0) goto L1a
            goto L34
        L1a:
            int r0 = r0.size()
            int r0 = r0 + r1
        L1f:
            if (r0 < 0) goto L34
            java.lang.Object r3 = r5.f332c
            java.util.List r3 = (java.util.List) r3
            java.lang.Object r3 = r3.get(r0)
            androidx.recyclerview.widget.n1 r3 = (androidx.recyclerview.widget.n1) r3
            int r4 = r3.f237a
            if (r4 != r6) goto L31
            r2 = r3
            goto L34
        L31:
            int r0 = r0 + (-1)
            goto L1f
        L34:
            if (r2 == 0) goto L3d
            java.lang.Object r0 = r5.f332c
            java.util.List r0 = (java.util.List) r0
            r0.remove(r2)
        L3d:
            java.lang.Object r0 = r5.f332c
            java.util.List r0 = (java.util.List) r0
            int r0 = r0.size()
            r2 = 0
        L46:
            if (r2 >= r0) goto L5a
            java.lang.Object r3 = r5.f332c
            java.util.List r3 = (java.util.List) r3
            java.lang.Object r3 = r3.get(r2)
            androidx.recyclerview.widget.n1 r3 = (androidx.recyclerview.widget.n1) r3
            int r3 = r3.f237a
            if (r3 < r6) goto L57
            goto L5b
        L57:
            int r2 = r2 + 1
            goto L46
        L5a:
            r2 = -1
        L5b:
            if (r2 == r1) goto L71
            java.lang.Object r0 = r5.f332c
            java.util.List r0 = (java.util.List) r0
            java.lang.Object r0 = r0.get(r2)
            androidx.recyclerview.widget.n1 r0 = (androidx.recyclerview.widget.n1) r0
            java.lang.Object r3 = r5.f332c
            java.util.List r3 = (java.util.List) r3
            r3.remove(r2)
            int r0 = r0.f237a
            goto L72
        L71:
            r0 = -1
        L72:
            if (r0 != r1) goto L82
            java.lang.Object r0 = r5.f331b
            int[] r0 = (int[]) r0
            int r2 = r0.length
            java.util.Arrays.fill(r0, r6, r2, r1)
            java.lang.Object r6 = r5.f331b
            int[] r6 = (int[]) r6
            int r6 = r6.length
            return r6
        L82:
            int r0 = r0 + 1
            java.lang.Object r2 = r5.f331b
            int[] r2 = (int[]) r2
            int r2 = r2.length
            int r0 = java.lang.Math.min(r0, r2)
            java.lang.Object r2 = r5.f331b
            int[] r2 = (int[]) r2
            java.util.Arrays.fill(r2, r6, r0, r1)
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: androidx.recyclerview.widget.t1.h(int):int");
    }

    public final boolean i(View view) {
        int B;
        q1 q1Var = (q1) this.f332c;
        r0 r0Var = (r0) ((r1) this.f331b);
        int i2 = r0Var.f297a;
        Object obj = r0Var.f298b;
        switch (i2) {
            case 0:
                B = ((t0) obj).z();
                break;
            default:
                B = ((t0) obj).B();
                break;
        }
        int c2 = ((r0) ((r1) this.f331b)).c();
        int b2 = ((r0) ((r1) this.f331b)).b(view);
        int a2 = ((r0) ((r1) this.f331b)).a(view);
        q1Var.f293b = B;
        q1Var.f294c = c2;
        q1Var.f295d = b2;
        q1Var.f296e = a2;
        Object obj2 = this.f332c;
        ((q1) obj2).f292a = 24579 | 0;
        return ((q1) obj2).a();
    }

    public final void j(int i2, int i3) {
        int[] iArr = (int[]) this.f331b;
        if (iArr == null || i2 >= iArr.length) {
            return;
        }
        int i4 = i2 + i3;
        f(i4);
        int[] iArr2 = (int[]) this.f331b;
        System.arraycopy(iArr2, i2, iArr2, i4, (iArr2.length - i2) - i3);
        Arrays.fill((int[]) this.f331b, i2, i4, -1);
        List list = (List) this.f332c;
        if (list == null) {
            return;
        }
        for (int size = list.size() - 1; size >= 0; size--) {
            n1 n1Var = (n1) ((List) this.f332c).get(size);
            int i5 = n1Var.f237a;
            if (i5 >= i2) {
                n1Var.f237a = i5 + i3;
            }
        }
    }

    public final void k(int i2, int i3) {
        int[] iArr = (int[]) this.f331b;
        if (iArr == null || i2 >= iArr.length) {
            return;
        }
        int i4 = i2 + i3;
        f(i4);
        int[] iArr2 = (int[]) this.f331b;
        System.arraycopy(iArr2, i4, iArr2, i2, (iArr2.length - i2) - i3);
        int[] iArr3 = (int[]) this.f331b;
        Arrays.fill(iArr3, iArr3.length - i3, iArr3.length, -1);
        List list = (List) this.f332c;
        if (list == null) {
            return;
        }
        for (int size = list.size() - 1; size >= 0; size--) {
            n1 n1Var = (n1) ((List) this.f332c).get(size);
            int i5 = n1Var.f237a;
            if (i5 >= i2) {
                if (i5 < i4) {
                    ((List) this.f332c).remove(size);
                } else {
                    n1Var.f237a = i5 - i3;
                }
            }
        }
    }

    public final n0 l(i1 i1Var, int i2) {
        n0 n0Var;
        int e2 = ((a.h) this.f331b).e(i1Var);
        if (e2 < 0) {
            return null;
        }
        Object obj = this.f331b;
        s1 s1Var = (s1) ((a.h) obj).f27b[(e2 << 1) + 1];
        if (s1Var != null) {
            int i3 = s1Var.f308a;
            if ((i3 & i2) != 0) {
                int i4 = i3 & (~i2);
                s1Var.f308a = i4;
                if (i2 == 4) {
                    n0Var = s1Var.f309b;
                } else {
                    if (i2 != 8) {
                        throw new IllegalArgumentException("Must provide flag PRE or POST");
                    }
                    n0Var = s1Var.f310c;
                }
                if ((i4 & 12) == 0) {
                    ((a.h) obj).h(e2);
                    s1Var.f308a = 0;
                    s1Var.f309b = null;
                    s1Var.f310c = null;
                    s1.f307d.b(s1Var);
                }
                return n0Var;
            }
        }
        return null;
    }

    public final void m(i1 i1Var) {
        s1 s1Var = (s1) ((a.h) this.f331b).get(i1Var);
        if (s1Var == null) {
            return;
        }
        s1Var.f308a &= -2;
    }

    public final void n(i1 i1Var) {
        a.c cVar = (a.c) this.f332c;
        if (cVar.f6a) {
            cVar.a();
        }
        int i2 = cVar.f9d - 1;
        while (true) {
            if (i2 < 0) {
                break;
            }
            a.c cVar2 = (a.c) this.f332c;
            if (cVar2.f6a) {
                cVar2.a();
            }
            if (i1Var == cVar2.f8c[i2]) {
                a.c cVar3 = (a.c) this.f332c;
                Object[] objArr = cVar3.f8c;
                Object obj = objArr[i2];
                Object obj2 = a.c.f5e;
                if (obj != obj2) {
                    objArr[i2] = obj2;
                    cVar3.f6a = true;
                }
            } else {
                i2--;
            }
        }
        s1 s1Var = (s1) ((a.h) this.f331b).remove(i1Var);
        if (s1Var != null) {
            s1Var.f308a = 0;
            s1Var.f309b = null;
            s1Var.f310c = null;
            s1.f307d.b(s1Var);
        }
    }

    public t1(r0 r0Var) {
        this.f330a = 2;
        this.f331b = r0Var;
        this.f332c = new q1();
    }
}
