package androidx.recyclerview.widget;

import java.util.ArrayList;
import java.util.Collections;
import java.util.concurrent.TimeUnit;

/* loaded from: classes.dex */
public final class u implements Runnable {

    /* renamed from: e, reason: collision with root package name */
    public static final ThreadLocal f333e = new ThreadLocal();

    /* renamed from: f, reason: collision with root package name */
    public static final r f334f = new r();

    /* renamed from: b, reason: collision with root package name */
    public long f336b;

    /* renamed from: c, reason: collision with root package name */
    public long f337c;

    /* renamed from: a, reason: collision with root package name */
    public final ArrayList f335a = new ArrayList();

    /* renamed from: d, reason: collision with root package name */
    public final ArrayList f338d = new ArrayList();

    public static i1 c(RecyclerView recyclerView, int i2, long j2) {
        boolean z2;
        int h2 = recyclerView.f73f.h();
        int i3 = 0;
        while (true) {
            if (i3 >= h2) {
                z2 = false;
                break;
            }
            i1 I = RecyclerView.I(recyclerView.f73f.g(i3));
            if (I.mPosition == i2 && !I.isInvalid()) {
                z2 = true;
                break;
            }
            i3++;
        }
        if (z2) {
            return null;
        }
        a1 a1Var = recyclerView.f67c;
        try {
            recyclerView.N();
            i1 k2 = a1Var.k(i2, j2);
            if (k2 != null) {
                if (!k2.isBound() || k2.isInvalid()) {
                    a1Var.a(k2, false);
                } else {
                    a1Var.h(k2.itemView);
                }
            }
            return k2;
        } finally {
            recyclerView.O(false);
        }
    }

    public final void a(RecyclerView recyclerView, int i2, int i3) {
        if (recyclerView.isAttachedToWindow()) {
            if (RecyclerView.y0 && !this.f335a.contains(recyclerView)) {
                throw new IllegalStateException("attempting to post unregistered view!");
            }
            if (this.f336b == 0) {
                this.f336b = recyclerView.getNanoTime();
                recyclerView.post(this);
            }
        }
        s sVar = recyclerView.f72e0;
        sVar.f299a = i2;
        sVar.f300b = i3;
    }

    public final void b(long j2) {
        t tVar;
        RecyclerView recyclerView;
        RecyclerView recyclerView2;
        t tVar2;
        ArrayList arrayList = this.f335a;
        int size = arrayList.size();
        int i2 = 0;
        for (int i3 = 0; i3 < size; i3++) {
            RecyclerView recyclerView3 = (RecyclerView) arrayList.get(i3);
            if (recyclerView3.getWindowVisibility() == 0) {
                s sVar = recyclerView3.f72e0;
                sVar.b(recyclerView3, false);
                i2 += sVar.f302d;
            }
        }
        ArrayList arrayList2 = this.f338d;
        arrayList2.ensureCapacity(i2);
        int i4 = 0;
        for (int i5 = 0; i5 < size; i5++) {
            RecyclerView recyclerView4 = (RecyclerView) arrayList.get(i5);
            if (recyclerView4.getWindowVisibility() == 0) {
                s sVar2 = recyclerView4.f72e0;
                int abs = Math.abs(sVar2.f300b) + Math.abs(sVar2.f299a);
                for (int i6 = 0; i6 < sVar2.f302d * 2; i6 += 2) {
                    if (i4 >= arrayList2.size()) {
                        tVar2 = new t();
                        arrayList2.add(tVar2);
                    } else {
                        tVar2 = (t) arrayList2.get(i4);
                    }
                    int[] iArr = sVar2.f301c;
                    int i7 = iArr[i6 + 1];
                    tVar2.f311a = i7 <= abs;
                    tVar2.f312b = abs;
                    tVar2.f313c = i7;
                    tVar2.f314d = recyclerView4;
                    tVar2.f315e = iArr[i6];
                    i4++;
                }
            }
        }
        Collections.sort(arrayList2, f334f);
        for (int i8 = 0; i8 < arrayList2.size() && (recyclerView = (tVar = (t) arrayList2.get(i8)).f314d) != null; i8++) {
            i1 c2 = c(recyclerView, tVar.f315e, tVar.f311a ? Long.MAX_VALUE : j2);
            if (c2 != null && c2.mNestedRecyclerView != null && c2.isBound() && !c2.isInvalid() && (recyclerView2 = c2.mNestedRecyclerView.get()) != null) {
                if (recyclerView2.C && recyclerView2.f73f.h() != 0) {
                    o0 o0Var = recyclerView2.L;
                    if (o0Var != null) {
                        o0Var.e();
                    }
                    t0 t0Var = recyclerView2.f84n;
                    a1 a1Var = recyclerView2.f67c;
                    if (t0Var != null) {
                        t0Var.c0(a1Var);
                        recyclerView2.f84n.d0(a1Var);
                    }
                    a1Var.f123a.clear();
                    a1Var.f();
                }
                s sVar3 = recyclerView2.f72e0;
                sVar3.b(recyclerView2, true);
                if (sVar3.f302d != 0) {
                    try {
                        int i9 = e.b.f393a;
                        e.a.a("RV Nested Prefetch");
                        e1 e1Var = recyclerView2.f74f0;
                        i0 i0Var = recyclerView2.f83m;
                        e1Var.f156c = 1;
                        e1Var.f157d = i0Var.getItemCount();
                        e1Var.f159f = false;
                        e1Var.f160g = false;
                        e1Var.f161h = false;
                        for (int i10 = 0; i10 < sVar3.f302d * 2; i10 += 2) {
                            c(recyclerView2, sVar3.f301c[i10], j2);
                        }
                        e.a.b();
                        tVar.f311a = false;
                        tVar.f312b = 0;
                        tVar.f313c = 0;
                        tVar.f314d = null;
                        tVar.f315e = 0;
                    } catch (Throwable th) {
                        int i11 = e.b.f393a;
                        e.a.b();
                        throw th;
                    }
                }
            }
            tVar.f311a = false;
            tVar.f312b = 0;
            tVar.f313c = 0;
            tVar.f314d = null;
            tVar.f315e = 0;
        }
    }

    @Override // java.lang.Runnable
    public final void run() {
        try {
            int i2 = e.b.f393a;
            e.a.a("RV Prefetch");
            ArrayList arrayList = this.f335a;
            if (arrayList.isEmpty()) {
                this.f336b = 0L;
                e.a.b();
                return;
            }
            int size = arrayList.size();
            long j2 = 0;
            for (int i3 = 0; i3 < size; i3++) {
                RecyclerView recyclerView = (RecyclerView) arrayList.get(i3);
                if (recyclerView.getWindowVisibility() == 0) {
                    j2 = Math.max(recyclerView.getDrawingTime(), j2);
                }
            }
            if (j2 == 0) {
                this.f336b = 0L;
                e.a.b();
            } else {
                b(TimeUnit.MILLISECONDS.toNanos(j2) + this.f337c);
                this.f336b = 0L;
                e.a.b();
            }
        } catch (Throwable th) {
            this.f336b = 0L;
            int i4 = e.b.f393a;
            e.a.b();
            throw th;
        }
    }
}
