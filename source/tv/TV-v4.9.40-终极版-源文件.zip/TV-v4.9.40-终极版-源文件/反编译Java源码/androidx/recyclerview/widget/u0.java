package androidx.recyclerview.widget;

import android.content.Context;
import android.graphics.Rect;
import android.util.AttributeSet;
import android.view.ViewGroup;

/* loaded from: classes.dex */
public class u0 extends ViewGroup.MarginLayoutParams {

    /* renamed from: a, reason: collision with root package name */
    public i1 f339a;

    /* renamed from: b, reason: collision with root package name */
    public final Rect f340b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f341c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f342d;

    public u0(int i2, int i3) {
        super(i2, i3);
        this.f340b = new Rect();
        this.f341c = true;
        this.f342d = false;
    }

    public final int a() {
        return this.f339a.getLayoutPosition();
    }

    public final boolean b() {
        return this.f339a.isUpdated();
    }

    public final boolean c() {
        return this.f339a.isRemoved();
    }

    public u0(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f340b = new Rect();
        this.f341c = true;
        this.f342d = false;
    }

    public u0(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
        this.f340b = new Rect();
        this.f341c = true;
        this.f342d = false;
    }

    public u0(ViewGroup.MarginLayoutParams marginLayoutParams) {
        super(marginLayoutParams);
        this.f340b = new Rect();
        this.f341c = true;
        this.f342d = false;
    }

    public u0(u0 u0Var) {
        super((ViewGroup.LayoutParams) u0Var);
        this.f340b = new Rect();
        this.f341c = true;
        this.f342d = false;
    }
}
