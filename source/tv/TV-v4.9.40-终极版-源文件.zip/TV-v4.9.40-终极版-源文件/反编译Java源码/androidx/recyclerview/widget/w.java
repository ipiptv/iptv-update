package androidx.recyclerview.widget;

import android.content.Context;
import android.util.AttributeSet;
import android.view.ViewGroup;

/* loaded from: classes.dex */
public final class w extends u0 {

    /* renamed from: e, reason: collision with root package name */
    public int f345e;

    /* renamed from: f, reason: collision with root package name */
    public int f346f;

    public w(int i2, int i3) {
        super(i2, i3);
        this.f345e = -1;
        this.f346f = 0;
    }

    public w(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        this.f345e = -1;
        this.f346f = 0;
    }

    public w(ViewGroup.LayoutParams layoutParams) {
        super(layoutParams);
        this.f345e = -1;
        this.f346f = 0;
    }

    public w(ViewGroup.MarginLayoutParams marginLayoutParams) {
        super(marginLayoutParams);
        this.f345e = -1;
        this.f346f = 0;
    }
}
