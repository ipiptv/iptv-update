package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public final class x {

    /* renamed from: b, reason: collision with root package name */
    public int f348b;

    /* renamed from: c, reason: collision with root package name */
    public int f349c;

    /* renamed from: d, reason: collision with root package name */
    public int f350d;

    /* renamed from: e, reason: collision with root package name */
    public int f351e;

    /* renamed from: h, reason: collision with root package name */
    public boolean f354h;

    /* renamed from: i, reason: collision with root package name */
    public boolean f355i;

    /* renamed from: a, reason: collision with root package name */
    public boolean f347a = true;

    /* renamed from: f, reason: collision with root package name */
    public int f352f = 0;

    /* renamed from: g, reason: collision with root package name */
    public int f353g = 0;

    public final String toString() {
        return "LayoutState{mAvailable=" + this.f348b + ", mCurrentPosition=" + this.f349c + ", mItemDirection=" + this.f350d + ", mLayoutDirection=" + this.f351e + ", mStartLine=" + this.f352f + ", mEndLine=" + this.f353g + '}';
    }
}
