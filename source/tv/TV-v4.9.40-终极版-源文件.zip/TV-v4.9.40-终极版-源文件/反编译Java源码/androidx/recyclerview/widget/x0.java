package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public abstract class x0 {
    public abstract void a(RecyclerView recyclerView);
}
