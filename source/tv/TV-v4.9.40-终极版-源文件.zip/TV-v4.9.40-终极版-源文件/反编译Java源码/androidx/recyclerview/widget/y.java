package androidx.recyclerview.widget;

import android.view.View;

/* loaded from: classes.dex */
public final class y {

    /* renamed from: a, reason: collision with root package name */
    public d0 f356a;

    /* renamed from: b, reason: collision with root package name */
    public int f357b;

    /* renamed from: c, reason: collision with root package name */
    public int f358c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f359d;

    /* renamed from: e, reason: collision with root package name */
    public boolean f360e;

    public y() {
        c();
    }

    public final void a(View view, int i2) {
        if (this.f359d) {
            int b2 = this.f356a.b(view);
            d0 d0Var = this.f356a;
            this.f358c = (Integer.MIN_VALUE == d0Var.f152b ? 0 : d0Var.i() - d0Var.f152b) + b2;
        } else {
            this.f358c = this.f356a.d(view);
        }
        this.f357b = i2;
    }

    public final void b(View view, int i2) {
        int min;
        d0 d0Var = this.f356a;
        int i3 = Integer.MIN_VALUE == d0Var.f152b ? 0 : d0Var.i() - d0Var.f152b;
        if (i3 >= 0) {
            a(view, i2);
            return;
        }
        this.f357b = i2;
        if (this.f359d) {
            int f2 = (this.f356a.f() - i3) - this.f356a.b(view);
            this.f358c = this.f356a.f() - f2;
            if (f2 <= 0) {
                return;
            }
            int c2 = this.f358c - this.f356a.c(view);
            int h2 = this.f356a.h();
            int min2 = c2 - (Math.min(this.f356a.d(view) - h2, 0) + h2);
            if (min2 >= 0) {
                return;
            } else {
                min = Math.min(f2, -min2) + this.f358c;
            }
        } else {
            int d2 = this.f356a.d(view);
            int h3 = d2 - this.f356a.h();
            this.f358c = d2;
            if (h3 <= 0) {
                return;
            }
            int f3 = (this.f356a.f() - Math.min(0, (this.f356a.f() - i3) - this.f356a.b(view))) - (this.f356a.c(view) + d2);
            if (f3 >= 0) {
                return;
            } else {
                min = this.f358c - Math.min(h3, -f3);
            }
        }
        this.f358c = min;
    }

    public final void c() {
        this.f357b = -1;
        this.f358c = Integer.MIN_VALUE;
        this.f359d = false;
        this.f360e = false;
    }

    public final String toString() {
        return "AnchorInfo{mPosition=" + this.f357b + ", mCoordinate=" + this.f358c + ", mLayoutFromEnd=" + this.f359d + ", mValid=" + this.f360e + '}';
    }
}
