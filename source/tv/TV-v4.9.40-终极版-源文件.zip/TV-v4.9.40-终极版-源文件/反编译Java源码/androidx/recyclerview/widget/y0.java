package androidx.recyclerview.widget;

import java.util.ArrayList;

/* loaded from: classes.dex */
public final class y0 {

    /* renamed from: a, reason: collision with root package name */
    public final ArrayList f361a = new ArrayList();

    /* renamed from: b, reason: collision with root package name */
    public final int f362b = 5;

    /* renamed from: c, reason: collision with root package name */
    public long f363c = 0;

    /* renamed from: d, reason: collision with root package name */
    public long f364d = 0;
}
