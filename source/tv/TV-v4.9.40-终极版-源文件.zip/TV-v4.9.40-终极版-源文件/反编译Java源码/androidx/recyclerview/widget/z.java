package androidx.recyclerview.widget;

/* loaded from: classes.dex */
public final class z {

    /* renamed from: a, reason: collision with root package name */
    public int f365a;

    /* renamed from: b, reason: collision with root package name */
    public boolean f366b;

    /* renamed from: c, reason: collision with root package name */
    public boolean f367c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f368d;
}
