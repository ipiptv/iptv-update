package androidx.recyclerview.widget;

import android.util.SparseArray;
import java.util.Collections;
import java.util.IdentityHashMap;
import java.util.Set;

/* loaded from: classes.dex */
public final class z0 {

    /* renamed from: a, reason: collision with root package name */
    public final SparseArray f369a = new SparseArray();

    /* renamed from: b, reason: collision with root package name */
    public int f370b = 0;

    /* renamed from: c, reason: collision with root package name */
    public final Set f371c = Collections.newSetFromMap(new IdentityHashMap());

    public final y0 a(int i2) {
        SparseArray sparseArray = this.f369a;
        y0 y0Var = (y0) sparseArray.get(i2);
        if (y0Var != null) {
            return y0Var;
        }
        y0 y0Var2 = new y0();
        sparseArray.put(i2, y0Var2);
        return y0Var2;
    }
}
