package androidx.versionedparcelable;

import m.c;

/* loaded from: classes.dex */
public abstract class CustomVersionedParcelable implements c {
}
