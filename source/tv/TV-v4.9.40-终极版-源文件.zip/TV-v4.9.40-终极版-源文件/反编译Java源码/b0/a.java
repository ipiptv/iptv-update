package b0;

import java.io.File;

/* loaded from: classes.dex */
public final class a extends b {
    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a(File file, File file2, String str, int i2) {
        super(file, file2, str);
        if (i2 != 1) {
        } else {
            super(file, file2, str);
        }
    }
}
