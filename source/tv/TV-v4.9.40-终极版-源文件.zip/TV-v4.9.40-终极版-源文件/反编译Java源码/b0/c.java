package b0;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public abstract class c extends d {
    public static final List L(Object[] objArr) {
        d.k(objArr, "<this>");
        List asList = Arrays.asList(objArr);
        d.j(asList, "asList(...)");
        return asList;
    }

    public static final int M(Iterable iterable) {
        d.k(iterable, "<this>");
        if (iterable instanceof Collection) {
            return ((Collection) iterable).size();
        }
        return 10;
    }

    public static void N(File file, File file2) {
        if (!file.exists()) {
            throw new a(file, null, "The source file doesn't exist.", 1);
        }
        if (file2.exists() && !file2.delete()) {
            throw new a(file, file2, "Tried to overwrite the destination, but failed to delete it.", 0);
        }
        if (file.isDirectory()) {
            if (!file2.mkdirs()) {
                throw new b(file, file2, "Failed to create target directory.");
            }
            return;
        }
        File parentFile = file2.getParentFile();
        if (parentFile != null) {
            parentFile.mkdirs();
        }
        FileInputStream fileInputStream = new FileInputStream(file);
        try {
            FileOutputStream fileOutputStream = new FileOutputStream(file2);
            try {
                d.q(fileInputStream, fileOutputStream, 8192);
                d.l(fileOutputStream, null);
                d.l(fileInputStream, null);
            } finally {
            }
        } catch (Throwable th) {
            try {
                throw th;
            } catch (Throwable th2) {
                d.l(fileInputStream, th);
                throw th2;
            }
        }
    }

    public static final char O(char[] cArr) {
        d.k(cArr, "<this>");
        int length = cArr.length;
        if (length == 0) {
            throw new NoSuchElementException("Array is empty.");
        }
        if (length == 1) {
            return cArr[0];
        }
        throw new IllegalArgumentException("Array has more than one element.");
    }
}
