package b0;

import android.os.Build;
import android.view.View;
import android.widget.EdgeEffect;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.e0;
import androidx.recyclerview.widget.e1;
import androidx.recyclerview.widget.t0;
import g.a0;
import java.io.Closeable;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringWriter;
import java.lang.reflect.Array;
import java.lang.reflect.Method;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import t.f;
import tv.live.R;
import u.k;

/* loaded from: classes.dex */
public abstract class d {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f375a = new int[0];

    /* renamed from: b, reason: collision with root package name */
    public static final Object[] f376b = new Object[0];

    /* renamed from: c, reason: collision with root package name */
    public static final Object[] f377c = new Object[0];

    /* renamed from: d, reason: collision with root package name */
    public static final int[] f378d = {-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, 36, -1, -1, -1, 37, 38, -1, -1, -1, -1, 39, 40, -1, 41, 42, 43, 0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 44, -1, -1, -1, -1, -1, -1, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, -1, -1, -1, -1, -1};

    /* renamed from: e, reason: collision with root package name */
    public static final int[][] f379e = {new int[]{1, 1, 1, 1, 1, 1, 1}, new int[]{1, 0, 0, 0, 0, 0, 1}, new int[]{1, 0, 1, 1, 1, 0, 1}, new int[]{1, 0, 1, 1, 1, 0, 1}, new int[]{1, 0, 1, 1, 1, 0, 1}, new int[]{1, 0, 0, 0, 0, 0, 1}, new int[]{1, 1, 1, 1, 1, 1, 1}};

    /* renamed from: f, reason: collision with root package name */
    public static final int[][] f380f = {new int[]{1, 1, 1, 1, 1}, new int[]{1, 0, 0, 0, 1}, new int[]{1, 0, 1, 0, 1}, new int[]{1, 0, 0, 0, 1}, new int[]{1, 1, 1, 1, 1}};

    /* renamed from: g, reason: collision with root package name */
    public static final int[][] f381g = {new int[]{-1, -1, -1, -1, -1, -1, -1}, new int[]{6, 18, -1, -1, -1, -1, -1}, new int[]{6, 22, -1, -1, -1, -1, -1}, new int[]{6, 26, -1, -1, -1, -1, -1}, new int[]{6, 30, -1, -1, -1, -1, -1}, new int[]{6, 34, -1, -1, -1, -1, -1}, new int[]{6, 22, 38, -1, -1, -1, -1}, new int[]{6, 24, 42, -1, -1, -1, -1}, new int[]{6, 26, 46, -1, -1, -1, -1}, new int[]{6, 28, 50, -1, -1, -1, -1}, new int[]{6, 30, 54, -1, -1, -1, -1}, new int[]{6, 32, 58, -1, -1, -1, -1}, new int[]{6, 34, 62, -1, -1, -1, -1}, new int[]{6, 26, 46, 66, -1, -1, -1}, new int[]{6, 26, 48, 70, -1, -1, -1}, new int[]{6, 26, 50, 74, -1, -1, -1}, new int[]{6, 30, 54, 78, -1, -1, -1}, new int[]{6, 30, 56, 82, -1, -1, -1}, new int[]{6, 30, 58, 86, -1, -1, -1}, new int[]{6, 34, 62, 90, -1, -1, -1}, new int[]{6, 28, 50, 72, 94, -1, -1}, new int[]{6, 26, 50, 74, 98, -1, -1}, new int[]{6, 30, 54, 78, 102, -1, -1}, new int[]{6, 28, 54, 80, 106, -1, -1}, new int[]{6, 32, 58, 84, 110, -1, -1}, new int[]{6, 30, 58, 86, 114, -1, -1}, new int[]{6, 34, 62, 90, 118, -1, -1}, new int[]{6, 26, 50, 74, 98, 122, -1}, new int[]{6, 30, 54, 78, 102, 126, -1}, new int[]{6, 26, 52, 78, 104, 130, -1}, new int[]{6, 30, 56, 82, 108, 134, -1}, new int[]{6, 34, 60, 86, 112, 138, -1}, new int[]{6, 30, 58, 86, 114, 142, -1}, new int[]{6, 34, 62, 90, 118, 146, -1}, new int[]{6, 30, 54, 78, 102, 126, 150}, new int[]{6, 24, 50, 76, 102, 128, 154}, new int[]{6, 28, 54, 80, 106, 132, 158}, new int[]{6, 32, 58, 84, 110, 136, 162}, new int[]{6, 26, 54, 82, 110, 138, 166}, new int[]{6, 30, 58, 86, 114, 142, 170}};

    /* renamed from: h, reason: collision with root package name */
    public static final int[][] f382h = {new int[]{8, 0}, new int[]{8, 1}, new int[]{8, 2}, new int[]{8, 3}, new int[]{8, 4}, new int[]{8, 5}, new int[]{8, 7}, new int[]{8, 8}, new int[]{7, 8}, new int[]{5, 8}, new int[]{4, 8}, new int[]{3, 8}, new int[]{2, 8}, new int[]{1, 8}, new int[]{0, 8}};

    /* renamed from: i, reason: collision with root package name */
    public static final x.c f383i = new x.c(null, null, null);

    /* renamed from: j, reason: collision with root package name */
    public static x.c f384j;

    public static float A(EdgeEffect edgeEffect, float f2, float f3) {
        if (Build.VERSION.SDK_INT >= 31) {
            return i.b.c(edgeEffect, f2, f3);
        }
        i.a.a(edgeEffect, f2, f3);
        return f2;
    }

    public static final String B(Reader reader) {
        StringWriter stringWriter = new StringWriter();
        char[] cArr = new char[8192];
        while (true) {
            int read = reader.read(cArr);
            if (read < 0) {
                String stringWriter2 = stringWriter.toString();
                j(stringWriter2, "toString(...)");
                return stringWriter2;
            }
            stringWriter.write(cArr, 0, read);
        }
    }

    public static String C(File file) {
        Charset charset = h0.a.f474a;
        k(charset, "charset");
        InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(file), charset);
        try {
            String B = B(inputStreamReader);
            l(inputStreamReader, null);
            return B;
        } finally {
        }
    }

    public static void D(RuntimeException runtimeException, String str) {
        StackTraceElement[] stackTrace = runtimeException.getStackTrace();
        int length = stackTrace.length;
        int i2 = -1;
        for (int i3 = 0; i3 < length; i3++) {
            if (str.equals(stackTrace[i3].getClassName())) {
                i2 = i3;
            }
        }
        runtimeException.setStackTrace((StackTraceElement[]) Arrays.copyOfRange(stackTrace, i2 + 1, length));
    }

    public static void E(Object obj, String str) {
        ClassCastException classCastException = new ClassCastException((obj == null ? "null" : obj.getClass().getName()) + " cannot be cast to " + str);
        D(classCastException, d.class.getName());
        throw classCastException;
    }

    public static final void F(Object obj) {
        if (obj instanceof t.c) {
            throw ((t.c) obj).f549a;
        }
    }

    public static void G(String str) {
        f fVar = new f("lateinit property " + str + " has not been initialized");
        D(fVar, d.class.getName());
        throw fVar;
    }

    public static final Object[] H(Collection collection) {
        k(collection, "collection");
        int size = collection.size();
        Object[] objArr = f377c;
        if (size == 0) {
            return objArr;
        }
        Iterator it = collection.iterator();
        if (!it.hasNext()) {
            return objArr;
        }
        Object[] objArr2 = new Object[size];
        int i2 = 0;
        while (true) {
            int i3 = i2 + 1;
            objArr2[i2] = it.next();
            if (i3 >= objArr2.length) {
                if (!it.hasNext()) {
                    return objArr2;
                }
                int i4 = ((i3 * 3) + 1) >>> 1;
                if (i4 <= i3) {
                    i4 = 2147483645;
                    if (i3 >= 2147483645) {
                        throw new OutOfMemoryError();
                    }
                }
                objArr2 = Arrays.copyOf(objArr2, i4);
                j(objArr2, "copyOf(...)");
            } else if (!it.hasNext()) {
                Object[] copyOf = Arrays.copyOf(objArr2, i3);
                j(copyOf, "copyOf(...)");
                return copyOf;
            }
            i2 = i3;
        }
    }

    public static final Object[] I(Collection collection, Object[] objArr) {
        Object[] objArr2;
        k(collection, "collection");
        objArr.getClass();
        int size = collection.size();
        int i2 = 0;
        if (size == 0) {
            if (objArr.length <= 0) {
                return objArr;
            }
            objArr[0] = null;
            return objArr;
        }
        Iterator it = collection.iterator();
        if (!it.hasNext()) {
            if (objArr.length <= 0) {
                return objArr;
            }
            objArr[0] = null;
            return objArr;
        }
        if (size <= objArr.length) {
            objArr2 = objArr;
        } else {
            Object newInstance = Array.newInstance(objArr.getClass().getComponentType(), size);
            i(newInstance, "null cannot be cast to non-null type kotlin.Array<kotlin.Any?>");
            objArr2 = (Object[]) newInstance;
        }
        while (true) {
            int i3 = i2 + 1;
            objArr2[i2] = it.next();
            if (i3 >= objArr2.length) {
                if (!it.hasNext()) {
                    return objArr2;
                }
                int i4 = ((i3 * 3) + 1) >>> 1;
                if (i4 <= i3) {
                    i4 = 2147483645;
                    if (i3 >= 2147483645) {
                        throw new OutOfMemoryError();
                    }
                }
                objArr2 = Arrays.copyOf(objArr2, i4);
                j(objArr2, "copyOf(...)");
            } else if (!it.hasNext()) {
                if (objArr2 == objArr) {
                    objArr[i3] = null;
                    return objArr;
                }
                Object[] copyOf = Arrays.copyOf(objArr2, i3);
                j(copyOf, "copyOf(...)");
                return copyOf;
            }
            i2 = i3;
        }
    }

    public static final void J(File file, byte[] bArr) {
        k(file, "<this>");
        FileOutputStream fileOutputStream = new FileOutputStream(file);
        try {
            fileOutputStream.write(bArr);
            l(fileOutputStream, null);
        } finally {
        }
    }

    public static void K(File file, String str) {
        Charset charset = h0.a.f474a;
        k(file, "<this>");
        k(str, "text");
        k(charset, "charset");
        byte[] bytes = str.getBytes(charset);
        j(bytes, "getBytes(...)");
        J(file, bytes);
    }

    public static int a(s.b bVar, boolean z2) {
        int i2 = bVar.f546c;
        int i3 = bVar.f545b;
        int i4 = z2 ? i2 : i3;
        if (z2) {
            i2 = i3;
        }
        int i5 = 0;
        for (int i6 = 0; i6 < i4; i6++) {
            byte b2 = -1;
            int i7 = 0;
            for (int i8 = 0; i8 < i2; i8++) {
                byte[][] bArr = bVar.f544a;
                byte b3 = z2 ? bArr[i6][i8] : bArr[i8][i6];
                if (b3 == b2) {
                    i7++;
                } else {
                    if (i7 >= 5) {
                        i5 += (i7 - 5) + 3;
                    }
                    b2 = b3;
                    i7 = 1;
                }
            }
            if (i7 >= 5) {
                i5 = (i7 - 5) + 3 + i5;
            }
        }
        return i5;
    }

    public static boolean b(Object obj, Object obj2) {
        return obj == null ? obj2 == null : obj.equals(obj2);
    }

    public static void c(c0.c cVar) {
        if (cVar != null) {
            if ((cVar instanceof d0.b ? ((d0.b) cVar).getArity() : cVar instanceof c0.a ? 0 : cVar instanceof c0.b ? 1 : 2) == 2) {
                return;
            }
            E(cVar, "kotlin.jvm.functions.Function2");
            throw null;
        }
    }

    public static int d(long[] jArr, int i2, long j2) {
        int i3 = i2 - 1;
        int i4 = 0;
        while (i4 <= i3) {
            int i5 = (i4 + i3) >>> 1;
            long j3 = jArr[i5];
            if (j3 < j2) {
                i4 = i5 + 1;
            } else {
                if (j3 <= j2) {
                    return i5;
                }
                i3 = i5 - 1;
            }
        }
        return ~i4;
    }

    /* JADX WARN: Removed duplicated region for block: B:101:0x0222  */
    /* JADX WARN: Removed duplicated region for block: B:103:0x0229  */
    /* JADX WARN: Removed duplicated region for block: B:107:0x0225  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static void e(o.a r23, int r24, r.b r25, int r26, s.b r27) {
        /*
            Method dump skipped, instructions count: 702
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b0.d.e(o.a, int, r.b, int, s.b):void");
    }

    public static int f(int i2, int i3) {
        if (i3 == 0) {
            throw new IllegalArgumentException("0 polynomial");
        }
        int numberOfLeadingZeros = 32 - Integer.numberOfLeadingZeros(i3);
        int i4 = i2 << (numberOfLeadingZeros - 1);
        while (32 - Integer.numberOfLeadingZeros(i4) >= numberOfLeadingZeros) {
            i4 ^= i3 << ((32 - Integer.numberOfLeadingZeros(i4)) - numberOfLeadingZeros);
        }
        return i4;
    }

    public static final void g(View view) {
        k(view, "<this>");
        a0 a0Var = new a0(view, null);
        g0.b bVar = new g0.b();
        bVar.f464d = a0Var.d(bVar, bVar);
        while (bVar.hasNext()) {
            View view2 = (View) bVar.next();
            j.a aVar = (j.a) view2.getTag(R.id.pooling_container_listener_holder_tag);
            if (aVar == null) {
                aVar = new j.a();
                view2.setTag(R.id.pooling_container_listener_holder_tag, aVar);
            }
            ArrayList arrayList = aVar.f490a;
            int x2 = x(arrayList);
            if (-1 < x2) {
                androidx.recyclerview.widget.c.c(arrayList.get(x2));
                throw null;
            }
        }
    }

    public static void h(Object obj) {
        if (obj != null) {
            return;
        }
        NullPointerException nullPointerException = new NullPointerException();
        D(nullPointerException, d.class.getName());
        throw nullPointerException;
    }

    public static void i(Object obj, String str) {
        if (obj != null) {
            return;
        }
        NullPointerException nullPointerException = new NullPointerException(str);
        D(nullPointerException, d.class.getName());
        throw nullPointerException;
    }

    public static void j(Object obj, String str) {
        if (obj != null) {
            return;
        }
        NullPointerException nullPointerException = new NullPointerException(str.concat(" must not be null"));
        D(nullPointerException, d.class.getName());
        throw nullPointerException;
    }

    public static void k(Object obj, String str) {
        if (obj == null) {
            StackTraceElement[] stackTrace = Thread.currentThread().getStackTrace();
            String name = d.class.getName();
            int i2 = 0;
            while (!stackTrace[i2].getClassName().equals(name)) {
                i2++;
            }
            while (stackTrace[i2].getClassName().equals(name)) {
                i2++;
            }
            StackTraceElement stackTraceElement = stackTrace[i2];
            NullPointerException nullPointerException = new NullPointerException("Parameter specified as non-null is null: method " + stackTraceElement.getClassName() + "." + stackTraceElement.getMethodName() + ", parameter " + str);
            D(nullPointerException, d.class.getName());
            throw nullPointerException;
        }
    }

    public static final void l(Closeable closeable, Throwable th) {
        if (closeable != null) {
            if (th == null) {
                closeable.close();
                return;
            }
            try {
                closeable.close();
            } catch (Throwable th2) {
                if (th != th2) {
                    Integer num = a0.a.f29a;
                    if (num == null || num.intValue() >= 19) {
                        th.addSuppressed(th2);
                        return;
                    }
                    Method method = z.a.f637a;
                    if (method != null) {
                        method.invoke(th, th2);
                    }
                }
            }
        }
    }

    public static final int m(int i2, int i3, int i4) {
        if (i3 <= i4) {
            return i2 < i3 ? i3 : i2 > i4 ? i4 : i2;
        }
        throw new IllegalArgumentException("Cannot coerce value to an empty range: maximum " + i4 + " is less than minimum " + i3 + '.');
    }

    public static int n(e1 e1Var, e0 e0Var, View view, View view2, t0 t0Var, boolean z2) {
        if (t0Var.u() == 0 || e1Var.b() == 0 || view == null || view2 == null) {
            return 0;
        }
        if (!z2) {
            return Math.abs(t0.C(view) - t0.C(view2)) + 1;
        }
        return Math.min(e0Var.i(), e0Var.b(view2) - e0Var.d(view));
    }

    public static int o(e1 e1Var, e0 e0Var, View view, View view2, t0 t0Var, boolean z2, boolean z3) {
        if (t0Var.u() == 0 || e1Var.b() == 0 || view == null || view2 == null) {
            return 0;
        }
        int max = z3 ? Math.max(0, (e1Var.b() - Math.max(t0.C(view), t0.C(view2))) - 1) : Math.max(0, Math.min(t0.C(view), t0.C(view2)));
        if (z2) {
            return Math.round((max * (Math.abs(e0Var.b(view2) - e0Var.d(view)) / (Math.abs(t0.C(view) - t0.C(view2)) + 1))) + (e0Var.h() - e0Var.d(view)));
        }
        return max;
    }

    public static int p(e1 e1Var, e0 e0Var, View view, View view2, t0 t0Var, boolean z2) {
        if (t0Var.u() == 0 || e1Var.b() == 0 || view == null || view2 == null) {
            return 0;
        }
        if (!z2) {
            return e1Var.b();
        }
        return (int) (((e0Var.b(view2) - e0Var.d(view)) / (Math.abs(t0.C(view) - t0.C(view2)) + 1)) * e1Var.b());
    }

    public static final long q(InputStream inputStream, FileOutputStream fileOutputStream, int i2) {
        k(inputStream, "<this>");
        byte[] bArr = new byte[i2];
        int read = inputStream.read(bArr);
        long j2 = 0;
        while (read >= 0) {
            fileOutputStream.write(bArr, 0, read);
            j2 += read;
            read = inputStream.read(bArr);
        }
        return j2;
    }

    public static void r(int i2, int i3, s.b bVar) {
        for (int i4 = 0; i4 < 8; i4++) {
            int i5 = i2 + i4;
            if (!y(bVar.a(i5, i3))) {
                throw new n.c();
            }
            bVar.b(i5, i3, 0);
        }
    }

    public static void s(int i2, int i3, s.b bVar) {
        for (int i4 = 0; i4 < 7; i4++) {
            for (int i5 = 0; i5 < 7; i5++) {
                bVar.b(i2 + i5, i3 + i4, f379e[i4][i5]);
            }
        }
    }

    public static void t(int i2, int i3, s.b bVar) {
        for (int i4 = 0; i4 < 7; i4++) {
            int i5 = i3 + i4;
            if (!y(bVar.a(i2, i5))) {
                throw new n.c();
            }
            bVar.b(i2, i5, 0);
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:284:0x06a5, code lost:
    
        r0 = r2 - r12.length;
        r6 = 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:285:0x06a9, code lost:
    
        if (r6 >= r0) goto L643;
     */
    /* JADX WARN: Code restructure failed: missing block: B:286:0x06ab, code lost:
    
        r5[r4 + r6] = 0;
        r6 = r6 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:288:0x06b3, code lost:
    
        java.lang.System.arraycopy(r12, 0, r5, r4 + r0, r12.length);
        r0 = new byte[r2];
        r4 = 0;
     */
    /* JADX WARN: Code restructure failed: missing block: B:289:0x06bc, code lost:
    
        if (r4 >= r2) goto L644;
     */
    /* JADX WARN: Code restructure failed: missing block: B:290:0x06be, code lost:
    
        r0[r4] = (byte) r5[r3 + r4];
        r4 = r4 + 1;
     */
    /* JADX WARN: Code restructure failed: missing block: B:292:0x06c8, code lost:
    
        r4 = new s.a(r1, r0);
        r0 = r31;
        r0.add(r4);
        r10 = java.lang.Math.max(r30, r3);
        r12 = java.lang.Math.max(r29, r2);
        r13 = r25 + r28[0];
        r9 = r26 + 1;
        r11 = r38;
        r6 = r0;
        r4 = r20;
        r3 = r22;
        r7 = r23;
        r8 = r24;
        r5 = r27;
        r0 = r41;
     */
    /* JADX WARN: Code restructure failed: missing block: B:34:0x00bc, code lost:
    
        r6 = r12;
     */
    /* JADX WARN: Code restructure failed: missing block: B:424:0x087e, code lost:
    
        if (r1 != false) goto L480;
     */
    /* JADX WARN: Removed duplicated region for block: B:102:0x036e  */
    /* JADX WARN: Removed duplicated region for block: B:44:0x00f8  */
    /* JADX WARN: Removed duplicated region for block: B:553:0x0a53  */
    /* JADX WARN: Removed duplicated region for block: B:555:0x0360  */
    /* JADX WARN: Removed duplicated region for block: B:559:0x0354  */
    /* JADX WARN: Removed duplicated region for block: B:565:0x027b  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x0134 A[LOOP:1: B:55:0x0106->B:63:0x0134, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:64:0x0143 A[SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:666:0x01c8  */
    /* JADX WARN: Removed duplicated region for block: B:713:0x0089  */
    /* JADX WARN: Removed duplicated region for block: B:76:0x021c  */
    /* JADX WARN: Removed duplicated region for block: B:93:0x0340 A[LOOP:3: B:92:0x033e->B:93:0x0340, LOOP_END] */
    /* JADX WARN: Removed duplicated region for block: B:96:0x034c  */
    /* JADX WARN: Removed duplicated region for block: B:99:0x035e  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static o.b u(java.lang.String r38, int r39, int r40, java.util.HashMap r41) {
        /*
            Method dump skipped, instructions count: 2788
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: b0.d.u(java.lang.String, int, int, java.util.HashMap):o.b");
    }

    public static final boolean v(char c2, char c3, boolean z2) {
        if (c2 == c3) {
            return true;
        }
        if (!z2) {
            return false;
        }
        char upperCase = Character.toUpperCase(c2);
        char upperCase2 = Character.toUpperCase(c3);
        return upperCase == upperCase2 || Character.toLowerCase(upperCase) == Character.toLowerCase(upperCase2);
    }

    public static float w(EdgeEffect edgeEffect) {
        return Build.VERSION.SDK_INT >= 31 ? i.b.b(edgeEffect) : RecyclerView.B0;
    }

    public static final int x(List list) {
        k(list, "<this>");
        return list.size() - 1;
    }

    public static boolean y(int i2) {
        return i2 == -1;
    }

    public static final List z(Object... objArr) {
        return objArr.length > 0 ? c.L(objArr) : k.f624a;
    }
}
