package c;

import android.graphics.Insets;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: e, reason: collision with root package name */
    public static final b f385e = new b(0, 0, 0, 0);

    /* renamed from: a, reason: collision with root package name */
    public final int f386a;

    /* renamed from: b, reason: collision with root package name */
    public final int f387b;

    /* renamed from: c, reason: collision with root package name */
    public final int f388c;

    /* renamed from: d, reason: collision with root package name */
    public final int f389d;

    public b(int i2, int i3, int i4, int i5) {
        this.f386a = i2;
        this.f387b = i3;
        this.f388c = i4;
        this.f389d = i5;
    }

    public static b a(int i2, int i3, int i4, int i5) {
        return (i2 == 0 && i3 == 0 && i4 == 0 && i5 == 0) ? f385e : new b(i2, i3, i4, i5);
    }

    public final Insets b() {
        return a.a(this.f386a, this.f387b, this.f388c, this.f389d);
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || b.class != obj.getClass()) {
            return false;
        }
        b bVar = (b) obj;
        return this.f389d == bVar.f389d && this.f386a == bVar.f386a && this.f388c == bVar.f388c && this.f387b == bVar.f387b;
    }

    public final int hashCode() {
        return (((((this.f386a * 31) + this.f387b) * 31) + this.f388c) * 31) + this.f389d;
    }

    public final String toString() {
        return "Insets{left=" + this.f386a + ", top=" + this.f387b + ", right=" + this.f388c + ", bottom=" + this.f389d + '}';
    }
}
