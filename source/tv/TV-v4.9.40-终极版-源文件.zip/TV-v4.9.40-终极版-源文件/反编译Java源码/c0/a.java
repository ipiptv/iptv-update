package c0;

/* loaded from: classes.dex */
public interface a {
    Object invoke();
}
