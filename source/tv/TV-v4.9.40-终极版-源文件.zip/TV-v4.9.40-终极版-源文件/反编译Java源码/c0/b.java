package c0;

/* loaded from: classes.dex */
public interface b {
    Object invoke(Object obj);
}
