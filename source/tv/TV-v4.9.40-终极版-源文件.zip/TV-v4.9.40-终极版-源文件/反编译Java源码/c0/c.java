package c0;

/* loaded from: classes.dex */
public interface c {
    Object c(Object obj, Object obj2);
}
