package c0;

/* loaded from: classes.dex */
public interface d {
    Object invoke(Object obj, Object obj2, Object obj3);
}
