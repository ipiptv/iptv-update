package c0;

/* loaded from: classes.dex */
public interface e {
    Object invoke(Object obj, Object obj2, Object obj3, Object obj4);
}
