package d0;

import java.io.Serializable;

/* loaded from: classes.dex */
public abstract class c implements b, Serializable {
    private final int arity;

    public c(int i2) {
        this.arity = i2;
    }

    @Override // d0.b
    public int getArity() {
        return this.arity;
    }

    public String toString() {
        f.f392a.getClass();
        String a2 = g.a(this);
        b0.d.j(a2, "renderLambdaToString(...)");
        return a2;
    }
}
