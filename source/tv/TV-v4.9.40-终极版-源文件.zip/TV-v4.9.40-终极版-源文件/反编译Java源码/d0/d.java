package d0;

import java.io.Serializable;

/* loaded from: classes.dex */
public final class d implements Serializable {

    /* renamed from: a, reason: collision with root package name */
    public boolean f390a;

    public final String toString() {
        return String.valueOf(this.f390a);
    }
}
