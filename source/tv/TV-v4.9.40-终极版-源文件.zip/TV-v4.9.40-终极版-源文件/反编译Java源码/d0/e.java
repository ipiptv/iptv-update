package d0;

import java.io.Serializable;

/* loaded from: classes.dex */
public final class e implements Serializable {

    /* renamed from: a, reason: collision with root package name */
    public int f391a;

    public final String toString() {
        return String.valueOf(this.f391a);
    }
}
