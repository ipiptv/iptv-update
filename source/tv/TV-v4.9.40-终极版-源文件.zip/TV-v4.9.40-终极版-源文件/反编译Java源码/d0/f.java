package d0;

/* loaded from: classes.dex */
public abstract class f {

    /* renamed from: a, reason: collision with root package name */
    public static final g f392a;

    static {
        g gVar = null;
        try {
            gVar = (g) Class.forName("kotlin.reflect.jvm.internal.ReflectionFactoryImpl").newInstance();
        } catch (ClassCastException | ClassNotFoundException | IllegalAccessException | InstantiationException unused) {
        }
        if (gVar == null) {
            gVar = new g();
        }
        f392a = gVar;
    }
}
