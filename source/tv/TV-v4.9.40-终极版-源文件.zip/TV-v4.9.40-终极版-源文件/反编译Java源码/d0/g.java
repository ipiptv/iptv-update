package d0;

/* loaded from: classes.dex */
public final class g {
    public static String a(b bVar) {
        String obj = bVar.getClass().getGenericInterfaces()[0].toString();
        return obj.startsWith("kotlin.jvm.functions.") ? obj.substring(21) : obj;
    }
}
