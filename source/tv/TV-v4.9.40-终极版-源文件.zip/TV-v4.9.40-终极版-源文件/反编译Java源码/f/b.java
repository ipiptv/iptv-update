package f;

import androidx.recyclerview.widget.n0;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public int f394a;

    /* renamed from: b, reason: collision with root package name */
    public final Object[] f395b;

    public b(int i2) {
        if (i2 <= 0) {
            throw new IllegalArgumentException("The max pool size must be > 0");
        }
        this.f395b = new Object[i2];
    }

    public final Object a() {
        int i2 = this.f394a;
        if (i2 <= 0) {
            return null;
        }
        int i3 = i2 - 1;
        Object[] objArr = this.f395b;
        Object obj = objArr[i3];
        objArr[i3] = null;
        this.f394a = i2 - 1;
        return obj;
    }

    public final void b(Object obj) {
        int i2;
        Object[] objArr;
        boolean z2 = false;
        int i3 = 0;
        while (true) {
            i2 = this.f394a;
            objArr = this.f395b;
            if (i3 >= i2) {
                break;
            }
            if (objArr[i3] == obj) {
                z2 = true;
                break;
            }
            i3++;
        }
        if (z2) {
            throw new IllegalStateException("Already in the pool!");
        }
        if (i2 < objArr.length) {
            objArr[i2] = obj;
            this.f394a = i2 + 1;
        }
    }

    public b(int i2, n0... n0VarArr) {
        this.f394a = i2;
        this.f395b = n0VarArr;
    }
}
