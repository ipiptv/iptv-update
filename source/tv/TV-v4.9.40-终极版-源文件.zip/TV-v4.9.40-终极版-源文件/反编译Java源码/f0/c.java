package f0;

/* loaded from: classes.dex */
public final class c extends a {

    /* renamed from: d, reason: collision with root package name */
    public static final c f403d = new c(1, 0);

    public c(int i2, int i3) {
        super(i2, i3, 1);
    }

    public final boolean equals(Object obj) {
        if (obj instanceof c) {
            if (!isEmpty() || !((c) obj).isEmpty()) {
                c cVar = (c) obj;
                if (this.f396a == cVar.f396a) {
                    if (this.f397b == cVar.f397b) {
                    }
                }
            }
            return true;
        }
        return false;
    }

    public final int hashCode() {
        if (isEmpty()) {
            return -1;
        }
        return (this.f396a * 31) + this.f397b;
    }

    public final boolean isEmpty() {
        return this.f396a > this.f397b;
    }

    public final String toString() {
        return this.f396a + ".." + this.f397b;
    }
}
