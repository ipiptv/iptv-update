package g;

import android.view.View;
import android.view.ViewGroup;
import androidx.recyclerview.widget.r0;

/* loaded from: classes.dex */
public final class a0 extends x.e implements c0.c {

    /* renamed from: c, reason: collision with root package name */
    public int f405c;

    /* renamed from: d, reason: collision with root package name */
    public /* synthetic */ Object f406d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ View f407e;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public a0(View view, v.a aVar) {
        super(aVar);
        this.f407e = view;
    }

    @Override // c0.c
    public final Object c(Object obj, Object obj2) {
        return ((a0) d((g0.b) obj, (v.a) obj2)).e(t.g.f554a);
    }

    @Override // x.a
    public final v.a d(Object obj, v.a aVar) {
        a0 a0Var = new a0(this.f407e, aVar);
        a0Var.f406d = obj;
        return a0Var;
    }

    @Override // x.a
    public final Object e(Object obj) {
        w.a aVar = w.a.f626a;
        int i2 = this.f405c;
        View view = this.f407e;
        int i3 = 1;
        if (i2 == 0) {
            b0.d.F(obj);
            g0.b bVar = (g0.b) this.f406d;
            this.f406d = bVar;
            this.f405c = 1;
            bVar.f462b = view;
            bVar.f461a = 3;
            bVar.f464d = this;
            return aVar;
        }
        if (i2 == 1) {
            g0.b bVar2 = (g0.b) this.f406d;
            b0.d.F(obj);
            if (view instanceof ViewGroup) {
                r0 r0Var = new r0(i3, new y((ViewGroup) view, null));
                this.f406d = null;
                this.f405c = 2;
                if (bVar2.d(r0Var, this) == aVar) {
                    return aVar;
                }
            }
        } else {
            if (i2 != 2) {
                throw new IllegalStateException("call to 'resume' before 'invoke' with coroutine");
            }
            b0.d.F(obj);
        }
        return t.g.f554a;
    }
}
