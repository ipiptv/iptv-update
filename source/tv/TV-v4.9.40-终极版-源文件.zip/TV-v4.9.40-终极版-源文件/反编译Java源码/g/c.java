package g;

import android.os.Bundle;
import android.text.Spanned;
import android.text.style.ClickableSpan;
import android.util.SparseArray;
import android.view.View;
import android.view.ViewGroup;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;
import android.view.accessibility.AccessibilityNodeProvider;
import java.lang.ref.WeakReference;
import java.util.Collections;
import java.util.List;
import tv.live.R;

/* loaded from: classes.dex */
public class c {

    /* renamed from: c, reason: collision with root package name */
    public static final View.AccessibilityDelegate f408c = new View.AccessibilityDelegate();

    /* renamed from: a, reason: collision with root package name */
    public final View.AccessibilityDelegate f409a;

    /* renamed from: b, reason: collision with root package name */
    public final a f410b;

    public c() {
        this(f408c);
    }

    public boolean a(View view, AccessibilityEvent accessibilityEvent) {
        return this.f409a.dispatchPopulateAccessibilityEvent(view, accessibilityEvent);
    }

    public d0 b(View view) {
        AccessibilityNodeProvider a2 = b.a(this.f409a, view);
        if (a2 != null) {
            return new d0(a2);
        }
        return null;
    }

    public void c(View view, AccessibilityEvent accessibilityEvent) {
        this.f409a.onInitializeAccessibilityEvent(view, accessibilityEvent);
    }

    public void d(View view, h.o oVar) {
        this.f409a.onInitializeAccessibilityNodeInfo(view, oVar.f473a);
    }

    public void e(View view, AccessibilityEvent accessibilityEvent) {
        this.f409a.onPopulateAccessibilityEvent(view, accessibilityEvent);
    }

    public boolean f(ViewGroup viewGroup, View view, AccessibilityEvent accessibilityEvent) {
        return this.f409a.onRequestSendAccessibilityEvent(viewGroup, view, accessibilityEvent);
    }

    public boolean g(View view, int i2, Bundle bundle) {
        WeakReference weakReference;
        boolean z2;
        List list = (List) view.getTag(R.id.tag_accessibility_actions);
        if (list == null) {
            list = Collections.emptyList();
        }
        boolean z3 = false;
        for (int i3 = 0; i3 < list.size() && ((AccessibilityNodeInfo.AccessibilityAction) ((h.i) list.get(i3)).f469a).getId() != i2; i3++) {
        }
        boolean b2 = b.b(this.f409a, view, i2, bundle);
        if (b2 || i2 != R.id.accessibility_action_clickable_span || bundle == null) {
            return b2;
        }
        int i4 = bundle.getInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", -1);
        SparseArray sparseArray = (SparseArray) view.getTag(R.id.tag_accessibility_clickable_spans);
        if (sparseArray != null && (weakReference = (WeakReference) sparseArray.get(i4)) != null) {
            ClickableSpan clickableSpan = (ClickableSpan) weakReference.get();
            if (clickableSpan != null) {
                CharSequence text = view.createAccessibilityNodeInfo().getText();
                ClickableSpan[] clickableSpanArr = text instanceof Spanned ? (ClickableSpan[]) ((Spanned) text).getSpans(0, text.length(), ClickableSpan.class) : null;
                for (int i5 = 0; clickableSpanArr != null && i5 < clickableSpanArr.length; i5++) {
                    if (clickableSpan.equals(clickableSpanArr[i5])) {
                        z2 = true;
                        break;
                    }
                }
            }
            z2 = false;
            if (z2) {
                clickableSpan.onClick(view);
                z3 = true;
            }
        }
        return z3;
    }

    public void h(View view, int i2) {
        this.f409a.sendAccessibilityEvent(view, i2);
    }

    public void i(View view, AccessibilityEvent accessibilityEvent) {
        this.f409a.sendAccessibilityEventUnchecked(view, accessibilityEvent);
    }

    public c(View.AccessibilityDelegate accessibilityDelegate) {
        this.f409a = accessibilityDelegate;
        this.f410b = new a(this);
    }
}
