package g;

import android.util.Log;
import android.view.View;
import java.lang.reflect.Field;

/* loaded from: classes.dex */
public abstract class c0 {

    /* renamed from: a, reason: collision with root package name */
    public static final Field f411a;

    /* renamed from: b, reason: collision with root package name */
    public static final Field f412b;

    /* renamed from: c, reason: collision with root package name */
    public static final Field f413c;

    /* renamed from: d, reason: collision with root package name */
    public static final boolean f414d;

    static {
        try {
            Field declaredField = View.class.getDeclaredField("mAttachInfo");
            f411a = declaredField;
            declaredField.setAccessible(true);
            Class<?> cls = Class.forName("android.view.View$AttachInfo");
            Field declaredField2 = cls.getDeclaredField("mStableInsets");
            f412b = declaredField2;
            declaredField2.setAccessible(true);
            Field declaredField3 = cls.getDeclaredField("mContentInsets");
            f413c = declaredField3;
            declaredField3.setAccessible(true);
            f414d = true;
        } catch (ReflectiveOperationException e2) {
            Log.w("WindowInsetsCompat", "Failed to get visible insets from AttachInfo " + e2.getMessage(), e2);
        }
    }
}
