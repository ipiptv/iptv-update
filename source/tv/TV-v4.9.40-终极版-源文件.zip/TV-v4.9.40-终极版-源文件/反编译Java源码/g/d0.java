package g;

import android.view.accessibility.AccessibilityNodeProvider;

/* loaded from: classes.dex */
public final class d0 {

    /* renamed from: a, reason: collision with root package name */
    public final Object f415a;

    public d0(AccessibilityNodeProvider accessibilityNodeProvider) {
        this.f415a = accessibilityNodeProvider;
    }
}
