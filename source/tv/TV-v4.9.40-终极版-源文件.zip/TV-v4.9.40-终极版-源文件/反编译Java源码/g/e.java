package g;

import android.view.DisplayCutout;

/* loaded from: classes.dex */
public final class e {

    /* renamed from: a, reason: collision with root package name */
    public final DisplayCutout f416a;

    public e(DisplayCutout displayCutout) {
        this.f416a = displayCutout;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (obj == null || e.class != obj.getClass()) {
            return false;
        }
        return f.a.a(this.f416a, ((e) obj).f416a);
    }

    public final int hashCode() {
        int hashCode;
        DisplayCutout displayCutout = this.f416a;
        if (displayCutout == null) {
            return 0;
        }
        hashCode = displayCutout.hashCode();
        return hashCode;
    }

    public final String toString() {
        return "DisplayCutoutCompat{" + this.f416a + "}";
    }
}
