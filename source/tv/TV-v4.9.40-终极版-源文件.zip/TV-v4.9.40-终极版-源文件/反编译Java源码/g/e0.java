package g;

import android.graphics.Rect;
import android.util.Log;
import android.view.WindowInsets;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;

/* loaded from: classes.dex */
public final class e0 extends i0 {

    /* renamed from: c, reason: collision with root package name */
    public static Field f417c = null;

    /* renamed from: d, reason: collision with root package name */
    public static boolean f418d = false;

    /* renamed from: e, reason: collision with root package name */
    public static Constructor f419e = null;

    /* renamed from: f, reason: collision with root package name */
    public static boolean f420f = false;

    /* renamed from: a, reason: collision with root package name */
    public WindowInsets f421a = e();

    /* renamed from: b, reason: collision with root package name */
    public c.b f422b;

    private static WindowInsets e() {
        if (!f418d) {
            try {
                f417c = WindowInsets.class.getDeclaredField("CONSUMED");
            } catch (ReflectiveOperationException e2) {
                Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets.CONSUMED field", e2);
            }
            f418d = true;
        }
        Field field = f417c;
        if (field != null) {
            try {
                WindowInsets windowInsets = (WindowInsets) field.get(null);
                if (windowInsets != null) {
                    return new WindowInsets(windowInsets);
                }
            } catch (ReflectiveOperationException e3) {
                Log.i("WindowInsetsCompat", "Could not get value from WindowInsets.CONSUMED field", e3);
            }
        }
        if (!f420f) {
            try {
                f419e = WindowInsets.class.getConstructor(Rect.class);
            } catch (ReflectiveOperationException e4) {
                Log.i("WindowInsetsCompat", "Could not retrieve WindowInsets(Rect) constructor", e4);
            }
            f420f = true;
        }
        Constructor constructor = f419e;
        if (constructor != null) {
            try {
                return (WindowInsets) constructor.newInstance(new Rect());
            } catch (ReflectiveOperationException e5) {
                Log.i("WindowInsetsCompat", "Could not invoke WindowInsets(Rect) constructor", e5);
            }
        }
        return null;
    }

    @Override // g.i0
    public q0 b() {
        a();
        q0 a2 = q0.a(this.f421a, null);
        p0 p0Var = a2.f447a;
        p0Var.j(null);
        p0Var.l(this.f422b);
        return a2;
    }

    @Override // g.i0
    public void c(c.b bVar) {
        this.f422b = bVar;
    }

    @Override // g.i0
    public void d(c.b bVar) {
        WindowInsets windowInsets = this.f421a;
        if (windowInsets != null) {
            this.f421a = windowInsets.replaceSystemWindowInsets(bVar.f386a, bVar.f387b, bVar.f388c, bVar.f389d);
        }
    }
}
