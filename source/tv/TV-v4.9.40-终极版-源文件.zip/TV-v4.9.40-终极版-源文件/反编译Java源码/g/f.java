package g;

import android.util.Log;
import android.view.View;
import android.view.ViewParent;

/* loaded from: classes.dex */
public final class f {

    /* renamed from: a, reason: collision with root package name */
    public ViewParent f423a;

    /* renamed from: b, reason: collision with root package name */
    public ViewParent f424b;

    /* renamed from: c, reason: collision with root package name */
    public final View f425c;

    /* renamed from: d, reason: collision with root package name */
    public boolean f426d;

    /* renamed from: e, reason: collision with root package name */
    public int[] f427e;

    public f(View view) {
        this.f425c = view;
    }

    public final boolean a(int i2, int i3, int[] iArr, int[] iArr2, int i4) {
        ViewParent c2;
        int i5;
        int i6;
        if (!this.f426d || (c2 = c(i4)) == null) {
            return false;
        }
        if (i2 == 0 && i3 == 0) {
            if (iArr2 == null) {
                return false;
            }
            iArr2[0] = 0;
            iArr2[1] = 0;
            return false;
        }
        View view = this.f425c;
        if (iArr2 != null) {
            view.getLocationInWindow(iArr2);
            i5 = iArr2[0];
            i6 = iArr2[1];
        } else {
            i5 = 0;
            i6 = 0;
        }
        if (iArr == null) {
            if (this.f427e == null) {
                this.f427e = new int[2];
            }
            iArr = this.f427e;
        }
        iArr[0] = 0;
        iArr[1] = 0;
        if (i4 == 0) {
            try {
                b0.c(c2, view, i2, i3, iArr);
            } catch (AbstractMethodError e2) {
                Log.e("ViewParentCompat", "ViewParent " + c2 + " does not implement interface method onNestedPreScroll", e2);
            }
        }
        if (iArr2 != null) {
            view.getLocationInWindow(iArr2);
            iArr2[0] = iArr2[0] - i5;
            iArr2[1] = iArr2[1] - i6;
        }
        return (iArr[0] == 0 && iArr[1] == 0) ? false : true;
    }

    public final boolean b(int i2, int i3, int i4, int i5, int[] iArr, int i6, int[] iArr2) {
        ViewParent c2;
        int i7;
        int i8;
        int[] iArr3;
        if (!this.f426d || (c2 = c(i6)) == null) {
            return false;
        }
        if (i2 == 0 && i3 == 0 && i4 == 0 && i5 == 0) {
            if (iArr != null) {
                iArr[0] = 0;
                iArr[1] = 0;
            }
            return false;
        }
        View view = this.f425c;
        if (iArr != null) {
            view.getLocationInWindow(iArr);
            i7 = iArr[0];
            i8 = iArr[1];
        } else {
            i7 = 0;
            i8 = 0;
        }
        if (iArr2 == null) {
            if (this.f427e == null) {
                this.f427e = new int[2];
            }
            iArr3 = this.f427e;
            iArr3[0] = 0;
            iArr3[1] = 0;
        } else {
            iArr3 = iArr2;
        }
        View view2 = this.f425c;
        iArr3[0] = iArr3[0] + i4;
        iArr3[1] = iArr3[1] + i5;
        if (i6 == 0) {
            try {
                b0.d(c2, view2, i2, i3, i4, i5);
            } catch (AbstractMethodError e2) {
                Log.e("ViewParentCompat", "ViewParent " + c2 + " does not implement interface method onNestedScroll", e2);
            }
        }
        if (iArr != null) {
            view.getLocationInWindow(iArr);
            iArr[0] = iArr[0] - i7;
            iArr[1] = iArr[1] - i8;
        }
        return true;
    }

    public final ViewParent c(int i2) {
        if (i2 == 0) {
            return this.f423a;
        }
        if (i2 != 1) {
            return null;
        }
        return this.f424b;
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0064  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x003e A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean d(int r11, int r12) {
        /*
            r10 = this;
            android.view.ViewParent r0 = r10.c(r12)
            r1 = 1
            r2 = 0
            if (r0 == 0) goto La
            r0 = 1
            goto Lb
        La:
            r0 = 0
        Lb:
            if (r0 == 0) goto Le
            return r1
        Le:
            boolean r0 = r10.f426d
            if (r0 == 0) goto L70
            android.view.View r0 = r10.f425c
            android.view.ViewParent r3 = r0.getParent()
            r4 = r0
        L19:
            if (r3 == 0) goto L70
            java.lang.String r5 = "ViewParentCompat"
            java.lang.String r6 = "ViewParent "
            if (r12 != 0) goto L3b
            boolean r7 = g.b0.f(r3, r4, r0, r11)     // Catch: java.lang.AbstractMethodError -> L26
            goto L3c
        L26:
            r7 = move-exception
            java.lang.StringBuilder r8 = new java.lang.StringBuilder
            r8.<init>(r6)
            r8.append(r3)
            java.lang.String r9 = " does not implement interface method onStartNestedScroll"
            r8.append(r9)
            java.lang.String r8 = r8.toString()
            android.util.Log.e(r5, r8, r7)
        L3b:
            r7 = 0
        L3c:
            if (r7 == 0) goto L64
            if (r12 == 0) goto L46
            if (r12 == r1) goto L43
            goto L48
        L43:
            r10.f424b = r3
            goto L48
        L46:
            r10.f423a = r3
        L48:
            if (r12 != 0) goto L63
            g.b0.e(r3, r4, r0, r11)     // Catch: java.lang.AbstractMethodError -> L4e
            goto L63
        L4e:
            r11 = move-exception
            java.lang.StringBuilder r12 = new java.lang.StringBuilder
            r12.<init>(r6)
            r12.append(r3)
            java.lang.String r0 = " does not implement interface method onNestedScrollAccepted"
            r12.append(r0)
            java.lang.String r12 = r12.toString()
            android.util.Log.e(r5, r12, r11)
        L63:
            return r1
        L64:
            boolean r5 = r3 instanceof android.view.View
            if (r5 == 0) goto L6b
            r4 = r3
            android.view.View r4 = (android.view.View) r4
        L6b:
            android.view.ViewParent r3 = r3.getParent()
            goto L19
        L70:
            return r2
        */
        throw new UnsupportedOperationException("Method not decompiled: g.f.d(int, int):boolean");
    }

    public final void e(int i2) {
        ViewParent c2 = c(i2);
        if (c2 != null) {
            View view = this.f425c;
            if (i2 == 0) {
                try {
                    b0.g(c2, view);
                } catch (AbstractMethodError e2) {
                    Log.e("ViewParentCompat", "ViewParent " + c2 + " does not implement interface method onStopNestedScroll", e2);
                }
            }
            if (i2 == 0) {
                this.f423a = null;
            } else {
                if (i2 != 1) {
                    return;
                }
                this.f424b = null;
            }
        }
    }
}
