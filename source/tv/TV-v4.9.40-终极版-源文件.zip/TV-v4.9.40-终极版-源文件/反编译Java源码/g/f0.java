package g;

import android.view.WindowInsets;

/* loaded from: classes.dex */
public abstract /* synthetic */ class f0 {
    public static /* synthetic */ WindowInsets.Builder a() {
        return new WindowInsets.Builder();
    }
}
