package g;

import android.view.WindowInsets;

/* loaded from: classes.dex */
public class g0 extends i0 {

    /* renamed from: a, reason: collision with root package name */
    public final WindowInsets.Builder f428a = f0.a();

    @Override // g.i0
    public q0 b() {
        WindowInsets build;
        a();
        build = this.f428a.build();
        q0 a2 = q0.a(build, null);
        a2.f447a.j(null);
        return a2;
    }

    @Override // g.i0
    public void c(c.b bVar) {
        this.f428a.setStableInsets(bVar.b());
    }

    @Override // g.i0
    public void d(c.b bVar) {
        this.f428a.setSystemWindowInsets(bVar.b());
    }
}
