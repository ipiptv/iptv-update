package g;

import android.view.View;

/* loaded from: classes.dex */
public final class h extends i {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ int f429d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public h(int i2, int i3) {
        super(i2, Boolean.class, 28);
        this.f429d = i3;
    }

    public final Boolean b(View view) {
        switch (this.f429d) {
            case 0:
                return Boolean.valueOf(r.d(view));
            default:
                return Boolean.valueOf(r.c(view));
        }
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ h(int i2, int i3, int i4, int i5) {
        super(i2, CharSequence.class, i4);
        this.f429d = i5;
    }
}
