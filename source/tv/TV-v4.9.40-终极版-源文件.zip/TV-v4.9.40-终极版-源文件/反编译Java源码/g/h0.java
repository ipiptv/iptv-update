package g;

/* loaded from: classes.dex */
public final class h0 extends g0 {
}
