package g;

import android.os.Build;
import android.view.View;
import tv.live.ManageType;

/* loaded from: classes.dex */
public abstract class i {

    /* renamed from: a, reason: collision with root package name */
    public final int f430a;

    /* renamed from: b, reason: collision with root package name */
    public final Class f431b;

    /* renamed from: c, reason: collision with root package name */
    public final int f432c;

    public i(int i2, Class cls, int i3) {
        this.f430a = i2;
        this.f431b = cls;
        this.f432c = i3;
    }

    public final Object a(View view) {
        if (!(Build.VERSION.SDK_INT >= this.f432c)) {
            Object tag = view.getTag(this.f430a);
            if (this.f431b.isInstance(tag)) {
                return tag;
            }
            return null;
        }
        h hVar = (h) this;
        int i2 = hVar.f429d;
        switch (i2) {
            case 0:
                return hVar.b(view);
            case 1:
                switch (i2) {
                    case 1:
                        return r.b(view);
                    default:
                        return t.b(view);
                }
            case ManageType.GROUP /* 2 */:
                switch (i2) {
                    case 1:
                        return r.b(view);
                    default:
                        return t.b(view);
                }
            default:
                return hVar.b(view);
        }
    }
}
