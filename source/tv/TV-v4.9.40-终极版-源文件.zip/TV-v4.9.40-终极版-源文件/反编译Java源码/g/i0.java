package g;

/* loaded from: classes.dex */
public abstract class i0 {
    public i0() {
        this(new q0());
    }

    public final void a() {
    }

    public abstract q0 b();

    public abstract void c(c.b bVar);

    public abstract void d(c.b bVar);

    public i0(q0 q0Var) {
    }
}
