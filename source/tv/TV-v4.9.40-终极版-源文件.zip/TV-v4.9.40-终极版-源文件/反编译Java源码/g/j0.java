package g;

import android.annotation.SuppressLint;
import android.graphics.Rect;
import android.os.Build;
import android.util.Log;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.Objects;

/* loaded from: classes.dex */
public abstract class j0 extends p0 {

    /* renamed from: f, reason: collision with root package name */
    public static boolean f433f = false;

    /* renamed from: g, reason: collision with root package name */
    public static Method f434g;

    /* renamed from: h, reason: collision with root package name */
    public static Class f435h;

    /* renamed from: i, reason: collision with root package name */
    public static Field f436i;

    /* renamed from: j, reason: collision with root package name */
    public static Field f437j;

    /* renamed from: c, reason: collision with root package name */
    public final WindowInsets f438c;

    /* renamed from: d, reason: collision with root package name */
    public c.b f439d;

    /* renamed from: e, reason: collision with root package name */
    public c.b f440e;

    public j0(q0 q0Var, WindowInsets windowInsets) {
        super(q0Var);
        this.f439d = null;
        this.f438c = windowInsets;
    }

    private c.b m(View view) {
        if (Build.VERSION.SDK_INT >= 30) {
            throw new UnsupportedOperationException("getVisibleInsets() should not be called on API >= 30. Use WindowInsets.isVisible() instead.");
        }
        if (!f433f) {
            n();
        }
        Method method = f434g;
        if (method != null && f435h != null && f436i != null) {
            try {
                Object invoke = method.invoke(view, new Object[0]);
                if (invoke == null) {
                    Log.w("WindowInsetsCompat", "Failed to get visible insets. getViewRootImpl() returned null from the provided view. This means that the view is either not attached or the method has been overridden", new NullPointerException());
                    return null;
                }
                Rect rect = (Rect) f436i.get(f437j.get(invoke));
                if (rect != null) {
                    return c.b.a(rect.left, rect.top, rect.right, rect.bottom);
                }
                return null;
            } catch (ReflectiveOperationException e2) {
                Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e2.getMessage(), e2);
            }
        }
        return null;
    }

    @SuppressLint({"PrivateApi"})
    private static void n() {
        try {
            f434g = View.class.getDeclaredMethod("getViewRootImpl", new Class[0]);
            Class<?> cls = Class.forName("android.view.View$AttachInfo");
            f435h = cls;
            f436i = cls.getDeclaredField("mVisibleInsets");
            f437j = Class.forName("android.view.ViewRootImpl").getDeclaredField("mAttachInfo");
            f436i.setAccessible(true);
            f437j.setAccessible(true);
        } catch (ReflectiveOperationException e2) {
            Log.e("WindowInsetsCompat", "Failed to get visible insets. (Reflection error). " + e2.getMessage(), e2);
        }
        f433f = true;
    }

    @Override // g.p0
    public void d(View view) {
        c.b m2 = m(view);
        if (m2 == null) {
            m2 = c.b.f385e;
        }
        o(m2);
    }

    @Override // g.p0
    public boolean equals(Object obj) {
        if (super.equals(obj)) {
            return Objects.equals(this.f440e, ((j0) obj).f440e);
        }
        return false;
    }

    @Override // g.p0
    public final c.b g() {
        if (this.f439d == null) {
            WindowInsets windowInsets = this.f438c;
            this.f439d = c.b.a(windowInsets.getSystemWindowInsetLeft(), windowInsets.getSystemWindowInsetTop(), windowInsets.getSystemWindowInsetRight(), windowInsets.getSystemWindowInsetBottom());
        }
        return this.f439d;
    }

    @Override // g.p0
    public boolean i() {
        return this.f438c.isRound();
    }

    @Override // g.p0
    public void j(c.b[] bVarArr) {
    }

    @Override // g.p0
    public void k(q0 q0Var) {
    }

    public void o(c.b bVar) {
        this.f440e = bVar;
    }
}
