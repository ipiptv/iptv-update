package g;

import android.view.WindowInsets;

/* loaded from: classes.dex */
public class k0 extends j0 {

    /* renamed from: k, reason: collision with root package name */
    public c.b f441k;

    public k0(q0 q0Var, WindowInsets windowInsets) {
        super(q0Var, windowInsets);
        this.f441k = null;
    }

    @Override // g.p0
    public q0 b() {
        return q0.a(this.f438c.consumeStableInsets(), null);
    }

    @Override // g.p0
    public q0 c() {
        return q0.a(this.f438c.consumeSystemWindowInsets(), null);
    }

    @Override // g.p0
    public final c.b f() {
        if (this.f441k == null) {
            WindowInsets windowInsets = this.f438c;
            this.f441k = c.b.a(windowInsets.getStableInsetLeft(), windowInsets.getStableInsetTop(), windowInsets.getStableInsetRight(), windowInsets.getStableInsetBottom());
        }
        return this.f441k;
    }

    @Override // g.p0
    public boolean h() {
        return this.f438c.isConsumed();
    }

    @Override // g.p0
    public void l(c.b bVar) {
        this.f441k = bVar;
    }
}
