package g;

import android.view.DisplayCutout;
import android.view.WindowInsets;
import java.util.Objects;

/* loaded from: classes.dex */
public class l0 extends k0 {
    public l0(q0 q0Var, WindowInsets windowInsets) {
        super(q0Var, windowInsets);
    }

    @Override // g.p0
    public q0 a() {
        WindowInsets consumeDisplayCutout;
        consumeDisplayCutout = this.f438c.consumeDisplayCutout();
        return q0.a(consumeDisplayCutout, null);
    }

    @Override // g.p0
    public e e() {
        DisplayCutout displayCutout;
        displayCutout = this.f438c.getDisplayCutout();
        if (displayCutout == null) {
            return null;
        }
        return new e(displayCutout);
    }

    @Override // g.j0, g.p0
    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof l0)) {
            return false;
        }
        l0 l0Var = (l0) obj;
        return Objects.equals(this.f438c, l0Var.f438c) && Objects.equals(this.f440e, l0Var.f440e);
    }

    @Override // g.p0
    public int hashCode() {
        return this.f438c.hashCode();
    }
}
