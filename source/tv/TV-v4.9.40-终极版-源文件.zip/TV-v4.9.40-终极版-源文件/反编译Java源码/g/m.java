package g;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;

/* loaded from: classes.dex */
public final class m implements View.OnApplyWindowInsetsListener {

    /* renamed from: a, reason: collision with root package name */
    public q0 f442a = null;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ View f443b;

    public m(View view, g gVar) {
        this.f443b = view;
    }

    @Override // android.view.View.OnApplyWindowInsetsListener
    public WindowInsets onApplyWindowInsets(View view, WindowInsets windowInsets) {
        q0 a2 = q0.a(windowInsets, view);
        if (Build.VERSION.SDK_INT < 30) {
            n.a(windowInsets, this.f443b);
            if (a2.equals(this.f442a)) {
                throw null;
            }
        }
        this.f442a = a2;
        throw null;
    }
}
