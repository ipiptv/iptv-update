package g;

import android.view.WindowInsets;

/* loaded from: classes.dex */
public class m0 extends l0 {
    public m0(q0 q0Var, WindowInsets windowInsets) {
        super(q0Var, windowInsets);
    }

    @Override // g.k0, g.p0
    public void l(c.b bVar) {
    }
}
