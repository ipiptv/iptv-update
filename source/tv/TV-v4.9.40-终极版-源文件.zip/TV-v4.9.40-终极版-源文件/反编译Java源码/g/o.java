package g;

import android.view.View;
import android.view.WindowInsets;

/* loaded from: classes.dex */
public abstract class o {
    public static q0 a(View view) {
        WindowInsets rootWindowInsets = view.getRootWindowInsets();
        if (rootWindowInsets == null) {
            return null;
        }
        q0 a2 = q0.a(rootWindowInsets, null);
        p0 p0Var = a2.f447a;
        p0Var.k(a2);
        p0Var.d(view.getRootView());
        return a2;
    }

    public static int b(View view) {
        return view.getScrollIndicators();
    }

    public static void c(View view, int i2) {
        view.setScrollIndicators(i2);
    }

    public static void d(View view, int i2, int i3) {
        view.setScrollIndicators(i2, i3);
    }
}
