package g;

import android.view.View;
import android.view.WindowInsets;

/* loaded from: classes.dex */
public final class o0 extends m0 {

    /* renamed from: l, reason: collision with root package name */
    public static final /* synthetic */ int f444l = 0;

    static {
        WindowInsets windowInsets;
        windowInsets = WindowInsets.CONSUMED;
        q0.a(windowInsets, null);
    }

    public o0(q0 q0Var, WindowInsets windowInsets) {
        super(q0Var, windowInsets);
    }

    @Override // g.j0, g.p0
    public final void d(View view) {
    }
}
