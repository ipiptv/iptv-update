package g;

import android.os.Build;
import android.view.View;

/* loaded from: classes.dex */
public class p0 {

    /* renamed from: b, reason: collision with root package name */
    public static final /* synthetic */ int f445b = 0;

    /* renamed from: a, reason: collision with root package name */
    public final q0 f446a;

    static {
        int i2 = Build.VERSION.SDK_INT;
        (i2 >= 30 ? new h0() : i2 >= 29 ? new g0() : new e0()).b().f447a.a().f447a.b().f447a.c();
    }

    public p0(q0 q0Var) {
        this.f446a = q0Var;
    }

    public q0 a() {
        return this.f446a;
    }

    public q0 b() {
        return this.f446a;
    }

    public q0 c() {
        return this.f446a;
    }

    public void d(View view) {
    }

    public e e() {
        return null;
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof p0)) {
            return false;
        }
        p0 p0Var = (p0) obj;
        return i() == p0Var.i() && h() == p0Var.h() && f.a.a(g(), p0Var.g()) && f.a.a(f(), p0Var.f()) && f.a.a(e(), p0Var.e());
    }

    public c.b f() {
        return c.b.f385e;
    }

    public c.b g() {
        return c.b.f385e;
    }

    public boolean h() {
        return false;
    }

    public int hashCode() {
        return f.a.b(Boolean.valueOf(i()), Boolean.valueOf(h()), g(), f(), e());
    }

    public boolean i() {
        return false;
    }

    public void j(c.b[] bVarArr) {
    }

    public void k(q0 q0Var) {
    }

    public void l(c.b bVar) {
    }
}
