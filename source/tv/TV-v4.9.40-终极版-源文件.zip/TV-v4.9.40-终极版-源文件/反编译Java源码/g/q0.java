package g;

import android.os.Build;
import android.view.View;
import android.view.WindowInsets;
import java.lang.reflect.Field;

/* loaded from: classes.dex */
public final class q0 {

    /* renamed from: a, reason: collision with root package name */
    public final p0 f447a;

    static {
        if (Build.VERSION.SDK_INT >= 30) {
            int i2 = o0.f444l;
        } else {
            int i3 = p0.f445b;
        }
    }

    public q0() {
        this.f447a = new p0(this);
    }

    public static q0 a(WindowInsets windowInsets, View view) {
        windowInsets.getClass();
        q0 q0Var = new q0(windowInsets);
        if (view != null) {
            Field field = v.f448a;
            if (l.b(view)) {
                q0 a2 = Build.VERSION.SDK_INT >= 23 ? o.a(view) : n.j(view);
                p0 p0Var = q0Var.f447a;
                p0Var.k(a2);
                p0Var.d(view.getRootView());
            }
        }
        return q0Var;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof q0)) {
            return false;
        }
        return f.a.a(this.f447a, ((q0) obj).f447a);
    }

    public final int hashCode() {
        p0 p0Var = this.f447a;
        if (p0Var == null) {
            return 0;
        }
        return p0Var.hashCode();
    }

    public q0(WindowInsets windowInsets) {
        int i2 = Build.VERSION.SDK_INT;
        this.f447a = i2 >= 30 ? new o0(this, windowInsets) : i2 >= 29 ? new m0(this, windowInsets) : i2 >= 28 ? new l0(this, windowInsets) : new k0(this, windowInsets);
    }
}
