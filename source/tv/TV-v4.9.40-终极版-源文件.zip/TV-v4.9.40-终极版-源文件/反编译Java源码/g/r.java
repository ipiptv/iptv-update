package g;

import android.view.View;
import android.view.autofill.AutofillId;
import java.util.Objects;
import tv.live.R;

/* loaded from: classes.dex */
public abstract class r {
    public static void a(View view, u uVar) {
        a.h hVar = (a.h) view.getTag(R.id.tag_unhandled_key_listeners);
        if (hVar == null) {
            hVar = new a.h();
            view.setTag(R.id.tag_unhandled_key_listeners, hVar);
        }
        Objects.requireNonNull(uVar);
        View.OnUnhandledKeyEventListener qVar = new q();
        hVar.put(uVar, qVar);
        view.addOnUnhandledKeyEventListener(qVar);
    }

    public static CharSequence b(View view) {
        return view.getAccessibilityPaneTitle();
    }

    public static boolean c(View view) {
        return view.isAccessibilityHeading();
    }

    public static boolean d(View view) {
        return view.isScreenReaderFocusable();
    }

    public static void e(View view, u uVar) {
        View.OnUnhandledKeyEventListener onUnhandledKeyEventListener;
        a.h hVar = (a.h) view.getTag(R.id.tag_unhandled_key_listeners);
        if (hVar == null || (onUnhandledKeyEventListener = (View.OnUnhandledKeyEventListener) hVar.get(uVar)) == null) {
            return;
        }
        view.removeOnUnhandledKeyEventListener(onUnhandledKeyEventListener);
    }

    public static <T> T f(View view, int i2) {
        return (T) view.requireViewById(i2);
    }

    public static void g(View view, boolean z2) {
        view.setAccessibilityHeading(z2);
    }

    public static void h(View view, CharSequence charSequence) {
        view.setAccessibilityPaneTitle(charSequence);
    }

    public static void i(View view, AutofillId autofillId) {
        view.setAutofillId(autofillId);
    }

    public static void j(View view, boolean z2) {
        view.setScreenReaderFocusable(z2);
    }
}
