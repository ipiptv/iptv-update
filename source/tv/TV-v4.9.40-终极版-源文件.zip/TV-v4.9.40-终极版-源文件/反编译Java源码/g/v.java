package g;

import android.os.Build;
import android.view.View;
import java.lang.reflect.Field;
import java.util.WeakHashMap;
import java.util.concurrent.atomic.AtomicInteger;

/* loaded from: classes.dex */
public abstract class v {

    /* renamed from: a, reason: collision with root package name */
    public static Field f448a;

    /* renamed from: b, reason: collision with root package name */
    public static boolean f449b;

    static {
        new AtomicInteger(1);
        f449b = false;
        new WeakHashMap();
    }

    public static View.AccessibilityDelegate a(View view) {
        if (Build.VERSION.SDK_INT >= 29) {
            return s.a(view);
        }
        if (f449b) {
            return null;
        }
        if (f448a == null) {
            try {
                Field declaredField = View.class.getDeclaredField("mAccessibilityDelegate");
                f448a = declaredField;
                declaredField.setAccessible(true);
            } catch (Throwable unused) {
                f449b = true;
                return null;
            }
        }
        Object obj = f448a.get(view);
        if (obj instanceof View.AccessibilityDelegate) {
            return (View.AccessibilityDelegate) obj;
        }
        return null;
    }

    public static void b(View view, c cVar) {
        if (cVar == null && (a(view) instanceof a)) {
            cVar = new c();
        }
        if (j.c(view) == 0) {
            j.s(view, 1);
        }
        view.setAccessibilityDelegate(cVar == null ? null : cVar.f410b);
    }
}
