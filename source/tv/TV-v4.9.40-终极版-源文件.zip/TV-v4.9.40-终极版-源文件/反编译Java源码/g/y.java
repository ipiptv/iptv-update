package g;

import android.view.View;
import android.view.ViewGroup;

/* loaded from: classes.dex */
public final class y extends x.e implements c0.c {

    /* renamed from: c, reason: collision with root package name */
    public ViewGroup f451c;

    /* renamed from: d, reason: collision with root package name */
    public View f452d;

    /* renamed from: e, reason: collision with root package name */
    public int f453e;

    /* renamed from: f, reason: collision with root package name */
    public int f454f;

    /* renamed from: g, reason: collision with root package name */
    public int f455g;

    /* renamed from: h, reason: collision with root package name */
    public /* synthetic */ Object f456h;

    /* renamed from: i, reason: collision with root package name */
    public final /* synthetic */ ViewGroup f457i;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public y(ViewGroup viewGroup, v.a aVar) {
        super(aVar);
        this.f457i = viewGroup;
    }

    @Override // c0.c
    public final Object c(Object obj, Object obj2) {
        return ((y) d((g0.b) obj, (v.a) obj2)).e(t.g.f554a);
    }

    @Override // x.a
    public final v.a d(Object obj, v.a aVar) {
        y yVar = new y(this.f457i, aVar);
        yVar.f456h = obj;
        return yVar;
    }

    /* JADX WARN: Removed duplicated region for block: B:16:0x006f  */
    /* JADX WARN: Removed duplicated region for block: B:20:0x0098  */
    /* JADX WARN: Removed duplicated region for block: B:21:0x00a1  */
    /* JADX WARN: Removed duplicated region for block: B:9:0x0046  */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:19:0x008f -> B:6:0x0091). Please report as a decompilation issue!!! */
    /* JADX WARN: Unsupported multi-entry loop pattern (BACK_EDGE: B:20:0x0098 -> B:7:0x009c). Please report as a decompilation issue!!! */
    @Override // x.a
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.lang.Object e(java.lang.Object r13) {
        /*
            r12 = this;
            w.a r0 = w.a.f626a
            int r1 = r12.f455g
            r2 = 2
            r3 = 1
            if (r1 == 0) goto L35
            if (r1 == r3) goto L24
            if (r1 != r2) goto L1c
            int r1 = r12.f454f
            int r4 = r12.f453e
            android.view.ViewGroup r5 = r12.f451c
            java.lang.Object r6 = r12.f456h
            g0.b r6 = (g0.b) r6
            b0.d.F(r13)
            r13 = r12
            goto L91
        L1c:
            java.lang.IllegalStateException r13 = new java.lang.IllegalStateException
            java.lang.String r0 = "call to 'resume' before 'invoke' with coroutine"
            r13.<init>(r0)
            throw r13
        L24:
            int r1 = r12.f454f
            int r4 = r12.f453e
            android.view.View r5 = r12.f452d
            android.view.ViewGroup r6 = r12.f451c
            java.lang.Object r7 = r12.f456h
            g0.b r7 = (g0.b) r7
            b0.d.F(r13)
            r13 = r12
            goto L6b
        L35:
            b0.d.F(r13)
            java.lang.Object r13 = r12.f456h
            g0.b r13 = (g0.b) r13
            android.view.ViewGroup r1 = r12.f457i
            int r4 = r1.getChildCount()
            r5 = 0
            r6 = r12
        L44:
            if (r5 >= r4) goto La1
            android.view.View r7 = r1.getChildAt(r5)
            r6.f456h = r13
            r6.f451c = r1
            r6.f452d = r7
            r6.f453e = r5
            r6.f454f = r4
            r6.f455g = r3
            r13.f462b = r7
            r8 = 3
            r13.f461a = r8
            r13.f464d = r6
            w.a r8 = w.a.f626a
            w.a r8 = w.a.f626a
            if (r8 != r0) goto L64
            return r0
        L64:
            r10 = r7
            r7 = r13
            r13 = r6
            r6 = r1
            r1 = r4
            r4 = r5
            r5 = r10
        L6b:
            boolean r8 = r5 instanceof android.view.ViewGroup
            if (r8 == 0) goto L98
            android.view.ViewGroup r5 = (android.view.ViewGroup) r5
            g.y r8 = new g.y
            r9 = 0
            r8.<init>(r5, r9)
            androidx.recyclerview.widget.r0 r5 = new androidx.recyclerview.widget.r0
            r5.<init>(r3, r8)
            r13.f456h = r7
            r13.f451c = r6
            r13.f452d = r9
            r13.f453e = r4
            r13.f454f = r1
            r13.f455g = r2
            java.lang.Object r5 = r7.d(r5, r13)
            if (r5 != r0) goto L8f
            return r0
        L8f:
            r5 = r6
            r6 = r7
        L91:
            r10 = r6
            r6 = r13
            r13 = r10
            r11 = r5
            r5 = r1
            r1 = r11
            goto L9c
        L98:
            r5 = r1
            r1 = r6
            r6 = r13
            r13 = r7
        L9c:
            int r4 = r4 + r3
            r10 = r5
            r5 = r4
            r4 = r10
            goto L44
        La1:
            t.g r13 = t.g.f554a
            return r13
        */
        throw new UnsupportedOperationException("Method not decompiled: g.y.e(java.lang.Object):java.lang.Object");
    }
}
