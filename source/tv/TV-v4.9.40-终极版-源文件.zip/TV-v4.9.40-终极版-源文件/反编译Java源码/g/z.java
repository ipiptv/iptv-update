package g;

import android.view.View;
import android.view.ViewGroup;
import java.util.Iterator;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public class z implements Iterator, e0.a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f458a;

    /* renamed from: b, reason: collision with root package name */
    public int f459b;

    /* renamed from: c, reason: collision with root package name */
    public final Object f460c;

    public /* synthetic */ z(int i2, Object obj) {
        this.f458a = i2;
        this.f460c = obj;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        int i2 = this.f458a;
        Object obj = this.f460c;
        switch (i2) {
            case 0:
                if (this.f459b < ((ViewGroup) obj).getChildCount()) {
                }
                break;
            case 1:
                if (this.f459b < ((u.e) obj).a()) {
                }
                break;
            default:
                if (this.f459b < ((Object[]) obj).length) {
                }
                break;
        }
        return false;
    }

    @Override // java.util.Iterator
    public final Object next() {
        int i2 = this.f458a;
        Object obj = this.f460c;
        switch (i2) {
            case 0:
                int i3 = this.f459b;
                this.f459b = i3 + 1;
                View childAt = ((ViewGroup) obj).getChildAt(i3);
                if (childAt != null) {
                    return childAt;
                }
                throw new IndexOutOfBoundsException();
            case 1:
                if (!hasNext()) {
                    throw new NoSuchElementException();
                }
                int i4 = this.f459b;
                this.f459b = i4 + 1;
                return ((u.e) obj).get(i4);
            default:
                try {
                    int i5 = this.f459b;
                    this.f459b = i5 + 1;
                    return ((Object[]) obj)[i5];
                } catch (ArrayIndexOutOfBoundsException e2) {
                    this.f459b--;
                    throw new NoSuchElementException(e2.getMessage());
                }
        }
    }

    @Override // java.util.Iterator
    public final void remove() {
        switch (this.f458a) {
            case 0:
                ViewGroup viewGroup = (ViewGroup) this.f460c;
                int i2 = this.f459b - 1;
                this.f459b = i2;
                viewGroup.removeViewAt(i2);
                return;
            case 1:
                throw new UnsupportedOperationException("Operation is not supported for read-only collection");
            default:
                throw new UnsupportedOperationException("Operation is not supported for read-only collection");
        }
    }

    public z(Object[] objArr) {
        this.f458a = 2;
        this.f460c = objArr;
    }
}
