package g0;

import java.util.Iterator;

/* loaded from: classes.dex */
public interface a {
    Iterator iterator();
}
