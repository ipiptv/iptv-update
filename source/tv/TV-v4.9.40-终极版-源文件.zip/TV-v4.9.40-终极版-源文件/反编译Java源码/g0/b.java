package g0;

import androidx.recyclerview.widget.r0;
import b0.d;
import java.util.Iterator;
import java.util.NoSuchElementException;
import t.g;

/* loaded from: classes.dex */
public final class b implements Iterator, v.a, e0.a {

    /* renamed from: a, reason: collision with root package name */
    public int f461a;

    /* renamed from: b, reason: collision with root package name */
    public Object f462b;

    /* renamed from: c, reason: collision with root package name */
    public Iterator f463c;

    /* renamed from: d, reason: collision with root package name */
    public v.a f464d;

    @Override // v.a
    public final void a(Object obj) {
        d.F(obj);
        this.f461a = 4;
    }

    @Override // v.a
    public final v.b b() {
        return v.c.f625a;
    }

    public final RuntimeException c() {
        int i2 = this.f461a;
        if (i2 == 4) {
            return new NoSuchElementException();
        }
        if (i2 == 5) {
            return new IllegalStateException("Iterator has failed.");
        }
        return new IllegalStateException("Unexpected state of the iterator: " + this.f461a);
    }

    public final Object d(r0 r0Var, v.a aVar) {
        Object obj;
        Iterator it = r0Var.iterator();
        boolean hasNext = it.hasNext();
        g gVar = g.f554a;
        if (hasNext) {
            this.f463c = it;
            this.f461a = 2;
            this.f464d = aVar;
            obj = w.a.f626a;
            d.k(aVar, "frame");
        } else {
            obj = gVar;
        }
        return obj == w.a.f626a ? obj : gVar;
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        while (true) {
            int i2 = this.f461a;
            if (i2 != 0) {
                if (i2 != 1) {
                    if (i2 == 2 || i2 == 3) {
                        return true;
                    }
                    if (i2 == 4) {
                        return false;
                    }
                    throw c();
                }
                Iterator it = this.f463c;
                d.h(it);
                if (it.hasNext()) {
                    this.f461a = 2;
                    return true;
                }
                this.f463c = null;
            }
            this.f461a = 5;
            v.a aVar = this.f464d;
            d.h(aVar);
            this.f464d = null;
            aVar.a(g.f554a);
        }
    }

    @Override // java.util.Iterator
    public final Object next() {
        int i2 = this.f461a;
        if (i2 == 0 || i2 == 1) {
            if (hasNext()) {
                return next();
            }
            throw new NoSuchElementException();
        }
        if (i2 == 2) {
            this.f461a = 1;
            Iterator it = this.f463c;
            d.h(it);
            return it.next();
        }
        if (i2 != 3) {
            throw c();
        }
        this.f461a = 0;
        Object obj = this.f462b;
        this.f462b = null;
        return obj;
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
