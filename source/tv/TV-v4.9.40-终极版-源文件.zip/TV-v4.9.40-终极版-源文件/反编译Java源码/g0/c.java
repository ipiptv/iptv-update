package g0;

import java.util.Iterator;

/* loaded from: classes.dex */
public final class c implements Iterable, e0.a {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ a f465a;

    public c(h0.c cVar) {
        this.f465a = cVar;
    }

    @Override // java.lang.Iterable
    public final Iterator iterator() {
        return this.f465a.iterator();
    }
}
