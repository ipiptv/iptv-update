package h;

import android.os.Bundle;
import android.text.style.ClickableSpan;
import android.view.View;

/* loaded from: classes.dex */
public final class a extends ClickableSpan {

    /* renamed from: a, reason: collision with root package name */
    public final int f466a;

    /* renamed from: b, reason: collision with root package name */
    public final o f467b;

    /* renamed from: c, reason: collision with root package name */
    public final int f468c;

    public a(int i2, o oVar, int i3) {
        this.f466a = i2;
        this.f467b = oVar;
        this.f468c = i3;
    }

    @Override // android.text.style.ClickableSpan
    public final void onClick(View view) {
        Bundle bundle = new Bundle();
        bundle.putInt("ACCESSIBILITY_CLICKABLE_SPAN_ID", this.f466a);
        this.f467b.f473a.performAction(this.f468c, bundle);
    }
}
