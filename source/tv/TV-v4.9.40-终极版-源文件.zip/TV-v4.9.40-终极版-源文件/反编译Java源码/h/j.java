package h;

import android.os.Bundle;
import android.view.accessibility.AccessibilityNodeInfo;

/* loaded from: classes.dex */
public abstract class j {
    public static n a(int i2, int i3, int i4, int i5, boolean z2) {
        return new n(AccessibilityNodeInfo.CollectionItemInfo.obtain(i2, i3, i4, i5, z2));
    }

    public static Object b(int i2, float f2, float f3, float f4) {
        return AccessibilityNodeInfo.RangeInfo.obtain(i2, f2, f3, f4);
    }

    public static Bundle c(AccessibilityNodeInfo accessibilityNodeInfo) {
        return accessibilityNodeInfo.getExtras();
    }
}
