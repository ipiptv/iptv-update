package h;

import android.view.accessibility.AccessibilityNodeInfo;

/* loaded from: classes.dex */
public final class n {

    /* renamed from: a, reason: collision with root package name */
    public final Object f471a;

    public n(AccessibilityNodeInfo.CollectionItemInfo collectionItemInfo) {
        this.f471a = collectionItemInfo;
    }

    public static n a(int i2, int i3, int i4, int i5) {
        return new n(AccessibilityNodeInfo.CollectionItemInfo.obtain(i2, i3, i4, i5, false, false));
    }
}
