package h;

/* loaded from: classes.dex */
public abstract class p extends b0.d {
}
