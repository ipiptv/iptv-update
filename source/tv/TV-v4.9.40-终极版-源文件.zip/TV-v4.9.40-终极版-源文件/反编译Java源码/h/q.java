package h;

/* loaded from: classes.dex */
public abstract class q extends b0.d {
}
