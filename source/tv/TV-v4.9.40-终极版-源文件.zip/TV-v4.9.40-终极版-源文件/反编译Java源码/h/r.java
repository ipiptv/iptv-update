package h;

/* loaded from: classes.dex */
public abstract class r extends b0.d {
}
