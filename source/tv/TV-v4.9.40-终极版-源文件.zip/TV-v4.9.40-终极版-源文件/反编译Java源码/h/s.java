package h;

/* loaded from: classes.dex */
public abstract class s extends b0.d {
}
