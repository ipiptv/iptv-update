package h;

/* loaded from: classes.dex */
public abstract class t extends b0.d {
}
