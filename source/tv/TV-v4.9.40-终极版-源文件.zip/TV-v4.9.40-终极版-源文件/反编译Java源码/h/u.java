package h;

/* loaded from: classes.dex */
public abstract class u extends b0.d {
}
