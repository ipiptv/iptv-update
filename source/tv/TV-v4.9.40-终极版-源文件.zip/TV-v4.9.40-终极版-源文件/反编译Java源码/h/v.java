package h;

/* loaded from: classes.dex */
public abstract class v extends b0.d {
}
