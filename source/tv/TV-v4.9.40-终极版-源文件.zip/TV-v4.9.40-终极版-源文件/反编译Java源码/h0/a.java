package h0;

import java.nio.charset.Charset;

/* loaded from: classes.dex */
public abstract class a {

    /* renamed from: a, reason: collision with root package name */
    public static final Charset f474a;

    /* renamed from: b, reason: collision with root package name */
    public static final Charset f475b;

    /* renamed from: c, reason: collision with root package name */
    public static final Charset f476c;

    static {
        Charset forName = Charset.forName("UTF-8");
        b0.d.j(forName, "forName(...)");
        f474a = forName;
        b0.d.j(Charset.forName("UTF-16"), "forName(...)");
        b0.d.j(Charset.forName("UTF-16BE"), "forName(...)");
        b0.d.j(Charset.forName("UTF-16LE"), "forName(...)");
        Charset forName2 = Charset.forName("US-ASCII");
        b0.d.j(forName2, "forName(...)");
        f475b = forName2;
        Charset forName3 = Charset.forName("ISO-8859-1");
        b0.d.j(forName3, "forName(...)");
        f476c = forName3;
    }
}
