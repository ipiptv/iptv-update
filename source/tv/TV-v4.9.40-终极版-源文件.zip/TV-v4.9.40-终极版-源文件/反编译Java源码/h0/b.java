package h0;

import java.util.Iterator;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public final class b implements Iterator, e0.a {

    /* renamed from: a, reason: collision with root package name */
    public int f477a = -1;

    /* renamed from: b, reason: collision with root package name */
    public int f478b;

    /* renamed from: c, reason: collision with root package name */
    public int f479c;

    /* renamed from: d, reason: collision with root package name */
    public f0.c f480d;

    /* renamed from: e, reason: collision with root package name */
    public int f481e;

    /* renamed from: f, reason: collision with root package name */
    public final /* synthetic */ c f482f;

    public b(c cVar) {
        this.f482f = cVar;
        int m2 = b0.d.m(cVar.f484b, 0, cVar.f483a.length());
        this.f478b = m2;
        this.f479c = m2;
    }

    /* JADX WARN: Code restructure failed: missing block: B:9:0x0019, code lost:
    
        if (r6 < r3) goto L9;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void a() {
        /*
            r7 = this;
            int r0 = r7.f479c
            r1 = 0
            if (r0 >= 0) goto Lc
            r7.f477a = r1
            r0 = 0
            r7.f480d = r0
            goto L83
        Lc:
            h0.c r2 = r7.f482f
            int r3 = r2.f485c
            r4 = -1
            r5 = 1
            if (r3 <= 0) goto L1b
            int r6 = r7.f481e
            int r6 = r6 + r5
            r7.f481e = r6
            if (r6 >= r3) goto L23
        L1b:
            java.lang.CharSequence r3 = r2.f483a
            int r3 = r3.length()
            if (r0 <= r3) goto L35
        L23:
            f0.c r0 = new f0.c
            int r1 = r7.f478b
            java.lang.CharSequence r2 = r2.f483a
            int r2 = h0.h.O(r2)
            r0.<init>(r1, r2)
        L30:
            r7.f480d = r0
            r7.f479c = r4
            goto L81
        L35:
            c0.c r0 = r2.f486d
            java.lang.CharSequence r3 = r2.f483a
            int r6 = r7.f479c
            java.lang.Integer r6 = java.lang.Integer.valueOf(r6)
            java.lang.Object r0 = r0.c(r3, r6)
            t.b r0 = (t.b) r0
            if (r0 != 0) goto L55
            f0.c r0 = new f0.c
            int r1 = r7.f478b
            java.lang.CharSequence r2 = r2.f483a
            int r2 = h0.h.O(r2)
            r0.<init>(r1, r2)
            goto L30
        L55:
            java.lang.Object r2 = r0.f547a
            java.lang.Number r2 = (java.lang.Number) r2
            int r2 = r2.intValue()
            java.lang.Object r0 = r0.f548b
            java.lang.Number r0 = (java.lang.Number) r0
            int r0 = r0.intValue()
            int r3 = r7.f478b
            r4 = -2147483648(0xffffffff80000000, float:-0.0)
            if (r2 > r4) goto L6e
            f0.c r3 = f0.c.f403d
            goto L76
        L6e:
            f0.c r4 = new f0.c
            int r6 = r2 + (-1)
            r4.<init>(r3, r6)
            r3 = r4
        L76:
            r7.f480d = r3
            int r2 = r2 + r0
            r7.f478b = r2
            if (r0 != 0) goto L7e
            r1 = 1
        L7e:
            int r2 = r2 + r1
            r7.f479c = r2
        L81:
            r7.f477a = r5
        L83:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: h0.b.a():void");
    }

    @Override // java.util.Iterator
    public final boolean hasNext() {
        if (this.f477a == -1) {
            a();
        }
        return this.f477a == 1;
    }

    @Override // java.util.Iterator
    public final Object next() {
        if (this.f477a == -1) {
            a();
        }
        if (this.f477a == 0) {
            throw new NoSuchElementException();
        }
        f0.c cVar = this.f480d;
        b0.d.i(cVar, "null cannot be cast to non-null type kotlin.ranges.IntRange");
        this.f480d = null;
        this.f477a = -1;
        return cVar;
    }

    @Override // java.util.Iterator
    public final void remove() {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
