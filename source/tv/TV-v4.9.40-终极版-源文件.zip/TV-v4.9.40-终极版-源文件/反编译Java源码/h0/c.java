package h0;

import java.util.Iterator;

/* loaded from: classes.dex */
public final class c implements g0.a {

    /* renamed from: a, reason: collision with root package name */
    public final CharSequence f483a;

    /* renamed from: b, reason: collision with root package name */
    public final int f484b;

    /* renamed from: c, reason: collision with root package name */
    public final int f485c;

    /* renamed from: d, reason: collision with root package name */
    public final c0.c f486d;

    public c(CharSequence charSequence, int i2, int i3, g gVar) {
        b0.d.k(charSequence, "input");
        this.f483a = charSequence;
        this.f484b = i2;
        this.f485c = i3;
        this.f486d = gVar;
    }

    @Override // g0.a
    public final Iterator iterator() {
        return new b(this);
    }
}
