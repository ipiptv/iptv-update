package h0;

/* loaded from: classes.dex */
public abstract class d extends b0.d {
}
