package h0;

/* loaded from: classes.dex */
public abstract class e extends d {
}
