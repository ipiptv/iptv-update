package h0;

/* loaded from: classes.dex */
public abstract class f extends e {
    /* JADX WARN: Removed duplicated region for block: B:18:0x0052  */
    /* JADX WARN: Removed duplicated region for block: B:38:0x0073  */
    /* JADX WARN: Removed duplicated region for block: B:41:0x0078  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final java.lang.Integer L(java.lang.String r11) {
        /*
            java.lang.String r0 = "<this>"
            b0.d.k(r11, r0)
            f0.c r0 = new f0.c
            r1 = 2
            r2 = 36
            r0.<init>(r1, r2)
            int r0 = r0.f397b
            r3 = 1
            r4 = 0
            r5 = 10
            if (r5 > r0) goto L17
            r0 = 1
            goto L18
        L17:
            r0 = 0
        L18:
            if (r0 == 0) goto L7f
            int r0 = r11.length()
            r1 = 0
            if (r0 != 0) goto L23
            goto L7e
        L23:
            char r2 = r11.charAt(r4)
            r6 = 48
            if (r2 >= r6) goto L2d
            r6 = -1
            goto L32
        L2d:
            if (r2 != r6) goto L31
            r6 = 0
            goto L32
        L31:
            r6 = 1
        L32:
            r7 = -2147483647(0xffffffff80000001, float:-1.4E-45)
            if (r6 >= 0) goto L48
            if (r0 != r3) goto L3a
            goto L7e
        L3a:
            r6 = 45
            if (r2 != r6) goto L42
            r7 = -2147483648(0xffffffff80000000, float:-0.0)
            r2 = 1
            goto L4a
        L42:
            r6 = 43
            if (r2 != r6) goto L7e
            r2 = 1
            goto L49
        L48:
            r2 = 0
        L49:
            r3 = 0
        L4a:
            r6 = -59652323(0xfffffffffc71c71d, float:-5.0215282E36)
            r8 = -59652323(0xfffffffffc71c71d, float:-5.0215282E36)
        L50:
            if (r2 >= r0) goto L71
            char r9 = r11.charAt(r2)
            int r9 = java.lang.Character.digit(r9, r5)
            if (r9 >= 0) goto L5d
            goto L7e
        L5d:
            if (r4 >= r8) goto L66
            if (r8 != r6) goto L7e
            int r8 = r7 / 10
            if (r4 >= r8) goto L66
            goto L7e
        L66:
            int r4 = r4 * 10
            int r10 = r7 + r9
            if (r4 >= r10) goto L6d
            goto L7e
        L6d:
            int r4 = r4 - r9
            int r2 = r2 + 1
            goto L50
        L71:
            if (r3 == 0) goto L78
            java.lang.Integer r11 = java.lang.Integer.valueOf(r4)
            goto L7d
        L78:
            int r11 = -r4
            java.lang.Integer r11 = java.lang.Integer.valueOf(r11)
        L7d:
            r1 = r11
        L7e:
            return r1
        L7f:
            java.lang.IllegalArgumentException r11 = new java.lang.IllegalArgumentException
            java.lang.StringBuilder r0 = new java.lang.StringBuilder
            java.lang.String r3 = "radix 10 was not in valid range "
            r0.<init>(r3)
            f0.c r3 = new f0.c
            r3.<init>(r1, r2)
            r0.append(r3)
            java.lang.String r0 = r0.toString()
            r11.<init>(r0)
            throw r11
        */
        throw new UnsupportedOperationException("Method not decompiled: h0.f.L(java.lang.String):java.lang.Integer");
    }
}
