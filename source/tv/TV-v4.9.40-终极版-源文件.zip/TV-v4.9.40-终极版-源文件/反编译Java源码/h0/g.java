package h0;

import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public final class g extends d0.c implements c0.c {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f487a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ boolean f488b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f489c;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ g(Object obj, boolean z2, int i2) {
        super(2);
        this.f487a = i2;
        this.f489c = obj;
        this.f488b = z2;
    }

    public final t.b a(int i2, CharSequence charSequence) {
        Object obj;
        t.b bVar;
        Object obj2;
        int i3 = this.f487a;
        Object obj3 = this.f489c;
        switch (i3) {
            case 0:
                b0.d.k(charSequence, "$this$$receiver");
                int S = h.S(i2, charSequence, this.f488b, (char[]) obj3);
                if (S < 0) {
                    return null;
                }
                return new t.b(Integer.valueOf(S), 1);
            default:
                b0.d.k(charSequence, "$this$$receiver");
                List list = (List) obj3;
                boolean z2 = this.f488b;
                if (z2 || list.size() != 1) {
                    if (i2 < 0) {
                        i2 = 0;
                    }
                    f0.c cVar = new f0.c(i2, charSequence.length());
                    boolean z3 = charSequence instanceof String;
                    int i4 = cVar.f398c;
                    int i5 = cVar.f397b;
                    if (z3) {
                        if ((i4 > 0 && i2 <= i5) || (i4 < 0 && i5 <= i2)) {
                            while (true) {
                                Iterator it = list.iterator();
                                while (true) {
                                    if (it.hasNext()) {
                                        obj2 = it.next();
                                        String str = (String) obj2;
                                        if (h.W(str, 0, (String) charSequence, i2, str.length(), z2)) {
                                        }
                                    } else {
                                        obj2 = null;
                                    }
                                }
                                String str2 = (String) obj2;
                                if (str2 != null) {
                                    bVar = new t.b(Integer.valueOf(i2), str2);
                                } else if (i2 != i5) {
                                    i2 += i4;
                                }
                            }
                        }
                        bVar = null;
                    } else {
                        if ((i4 > 0 && i2 <= i5) || (i4 < 0 && i5 <= i2)) {
                            while (true) {
                                Iterator it2 = list.iterator();
                                while (true) {
                                    if (it2.hasNext()) {
                                        obj = it2.next();
                                        String str3 = (String) obj;
                                        if (h.X(str3, charSequence, i2, str3.length(), z2)) {
                                        }
                                    } else {
                                        obj = null;
                                    }
                                }
                                String str4 = (String) obj;
                                if (str4 != null) {
                                    bVar = new t.b(Integer.valueOf(i2), str4);
                                } else if (i2 != i5) {
                                    i2 += i4;
                                }
                            }
                        }
                        bVar = null;
                    }
                } else {
                    int size = list.size();
                    if (size == 0) {
                        throw new NoSuchElementException("List is empty.");
                    }
                    if (size != 1) {
                        throw new IllegalArgumentException("List has more than one element.");
                    }
                    String str5 = (String) list.get(0);
                    int R = h.R(charSequence, str5, i2, false, 4);
                    if (R >= 0) {
                        bVar = new t.b(Integer.valueOf(R), str5);
                    }
                    bVar = null;
                }
                if (bVar == null) {
                    return null;
                }
                return new t.b(bVar.f547a, Integer.valueOf(((String) bVar.f548b).length()));
        }
    }

    @Override // c0.c
    public final /* bridge */ /* synthetic */ Object c(Object obj, Object obj2) {
        switch (this.f487a) {
            case 0:
                return a(((Number) obj2).intValue(), (CharSequence) obj);
            default:
                return a(((Number) obj2).intValue(), (CharSequence) obj);
        }
    }
}
