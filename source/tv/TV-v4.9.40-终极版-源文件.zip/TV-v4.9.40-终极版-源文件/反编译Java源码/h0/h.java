package h0;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public abstract class h extends f {
    public static final boolean M(String str, String str2, boolean z2) {
        b0.d.k(str, "<this>");
        b0.d.k(str2, "other");
        return R(str, str2, 0, z2, 2) >= 0;
    }

    public static final boolean N(String str, String str2, boolean z2) {
        return !z2 ? str.endsWith(str2) : W(str, str.length() - str2.length(), str2, 0, str2.length(), true);
    }

    public static final int O(CharSequence charSequence) {
        b0.d.k(charSequence, "<this>");
        return charSequence.length() - 1;
    }

    public static final int P(int i2, CharSequence charSequence, String str, boolean z2) {
        b0.d.k(charSequence, "<this>");
        b0.d.k(str, "string");
        if (!z2 && (charSequence instanceof String)) {
            return ((String) charSequence).indexOf(str, i2);
        }
        int length = charSequence.length();
        if (i2 < 0) {
            i2 = 0;
        }
        int length2 = charSequence.length();
        if (length > length2) {
            length = length2;
        }
        f0.c cVar = new f0.c(i2, length);
        boolean z3 = charSequence instanceof String;
        int i3 = cVar.f398c;
        int i4 = cVar.f397b;
        if (z3) {
            if ((i3 > 0 && i2 <= i4) || (i3 < 0 && i4 <= i2)) {
                while (!W(str, 0, (String) charSequence, i2, str.length(), z2)) {
                    if (i2 != i4) {
                        i2 += i3;
                    }
                }
                return i2;
            }
        } else if ((i3 > 0 && i2 <= i4) || (i3 < 0 && i4 <= i2)) {
            while (!X(str, charSequence, i2, str.length(), z2)) {
                if (i2 != i4) {
                    i2 += i3;
                }
            }
            return i2;
        }
        return -1;
    }

    public static int Q(CharSequence charSequence, char c2, int i2, int i3) {
        if ((i3 & 2) != 0) {
            i2 = 0;
        }
        b0.d.k(charSequence, "<this>");
        return !(charSequence instanceof String) ? S(i2, charSequence, false, new char[]{c2}) : ((String) charSequence).indexOf(c2, i2);
    }

    public static /* synthetic */ int R(CharSequence charSequence, String str, int i2, boolean z2, int i3) {
        if ((i3 & 2) != 0) {
            i2 = 0;
        }
        if ((i3 & 4) != 0) {
            z2 = false;
        }
        return P(i2, charSequence, str, z2);
    }

    public static final int S(int i2, CharSequence charSequence, boolean z2, char[] cArr) {
        int i3;
        boolean z3;
        b0.d.k(charSequence, "<this>");
        b0.d.k(cArr, "chars");
        if (!z2 && cArr.length == 1 && (charSequence instanceof String)) {
            return ((String) charSequence).indexOf(b0.c.O(cArr), i2);
        }
        if (i2 < 0) {
            i2 = 0;
        }
        f0.c cVar = new f0.c(i2, O(charSequence));
        int i4 = cVar.f397b;
        int i5 = cVar.f398c;
        boolean z4 = i5 <= 0 ? i2 >= i4 : i2 <= i4;
        if (!z4) {
            i2 = i4;
        }
        while (z4) {
            if (i2 != i4) {
                i3 = i5 + i2;
            } else {
                if (!z4) {
                    throw new NoSuchElementException();
                }
                i3 = i2;
                z4 = false;
            }
            char charAt = charSequence.charAt(i2);
            int length = cArr.length;
            int i6 = 0;
            while (true) {
                if (i6 >= length) {
                    z3 = false;
                    break;
                }
                if (b0.d.v(cArr[i6], charAt, z2)) {
                    z3 = true;
                    break;
                }
                i6++;
            }
            if (z3) {
                return i2;
            }
            i2 = i3;
        }
        return -1;
    }

    public static final boolean T(String str) {
        boolean z2;
        b0.d.k(str, "<this>");
        if (str.length() == 0) {
            return true;
        }
        Iterable cVar = new f0.c(0, str.length() - 1);
        if (!(cVar instanceof Collection) || !((Collection) cVar).isEmpty()) {
            Iterator it = cVar.iterator();
            while (((f0.b) it).f401c) {
                char charAt = str.charAt(((f0.b) it).b());
                if (!(Character.isWhitespace(charAt) || Character.isSpaceChar(charAt))) {
                    z2 = false;
                    break;
                }
            }
        }
        z2 = true;
        return z2;
    }

    public static int U(CharSequence charSequence, char c2) {
        int O = O(charSequence);
        b0.d.k(charSequence, "<this>");
        if (charSequence instanceof String) {
            return ((String) charSequence).lastIndexOf(c2, O);
        }
        char[] cArr = {c2};
        if (charSequence instanceof String) {
            return ((String) charSequence).lastIndexOf(b0.c.O(cArr), O);
        }
        int O2 = O(charSequence);
        if (O > O2) {
            O = O2;
        }
        while (-1 < O) {
            if (b0.d.v(cArr[0], charSequence.charAt(O), false)) {
                return O;
            }
            O--;
        }
        return -1;
    }

    public static c V(CharSequence charSequence, String[] strArr, boolean z2, int i2) {
        Z(i2);
        return new c(charSequence, 0, i2, new g(b0.c.L(strArr), z2, 1));
    }

    public static final boolean W(String str, int i2, String str2, int i3, int i4, boolean z2) {
        b0.d.k(str, "<this>");
        b0.d.k(str2, "other");
        return !z2 ? str.regionMatches(i2, str2, i3, i4) : str.regionMatches(z2, i2, str2, i3, i4);
    }

    public static final boolean X(CharSequence charSequence, CharSequence charSequence2, int i2, int i3, boolean z2) {
        b0.d.k(charSequence, "<this>");
        b0.d.k(charSequence2, "other");
        if (i2 < 0 || charSequence.length() - i3 < 0 || i2 > charSequence2.length() - i3) {
            return false;
        }
        for (int i4 = 0; i4 < i3; i4++) {
            if (!b0.d.v(charSequence.charAt(0 + i4), charSequence2.charAt(i2 + i4), z2)) {
                return false;
            }
        }
        return true;
    }

    public static String Y(String str, String str2, String str3) {
        b0.d.k(str, "<this>");
        b0.d.k(str2, "oldValue");
        int P = P(0, str, str2, false);
        if (P < 0) {
            return str;
        }
        int length = str2.length();
        int i2 = length >= 1 ? length : 1;
        int length2 = str3.length() + (str.length() - length);
        if (length2 < 0) {
            throw new OutOfMemoryError();
        }
        StringBuilder sb = new StringBuilder(length2);
        int i3 = 0;
        do {
            sb.append((CharSequence) str, i3, P);
            sb.append(str3);
            i3 = P + length;
            if (P >= str.length()) {
                break;
            }
            P = P(P + i2, str, str2, false);
        } while (P > 0);
        sb.append((CharSequence) str, i3, str.length());
        String sb2 = sb.toString();
        b0.d.j(sb2, "toString(...)");
        return sb2;
    }

    public static final void Z(int i2) {
        if (i2 >= 0) {
            return;
        }
        throw new IllegalArgumentException(("Limit must be non-negative, but was " + i2).toString());
    }

    public static final List a0(int i2, CharSequence charSequence, String str, boolean z2) {
        Z(i2);
        int i3 = 0;
        int P = P(0, charSequence, str, z2);
        if (P != -1) {
            if (i2 != 1) {
                boolean z3 = i2 > 0;
                int i4 = 10;
                if (z3 && i2 <= 10) {
                    i4 = i2;
                }
                ArrayList arrayList = new ArrayList(i4);
                do {
                    arrayList.add(charSequence.subSequence(i3, P).toString());
                    i3 = str.length() + P;
                    if (z3 && arrayList.size() == i2 - 1) {
                        break;
                    }
                    P = P(i3, charSequence, str, z2);
                } while (P != -1);
                arrayList.add(charSequence.subSequence(i3, charSequence.length()).toString());
                return arrayList;
            }
        }
        List singletonList = Collections.singletonList(charSequence.toString());
        b0.d.j(singletonList, "singletonList(...)");
        return singletonList;
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static List b0(CharSequence charSequence, char[] cArr) {
        b0.d.k(charSequence, "<this>");
        boolean z2 = false;
        Object[] objArr = 0;
        if (cArr.length == 1) {
            return a0(0, charSequence, String.valueOf(cArr[0]), false);
        }
        Z(0);
        g0.c cVar = new g0.c(new c(charSequence, 0, 0, new g(cArr, z2, objArr == true ? 1 : 0)));
        ArrayList arrayList = new ArrayList(b0.c.M(cVar));
        Iterator it = cVar.iterator();
        while (it.hasNext()) {
            arrayList.add(e0(charSequence, (f0.c) it.next()));
        }
        return arrayList;
    }

    public static List c0(CharSequence charSequence, String[] strArr) {
        b0.d.k(charSequence, "<this>");
        if (strArr.length == 1) {
            String str = strArr[0];
            if (!(str.length() == 0)) {
                return a0(0, charSequence, str, false);
            }
        }
        g0.c cVar = new g0.c(V(charSequence, strArr, false, 0));
        ArrayList arrayList = new ArrayList(b0.c.M(cVar));
        Iterator it = cVar.iterator();
        while (it.hasNext()) {
            arrayList.add(e0(charSequence, (f0.c) it.next()));
        }
        return arrayList;
    }

    public static final boolean d0(String str, String str2, boolean z2) {
        b0.d.k(str, "<this>");
        b0.d.k(str2, "prefix");
        return !z2 ? str.startsWith(str2) : W(str, 0, str2, 0, str2.length(), z2);
    }

    public static final String e0(CharSequence charSequence, f0.c cVar) {
        b0.d.k(charSequence, "<this>");
        b0.d.k(cVar, "range");
        return charSequence.subSequence(Integer.valueOf(cVar.f396a).intValue(), Integer.valueOf(cVar.f397b).intValue() + 1).toString();
    }

    public static final String f0(String str, char c2, String str2) {
        b0.d.k(str, "<this>");
        b0.d.k(str2, "missingDelimiterValue");
        int Q = Q(str, c2, 0, 6);
        if (Q == -1) {
            return str2;
        }
        String substring = str.substring(Q + 1, str.length());
        b0.d.j(substring, "substring(...)");
        return substring;
    }

    public static final String g0(String str, String str2, String str3) {
        b0.d.k(str, "<this>");
        b0.d.k(str2, "delimiter");
        b0.d.k(str3, "missingDelimiterValue");
        int R = R(str, str2, 0, false, 6);
        if (R == -1) {
            return str3;
        }
        String substring = str.substring(str2.length() + R, str.length());
        b0.d.j(substring, "substring(...)");
        return substring;
    }

    public static String h0(String str, char c2) {
        b0.d.k(str, "<this>");
        b0.d.k(str, "missingDelimiterValue");
        int U = U(str, c2);
        if (U == -1) {
            return str;
        }
        String substring = str.substring(U + 1, str.length());
        b0.d.j(substring, "substring(...)");
        return substring;
    }

    public static String i0(String str, char c2) {
        b0.d.k(str, "<this>");
        b0.d.k(str, "missingDelimiterValue");
        int Q = Q(str, c2, 0, 6);
        if (Q == -1) {
            return str;
        }
        String substring = str.substring(0, Q);
        b0.d.j(substring, "substring(...)");
        return substring;
    }

    public static final CharSequence j0(CharSequence charSequence) {
        b0.d.k(charSequence, "<this>");
        int length = charSequence.length() - 1;
        int i2 = 0;
        boolean z2 = false;
        while (i2 <= length) {
            char charAt = charSequence.charAt(!z2 ? i2 : length);
            boolean z3 = Character.isWhitespace(charAt) || Character.isSpaceChar(charAt);
            if (z2) {
                if (!z3) {
                    break;
                }
                length--;
            } else if (z3) {
                i2++;
            } else {
                z2 = true;
            }
        }
        return charSequence.subSequence(i2, length + 1);
    }
}
