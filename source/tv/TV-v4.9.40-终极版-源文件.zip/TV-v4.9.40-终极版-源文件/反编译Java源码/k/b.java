package k;

import android.os.Parcel;
import android.os.Parcelable;
import androidx.recyclerview.widget.d1;

/* loaded from: classes.dex */
public final class b implements Parcelable.ClassLoaderCreator {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f491a;

    public /* synthetic */ b(int i2) {
        this.f491a = i2;
    }

    @Override // android.os.Parcelable.Creator
    public final Object createFromParcel(Parcel parcel) {
        switch (this.f491a) {
            case 0:
                if (parcel.readParcelable(null) == null) {
                    return c.f492b;
                }
                throw new IllegalStateException("superState must be null");
            default:
                return new d1(parcel, null);
        }
    }

    @Override // android.os.Parcelable.Creator
    public final Object[] newArray(int i2) {
        switch (this.f491a) {
            case 0:
                return new c[i2];
            default:
                return new d1[i2];
        }
    }

    @Override // android.os.Parcelable.ClassLoaderCreator
    public final Object createFromParcel(Parcel parcel, ClassLoader classLoader) {
        switch (this.f491a) {
            case 0:
                if (parcel.readParcelable(classLoader) == null) {
                    return c.f492b;
                }
                throw new IllegalStateException("superState must be null");
            default:
                return new d1(parcel, classLoader);
        }
    }
}
