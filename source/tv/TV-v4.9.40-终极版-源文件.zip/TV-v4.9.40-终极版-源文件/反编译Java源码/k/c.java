package k;

import android.os.Parcel;
import android.os.Parcelable;

/* loaded from: classes.dex */
public abstract class c implements Parcelable {

    /* renamed from: a, reason: collision with root package name */
    public final Parcelable f493a;

    /* renamed from: b, reason: collision with root package name */
    public static final a f492b = new a();
    public static final Parcelable.Creator<c> CREATOR = new b(0);

    public c() {
        this.f493a = null;
    }

    @Override // android.os.Parcelable
    public final int describeContents() {
        return 0;
    }

    @Override // android.os.Parcelable
    public void writeToParcel(Parcel parcel, int i2) {
        parcel.writeParcelable(this.f493a, i2);
    }

    public c(Parcel parcel, ClassLoader classLoader) {
        Parcelable readParcelable = parcel.readParcelable(classLoader);
        this.f493a = readParcelable == null ? f492b : readParcelable;
    }

    public c(Parcelable parcelable) {
        if (parcelable == null) {
            throw new IllegalArgumentException("superState must not be null");
        }
        this.f493a = parcelable == f492b ? null : parcelable;
    }
}
