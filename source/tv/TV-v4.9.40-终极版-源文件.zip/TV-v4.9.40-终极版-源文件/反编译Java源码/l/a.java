package l;

import android.R;

/* loaded from: classes.dex */
public abstract class a {

    /* renamed from: a, reason: collision with root package name */
    public static final int[] f494a = {R.attr.orientation, R.attr.clipToPadding, R.attr.descendantFocusability, tv.live.R.attr.fastScrollEnabled, tv.live.R.attr.fastScrollHorizontalThumbDrawable, tv.live.R.attr.fastScrollHorizontalTrackDrawable, tv.live.R.attr.fastScrollVerticalThumbDrawable, tv.live.R.attr.fastScrollVerticalTrackDrawable, tv.live.R.attr.layoutManager, tv.live.R.attr.reverseLayout, tv.live.R.attr.spanCount, tv.live.R.attr.stackFromEnd};
}
