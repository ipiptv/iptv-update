package m;

import android.os.Parcel;
import android.util.SparseIntArray;

/* loaded from: classes.dex */
public final class b extends a {

    /* renamed from: d, reason: collision with root package name */
    public final SparseIntArray f498d;

    /* renamed from: e, reason: collision with root package name */
    public final Parcel f499e;

    /* renamed from: f, reason: collision with root package name */
    public final int f500f;

    /* renamed from: g, reason: collision with root package name */
    public final int f501g;

    /* renamed from: h, reason: collision with root package name */
    public final String f502h;

    /* renamed from: i, reason: collision with root package name */
    public int f503i;

    /* renamed from: j, reason: collision with root package name */
    public int f504j;

    /* renamed from: k, reason: collision with root package name */
    public int f505k;

    public b(Parcel parcel) {
        this(parcel, parcel.dataPosition(), parcel.dataSize(), "", new a.b(), new a.b(), new a.b());
    }

    @Override // m.a
    public final b a() {
        Parcel parcel = this.f499e;
        int dataPosition = parcel.dataPosition();
        int i2 = this.f504j;
        if (i2 == this.f500f) {
            i2 = this.f501g;
        }
        return new b(parcel, dataPosition, i2, this.f502h + "  ", this.f495a, this.f496b, this.f497c);
    }

    @Override // m.a
    public final boolean e(int i2) {
        while (this.f504j < this.f501g) {
            int i3 = this.f505k;
            if (i3 == i2) {
                return true;
            }
            if (String.valueOf(i3).compareTo(String.valueOf(i2)) > 0) {
                return false;
            }
            int i4 = this.f504j;
            Parcel parcel = this.f499e;
            parcel.setDataPosition(i4);
            int readInt = parcel.readInt();
            this.f505k = parcel.readInt();
            this.f504j += readInt;
        }
        return this.f505k == i2;
    }

    @Override // m.a
    public final void i(int i2) {
        int i3 = this.f503i;
        SparseIntArray sparseIntArray = this.f498d;
        Parcel parcel = this.f499e;
        if (i3 >= 0) {
            int i4 = sparseIntArray.get(i3);
            int dataPosition = parcel.dataPosition();
            parcel.setDataPosition(i4);
            parcel.writeInt(dataPosition - i4);
            parcel.setDataPosition(dataPosition);
        }
        this.f503i = i2;
        sparseIntArray.put(i2, parcel.dataPosition());
        parcel.writeInt(0);
        parcel.writeInt(i2);
    }

    public b(Parcel parcel, int i2, int i3, String str, a.b bVar, a.b bVar2, a.b bVar3) {
        super(bVar, bVar2, bVar3);
        this.f498d = new SparseIntArray();
        this.f503i = -1;
        this.f505k = -1;
        this.f499e = parcel;
        this.f500f = i2;
        this.f501g = i3;
        this.f504j = i2;
        this.f502h = str;
    }
}
