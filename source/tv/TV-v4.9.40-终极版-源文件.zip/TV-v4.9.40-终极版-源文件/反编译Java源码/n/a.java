package n;

/* loaded from: classes.dex */
public abstract /* synthetic */ class a {
    public static /* synthetic */ int a(int i2) {
        if (i2 != 0) {
            return i2 - 1;
        }
        throw null;
    }
}
