package n;

/* loaded from: classes.dex */
public enum b {
    ERROR_CORRECTION,
    CHARACTER_SET,
    /* JADX INFO: Fake field, exist only in values array */
    DATA_MATRIX_SHAPE,
    /* JADX INFO: Fake field, exist only in values array */
    MIN_SIZE,
    /* JADX INFO: Fake field, exist only in values array */
    MAX_SIZE,
    MARGIN,
    /* JADX INFO: Fake field, exist only in values array */
    PDF417_COMPACT,
    /* JADX INFO: Fake field, exist only in values array */
    PDF417_COMPACTION,
    /* JADX INFO: Fake field, exist only in values array */
    PDF417_DIMENSIONS,
    /* JADX INFO: Fake field, exist only in values array */
    AZTEC_LAYERS,
    QR_VERSION
}
