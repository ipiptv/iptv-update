package n;

import java.io.UnsupportedEncodingException;

/* loaded from: classes.dex */
public final class c extends Exception {
    public c(UnsupportedEncodingException unsupportedEncodingException) {
        super(unsupportedEncodingException);
    }
}
