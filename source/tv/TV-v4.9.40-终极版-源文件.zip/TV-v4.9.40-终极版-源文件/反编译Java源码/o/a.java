package o;

import java.util.Arrays;

/* loaded from: classes.dex */
public final class a implements Cloneable {

    /* renamed from: a, reason: collision with root package name */
    public int[] f511a;

    /* renamed from: b, reason: collision with root package name */
    public int f512b;

    public a() {
        this.f512b = 0;
        this.f511a = new int[1];
    }

    public final void a(boolean z2) {
        c(this.f512b + 1);
        if (z2) {
            int[] iArr = this.f511a;
            int i2 = this.f512b;
            int i3 = i2 / 32;
            iArr[i3] = (1 << (i2 & 31)) | iArr[i3];
        }
        this.f512b++;
    }

    public final void b(int i2, int i3) {
        if (i3 < 0 || i3 > 32) {
            throw new IllegalArgumentException("Num bits must be between 0 and 32");
        }
        c(this.f512b + i3);
        while (i3 > 0) {
            boolean z2 = true;
            if (((i2 >> (i3 - 1)) & 1) != 1) {
                z2 = false;
            }
            a(z2);
            i3--;
        }
    }

    public final void c(int i2) {
        int[] iArr = this.f511a;
        if (i2 > (iArr.length << 5)) {
            int[] iArr2 = new int[(i2 + 31) / 32];
            System.arraycopy(iArr, 0, iArr2, 0, iArr.length);
            this.f511a = iArr2;
        }
    }

    public final Object clone() {
        return new a((int[]) this.f511a.clone(), this.f512b);
    }

    public final boolean d(int i2) {
        return ((1 << (i2 & 31)) & this.f511a[i2 / 32]) != 0;
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof a)) {
            return false;
        }
        a aVar = (a) obj;
        return this.f512b == aVar.f512b && Arrays.equals(this.f511a, aVar.f511a);
    }

    public final int hashCode() {
        return Arrays.hashCode(this.f511a) + (this.f512b * 31);
    }

    public final String toString() {
        StringBuilder sb = new StringBuilder(this.f512b);
        for (int i2 = 0; i2 < this.f512b; i2++) {
            if ((i2 & 7) == 0) {
                sb.append(' ');
            }
            sb.append(d(i2) ? 'X' : '.');
        }
        return sb.toString();
    }

    public a(int[] iArr, int i2) {
        this.f511a = iArr;
        this.f512b = i2;
    }
}
