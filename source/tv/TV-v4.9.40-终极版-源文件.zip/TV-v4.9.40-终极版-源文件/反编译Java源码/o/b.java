package o;

import java.util.Arrays;

/* loaded from: classes.dex */
public final class b implements Cloneable {

    /* renamed from: a, reason: collision with root package name */
    public final int f513a;

    /* renamed from: b, reason: collision with root package name */
    public final int f514b;

    /* renamed from: c, reason: collision with root package name */
    public final int f515c;

    /* renamed from: d, reason: collision with root package name */
    public final int[] f516d;

    public b(int i2, int i3) {
        if (i2 <= 0 || i3 <= 0) {
            throw new IllegalArgumentException("Both dimensions must be greater than 0");
        }
        this.f513a = i2;
        this.f514b = i3;
        int i4 = (i2 + 31) / 32;
        this.f515c = i4;
        this.f516d = new int[i4 * i3];
    }

    public final Object clone() {
        int[] iArr = (int[]) this.f516d.clone();
        return new b(this.f513a, this.f514b, this.f515c, iArr);
    }

    public final boolean equals(Object obj) {
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return this.f513a == bVar.f513a && this.f514b == bVar.f514b && this.f515c == bVar.f515c && Arrays.equals(this.f516d, bVar.f516d);
    }

    public final int hashCode() {
        int i2 = this.f513a;
        return Arrays.hashCode(this.f516d) + (((((((i2 * 31) + i2) * 31) + this.f514b) * 31) + this.f515c) * 31);
    }

    public final String toString() {
        int i2 = this.f513a;
        int i3 = this.f514b;
        StringBuilder sb = new StringBuilder((i2 + 1) * i3);
        for (int i4 = 0; i4 < i3; i4++) {
            for (int i5 = 0; i5 < i2; i5++) {
                sb.append(((this.f516d[(i5 / 32) + (this.f515c * i4)] >>> (i5 & 31)) & 1) != 0 ? "X " : "  ");
            }
            sb.append("\n");
        }
        return sb.toString();
    }

    public b(int i2, int i3, int i4, int[] iArr) {
        this.f513a = i2;
        this.f514b = i3;
        this.f515c = i4;
        this.f516d = iArr;
    }
}
