package p;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: g, reason: collision with root package name */
    public static final a f522g;

    /* renamed from: a, reason: collision with root package name */
    public final int[] f523a;

    /* renamed from: b, reason: collision with root package name */
    public final int[] f524b;

    /* renamed from: c, reason: collision with root package name */
    public final b f525c;

    /* renamed from: d, reason: collision with root package name */
    public final int f526d;

    /* renamed from: e, reason: collision with root package name */
    public final int f527e;

    /* renamed from: f, reason: collision with root package name */
    public final int f528f;

    static {
        new a(4201, 4096, 1);
        new a(1033, 1024, 1);
        new a(67, 64, 1);
        new a(19, 16, 1);
        f522g = new a(285, 256, 0);
        new a(301, 256, 1);
    }

    public a(int i2, int i3, int i4) {
        this.f527e = i2;
        this.f526d = i3;
        this.f528f = i4;
        this.f523a = new int[i3];
        this.f524b = new int[i3];
        int i5 = 1;
        int i6 = 1;
        for (int i7 = 0; i7 < i3; i7++) {
            this.f523a[i7] = i6;
            i6 <<= 1;
            if (i6 >= i3) {
                i6 = (i6 ^ i2) & (i3 - 1);
            }
        }
        for (int i8 = 0; i8 < i3 - 1; i8++) {
            this.f524b[this.f523a[i8]] = i8;
        }
        this.f525c = new b(this, new int[]{0});
        int[] iArr = {1};
        if (iArr.length == 0) {
            throw new IllegalArgumentException();
        }
        int length = iArr.length;
        if (length <= 1 || iArr[0] != 0) {
            return;
        }
        while (i5 < length && iArr[i5] == 0) {
            i5++;
        }
        if (i5 == length) {
            return;
        }
        int[] iArr2 = new int[length - i5];
        System.arraycopy(iArr, i5, iArr2, 0, iArr2.length);
    }

    public final int a(int i2, int i3) {
        if (i2 == 0 || i3 == 0) {
            return 0;
        }
        int[] iArr = this.f524b;
        return this.f523a[(iArr[i2] + iArr[i3]) % (this.f526d - 1)];
    }

    public final String toString() {
        return "GF(0x" + Integer.toHexString(this.f527e) + ',' + this.f526d + ')';
    }
}
