package p;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public final a f529a;

    /* renamed from: b, reason: collision with root package name */
    public final int[] f530b;

    public b(a aVar, int[] iArr) {
        if (iArr.length == 0) {
            throw new IllegalArgumentException();
        }
        this.f529a = aVar;
        int length = iArr.length;
        int i2 = 1;
        if (length <= 1 || iArr[0] != 0) {
            this.f530b = iArr;
            return;
        }
        while (i2 < length && iArr[i2] == 0) {
            i2++;
        }
        if (i2 == length) {
            this.f530b = new int[]{0};
            return;
        }
        int i3 = length - i2;
        int[] iArr2 = new int[i3];
        this.f530b = iArr2;
        System.arraycopy(iArr, i2, iArr2, 0, i3);
    }

    public final b a(b bVar) {
        a aVar = bVar.f529a;
        a aVar2 = this.f529a;
        if (!aVar2.equals(aVar)) {
            throw new IllegalArgumentException("GenericGFPolys do not have same GenericGF field");
        }
        int[] iArr = this.f530b;
        if (iArr[0] == 0) {
            return bVar;
        }
        int[] iArr2 = bVar.f530b;
        if (iArr2[0] == 0) {
            return this;
        }
        if (iArr.length <= iArr2.length) {
            iArr = iArr2;
            iArr2 = iArr;
        }
        int[] iArr3 = new int[iArr.length];
        int length = iArr.length - iArr2.length;
        System.arraycopy(iArr, 0, iArr3, 0, length);
        for (int i2 = length; i2 < iArr.length; i2++) {
            iArr3[i2] = iArr2[i2 - length] ^ iArr[i2];
        }
        return new b(aVar2, iArr3);
    }

    public final String toString() {
        char c2;
        int[] iArr = this.f530b;
        StringBuilder sb = new StringBuilder((iArr.length - 1) * 8);
        int length = iArr.length;
        while (true) {
            length--;
            if (length < 0) {
                return sb.toString();
            }
            int i2 = iArr[(iArr.length - 1) - length];
            if (i2 != 0) {
                if (i2 < 0) {
                    sb.append(" - ");
                    i2 = -i2;
                } else if (sb.length() > 0) {
                    sb.append(" + ");
                }
                if (length == 0 || i2 != 1) {
                    a aVar = this.f529a;
                    if (i2 == 0) {
                        aVar.getClass();
                        throw new IllegalArgumentException();
                    }
                    int i3 = aVar.f524b[i2];
                    if (i3 == 0) {
                        c2 = '1';
                    } else if (i3 == 1) {
                        c2 = 'a';
                    } else {
                        sb.append("a^");
                        sb.append(i3);
                    }
                    sb.append(c2);
                }
                if (length != 0) {
                    if (length == 1) {
                        sb.append('x');
                    } else {
                        sb.append("x^");
                        sb.append(length);
                    }
                }
            }
        }
    }
}
