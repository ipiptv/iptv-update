package r;

import androidx.recyclerview.widget.n0;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: d, reason: collision with root package name */
    public static final b[] f538d = a();

    /* renamed from: a, reason: collision with root package name */
    public final int f539a;

    /* renamed from: b, reason: collision with root package name */
    public final f.b[] f540b;

    /* renamed from: c, reason: collision with root package name */
    public final int f541c;

    public b(int i2, f.b... bVarArr) {
        this.f539a = i2;
        this.f540b = bVarArr;
        f.b bVar = bVarArr[0];
        int i3 = bVar.f394a;
        int i4 = 0;
        for (n0 n0Var : (n0[]) bVar.f395b) {
            i4 += (n0Var.f236b + i3) * n0Var.f235a;
        }
        this.f541c = i4;
    }

    public static b[] a() {
        return new b[]{new b(1, new f.b(7, new n0(1, 19)), new f.b(10, new n0(1, 16)), new f.b(13, new n0(1, 13)), new f.b(17, new n0(1, 9))), new b(2, new f.b(10, new n0(1, 34)), new f.b(16, new n0(1, 28)), new f.b(22, new n0(1, 22)), new f.b(28, new n0(1, 16))), new b(3, new f.b(15, new n0(1, 55)), new f.b(26, new n0(1, 44)), new f.b(18, new n0(2, 17)), new f.b(22, new n0(2, 13))), new b(4, new f.b(20, new n0(1, 80)), new f.b(18, new n0(2, 32)), new f.b(26, new n0(2, 24)), new f.b(16, new n0(4, 9))), new b(5, new f.b(26, new n0(1, 108)), new f.b(24, new n0(2, 43)), new f.b(18, new n0(2, 15), new n0(2, 16)), new f.b(22, new n0(2, 11), new n0(2, 12))), new b(6, new f.b(18, new n0(2, 68)), new f.b(16, new n0(4, 27)), new f.b(24, new n0(4, 19)), new f.b(28, new n0(4, 15))), new b(7, new f.b(20, new n0(2, 78)), new f.b(18, new n0(4, 31)), new f.b(18, new n0(2, 14), new n0(4, 15)), new f.b(26, new n0(4, 13), new n0(1, 14))), new b(8, new f.b(24, new n0(2, 97)), new f.b(22, new n0(2, 38), new n0(2, 39)), new f.b(22, new n0(4, 18), new n0(2, 19)), new f.b(26, new n0(4, 14), new n0(2, 15))), new b(9, new f.b(30, new n0(2, 116)), new f.b(22, new n0(3, 36), new n0(2, 37)), new f.b(20, new n0(4, 16), new n0(4, 17)), new f.b(24, new n0(4, 12), new n0(4, 13))), new b(10, new f.b(18, new n0(2, 68), new n0(2, 69)), new f.b(26, new n0(4, 43), new n0(1, 44)), new f.b(24, new n0(6, 19), new n0(2, 20)), new f.b(28, new n0(6, 15), new n0(2, 16))), new b(11, new f.b(20, new n0(4, 81)), new f.b(30, new n0(1, 50), new n0(4, 51)), new f.b(28, new n0(4, 22), new n0(4, 23)), new f.b(24, new n0(3, 12), new n0(8, 13))), new b(12, new f.b(24, new n0(2, 92), new n0(2, 93)), new f.b(22, new n0(6, 36), new n0(2, 37)), new f.b(26, new n0(4, 20), new n0(6, 21)), new f.b(28, new n0(7, 14), new n0(4, 15))), new b(13, new f.b(26, new n0(4, 107)), new f.b(22, new n0(8, 37), new n0(1, 38)), new f.b(24, new n0(8, 20), new n0(4, 21)), new f.b(22, new n0(12, 11), new n0(4, 12))), new b(14, new f.b(30, new n0(3, 115), new n0(1, 116)), new f.b(24, new n0(4, 40), new n0(5, 41)), new f.b(20, new n0(11, 16), new n0(5, 17)), new f.b(24, new n0(11, 12), new n0(5, 13))), new b(15, new f.b(22, new n0(5, 87), new n0(1, 88)), new f.b(24, new n0(5, 41), new n0(5, 42)), new f.b(30, new n0(5, 24), new n0(7, 25)), new f.b(24, new n0(11, 12), new n0(7, 13))), new b(16, new f.b(24, new n0(5, 98), new n0(1, 99)), new f.b(28, new n0(7, 45), new n0(3, 46)), new f.b(24, new n0(15, 19), new n0(2, 20)), new f.b(30, new n0(3, 15), new n0(13, 16))), new b(17, new f.b(28, new n0(1, 107), new n0(5, 108)), new f.b(28, new n0(10, 46), new n0(1, 47)), new f.b(28, new n0(1, 22), new n0(15, 23)), new f.b(28, new n0(2, 14), new n0(17, 15))), new b(18, new f.b(30, new n0(5, 120), new n0(1, 121)), new f.b(26, new n0(9, 43), new n0(4, 44)), new f.b(28, new n0(17, 22), new n0(1, 23)), new f.b(28, new n0(2, 14), new n0(19, 15))), new b(19, new f.b(28, new n0(3, 113), new n0(4, 114)), new f.b(26, new n0(3, 44), new n0(11, 45)), new f.b(26, new n0(17, 21), new n0(4, 22)), new f.b(26, new n0(9, 13), new n0(16, 14))), new b(20, new f.b(28, new n0(3, 107), new n0(5, 108)), new f.b(26, new n0(3, 41), new n0(13, 42)), new f.b(30, new n0(15, 24), new n0(5, 25)), new f.b(28, new n0(15, 15), new n0(10, 16))), new b(21, new f.b(28, new n0(4, 116), new n0(4, 117)), new f.b(26, new n0(17, 42)), new f.b(28, new n0(17, 22), new n0(6, 23)), new f.b(30, new n0(19, 16), new n0(6, 17))), new b(22, new f.b(28, new n0(2, 111), new n0(7, 112)), new f.b(28, new n0(17, 46)), new f.b(30, new n0(7, 24), new n0(16, 25)), new f.b(24, new n0(34, 13))), new b(23, new f.b(30, new n0(4, 121), new n0(5, 122)), new f.b(28, new n0(4, 47), new n0(14, 48)), new f.b(30, new n0(11, 24), new n0(14, 25)), new f.b(30, new n0(16, 15), new n0(14, 16))), new b(24, new f.b(30, new n0(6, 117), new n0(4, 118)), new f.b(28, new n0(6, 45), new n0(14, 46)), new f.b(30, new n0(11, 24), new n0(16, 25)), new f.b(30, new n0(30, 16), new n0(2, 17))), new b(25, new f.b(26, new n0(8, 106), new n0(4, 107)), new f.b(28, new n0(8, 47), new n0(13, 48)), new f.b(30, new n0(7, 24), new n0(22, 25)), new f.b(30, new n0(22, 15), new n0(13, 16))), new b(26, new f.b(28, new n0(10, 114), new n0(2, 115)), new f.b(28, new n0(19, 46), new n0(4, 47)), new f.b(28, new n0(28, 22), new n0(6, 23)), new f.b(30, new n0(33, 16), new n0(4, 17))), new b(27, new f.b(30, new n0(8, 122), new n0(4, 123)), new f.b(28, new n0(22, 45), new n0(3, 46)), new f.b(30, new n0(8, 23), new n0(26, 24)), new f.b(30, new n0(12, 15), new n0(28, 16))), new b(28, new f.b(30, new n0(3, 117), new n0(10, 118)), new f.b(28, new n0(3, 45), new n0(23, 46)), new f.b(30, new n0(4, 24), new n0(31, 25)), new f.b(30, new n0(11, 15), new n0(31, 16))), new b(29, new f.b(30, new n0(7, 116), new n0(7, 117)), new f.b(28, new n0(21, 45), new n0(7, 46)), new f.b(30, new n0(1, 23), new n0(37, 24)), new f.b(30, new n0(19, 15), new n0(26, 16))), new b(30, new f.b(30, new n0(5, 115), new n0(10, 116)), new f.b(28, new n0(19, 47), new n0(10, 48)), new f.b(30, new n0(15, 24), new n0(25, 25)), new f.b(30, new n0(23, 15), new n0(25, 16))), new b(31, new f.b(30, new n0(13, 115), new n0(3, 116)), new f.b(28, new n0(2, 46), new n0(29, 47)), new f.b(30, new n0(42, 24), new n0(1, 25)), new f.b(30, new n0(23, 15), new n0(28, 16))), new b(32, new f.b(30, new n0(17, 115)), new f.b(28, new n0(10, 46), new n0(23, 47)), new f.b(30, new n0(10, 24), new n0(35, 25)), new f.b(30, new n0(19, 15), new n0(35, 16))), new b(33, new f.b(30, new n0(17, 115), new n0(1, 116)), new f.b(28, new n0(14, 46), new n0(21, 47)), new f.b(30, new n0(29, 24), new n0(19, 25)), new f.b(30, new n0(11, 15), new n0(46, 16))), new b(34, new f.b(30, new n0(13, 115), new n0(6, 116)), new f.b(28, new n0(14, 46), new n0(23, 47)), new f.b(30, new n0(44, 24), new n0(7, 25)), new f.b(30, new n0(59, 16), new n0(1, 17))), new b(35, new f.b(30, new n0(12, 121), new n0(7, 122)), new f.b(28, new n0(12, 47), new n0(26, 48)), new f.b(30, new n0(39, 24), new n0(14, 25)), new f.b(30, new n0(22, 15), new n0(41, 16))), new b(36, new f.b(30, new n0(6, 121), new n0(14, 122)), new f.b(28, new n0(6, 47), new n0(34, 48)), new f.b(30, new n0(46, 24), new n0(10, 25)), new f.b(30, new n0(2, 15), new n0(64, 16))), new b(37, new f.b(30, new n0(17, 122), new n0(4, 123)), new f.b(28, new n0(29, 46), new n0(14, 47)), new f.b(30, new n0(49, 24), new n0(10, 25)), new f.b(30, new n0(24, 15), new n0(46, 16))), new b(38, new f.b(30, new n0(4, 122), new n0(18, 123)), new f.b(28, new n0(13, 46), new n0(32, 47)), new f.b(30, new n0(48, 24), new n0(14, 25)), new f.b(30, new n0(42, 15), new n0(32, 16))), new b(39, new f.b(30, new n0(20, 117), new n0(4, 118)), new f.b(28, new n0(40, 47), new n0(7, 48)), new f.b(30, new n0(43, 24), new n0(22, 25)), new f.b(30, new n0(10, 15), new n0(67, 16))), new b(40, new f.b(30, new n0(19, 118), new n0(6, 119)), new f.b(28, new n0(18, 47), new n0(31, 48)), new f.b(30, new n0(34, 24), new n0(34, 25)), new f.b(30, new n0(20, 15), new n0(61, 16)))};
    }

    public static b b(int i2) {
        if (i2 <= 0 || i2 > 40) {
            throw new IllegalArgumentException();
        }
        return f538d[i2 - 1];
    }

    public final String toString() {
        return String.valueOf(this.f539a);
    }
}
