package s;

/* loaded from: classes.dex */
public final class a {

    /* renamed from: a, reason: collision with root package name */
    public final byte[] f542a;

    /* renamed from: b, reason: collision with root package name */
    public final byte[] f543b;

    public a(byte[] bArr, byte[] bArr2) {
        this.f542a = bArr;
        this.f543b = bArr2;
    }
}
