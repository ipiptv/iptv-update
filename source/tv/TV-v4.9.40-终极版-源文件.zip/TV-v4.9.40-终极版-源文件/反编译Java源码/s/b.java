package s;

import java.lang.reflect.Array;

/* loaded from: classes.dex */
public final class b {

    /* renamed from: a, reason: collision with root package name */
    public final byte[][] f544a;

    /* renamed from: b, reason: collision with root package name */
    public final int f545b;

    /* renamed from: c, reason: collision with root package name */
    public final int f546c;

    public b(int i2, int i3) {
        this.f544a = (byte[][]) Array.newInstance((Class<?>) Byte.TYPE, i3, i2);
        this.f545b = i2;
        this.f546c = i3;
    }

    public final byte a(int i2, int i3) {
        return this.f544a[i3][i2];
    }

    public final void b(int i2, int i3, int i4) {
        this.f544a[i3][i2] = (byte) i4;
    }

    public final void c(int i2, int i3, boolean z2) {
        this.f544a[i3][i2] = z2 ? (byte) 1 : (byte) 0;
    }

    public final String toString() {
        int i2 = this.f545b;
        int i3 = this.f546c;
        StringBuilder sb = new StringBuilder((i2 * 2 * i3) + 2);
        for (int i4 = 0; i4 < i3; i4++) {
            for (int i5 = 0; i5 < i2; i5++) {
                byte b2 = this.f544a[i4][i5];
                sb.append(b2 != 0 ? b2 != 1 ? "  " : " 1" : " 0");
            }
            sb.append('\n');
        }
        return sb.toString();
    }
}
