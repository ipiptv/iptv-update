package t;

import java.io.Serializable;

/* loaded from: classes.dex */
public final class b implements Serializable {

    /* renamed from: a, reason: collision with root package name */
    public final Object f547a;

    /* renamed from: b, reason: collision with root package name */
    public final Object f548b;

    public b(Object obj, Object obj2) {
        this.f547a = obj;
        this.f548b = obj2;
    }

    public final boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof b)) {
            return false;
        }
        b bVar = (b) obj;
        return b0.d.b(this.f547a, bVar.f547a) && b0.d.b(this.f548b, bVar.f548b);
    }

    public final int hashCode() {
        Object obj = this.f547a;
        int hashCode = (obj == null ? 0 : obj.hashCode()) * 31;
        Object obj2 = this.f548b;
        return hashCode + (obj2 != null ? obj2.hashCode() : 0);
    }

    public final String toString() {
        return "(" + this.f547a + ", " + this.f548b + ')';
    }
}
