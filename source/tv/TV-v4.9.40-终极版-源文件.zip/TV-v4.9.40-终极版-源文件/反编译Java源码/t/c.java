package t;

import java.io.Serializable;

/* loaded from: classes.dex */
public final class c implements Serializable {

    /* renamed from: a, reason: collision with root package name */
    public final Throwable f549a;

    public c(Throwable th) {
        this.f549a = th;
    }

    public final boolean equals(Object obj) {
        if (obj instanceof c) {
            if (b0.d.b(this.f549a, ((c) obj).f549a)) {
                return true;
            }
        }
        return false;
    }

    public final int hashCode() {
        return this.f549a.hashCode();
    }

    public final String toString() {
        return "Failure(" + this.f549a + ')';
    }
}
