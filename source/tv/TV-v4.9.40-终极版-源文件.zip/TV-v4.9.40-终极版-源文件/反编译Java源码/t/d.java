package t;

import java.io.Serializable;

/* loaded from: classes.dex */
public final class d implements a, Serializable {

    /* renamed from: a, reason: collision with root package name */
    public c0.a f550a;

    /* renamed from: b, reason: collision with root package name */
    public volatile Object f551b = e.f553a;

    /* renamed from: c, reason: collision with root package name */
    public final Object f552c = this;

    public d(c0.a aVar) {
        this.f550a = aVar;
    }

    public final Object a() {
        Object obj;
        Object obj2 = this.f551b;
        e eVar = e.f553a;
        if (obj2 != eVar) {
            return obj2;
        }
        synchronized (this.f552c) {
            obj = this.f551b;
            if (obj == eVar) {
                c0.a aVar = this.f550a;
                b0.d.h(aVar);
                obj = aVar.invoke();
                this.f551b = obj;
                this.f550a = null;
            }
        }
        return obj;
    }

    public final String toString() {
        return this.f551b != e.f553a ? String.valueOf(a()) : "Lazy value not initialized yet.";
    }
}
