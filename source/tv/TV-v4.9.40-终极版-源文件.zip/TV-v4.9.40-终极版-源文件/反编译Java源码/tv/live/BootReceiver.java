package tv.live;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Handler;
import android.os.Looper;

/* loaded from: classes.dex */
public final class BootReceiver extends BroadcastReceiver {
    public static final Companion Companion = new Companion(null);
    public static final int MAX_RETRY = 1;
    public static final long RETRY_INTERVAL_MS = 4000;
    public static final long START_DELAY_MS = 3000;

    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(d0.a aVar) {
            this();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean hasNetwork(Context context) {
        Network activeNetwork;
        NetworkCapabilities networkCapabilities;
        try {
            Object systemService = context.getSystemService("connectivity");
            b0.d.i(systemService, "null cannot be cast to non-null type android.net.ConnectivityManager");
            ConnectivityManager connectivityManager = (ConnectivityManager) systemService;
            activeNetwork = connectivityManager.getActiveNetwork();
            if (activeNetwork == null || (networkCapabilities = connectivityManager.getNetworkCapabilities(activeNetwork)) == null) {
                return false;
            }
            return networkCapabilities.hasCapability(12);
        } catch (Exception unused) {
            return false;
        }
    }

    @Override // android.content.BroadcastReceiver
    public void onReceive(Context context, Intent intent) {
        b0.d.k(context, "context");
        if (context.getSharedPreferences("tv", 0).getBoolean("boot", true)) {
            final BroadcastReceiver.PendingResult goAsync = goAsync();
            final Context applicationContext = context.getApplicationContext();
            final Handler handler = new Handler(Looper.getMainLooper());
            handler.postDelayed(new Runnable() { // from class: tv.live.BootReceiver$onReceive$attempt$1
                private int tries;

                public final int getTries() {
                    return this.tries;
                }

                @Override // java.lang.Runnable
                public void run() {
                    boolean hasNetwork;
                    if (this.tries < 1) {
                        BootReceiver bootReceiver = BootReceiver.this;
                        Context context2 = applicationContext;
                        b0.d.j(context2, "$appContext");
                        hasNetwork = bootReceiver.hasNetwork(context2);
                        if (!hasNetwork) {
                            this.tries++;
                            handler.postDelayed(this, BootReceiver.RETRY_INTERVAL_MS);
                            return;
                        }
                    }
                    Intent intent2 = new Intent(applicationContext, (Class<?>) MainActivity.class);
                    intent2.addFlags(268435456);
                    applicationContext.startActivity(intent2);
                    goAsync.finish();
                }

                public final void setTries(int i2) {
                    this.tries = i2;
                }
            }, START_DELAY_MS);
        }
    }
}
