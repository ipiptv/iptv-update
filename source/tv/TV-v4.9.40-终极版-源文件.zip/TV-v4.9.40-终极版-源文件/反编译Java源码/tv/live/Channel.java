package tv.live;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/* loaded from: classes.dex */
public final class Channel {
    private final String group;
    private final String name;
    private int number;
    private final Map<String, String> urlSrc;
    private final List<String> urls;

    public Channel(String str, String str2, List<String> list) {
        b0.d.k(str, "name");
        b0.d.k(str2, "group");
        b0.d.k(list, "urls");
        this.name = str;
        this.group = str2;
        this.urls = list;
        this.urlSrc = new LinkedHashMap();
    }

    /* JADX WARN: Multi-variable type inference failed */
    public static /* synthetic */ Channel copy$default(Channel channel, String str, String str2, List list, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            str = channel.name;
        }
        if ((i2 & 2) != 0) {
            str2 = channel.group;
        }
        if ((i2 & 4) != 0) {
            list = channel.urls;
        }
        return channel.copy(str, str2, list);
    }

    public final String component1() {
        return this.name;
    }

    public final String component2() {
        return this.group;
    }

    public final List<String> component3() {
        return this.urls;
    }

    public final Channel copy(String str, String str2, List<String> list) {
        b0.d.k(str, "name");
        b0.d.k(str2, "group");
        b0.d.k(list, "urls");
        return new Channel(str, str2, list);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof Channel)) {
            return false;
        }
        Channel channel = (Channel) obj;
        return b0.d.b(this.name, channel.name) && b0.d.b(this.group, channel.group) && b0.d.b(this.urls, channel.urls);
    }

    public final String getGroup() {
        return this.group;
    }

    public final String getName() {
        return this.name;
    }

    public final int getNumber() {
        return this.number;
    }

    public final Map<String, String> getUrlSrc() {
        return this.urlSrc;
    }

    public final List<String> getUrls() {
        return this.urls;
    }

    public int hashCode() {
        return this.urls.hashCode() + ((this.group.hashCode() + (this.name.hashCode() * 31)) * 31);
    }

    public final void setNumber(int i2) {
        this.number = i2;
    }

    public String toString() {
        return "Channel(name=" + this.name + ", group=" + this.group + ", urls=" + this.urls + ')';
    }

    public /* synthetic */ Channel(String str, String str2, List list, int i2, d0.a aVar) {
        this(str, (i2 & 2) != 0 ? "未分组" : str2, (i2 & 4) != 0 ? new ArrayList() : list);
    }
}
