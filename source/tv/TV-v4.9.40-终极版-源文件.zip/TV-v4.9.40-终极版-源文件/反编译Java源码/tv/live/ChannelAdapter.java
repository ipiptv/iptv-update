package tv.live;

import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.i0;
import androidx.recyclerview.widget.i1;
import java.util.List;

/* loaded from: classes.dex */
public final class ChannelAdapter extends i0 {
    private boolean focused;
    private final List<Channel> list;
    private final c0.b onClick;
    private final c0.b onLongClick;
    private c0.b programProvider;
    private int rowHeightPx;
    private int selected;
    private c0.b sourceInfoProvider;
    private float textSizePx;

    public static final class VH extends i1 {
        private final ImageView icon;
        private final TextView name;
        private final TextView num;
        private final TextView programName;
        private final View programRow;
        private final TextView sourceInfo;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public VH(View view) {
            super(view);
            b0.d.k(view, "v");
            View findViewById = view.findViewById(R.id.channelNum);
            b0.d.j(findViewById, "findViewById(...)");
            this.num = (TextView) findViewById;
            View findViewById2 = view.findViewById(R.id.channelIcon);
            b0.d.j(findViewById2, "findViewById(...)");
            this.icon = (ImageView) findViewById2;
            View findViewById3 = view.findViewById(R.id.channelName);
            b0.d.j(findViewById3, "findViewById(...)");
            this.name = (TextView) findViewById3;
            View findViewById4 = view.findViewById(R.id.programRow);
            b0.d.j(findViewById4, "findViewById(...)");
            this.programRow = findViewById4;
            View findViewById5 = view.findViewById(R.id.programName);
            b0.d.j(findViewById5, "findViewById(...)");
            this.programName = (TextView) findViewById5;
            View findViewById6 = view.findViewById(R.id.sourceInfo);
            b0.d.j(findViewById6, "findViewById(...)");
            this.sourceInfo = (TextView) findViewById6;
        }

        public final ImageView getIcon() {
            return this.icon;
        }

        public final TextView getName() {
            return this.name;
        }

        public final TextView getNum() {
            return this.num;
        }

        public final TextView getProgramName() {
            return this.programName;
        }

        public final View getProgramRow() {
            return this.programRow;
        }

        public final TextView getSourceInfo() {
            return this.sourceInfo;
        }
    }

    public ChannelAdapter(List<Channel> list, int i2, int i3, float f2, boolean z2, c0.b bVar, c0.b bVar2, c0.b bVar3, c0.b bVar4) {
        b0.d.k(list, "list");
        this.list = list;
        this.selected = i2;
        this.rowHeightPx = i3;
        this.textSizePx = f2;
        this.focused = z2;
        this.programProvider = bVar;
        this.sourceInfoProvider = bVar2;
        this.onClick = bVar3;
        this.onLongClick = bVar4;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBindViewHolder$lambda$0(VH vh, ChannelAdapter channelAdapter, Channel channel) {
        TextView name;
        float f2;
        b0.d.k(vh, "$holder");
        b0.d.k(channelAdapter, "this$0");
        b0.d.k(channel, "$c");
        int width = vh.getName().getWidth();
        if (width <= 0 || channelAdapter.textSizePx <= RecyclerView.B0) {
            return;
        }
        float measureText = vh.getName().getPaint().measureText(channel.getName());
        float f3 = width;
        if (measureText > f3) {
            float f4 = ((f3 / measureText) * channelAdapter.textSizePx) - 1.0f;
            name = vh.getName();
            f2 = Math.max(f4, channelAdapter.textSizePx * 0.5f);
        } else {
            name = vh.getName();
            f2 = channelAdapter.textSizePx;
        }
        name.setTextSize(0, f2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBindViewHolder$lambda$1(VH vh, String str) {
        b0.d.k(vh, "$holder");
        int width = vh.getProgramName().getWidth();
        if (width > 0) {
            float measureText = vh.getProgramName().getPaint().measureText(str);
            float f2 = width;
            vh.getProgramName().setSelected(measureText > f2);
            vh.getProgramName().setEllipsize(measureText > f2 ? TextUtils.TruncateAt.MARQUEE : TextUtils.TruncateAt.END);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBindViewHolder$lambda$2(ChannelAdapter channelAdapter, int i2, View view) {
        b0.d.k(channelAdapter, "this$0");
        c0.b bVar = channelAdapter.onClick;
        if (bVar != null) {
            bVar.invoke(Integer.valueOf(i2));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean onBindViewHolder$lambda$3(ChannelAdapter channelAdapter, int i2, View view) {
        b0.d.k(channelAdapter, "this$0");
        c0.b bVar = channelAdapter.onLongClick;
        if (bVar == null) {
            return true;
        }
        bVar.invoke(Integer.valueOf(i2));
        return true;
    }

    public final boolean getFocused() {
        return this.focused;
    }

    @Override // androidx.recyclerview.widget.i0
    public int getItemCount() {
        return this.list.size();
    }

    public final c0.b getProgramProvider() {
        return this.programProvider;
    }

    public final int getRowHeightPx() {
        return this.rowHeightPx;
    }

    public final int getSelected() {
        return this.selected;
    }

    public final c0.b getSourceInfoProvider() {
        return this.sourceInfoProvider;
    }

    public final float getTextSizePx() {
        return this.textSizePx;
    }

    public final void setFocused(boolean z2) {
        this.focused = z2;
    }

    public final void setProgramProvider(c0.b bVar) {
        this.programProvider = bVar;
    }

    public final void setRowHeightPx(int i2) {
        this.rowHeightPx = i2;
    }

    public final void setSelected(int i2) {
        this.selected = i2;
    }

    public final void setSourceInfoProvider(c0.b bVar) {
        this.sourceInfoProvider = bVar;
    }

    public final void setTextSizePx(float f2) {
        this.textSizePx = f2;
    }

    public /* synthetic */ ChannelAdapter(List list, int i2, int i3, float f2, boolean z2, c0.b bVar, c0.b bVar2, c0.b bVar3, c0.b bVar4, int i4, d0.a aVar) {
        this(list, (i4 & 2) != 0 ? 0 : i2, (i4 & 4) != 0 ? 0 : i3, (i4 & 8) != 0 ? RecyclerView.B0 : f2, (i4 & 16) == 0 ? z2 : false, (i4 & 32) != 0 ? null : bVar, (i4 & 64) != 0 ? null : bVar2, (i4 & 128) != 0 ? null : bVar3, (i4 & 256) == 0 ? bVar4 : null);
    }

    @Override // androidx.recyclerview.widget.i0
    public void onBindViewHolder(VH vh, final int i2) {
        b0.d.k(vh, "holder");
        if (this.rowHeightPx > 0) {
            ViewGroup.LayoutParams layoutParams = vh.itemView.getLayoutParams();
            int i3 = this.rowHeightPx;
            layoutParams.height = i3;
            int i4 = (int) (i3 * 0.26f);
            ViewGroup.LayoutParams layoutParams2 = vh.getIcon().getLayoutParams();
            layoutParams2.width = i4;
            layoutParams2.height = i4;
            vh.getIcon().setLayoutParams(layoutParams2);
        }
        int i5 = 0;
        if (this.textSizePx > RecyclerView.B0) {
            vh.getNum().setTextSize(0, this.textSizePx * 0.62f);
            vh.getName().setTextSize(0, this.textSizePx);
        }
        Channel channel = this.list.get(i2);
        vh.getNum().setText(String.valueOf(channel.getNumber() > 0 ? channel.getNumber() : i2 + 1));
        vh.getName().setText(channel.getName());
        vh.getName().post(new a(vh, this, channel, i5));
        c0.b bVar = this.programProvider;
        String str = bVar != null ? (String) bVar.invoke(channel.getName()) : null;
        if (str == null || str.length() == 0) {
            vh.getProgramRow().setVisibility(4);
            vh.getProgramName().setText("");
            vh.getProgramName().setSelected(false);
        } else {
            vh.getProgramRow().setVisibility(0);
            vh.getProgramName().setText(str);
            vh.getProgramName().post(new o(vh, str, 2));
        }
        c0.b bVar2 = this.sourceInfoProvider;
        String str2 = bVar2 != null ? (String) bVar2.invoke(channel) : null;
        if (str2 == null || str2.length() == 0) {
            vh.getSourceInfo().setVisibility(8);
            vh.getSourceInfo().setText("");
        } else {
            vh.getSourceInfo().setVisibility(0);
            vh.getSourceInfo().setText(str2);
        }
        vh.getName().setAlpha(this.focused ? 1.0f : 0.88f);
        vh.itemView.setBackgroundColor(i2 == this.selected ? this.focused ? -871736167 : -1727116163 : 0);
        vh.itemView.setOnClickListener(new b(this, i2, i5));
        vh.itemView.setOnLongClickListener(new View.OnLongClickListener() { // from class: tv.live.c
            @Override // android.view.View.OnLongClickListener
            public final boolean onLongClick(View view) {
                boolean onBindViewHolder$lambda$3;
                onBindViewHolder$lambda$3 = ChannelAdapter.onBindViewHolder$lambda$3(ChannelAdapter.this, i2, view);
                return onBindViewHolder$lambda$3;
            }
        });
        vh.itemView.setFocusable(true);
    }

    @Override // androidx.recyclerview.widget.i0
    public VH onCreateViewHolder(ViewGroup viewGroup, int i2) {
        b0.d.k(viewGroup, "parent");
        View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_channel, viewGroup, false);
        b0.d.h(inflate);
        return new VH(inflate);
    }
}
