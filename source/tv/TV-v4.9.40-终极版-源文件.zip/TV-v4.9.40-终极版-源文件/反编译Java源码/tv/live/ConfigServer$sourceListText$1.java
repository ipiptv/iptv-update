package tv.live;

/* loaded from: classes.dex */
public final class ConfigServer$sourceListText$1 extends d0.c implements c0.b {
    final /* synthetic */ String $cur;
    final /* synthetic */ ConfigServer this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public ConfigServer$sourceListText$1(String str, ConfigServer configServer) {
        super(1);
        this.$cur = str;
        this.this$0 = configServer;
    }

    @Override // c0.b
    public final CharSequence invoke(SourceItem sourceItem) {
        String escape;
        String escape2;
        b0.d.k(sourceItem, "s");
        String str = b0.d.b(sourceItem.getId(), this.$cur) ? "● " : "○ ";
        StringBuilder sb = new StringBuilder("<div class='cur'>");
        sb.append(str);
        sb.append("<b>");
        escape = this.this$0.escape(sourceItem.getName());
        sb.append(escape);
        sb.append("</b> · ");
        escape2 = this.this$0.escape(sourceItem.getUrl());
        sb.append(escape2);
        sb.append("</div>");
        return sb.toString();
    }
}
