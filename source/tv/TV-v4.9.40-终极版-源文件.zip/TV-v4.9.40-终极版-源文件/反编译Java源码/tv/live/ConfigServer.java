package tv.live;

import android.content.Context;
import java.io.File;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URLDecoder;
import java.nio.charset.Charset;
import java.util.Arrays;
import java.util.Iterator;

/* loaded from: classes.dex */
public final class ConfigServer {
    private final Context context;
    private final c0.b onApkUploaded;
    private final c0.e onSourceUpdated;
    private final c0.a onUpdateNow;
    private final int port;
    private volatile boolean running;
    private ServerSocket serverSocket;
    private Thread thread;

    /* renamed from: tv.live.ConfigServer$1, reason: invalid class name */
    public static final class AnonymousClass1 extends d0.c implements c0.a {
        public static final AnonymousClass1 INSTANCE = new AnonymousClass1();

        public AnonymousClass1() {
            super(0);
        }

        @Override // c0.a
        public /* bridge */ /* synthetic */ Object invoke() {
            m0invoke();
            return t.g.f554a;
        }

        /* renamed from: invoke, reason: collision with other method in class */
        public final void m0invoke() {
        }
    }

    /* renamed from: tv.live.ConfigServer$2, reason: invalid class name */
    public static final class AnonymousClass2 extends d0.c implements c0.b {
        public static final AnonymousClass2 INSTANCE = new AnonymousClass2();

        public AnonymousClass2() {
            super(1);
        }

        @Override // c0.b
        public /* bridge */ /* synthetic */ Object invoke(Object obj) {
            invoke((File) obj);
            return t.g.f554a;
        }

        public final void invoke(File file) {
            b0.d.k(file, "it");
        }
    }

    public ConfigServer(Context context, int i2, c0.e eVar, c0.a aVar, c0.b bVar) {
        b0.d.k(context, "context");
        b0.d.k(eVar, "onSourceUpdated");
        b0.d.k(aVar, "onUpdateNow");
        b0.d.k(bVar, "onApkUploaded");
        this.context = context;
        this.port = i2;
        this.onSourceUpdated = eVar;
        this.onUpdateNow = aVar;
        this.onApkUploaded = bVar;
    }

    private final String currentUpdateUrl() {
        String string = this.context.getSharedPreferences("tv", 0).getString("update_url", "");
        return string == null ? "" : string;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String escape(String str) {
        return h0.h.Y(h0.h.Y(h0.h.Y(str, "&", "&amp;"), "<", "&lt;"), ">", "&gt;");
    }

    private final t.b extractFilePart(byte[] bArr, String str) {
        byte[] bytes = "filename=\"".getBytes(h0.a.f476c);
        b0.d.j(bytes, "getBytes(...)");
        Integer indexOf$default = indexOf$default(this, bArr, bytes, 0, 4, null);
        if (indexOf$default != null) {
            int intValue = indexOf$default.intValue();
            int length = bytes.length + intValue;
            int i2 = length;
            while (i2 < bArr.length && bArr[i2] != 34) {
                i2++;
            }
            String str2 = new String(bArr, length, i2 - length, h0.a.f474a);
            Charset charset = h0.a.f476c;
            byte[] bytes2 = "\r\n\r\n".getBytes(charset);
            b0.d.j(bytes2, "getBytes(...)");
            Integer indexOf = indexOf(bArr, bytes2, intValue);
            if (indexOf != null) {
                int intValue2 = indexOf.intValue() + 4;
                byte[] bytes3 = ("\r\n--" + str).getBytes(charset);
                b0.d.j(bytes3, "getBytes(...)");
                Integer indexOf2 = indexOf(bArr, bytes3, intValue2);
                int intValue3 = indexOf2 != null ? indexOf2.intValue() : bArr.length;
                if (intValue3 <= intValue2) {
                    return null;
                }
                int length2 = bArr.length;
                if (intValue3 <= length2) {
                    byte[] copyOfRange = Arrays.copyOfRange(bArr, intValue2, intValue3);
                    b0.d.j(copyOfRange, "copyOfRange(...)");
                    return new t.b(str2, copyOfRange);
                }
                throw new IndexOutOfBoundsException("toIndex (" + intValue3 + ") is greater than size (" + length2 + ").");
            }
        }
        return null;
    }

    /* JADX WARN: Code restructure failed: missing block: B:52:0x0172, code lost:
    
        if (r2 == null) goto L65;
     */
    /* JADX WARN: Removed duplicated region for block: B:144:0x02fb  */
    /* JADX WARN: Removed duplicated region for block: B:146:0x0301  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void handle(java.net.Socket r17) {
        /*
            Method dump skipped, instructions count: 965
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: tv.live.ConfigServer.handle(java.net.Socket):void");
    }

    private final Integer indexOf(byte[] bArr, byte[] bArr2, int i2) {
        if (!(bArr2.length == 0) && bArr.length >= bArr2.length) {
            if (i2 < 0) {
                i2 = 0;
            }
            while (i2 <= bArr.length - bArr2.length) {
                int i3 = 0;
                while (i3 < bArr2.length && bArr[i2 + i3] == bArr2[i3]) {
                    i3++;
                }
                if (i3 == bArr2.length) {
                    return Integer.valueOf(i2);
                }
                i2++;
            }
        }
        return null;
    }

    public static /* synthetic */ Integer indexOf$default(ConfigServer configServer, byte[] bArr, byte[] bArr2, int i2, int i3, Object obj) {
        if ((i3 & 4) != 0) {
            i2 = 0;
        }
        return configServer.indexOf(bArr, bArr2, i2);
    }

    private final String page(String str, String str2, String str3, String str4) {
        String str5;
        StringBuilder sb;
        String str6;
        if (str2.length() == 0) {
            str5 = "";
        } else {
            str5 = "<div class=\"msg\"><b>" + escape(str) + "</b><span>" + str2 + "</span></div>";
        }
        String str7 = b0.d.b(str4, "update") ? "" : " on";
        String str8 = b0.d.b(str4, "update") ? " on" : "";
        String sourceListText = sourceListText();
        if (h0.h.T(sourceListText)) {
            sourceListText = "<div class=\"hint\">还没有其它源</div>";
        }
        StringBuilder sb2 = new StringBuilder("<!DOCTYPE html>\n<html lang=\"zh\">\n<head>\n<meta charset=\"utf-8\">\n<meta name=\"viewport\" content=\"width=device-width, initial-scale=1, viewport-fit=cover\">\n<title>TV 订阅源</title>\n<style>\n*{box-sizing:border-box;-webkit-tap-highlight-color:transparent;}\nbody{margin:0;padding:16px 16px 108px;background:#0b0d10;color:#e8eaed;\n     font:15px/1.5 -apple-system,BlinkMacSystemFont,\"Segoe UI\",Roboto,\"PingFang SC\",\"Microsoft YaHei\",sans-serif;\n     -webkit-text-size-adjust:100%;}\nh1{font-size:19px;margin:2px 0 4px;font-weight:600;}\n.sub{color:#9aa0a6;font-size:13px;margin-bottom:14px;}\n.tabs{display:flex;gap:6px;background:#14181f;border:1px solid #242932;border-radius:12px;padding:5px;margin-bottom:14px;}\n.tabs a{flex:1;text-align:center;padding:10px 0;border-radius:8px;color:#9aa0a6;text-decoration:none;font-size:14px;}\n.tabs a.on{background:#1f6feb;color:#fff;}\n.card{background:#14181f;border:1px solid #242932;border-radius:14px;padding:16px;margin-bottom:14px;}\n.card h2{font-size:15px;margin:0 0 4px;font-weight:600;}\nlabel{display:block;font-size:12px;color:#9aa0a6;margin:14px 0 6px;}\ninput[type=text],input[type=file]{display:block;width:100%;padding:13px;border-radius:10px;border:1px solid #242932;\n     background:#0f1318;color:#fff;font-size:16px;outline:none;}\ninput[type=text]:focus{border-color:#1f6feb;}\ninput[type=text]::placeholder{color:#5c636b;}\n.sw{display:flex;align-items:center;justify-content:space-between;margin-top:16px;padding:12px 14px;\n    background:#0f1318;border:1px solid #242932;border-radius:10px;}\n.sw span{font-size:14px;}\n.sw input{width:22px;height:22px;}\n.msg{display:flex;flex-direction:column;gap:3px;background:#0d2a17;border:1px solid #1f6f4a;border-radius:12px;\n     padding:12px 14px;margin-bottom:14px;font-size:13px;color:#8fe0ab;}\n.msg b{font-size:14px;color:#b7f5cf;}\n.src{display:flex;align-items:flex-start;gap:10px;padding:12px 14px;border:1px solid #242932;\n     border-radius:10px;margin-top:10px;background:#0f1318;}\n.src .nm{font-size:14px;font-weight:600;margin-bottom:3px;}\n.src .u{font-size:12px;color:#9aa0a6;word-break:break-all;display:-webkit-box;-webkit-line-clamp:2;\n     -webkit-box-orient:vertical;overflow:hidden;}\n.badge{flex:0 0 auto;font-size:11px;padding:3px 8px;border-radius:999px;background:#12240f;color:#7ee2a8;border:1px solid #2ea04355;}\n.submit{position:fixed;left:16px;right:16px;bottom:calc(16px + env(safe-area-inset-bottom));padding:15px;\n     border:0;border-radius:12px;background:#1f6feb;color:#fff;font-size:16px;font-weight:600;}\n.hint{font-size:12px;color:#7c8288;margin-top:10px;line-height:1.6;}\ndetails summary{font-size:13px;color:#9aa0a6;cursor:pointer;padding:8px 0;}\n</style>\n</head>\n<body>\n  <h1>TV 订阅源</h1>\n  <div class=\"sub\">手机与电视连同一个 WiFi，改完立刻生效</div>\n  <div class=\"tabs\">\n    <a class=\"tab");
        sb2.append(str7);
        sb2.append("\" href=\"/\">订阅源</a>\n    <a class=\"tab");
        sb2.append(str8);
        sb2.append("\" href=\"/?tab=update\">安装更新</a>\n  </div>\n  ");
        sb2.append(str5);
        sb2.append("\n  ");
        if (b0.d.b(str4, "update")) {
            sb = new StringBuilder("<form method=\"post\" action=\"/uploadApk\" enctype=\"multipart/form-data\">\n    <div class=\"card\">\n      <h2>上传安装包</h2>\n      <label>选择 APK 文件</label>\n      <input type=\"file\" name=\"apk\" accept=\".apk\">\n      <div class=\"hint\">上传后电视会弹出系统安装确认，用遥控器点「安装」即可覆盖。</div>\n    </div>\n    <button class=\"submit\" type=\"submit\">上传到电视并安装</button>\n  </form>\n  <div class=\"card\">\n    <details>\n      <summary>或者：填安装包直链地址</summary>\n      <form method=\"post\" action=\"/saveUpdate\">\n        <label>新版安装包地址（.apk 直链）</label>\n        <input type=\"text\" name=\"apkurl\" inputmode=\"url\" autocapitalize=\"off\" autocorrect=\"off\" spellcheck=\"false\"\n               value=\"");
            sb.append(escape(str3));
            str6 = "\" placeholder=\"https://example.com/TV-latest.apk\">\n        <div class=\"sw\"><span>保存后立即下载安装</span><input type=\"checkbox\" name=\"now\" checked></div>\n        <button class=\"submit\" type=\"submit\">保存并检查更新</button>\n      </form>\n    </details>\n  </div>";
        } else {
            sb = new StringBuilder("<form method=\"post\" action=\"/save\">\n    <div class=\"card\">\n      <h2>添加订阅源</h2>\n      <label>源名称（可留空）</label>\n      <input type=\"text\" name=\"name\" inputmode=\"text\" autocapitalize=\"off\" autocorrect=\"off\" spellcheck=\"false\"\n             placeholder=\"例如：我的源\">\n      <label>订阅源地址（m3u / m3u8 列表）</label>\n      <input type=\"text\" name=\"url\" inputmode=\"url\" autocapitalize=\"off\" autocorrect=\"off\" spellcheck=\"false\"\n             placeholder=\"https://example.com/list.m3u\">\n      <label>UA（可留空，留空用默认）</label>\n      <input type=\"text\" name=\"ua\" inputmode=\"text\" autocapitalize=\"off\" autocorrect=\"off\" spellcheck=\"false\"\n             placeholder=\"默认：Mozilla/5.0 (Linux; Android) TV/1.0\">\n      <div class=\"sw\"><span>立即切换使用这个源</span><input type=\"checkbox\" name=\"current\" checked></div>\n    </div>\n    <button class=\"submit\" type=\"submit\">添加到电视</button>\n  </form>\n  <div class=\"card\">\n    <h2>电视上已有的源</h2>\n    ");
            sb.append(sourceListText);
            str6 = "\n  </div>";
        }
        sb.append(str6);
        sb2.append(sb.toString());
        sb2.append("\n</body>\n</html>");
        return sb2.toString();
    }

    public static /* synthetic */ String page$default(ConfigServer configServer, String str, String str2, String str3, String str4, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            str3 = "";
        }
        if ((i2 & 8) != 0) {
            str4 = "source";
        }
        return configServer.page(str, str2, str3, str4);
    }

    private final String parseField(String str, String str2) {
        Object obj;
        Iterator it = h0.h.c0(str, new String[]{"&"}).iterator();
        while (true) {
            if (!it.hasNext()) {
                obj = null;
                break;
            }
            obj = it.next();
            if (h0.h.d0((String) obj, str2 + '=', false)) {
                break;
            }
        }
        String str3 = (String) obj;
        if (str3 == null) {
            return null;
        }
        try {
            String decode = URLDecoder.decode(h0.h.g0(str3, str2 + '=', str3), "UTF-8");
            b0.d.j(decode, "decode(...)");
            return h0.h.j0(decode).toString();
        } catch (Exception unused) {
            return null;
        }
    }

    private final byte[] readFully(InputStream inputStream, int i2) {
        byte[] bArr = new byte[i2];
        int i3 = 0;
        while (i3 < i2) {
            int read = inputStream.read(bArr, i3, i2 - i3);
            if (read <= 0) {
                break;
            }
            i3 += read;
        }
        if (i3 == i2) {
            return bArr;
        }
        byte[] copyOf = Arrays.copyOf(bArr, i3);
        b0.d.j(copyOf, "copyOf(...)");
        return copyOf;
    }

    private final String sourceListText() {
        SourceStore sourceStore = SourceStore.INSTANCE;
        return u.i.Q(sourceStore.load(this.context), "", null, null, new ConfigServer$sourceListText$1(sourceStore.currentId(this.context), this), 30);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void start$lambda$0(ConfigServer configServer) {
        b0.d.k(configServer, "this$0");
        try {
            ServerSocket serverSocket = new ServerSocket(configServer.port);
            configServer.serverSocket = serverSocket;
            while (configServer.running) {
                Socket accept = serverSocket.accept();
                try {
                    b0.d.h(accept);
                    configServer.handle(accept);
                } catch (Exception unused) {
                } catch (Throwable th) {
                    try {
                        accept.close();
                    } catch (Exception unused2) {
                    }
                    throw th;
                }
                try {
                    accept.close();
                } catch (Exception unused3) {
                }
            }
        } catch (Exception unused4) {
        }
    }

    private final void writeHtml(OutputStream outputStream, String str) {
        Charset charset = h0.a.f474a;
        byte[] bytes = str.getBytes(charset);
        b0.d.j(bytes, "getBytes(...)");
        byte[] bytes2 = ("HTTP/1.1 200 OK\r\nContent-Type: text/html; charset=utf-8\r\nContent-Length: " + bytes.length + "\r\nConnection: close\r\n\r\n").getBytes(charset);
        b0.d.j(bytes2, "getBytes(...)");
        outputStream.write(bytes2);
        outputStream.write(bytes);
        outputStream.flush();
    }

    public final void start() {
        if (this.running) {
            return;
        }
        this.running = true;
        Thread thread = new Thread(new d(0, this));
        thread.setDaemon(true);
        thread.start();
        this.thread = thread;
    }

    public final void stop() {
        this.running = false;
        try {
            ServerSocket serverSocket = this.serverSocket;
            if (serverSocket != null) {
                serverSocket.close();
            }
        } catch (Exception unused) {
        }
        this.serverSocket = null;
        Thread thread = this.thread;
        if (thread != null) {
            thread.interrupt();
        }
        this.thread = null;
    }

    public /* synthetic */ ConfigServer(Context context, int i2, c0.e eVar, c0.a aVar, c0.b bVar, int i3, d0.a aVar2) {
        this(context, (i3 & 2) != 0 ? 8888 : i2, eVar, (i3 & 8) != 0 ? AnonymousClass1.INSTANCE : aVar, (i3 & 16) != 0 ? AnonymousClass2.INSTANCE : bVar);
    }
}
