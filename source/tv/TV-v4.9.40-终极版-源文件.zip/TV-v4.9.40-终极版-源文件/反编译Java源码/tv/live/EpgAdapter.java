package tv.live;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.i0;
import androidx.recyclerview.widget.i1;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

/* loaded from: classes.dex */
public final class EpgAdapter extends i0 {
    private boolean focused;
    private final SimpleDateFormat hm;
    private final List<EpgProgram> list;
    private final c0.b onClick;
    private int rowHeightPx;
    private int selected;
    private float textSizePx;

    public static final class VH extends i1 {
        private final TextView badge;
        private final TextView time;
        private final TextView title;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public VH(View view) {
            super(view);
            b0.d.k(view, "v");
            View findViewById = view.findViewById(R.id.epgTime);
            b0.d.j(findViewById, "findViewById(...)");
            this.time = (TextView) findViewById;
            View findViewById2 = view.findViewById(R.id.epgTitle);
            b0.d.j(findViewById2, "findViewById(...)");
            this.title = (TextView) findViewById2;
            View findViewById3 = view.findViewById(R.id.epgBadge);
            b0.d.j(findViewById3, "findViewById(...)");
            this.badge = (TextView) findViewById3;
        }

        public final TextView getBadge() {
            return this.badge;
        }

        public final TextView getTime() {
            return this.time;
        }

        public final TextView getTitle() {
            return this.title;
        }
    }

    public EpgAdapter(List<EpgProgram> list, int i2, int i3, float f2, boolean z2, c0.b bVar) {
        b0.d.k(list, "list");
        this.list = list;
        this.selected = i2;
        this.rowHeightPx = i3;
        this.textSizePx = f2;
        this.focused = z2;
        this.onClick = bVar;
        this.hm = new SimpleDateFormat("HH:mm", Locale.CHINA);
    }

    private final boolean isNow(EpgProgram epgProgram) {
        long currentTimeMillis = System.currentTimeMillis();
        return currentTimeMillis >= epgProgram.getStartMillis() && currentTimeMillis < epgProgram.getEndMillis();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBindViewHolder$lambda$0(EpgAdapter epgAdapter, int i2, View view) {
        b0.d.k(epgAdapter, "this$0");
        c0.b bVar = epgAdapter.onClick;
        if (bVar != null) {
            bVar.invoke(Integer.valueOf(i2));
        }
    }

    public final boolean getFocused() {
        return this.focused;
    }

    @Override // androidx.recyclerview.widget.i0
    public int getItemCount() {
        return this.list.size();
    }

    public final int getRowHeightPx() {
        return this.rowHeightPx;
    }

    public final int getSelected() {
        return this.selected;
    }

    public final float getTextSizePx() {
        return this.textSizePx;
    }

    public final void setFocused(boolean z2) {
        this.focused = z2;
    }

    public final void setRowHeightPx(int i2) {
        this.rowHeightPx = i2;
    }

    public final void setSelected(int i2) {
        this.selected = i2;
    }

    public final void setTextSizePx(float f2) {
        this.textSizePx = f2;
    }

    public /* synthetic */ EpgAdapter(List list, int i2, int i3, float f2, boolean z2, c0.b bVar, int i4, d0.a aVar) {
        this(list, (i4 & 2) != 0 ? 0 : i2, (i4 & 4) == 0 ? i3 : 0, (i4 & 8) != 0 ? RecyclerView.B0 : f2, (i4 & 16) != 0 ? true : z2, (i4 & 32) != 0 ? null : bVar);
    }

    @Override // androidx.recyclerview.widget.i0
    public void onBindViewHolder(VH vh, int i2) {
        b0.d.k(vh, "holder");
        if (this.rowHeightPx > 0) {
            vh.itemView.getLayoutParams().height = this.rowHeightPx;
        }
        if (this.textSizePx > RecyclerView.B0) {
            vh.getTitle().setTextSize(0, this.textSizePx * 0.92f);
            vh.getTime().setTextSize(0, this.textSizePx * 0.7f);
        }
        EpgProgram epgProgram = this.list.get(i2);
        vh.getTime().setText(this.hm.format(new Date(epgProgram.getStartMillis())));
        vh.getTitle().setText(epgProgram.getTitle());
        boolean isNow = isNow(epgProgram);
        vh.getBadge().setText(isNow ? "正在播出" : "");
        vh.getTitle().setTextColor(isNow ? -8395777 : (i2 == this.selected && this.focused) ? -1 : -2039584);
        vh.itemView.setBackgroundColor(i2 == this.selected ? this.focused ? -871736167 : -1727116163 : 0);
        vh.itemView.setOnClickListener(new b(this, i2, 1));
        vh.itemView.setFocusable(true);
    }

    @Override // androidx.recyclerview.widget.i0
    public VH onCreateViewHolder(ViewGroup viewGroup, int i2) {
        b0.d.k(viewGroup, "parent");
        View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_epg, viewGroup, false);
        b0.d.h(inflate);
        return new VH(inflate);
    }
}
