package tv.live;

/* loaded from: classes.dex */
public final class EpgAdapterKt {
    private static final int FOCUS_BG = -871736167;
    private static final int FOCUS_BG_DIM = -1727116163;
}
