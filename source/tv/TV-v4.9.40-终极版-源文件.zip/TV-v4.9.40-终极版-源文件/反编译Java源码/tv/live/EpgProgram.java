package tv.live;

/* loaded from: classes.dex */
public final class EpgProgram {
    private final long endMillis;
    private final long startMillis;
    private final String title;

    public EpgProgram(long j2, long j3, String str) {
        b0.d.k(str, "title");
        this.startMillis = j2;
        this.endMillis = j3;
        this.title = str;
    }

    public static /* synthetic */ EpgProgram copy$default(EpgProgram epgProgram, long j2, long j3, String str, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            j2 = epgProgram.startMillis;
        }
        long j4 = j2;
        if ((i2 & 2) != 0) {
            j3 = epgProgram.endMillis;
        }
        long j5 = j3;
        if ((i2 & 4) != 0) {
            str = epgProgram.title;
        }
        return epgProgram.copy(j4, j5, str);
    }

    public final long component1() {
        return this.startMillis;
    }

    public final long component2() {
        return this.endMillis;
    }

    public final String component3() {
        return this.title;
    }

    public final EpgProgram copy(long j2, long j3, String str) {
        b0.d.k(str, "title");
        return new EpgProgram(j2, j3, str);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof EpgProgram)) {
            return false;
        }
        EpgProgram epgProgram = (EpgProgram) obj;
        return this.startMillis == epgProgram.startMillis && this.endMillis == epgProgram.endMillis && b0.d.b(this.title, epgProgram.title);
    }

    public final long getEndMillis() {
        return this.endMillis;
    }

    public final long getStartMillis() {
        return this.startMillis;
    }

    public final String getTitle() {
        return this.title;
    }

    public int hashCode() {
        long j2 = this.startMillis;
        long j3 = this.endMillis;
        return this.title.hashCode() + (((((int) (j2 ^ (j2 >>> 32))) * 31) + ((int) (j3 ^ (j3 >>> 32)))) * 31);
    }

    public String toString() {
        return "EpgProgram(startMillis=" + this.startMillis + ", endMillis=" + this.endMillis + ", title=" + this.title + ')';
    }
}
