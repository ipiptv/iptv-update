package tv.live;

import android.content.Context;
import android.util.Xml;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import org.xmlpull.v1.XmlPullParser;

/* loaded from: classes.dex */
public final class EpgRepository {
    private static final SimpleDateFormat hmFormat;
    private static volatile boolean loaded;
    private static final SimpleDateFormat timeFormat;
    public static final EpgRepository INSTANCE = new EpgRepository();
    private static final List<String> EPG_URLS = b0.d.z("https://gitee.com/IptvIptv/Iptv/raw/master/e.xml", "https://tv.whyun.com/epg/51zmt.xml", "https://iptv-4us.pages.dev/epg/51zmt.xml");
    private static final HashMap<String, List<EpgProgram>> data = new HashMap<>();

    static {
        Locale locale = Locale.US;
        timeFormat = new SimpleDateFormat("yyyyMMddHHmmss Z", locale);
        hmFormat = new SimpleDateFormat("HH:mm", locale);
    }

    private EpgRepository() {
    }

    private final String fetch(String str) {
        URLConnection openConnection = new URL(str).openConnection();
        b0.d.i(openConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
        HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
        httpURLConnection.setConnectTimeout(12000);
        httpURLConnection.setReadTimeout(25000);
        httpURLConnection.setRequestMethod("GET");
        httpURLConnection.setRequestProperty("User-Agent", "TV/1.0");
        httpURLConnection.setInstanceFollowRedirects(true);
        try {
            InputStream inputStream = httpURLConnection.getInputStream();
            b0.d.j(inputStream, "getInputStream(...)");
            Reader inputStreamReader = new InputStreamReader(inputStream, h0.a.f474a);
            BufferedReader bufferedReader = inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192);
            try {
                String B = b0.d.B(bufferedReader);
                b0.d.l(bufferedReader, null);
                return B;
            } finally {
            }
        } finally {
            try {
                httpURLConnection.disconnect();
            } catch (Throwable unused) {
            }
        }
    }

    private final boolean isFresh(HashMap<String, List<EpgProgram>> hashMap) {
        if (hashMap.isEmpty()) {
            return false;
        }
        long currentTimeMillis = System.currentTimeMillis();
        Iterator<List<EpgProgram>> it = hashMap.values().iterator();
        while (it.hasNext()) {
            for (EpgProgram epgProgram : it.next()) {
                if (currentTimeMillis >= epgProgram.getStartMillis() && currentTimeMillis < epgProgram.getEndMillis()) {
                    return true;
                }
            }
        }
        String str = todayKey();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyyMMdd", Locale.US);
        Iterator<List<EpgProgram>> it2 = hashMap.values().iterator();
        while (it2.hasNext()) {
            Iterator<EpgProgram> it3 = it2.next().iterator();
            while (it3.hasNext()) {
                if (b0.d.b(simpleDateFormat.format(new Date(it3.next().getStartMillis())), str)) {
                    return true;
                }
            }
        }
        return false;
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Removed duplicated region for block: B:15:0x005f A[Catch: Exception -> 0x00b1, TryCatch #5 {Exception -> 0x00b1, blocks: (B:3:0x0012, B:5:0x0039, B:11:0x0050, B:15:0x005f, B:16:0x0065, B:18:0x006b, B:23:0x007c, B:31:0x008e, B:48:0x009c, B:49:0x009e, B:52:0x00a5, B:53:0x00a6, B:56:0x00af, B:57:0x00b0, B:61:0x0059, B:51:0x009f), top: B:2:0x0012, inners: #4 }] */
    /* JADX WARN: Removed duplicated region for block: B:48:0x009c A[Catch: Exception -> 0x00b1, TRY_ENTER, TryCatch #5 {Exception -> 0x00b1, blocks: (B:3:0x0012, B:5:0x0039, B:11:0x0050, B:15:0x005f, B:16:0x0065, B:18:0x006b, B:23:0x007c, B:31:0x008e, B:48:0x009c, B:49:0x009e, B:52:0x00a5, B:53:0x00a6, B:56:0x00af, B:57:0x00b0, B:61:0x0059, B:51:0x009f), top: B:2:0x0012, inners: #4 }] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public static final void load$lambda$8(android.content.Context r9, c0.a r10) {
        /*
            java.lang.String r0 = "epg_"
            java.lang.String r1 = "$ctx"
            b0.d.k(r9, r1)
            java.lang.String r1 = "$onDone"
            b0.d.k(r10, r1)
            r1 = 10
            android.os.Process.setThreadPriority(r1)
            r1 = 1
            java.io.File r9 = r9.getFilesDir()     // Catch: java.lang.Exception -> Lb1
            tv.live.EpgRepository r2 = tv.live.EpgRepository.INSTANCE     // Catch: java.lang.Exception -> Lb1
            java.lang.String r3 = r2.todayKey()     // Catch: java.lang.Exception -> Lb1
            java.io.File r4 = new java.io.File     // Catch: java.lang.Exception -> Lb1
            java.lang.StringBuilder r5 = new java.lang.StringBuilder     // Catch: java.lang.Exception -> Lb1
            r5.<init>(r0)     // Catch: java.lang.Exception -> Lb1
            r5.append(r3)     // Catch: java.lang.Exception -> Lb1
            java.lang.String r0 = ".xml"
            r5.append(r0)     // Catch: java.lang.Exception -> Lb1
            java.lang.String r0 = r5.toString()     // Catch: java.lang.Exception -> Lb1
            r4.<init>(r9, r0)     // Catch: java.lang.Exception -> Lb1
            boolean r9 = r4.exists()     // Catch: java.lang.Exception -> Lb1
            r0 = 0
            if (r9 == 0) goto L5c
            long r5 = r4.length()     // Catch: java.lang.Exception -> Lb1
            r7 = 0
            int r9 = (r5 > r7 ? 1 : (r5 == r7 ? 0 : -1))
            if (r9 <= 0) goto L5c
            java.lang.String r9 = b0.d.C(r4)     // Catch: java.lang.Throwable -> L4c
            java.util.HashMap r9 = r2.parse(r9)     // Catch: java.lang.Throwable -> L4c
            goto L4e
        L4c:
            r9 = r0
        L4e:
            if (r9 == 0) goto L59
            tv.live.EpgRepository r2 = tv.live.EpgRepository.INSTANCE     // Catch: java.lang.Exception -> Lb1
            boolean r2 = r2.isFresh(r9)     // Catch: java.lang.Exception -> Lb1
            if (r2 == 0) goto L59
            goto L5d
        L59:
            r4.delete()     // Catch: java.lang.Exception -> Lb1
        L5c:
            r9 = r0
        L5d:
            if (r9 != 0) goto L9a
            java.util.List<java.lang.String> r2 = tv.live.EpgRepository.EPG_URLS     // Catch: java.lang.Exception -> Lb1
            java.util.Iterator r2 = r2.iterator()     // Catch: java.lang.Exception -> Lb1
        L65:
            boolean r3 = r2.hasNext()     // Catch: java.lang.Exception -> Lb1
            if (r3 == 0) goto L9a
            java.lang.Object r3 = r2.next()     // Catch: java.lang.Exception -> Lb1
            java.lang.String r3 = (java.lang.String) r3     // Catch: java.lang.Exception -> Lb1
            tv.live.EpgRepository r5 = tv.live.EpgRepository.INSTANCE     // Catch: java.lang.Throwable -> L78
            java.lang.String r3 = r5.fetch(r3)     // Catch: java.lang.Throwable -> L78
            goto L7a
        L78:
            r3 = r0
        L7a:
            if (r3 == 0) goto L65
            int r5 = r3.length()     // Catch: java.lang.Exception -> Lb1
            if (r5 != 0) goto L84
            r5 = 1
            goto L85
        L84:
            r5 = 0
        L85:
            if (r5 == 0) goto L88
            goto L65
        L88:
            tv.live.EpgRepository r5 = tv.live.EpgRepository.INSTANCE     // Catch: java.lang.Throwable -> L65
            java.util.HashMap r6 = r5.parse(r3)     // Catch: java.lang.Throwable -> L65
            boolean r5 = r5.isFresh(r6)     // Catch: java.lang.Exception -> Lb1
            if (r5 == 0) goto L65
            b0.d.K(r4, r3)     // Catch: java.lang.Throwable -> L98
            goto L99
        L98:
        L99:
            r9 = r6
        L9a:
            if (r9 == 0) goto Lb1
            java.util.HashMap<java.lang.String, java.util.List<tv.live.EpgProgram>> r0 = tv.live.EpgRepository.data     // Catch: java.lang.Exception -> Lb1
            monitor-enter(r0)     // Catch: java.lang.Exception -> Lb1
            r0.clear()     // Catch: java.lang.Throwable -> Lae
            r0.putAll(r9)     // Catch: java.lang.Throwable -> Lae
            monitor-exit(r0)     // Catch: java.lang.Exception -> Lb1
            boolean r9 = r9.isEmpty()     // Catch: java.lang.Exception -> Lb1
            r9 = r9 ^ r1
            tv.live.EpgRepository.loaded = r9     // Catch: java.lang.Exception -> Lb1
            goto Lb1
        Lae:
            r9 = move-exception
            monitor-exit(r0)     // Catch: java.lang.Exception -> Lb1
            throw r9     // Catch: java.lang.Exception -> Lb1
        Lb1:
            android.os.Handler r9 = new android.os.Handler
            android.os.Looper r0 = android.os.Looper.getMainLooper()
            r9.<init>(r0)
            tv.live.d r0 = new tv.live.d
            r0.<init>(r1, r10)
            r9.post(r0)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: tv.live.EpgRepository.load$lambda$8(android.content.Context, c0.a):void");
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void load$lambda$8$lambda$7(c0.a aVar) {
        b0.d.k(aVar, "$onDone");
        aVar.invoke();
    }

    private final HashMap<String, List<EpgProgram>> parse(String str) {
        String name;
        String str2;
        Object cVar;
        Object cVar2;
        HashMap hashMap = new HashMap();
        HashMap hashMap2 = new HashMap();
        XmlPullParser newPullParser = Xml.newPullParser();
        newPullParser.setFeature("http://xmlpull.org/v1/doc/features.html#process-namespaces", false);
        newPullParser.setInput(new StringReader(str));
        int eventType = newPullParser.getEventType();
        String str3 = null;
        while (true) {
            if (eventType == 1) {
                break;
            }
            if (eventType == 2 && (name = newPullParser.getName()) != null) {
                int hashCode = name.hashCode();
                if (hashCode != -968778980) {
                    if (hashCode != 738950403) {
                        if (hashCode == 1568910518 && name.equals("display-name")) {
                            try {
                                cVar2 = newPullParser.nextText();
                            } catch (Throwable th) {
                                cVar2 = new t.c(th);
                            }
                            String str4 = (String) (cVar2 instanceof t.c ? "" : cVar2);
                            if (str3 != null) {
                                b0.d.h(str4);
                                if (str4.length() > 0) {
                                    hashMap2.put(str3, normalize(str4));
                                }
                            }
                        }
                    } else if (name.equals("channel")) {
                        str3 = newPullParser.getAttributeValue(null, "id");
                    }
                } else if (name.equals("programme")) {
                    String attributeValue = newPullParser.getAttributeValue(null, "channel");
                    long parseTime = parseTime(newPullParser.getAttributeValue(null, "start"));
                    long parseTime2 = parseTime(newPullParser.getAttributeValue(null, "stop"));
                    int depth = newPullParser.getDepth();
                    String str5 = "";
                    while (true) {
                        int next = newPullParser.next();
                        if (next == 1 || (next == 3 && newPullParser.getDepth() == depth && b0.d.b(newPullParser.getName(), "programme"))) {
                            break;
                        }
                        if (next == 2 && b0.d.b(newPullParser.getName(), "title")) {
                            try {
                                cVar = newPullParser.nextText();
                            } catch (Throwable th2) {
                                cVar = new t.c(th2);
                            }
                            if (cVar instanceof t.c) {
                                cVar = "";
                            }
                            str5 = (String) cVar;
                        }
                    }
                    if (attributeValue != null && parseTime > 0) {
                        if ((str5.length() > 0) && (str2 = (String) hashMap2.get(attributeValue)) != null) {
                            Object obj = hashMap.get(str2);
                            if (obj == null) {
                                obj = new ArrayList();
                                hashMap.put(str2, obj);
                            }
                            ((List) obj).add(new EpgProgram(parseTime, parseTime2, h0.h.j0(str5).toString()));
                        }
                    }
                }
            }
            eventType = newPullParser.next();
        }
        Collection<List> values = hashMap.values();
        b0.d.j(values, "<get-values>(...)");
        for (List list : values) {
            b0.d.h(list);
            if (list.size() > 1) {
                Comparator comparator = new Comparator() { // from class: tv.live.EpgRepository$parse$lambda$14$$inlined$sortBy$1
                    /* JADX WARN: Multi-variable type inference failed */
                    @Override // java.util.Comparator
                    public final int compare(T t2, T t3) {
                        Long valueOf = Long.valueOf(((EpgProgram) t2).getStartMillis());
                        Long valueOf2 = Long.valueOf(((EpgProgram) t3).getStartMillis());
                        if (valueOf == valueOf2) {
                            return 0;
                        }
                        if (valueOf == null) {
                            return -1;
                        }
                        if (valueOf2 == null) {
                            return 1;
                        }
                        return valueOf.compareTo(valueOf2);
                    }
                };
                if (list.size() > 1) {
                    Collections.sort(list, comparator);
                }
            }
        }
        HashMap<String, List<EpgProgram>> hashMap3 = new HashMap<>();
        for (Map.Entry entry : hashMap.entrySet()) {
            hashMap3.put((String) entry.getKey(), (List) entry.getValue());
        }
        return hashMap3;
    }

    private final long parseTime(String str) {
        if (str == null) {
            return 0L;
        }
        try {
            Date parse = timeFormat.parse(h0.h.j0(str).toString());
            if (parse != null) {
                return parse.getTime();
            }
            return 0L;
        } catch (Exception unused) {
            return 0L;
        }
    }

    private final String todayKey() {
        String format = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
        b0.d.j(format, "format(...)");
        return format;
    }

    public final List<String> getEPG_URLS() {
        return EPG_URLS;
    }

    public final boolean isLoaded() {
        return loaded;
    }

    public final void load(Context context, c0.a aVar) {
        b0.d.k(context, "ctx");
        b0.d.k(aVar, "onDone");
        new Thread(new o(context, aVar, 3)).start();
    }

    public final String normalize(String str) {
        b0.d.k(str, "raw");
        String upperCase = str.toUpperCase(Locale.ROOT);
        b0.d.j(upperCase, "toUpperCase(...)");
        Iterator it = b0.d.z("高清", "超清", "蓝光", "4K", "HD", "频道", "电视台", "台").iterator();
        while (it.hasNext()) {
            upperCase = h0.h.Y(upperCase, (String) it.next(), "");
        }
        return h0.h.Y(h0.h.Y(h0.h.Y(h0.h.Y(h0.h.Y(h0.h.Y(h0.h.Y(h0.h.Y(h0.h.Y(h0.h.Y(h0.h.Y(upperCase, " ", ""), "-", ""), "_", ""), "·", ""), "(", ""), ")", ""), "（", ""), "）", ""), "「", ""), "」", ""), "+", "+");
    }

    public final t.b nowNext(String str) {
        Object obj;
        b0.d.k(str, "channelName");
        List<EpgProgram> programsFor = programsFor(str);
        if (programsFor.isEmpty()) {
            return new t.b(null, null);
        }
        long currentTimeMillis = System.currentTimeMillis();
        Iterator<EpgProgram> it = programsFor.iterator();
        int i2 = 0;
        while (true) {
            if (!it.hasNext()) {
                i2 = -1;
                break;
            }
            EpgProgram next = it.next();
            if (currentTimeMillis >= next.getStartMillis() && currentTimeMillis < next.getEndMillis()) {
                break;
            }
            i2++;
        }
        if (i2 >= 0) {
            return new t.b(programsFor.get(i2), u.i.P(programsFor, i2 + 1));
        }
        Iterator<T> it2 = programsFor.iterator();
        while (true) {
            if (!it2.hasNext()) {
                obj = null;
                break;
            }
            obj = it2.next();
            if (((EpgProgram) obj).getStartMillis() > currentTimeMillis) {
                break;
            }
        }
        return new t.b(null, (EpgProgram) obj);
    }

    public final List<EpgProgram> programsFor(String str) {
        List<EpgProgram> list;
        boolean z2;
        b0.d.k(str, "channelName");
        if (loaded) {
            HashMap<String, List<EpgProgram>> hashMap = data;
            if (!hashMap.isEmpty()) {
                String normalize = normalize(str);
                if (normalize.length() == 0) {
                    return u.k.f624a;
                }
                synchronized (hashMap) {
                    List<EpgProgram> list2 = hashMap.get(normalize);
                    if (list2 != null) {
                        return list2;
                    }
                    String str2 = null;
                    for (String str3 : hashMap.keySet()) {
                        b0.d.h(str3);
                        if (!(str3.length() == 0)) {
                            if (!h0.h.M(normalize, str3, false) && !h0.h.M(str3, normalize, false)) {
                                z2 = false;
                                if (z2 && normalize.length() >= 3 && str3.length() >= 3 && (str2 == null || str3.length() > str2.length())) {
                                    str2 = str3;
                                }
                            }
                            z2 = true;
                            if (z2) {
                                str2 = str3;
                            }
                        }
                    }
                    if (str2 == null || (list = data.get(str2)) == null) {
                        list = u.k.f624a;
                    }
                    return list;
                }
            }
        }
        return u.k.f624a;
    }

    public final String timeText(long j2) {
        String format = hmFormat.format(new Date(j2));
        b0.d.j(format, "format(...)");
        return format;
    }
}
