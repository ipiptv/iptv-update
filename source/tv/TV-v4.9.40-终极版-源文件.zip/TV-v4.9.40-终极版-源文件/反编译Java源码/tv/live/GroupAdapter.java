package tv.live;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.i0;
import androidx.recyclerview.widget.i1;
import java.util.List;

/* loaded from: classes.dex */
public final class GroupAdapter extends i0 {
    private boolean focused;
    private int highlightColor;
    private final List<String> list;
    private final c0.b onClick;
    private int rowHeightPx;
    private int selected;
    private float textSizePx;

    public static final class VH extends i1 {

        /* renamed from: tv, reason: collision with root package name */
        private final TextView f555tv;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public VH(View view) {
            super(view);
            b0.d.k(view, "v");
            this.f555tv = (TextView) view;
        }

        public final TextView getTv() {
            return this.f555tv;
        }
    }

    public GroupAdapter(List<String> list, int i2, int i3, float f2, boolean z2, int i4, c0.b bVar) {
        b0.d.k(list, "list");
        this.list = list;
        this.selected = i2;
        this.rowHeightPx = i3;
        this.textSizePx = f2;
        this.focused = z2;
        this.highlightColor = i4;
        this.onClick = bVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBindViewHolder$lambda$0(VH vh, GroupAdapter groupAdapter, String str) {
        TextView tv2;
        float f2;
        b0.d.k(vh, "$holder");
        b0.d.k(groupAdapter, "this$0");
        b0.d.k(str, "$text");
        int width = (vh.getTv().getWidth() - vh.getTv().getPaddingLeft()) - vh.getTv().getPaddingRight();
        if (width <= 0 || groupAdapter.textSizePx <= RecyclerView.B0) {
            return;
        }
        float measureText = vh.getTv().getPaint().measureText(str);
        float f3 = width;
        if (measureText > f3) {
            float f4 = ((f3 / measureText) * groupAdapter.textSizePx) - 1.0f;
            tv2 = vh.getTv();
            f2 = Math.max(f4, groupAdapter.textSizePx * 0.5f);
        } else {
            tv2 = vh.getTv();
            f2 = groupAdapter.textSizePx;
        }
        tv2.setTextSize(0, f2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBindViewHolder$lambda$1(GroupAdapter groupAdapter, int i2, View view) {
        b0.d.k(groupAdapter, "this$0");
        c0.b bVar = groupAdapter.onClick;
        if (bVar != null) {
            bVar.invoke(Integer.valueOf(i2));
        }
    }

    public final boolean getFocused() {
        return this.focused;
    }

    public final int getHighlightColor() {
        return this.highlightColor;
    }

    @Override // androidx.recyclerview.widget.i0
    public int getItemCount() {
        return this.list.size();
    }

    public final int getRowHeightPx() {
        return this.rowHeightPx;
    }

    public final int getSelected() {
        return this.selected;
    }

    public final float getTextSizePx() {
        return this.textSizePx;
    }

    public final void setFocused(boolean z2) {
        this.focused = z2;
    }

    public final void setHighlightColor(int i2) {
        this.highlightColor = i2;
    }

    public final void setRowHeightPx(int i2) {
        this.rowHeightPx = i2;
    }

    public final void setSelected(int i2) {
        this.selected = i2;
    }

    public final void setTextSizePx(float f2) {
        this.textSizePx = f2;
    }

    public /* synthetic */ GroupAdapter(List list, int i2, int i3, float f2, boolean z2, int i4, c0.b bVar, int i5, d0.a aVar) {
        this(list, (i5 & 2) != 0 ? 0 : i2, (i5 & 4) != 0 ? 0 : i3, (i5 & 8) != 0 ? RecyclerView.B0 : f2, (i5 & 16) == 0 ? z2 : false, (i5 & 32) != 0 ? -10929 : i4, (i5 & 64) != 0 ? null : bVar);
    }

    @Override // androidx.recyclerview.widget.i0
    public void onBindViewHolder(VH vh, int i2) {
        b0.d.k(vh, "holder");
        if (this.rowHeightPx > 0) {
            vh.itemView.getLayoutParams().height = this.rowHeightPx;
        }
        if (this.textSizePx > RecyclerView.B0) {
            vh.getTv().setTextSize(0, this.textSizePx);
        }
        String str = this.list.get(i2);
        vh.getTv().setText(str);
        vh.getTv().setGravity(8388627);
        vh.getTv().post(new a(vh, this, str, 1));
        boolean z2 = i2 == this.selected;
        vh.getTv().setTextColor((z2 && this.focused) ? -1 : z2 ? this.highlightColor : -1644826);
        vh.getTv().setBackgroundColor(z2 ? this.focused ? -871736167 : -1727116163 : 0);
        vh.getTv().setOnClickListener(new b(this, i2, 2));
        vh.getTv().setFocusable(true);
    }

    @Override // androidx.recyclerview.widget.i0
    public VH onCreateViewHolder(ViewGroup viewGroup, int i2) {
        b0.d.k(viewGroup, "parent");
        View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_group, viewGroup, false);
        b0.d.h(inflate);
        return new VH(inflate);
    }
}
