package tv.live;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import org.json.JSONArray;

/* loaded from: classes.dex */
public final class GroupStore {
    public static final GroupStore INSTANCE = new GroupStore();

    private GroupStore() {
    }

    private final SharedPreferences sp(Context context) {
        return context.getSharedPreferences("tv", 0);
    }

    public final List<String> apply(Context context, List<String> list) {
        b0.d.k(context, "ctx");
        b0.d.k(list, "allGroups");
        Set<String> loadHidden = loadHidden(context);
        List<String> loadOrder = loadOrder(context);
        ArrayList arrayList = new ArrayList();
        for (String str : loadOrder) {
            if (list.contains(str) && !loadHidden.contains(str)) {
                arrayList.add(str);
            }
        }
        for (String str2 : list) {
            if (!loadOrder.contains(str2) && !loadHidden.contains(str2)) {
                arrayList.add(str2);
            }
        }
        return arrayList;
    }

    public final Set<String> loadHidden(Context context) {
        b0.d.k(context, "ctx");
        String string = sp(context).getString("group_hidden", null);
        if (string == null) {
            return new LinkedHashSet();
        }
        try {
            JSONArray jSONArray = new JSONArray(string);
            LinkedHashSet linkedHashSet = new LinkedHashSet();
            int length = jSONArray.length();
            for (int i2 = 0; i2 < length; i2++) {
                String string2 = jSONArray.getString(i2);
                b0.d.j(string2, "getString(...)");
                linkedHashSet.add(string2);
            }
            return linkedHashSet;
        } catch (Exception unused) {
            return new LinkedHashSet();
        }
    }

    public final List<String> loadOrder(Context context) {
        b0.d.k(context, "ctx");
        String string = sp(context).getString("group_order", null);
        u.k kVar = u.k.f624a;
        if (string == null) {
            return kVar;
        }
        try {
            JSONArray jSONArray = new JSONArray(string);
            ArrayList arrayList = new ArrayList();
            int length = jSONArray.length();
            for (int i2 = 0; i2 < length; i2++) {
                String string2 = jSONArray.getString(i2);
                b0.d.j(string2, "getString(...)");
                arrayList.add(string2);
            }
            return arrayList;
        } catch (Exception unused) {
            return kVar;
        }
    }

    public final void saveHidden(Context context, Set<String> set) {
        b0.d.k(context, "ctx");
        b0.d.k(set, "hidden");
        JSONArray jSONArray = new JSONArray();
        Iterator<T> it = set.iterator();
        while (it.hasNext()) {
            jSONArray.put((String) it.next());
        }
        sp(context).edit().putString("group_hidden", jSONArray.toString()).apply();
    }

    public final void saveOrder(Context context, List<String> list) {
        b0.d.k(context, "ctx");
        b0.d.k(list, "order");
        JSONArray jSONArray = new JSONArray();
        Iterator<T> it = list.iterator();
        while (it.hasNext()) {
            jSONArray.put((String) it.next());
        }
        sp(context).edit().putString("group_order", jSONArray.toString()).apply();
    }
}
