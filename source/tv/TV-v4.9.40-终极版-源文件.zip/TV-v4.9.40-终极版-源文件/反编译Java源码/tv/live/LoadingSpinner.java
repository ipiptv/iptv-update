package tv.live;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.View;
import androidx.recyclerview.widget.RecyclerView;

/* loaded from: classes.dex */
public final class LoadingSpinner extends View {
    private float angle;
    private final Handler handler;
    private final Paint paint;
    private boolean running;
    private final LoadingSpinner$tick$1 tick;

    /* JADX WARN: 'this' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Multi-variable type inference failed */
    public LoadingSpinner(Context context) {
        this(context, null, 2, 0 == true ? 1 : 0);
        b0.d.k(context, "context");
    }

    @Override // android.view.View
    public void onAttachedToWindow() {
        super.onAttachedToWindow();
        startSpin();
    }

    @Override // android.view.View
    public void onDetachedFromWindow() {
        super.onDetachedFromWindow();
        stopSpin();
    }

    @Override // android.view.View
    public void onDraw(Canvas canvas) {
        b0.d.k(canvas, "canvas");
        super.onDraw(canvas);
        float width = getWidth();
        float height = getHeight();
        if (width <= RecyclerView.B0 || height <= RecyclerView.B0) {
            return;
        }
        Paint paint = this.paint;
        float min = Math.min(width, height) * 0.13f;
        if (min < 3.0f) {
            min = 3.0f;
        }
        paint.setStrokeWidth(min);
        float f2 = width / 2.0f;
        float f3 = height / 2.0f;
        float min2 = (Math.min(width, height) / 2.0f) - this.paint.getStrokeWidth();
        int[] iArr = {255, 190, 120};
        for (int i2 = 0; i2 < 3; i2++) {
            this.paint.setColor(Color.argb(iArr[i2], 127, 227, 255));
            canvas.drawArc(f2 - min2, f3 - min2, f2 + min2, f3 + min2, (i2 * 120.0f) + this.angle, 82.0f, false, this.paint);
        }
    }

    @Override // android.view.View
    public void setVisibility(int i2) {
        super.setVisibility(i2);
        if (i2 == 0) {
            startSpin();
        } else {
            stopSpin();
        }
    }

    public final void startSpin() {
        if (this.running) {
            return;
        }
        this.running = true;
        this.handler.removeCallbacks(this.tick);
        this.handler.post(this.tick);
    }

    public final void stopSpin() {
        this.running = false;
        this.handler.removeCallbacks(this.tick);
    }

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    /* JADX WARN: Type inference failed for: r2v3, types: [tv.live.LoadingSpinner$tick$1] */
    public LoadingSpinner(Context context, AttributeSet attributeSet) {
        super(context, attributeSet);
        b0.d.k(context, "context");
        this.handler = new Handler(Looper.getMainLooper());
        Paint paint = new Paint(1);
        paint.setStyle(Paint.Style.STROKE);
        paint.setColor(-8395777);
        this.paint = paint;
        this.tick = new Runnable() { // from class: tv.live.LoadingSpinner$tick$1
            @Override // java.lang.Runnable
            public void run() {
                float f2;
                boolean z2;
                Handler handler;
                LoadingSpinner loadingSpinner = LoadingSpinner.this;
                f2 = loadingSpinner.angle;
                loadingSpinner.angle = (f2 + 9.0f) % 360.0f;
                LoadingSpinner.this.invalidate();
                z2 = LoadingSpinner.this.running;
                if (z2) {
                    handler = LoadingSpinner.this.handler;
                    handler.postDelayed(this, 26L);
                }
            }
        };
    }

    public /* synthetic */ LoadingSpinner(Context context, AttributeSet attributeSet, int i2, d0.a aVar) {
        this(context, (i2 & 2) != 0 ? null : attributeSet);
    }
}
