package tv.live;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.List;

/* loaded from: classes.dex */
public final class M3UParser {
    public static final M3UParser INSTANCE = new M3UParser();
    public static final int MAX_URLS_PER_CHANNEL = 500;

    private M3UParser() {
    }

    private final String attr(String str, String str2) {
        int length;
        int Q;
        String str3 = str2 + "=\"";
        int R = h0.h.R(str, str3, 0, false, 6);
        if (R < 0 || (Q = h0.h.Q(str, '\"', (length = str3.length() + R), 4)) < 0) {
            return "";
        }
        String substring = str.substring(length, Q);
        b0.d.j(substring, "substring(...)");
        return substring;
    }

    public static /* synthetic */ t.b fetchAndParse$default(M3UParser m3UParser, String str, String str2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            str2 = SourceStore.DEFAULT_UA;
        }
        return m3UParser.fetchAndParse(str, str2);
    }

    private final HttpURLConnection openFollowing(String str, int i2, String str2) {
        URLConnection openConnection = new URL(str).openConnection();
        b0.d.i(openConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
        HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
        httpURLConnection.setInstanceFollowRedirects(false);
        httpURLConnection.setConnectTimeout(8000);
        httpURLConnection.setReadTimeout(8000);
        httpURLConnection.setRequestMethod("GET");
        httpURLConnection.setRequestProperty("User-Agent", str2);
        int responseCode = httpURLConnection.getResponseCode();
        if (!(301 <= responseCode && responseCode < 309) || i2 >= 4) {
            return httpURLConnection;
        }
        String headerField = httpURLConnection.getHeaderField("Location");
        if (headerField == null) {
            return httpURLConnection;
        }
        httpURLConnection.disconnect();
        if (!h0.h.d0(headerField, "http", false)) {
            headerField = new URL(new URL(str), headerField).toString();
            b0.d.j(headerField, "toString(...)");
        }
        return openFollowing(headerField, i2 + 1, str2);
    }

    public static /* synthetic */ HttpURLConnection openFollowing$default(M3UParser m3UParser, String str, int i2, String str2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            i2 = 0;
        }
        if ((i3 & 4) != 0) {
            str2 = SourceStore.DEFAULT_UA;
        }
        return m3UParser.openFollowing(str, i2, str2);
    }

    public final t.b fetchAndParse(String str, String str2) {
        b0.d.k(str, "url");
        b0.d.k(str2, "ua");
        HttpURLConnection openFollowing = openFollowing(str, 0, str2);
        openFollowing.setConnectTimeout(8000);
        openFollowing.setReadTimeout(12000);
        String requestMethod = openFollowing.getRequestMethod();
        if (requestMethod == null || requestMethod.length() == 0) {
            openFollowing.setRequestMethod("GET");
        }
        final StringBuilder sb = new StringBuilder(1024);
        InputStream inputStream = openFollowing.getInputStream();
        b0.d.j(inputStream, "getInputStream(...)");
        Reader inputStreamReader = new InputStreamReader(inputStream, h0.a.f474a);
        final BufferedReader bufferedReader = inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192);
        try {
            List<Channel> parse = INSTANCE.parse(new Reader() { // from class: tv.live.M3UParser$fetchAndParse$1$tee$1
                @Override // java.io.Reader, java.io.Closeable, java.lang.AutoCloseable
                public void close() {
                }

                @Override // java.io.Reader
                public int read(char[] cArr, int i2, int i3) {
                    b0.d.k(cArr, "cbuf");
                    int read = bufferedReader.read(cArr, i2, i3);
                    if (read > 0) {
                        sb.append(new String(cArr, i2, read));
                    }
                    return read;
                }
            });
            b0.d.l(bufferedReader, null);
            String sb2 = sb.toString();
            b0.d.j(sb2, "toString(...)");
            return new t.b(sb2, parse);
        } finally {
        }
    }

    /* JADX WARN: Code restructure failed: missing block: B:25:0x009a, code lost:
    
        if (r1.length() <= 0) goto L42;
     */
    /* JADX WARN: Code restructure failed: missing block: B:26:0x009c, code lost:
    
        r6 = true;
     */
    /* JADX WARN: Code restructure failed: missing block: B:27:0x009d, code lost:
    
        if (r6 == false) goto L58;
     */
    /* JADX WARN: Code restructure failed: missing block: B:29:0x009f, code lost:
    
        r2 = r3 + (char) 1 + r1;
        r5 = (tv.live.Channel) r0.get(r2);
     */
    /* JADX WARN: Code restructure failed: missing block: B:30:0x00b7, code lost:
    
        if (r5 != null) goto L53;
     */
    /* JADX WARN: Code restructure failed: missing block: B:33:0x00db, code lost:
    
        if (r5.getUrls().size() >= 500) goto L59;
     */
    /* JADX WARN: Code restructure failed: missing block: B:36:0x00e5, code lost:
    
        if (r5.getUrls().contains(r4) != false) goto L60;
     */
    /* JADX WARN: Code restructure failed: missing block: B:38:0x00e7, code lost:
    
        r5.getUrls().add(r4);
     */
    /* JADX WARN: Code restructure failed: missing block: B:44:0x00b9, code lost:
    
        r0.put(r2, new tv.live.Channel(r1, r3, new java.util.ArrayList(new u.f(new java.lang.String[]{r4}))));
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final java.util.List<tv.live.Channel> parse(java.io.Reader r10) {
        /*
            r9 = this;
            java.lang.String r0 = "reader"
            b0.d.k(r10, r0)
            java.util.LinkedHashMap r0 = new java.util.LinkedHashMap
            r0.<init>()
            boolean r1 = r10 instanceof java.io.BufferedReader
            if (r1 == 0) goto L11
            java.io.BufferedReader r10 = (java.io.BufferedReader) r10
            goto L17
        L11:
            java.io.BufferedReader r1 = new java.io.BufferedReader
            r1.<init>(r10)
            r10 = r1
        L17:
            java.lang.String r1 = ""
            java.lang.String r2 = "未分组"
            r3 = r2
        L1c:
            java.lang.String r4 = r10.readLine()
            if (r4 != 0) goto L30
            java.util.Collection r10 = r0.values()
            java.lang.String r0 = "<get-values>(...)"
            b0.d.j(r10, r0)
            java.util.List r10 = u.i.S(r10)
            return r10
        L30:
            int r5 = r4.length()
            r6 = 0
            r7 = 1
            if (r5 != 0) goto L3a
            r5 = 1
            goto L3b
        L3a:
            r5 = 0
        L3b:
            if (r5 != 0) goto L1c
            char r5 = r4.charAt(r6)
            r8 = 35
            if (r5 != r8) goto L7b
            java.lang.String r5 = "#EXTINF"
            boolean r5 = h0.h.d0(r4, r5, r6)
            if (r5 == 0) goto L1c
            java.lang.String r1 = "group-title"
            java.lang.String r1 = r9.attr(r4, r1)
            int r3 = r1.length()
            if (r3 != 0) goto L5b
            r3 = 1
            goto L5c
        L5b:
            r3 = 0
        L5c:
            if (r3 == 0) goto L60
            r3 = r2
            goto L61
        L60:
            r3 = r1
        L61:
            r1 = 44
            java.lang.String r1 = h0.h.h0(r4, r1)
            java.lang.CharSequence r1 = h0.h.j0(r1)
            java.lang.String r1 = r1.toString()
            int r4 = r1.length()
            if (r4 != 0) goto L76
            r6 = 1
        L76:
            if (r6 == 0) goto L1c
            java.lang.String r1 = "未命名频道"
            goto L1c
        L7b:
            java.lang.String r5 = "//"
            boolean r5 = h0.h.d0(r4, r5, r6)
            if (r5 != 0) goto L1c
            java.lang.CharSequence r4 = h0.h.j0(r4)
            java.lang.String r4 = r4.toString()
            int r5 = r4.length()
            if (r5 != 0) goto L93
            r5 = 1
            goto L94
        L93:
            r5 = 0
        L94:
            if (r5 != 0) goto L1c
            int r2 = r1.length()
            if (r2 <= 0) goto L9d
            r6 = 1
        L9d:
            if (r6 == 0) goto L17
            java.lang.StringBuilder r2 = new java.lang.StringBuilder
            r2.<init>()
            r2.append(r3)
            r2.append(r7)
            r2.append(r1)
            java.lang.String r2 = r2.toString()
            java.lang.Object r5 = r0.get(r2)
            tv.live.Channel r5 = (tv.live.Channel) r5
            if (r5 != 0) goto Ld1
            tv.live.Channel r5 = new tv.live.Channel
            java.lang.String[] r4 = new java.lang.String[]{r4}
            java.util.ArrayList r6 = new java.util.ArrayList
            u.f r7 = new u.f
            r7.<init>(r4)
            r6.<init>(r7)
            r5.<init>(r1, r3, r6)
            r0.put(r2, r5)
            goto L17
        Ld1:
            java.util.List r1 = r5.getUrls()
            int r1 = r1.size()
            r2 = 500(0x1f4, float:7.0E-43)
            if (r1 >= r2) goto L17
            java.util.List r1 = r5.getUrls()
            boolean r1 = r1.contains(r4)
            if (r1 != 0) goto L17
            java.util.List r1 = r5.getUrls()
            r1.add(r4)
            goto L17
        */
        throw new UnsupportedOperationException("Method not decompiled: tv.live.M3UParser.parse(java.io.Reader):java.util.List");
    }

    public final List<Channel> parse(String str) {
        b0.d.k(str, "text");
        return parse(new StringReader(str));
    }
}
