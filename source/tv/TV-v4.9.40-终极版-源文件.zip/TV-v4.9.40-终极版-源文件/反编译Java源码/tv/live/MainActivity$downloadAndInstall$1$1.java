package tv.live;

/* loaded from: classes.dex */
public final class MainActivity$downloadAndInstall$1$1 extends d0.c implements c0.b {
    final /* synthetic */ MainActivity this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MainActivity$downloadAndInstall$1$1(MainActivity mainActivity) {
        super(1);
        this.this$0 = mainActivity;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void invoke$lambda$0(MainActivity mainActivity, String str) {
        b0.d.k(mainActivity, "this$0");
        b0.d.k(str, "$m");
        mainActivity.setDownloadText(str);
        mainActivity.hideDownloadPanelDelayed(BootReceiver.START_DELAY_MS);
    }

    @Override // c0.b
    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke((String) obj);
        return t.g.f554a;
    }

    public final void invoke(String str) {
        b0.d.k(str, "m");
        MainActivity mainActivity = this.this$0;
        mainActivity.runOnUiThread(new o(mainActivity, str, 0));
    }
}
