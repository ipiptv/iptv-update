package tv.live;

import java.util.Arrays;
import java.util.Locale;
import tv.live.UpdateChecker;

/* loaded from: classes.dex */
public final class MainActivity$downloadAndInstall$1$2 extends d0.c implements c0.d {
    final /* synthetic */ UpdateChecker.Remote $remote;
    final /* synthetic */ MainActivity this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MainActivity$downloadAndInstall$1$2(MainActivity mainActivity, UpdateChecker.Remote remote) {
        super(3);
        this.this$0 = mainActivity;
        this.$remote = remote;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void invoke$lambda$0(long j2, int i2, UpdateChecker.Remote remote, MainActivity mainActivity) {
        String str;
        b0.d.k(remote, "$remote");
        b0.d.k(mainActivity, "this$0");
        String format = String.format(Locale.US, "%.1f", Arrays.copyOf(new Object[]{Double.valueOf(j2 / 1048576.0d)}, 1));
        b0.d.j(format, "format(...)");
        if (i2 >= 0) {
            str = "正在下载 v" + remote.getVersionName() + "   " + i2 + '%';
        } else {
            str = "正在下载 v" + remote.getVersionName() + "   已下载 " + format + " MB";
        }
        mainActivity.setDownloadProgress(i2, str);
    }

    @Override // c0.d
    public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3) {
        invoke(((Number) obj).intValue(), ((Number) obj2).longValue(), ((Number) obj3).longValue());
        return t.g.f554a;
    }

    public final void invoke(final int i2, final long j2, long j3) {
        final MainActivity mainActivity = this.this$0;
        final UpdateChecker.Remote remote = this.$remote;
        mainActivity.runOnUiThread(new Runnable() { // from class: tv.live.p
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity$downloadAndInstall$1$2.invoke$lambda$0(j2, i2, remote, mainActivity);
            }
        });
    }
}
