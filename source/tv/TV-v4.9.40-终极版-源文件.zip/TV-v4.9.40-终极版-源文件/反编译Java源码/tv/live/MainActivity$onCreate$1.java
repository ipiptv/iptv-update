package tv.live;

import androidx.recyclerview.widget.RecyclerView;

/* loaded from: classes.dex */
public final class MainActivity$onCreate$1 extends d0.c implements c0.b {
    final /* synthetic */ MainActivity this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MainActivity$onCreate$1(MainActivity mainActivity) {
        super(1);
        this.this$0 = mainActivity;
    }

    @Override // c0.b
    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Number) obj).intValue());
        return t.g.f554a;
    }

    public final void invoke(int i2) {
        GroupAdapter groupAdapter;
        GroupAdapter groupAdapter2;
        RecyclerView recyclerView;
        this.this$0.groupPos = i2;
        groupAdapter = this.this$0.groupAdapter;
        if (groupAdapter == null) {
            b0.d.G("groupAdapter");
            throw null;
        }
        groupAdapter.setSelected(i2);
        groupAdapter2 = this.this$0.groupAdapter;
        if (groupAdapter2 == null) {
            b0.d.G("groupAdapter");
            throw null;
        }
        groupAdapter2.notifyDataSetChanged();
        recyclerView = this.this$0.groupListRv;
        if (recyclerView == null) {
            b0.d.G("groupListRv");
            throw null;
        }
        recyclerView.a0(i2);
        this.this$0.reloadChannelList(i2, 0);
        this.this$0.resetHideTimer();
    }
}
