package tv.live;

/* loaded from: classes.dex */
public final class MainActivity$onCreate$3 extends d0.c implements c0.b {
    final /* synthetic */ MainActivity this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MainActivity$onCreate$3(MainActivity mainActivity) {
        super(1);
        this.this$0 = mainActivity;
    }

    @Override // c0.b
    public final String invoke(Channel channel) {
        String sourceInfoOf;
        b0.d.k(channel, "ch");
        sourceInfoOf = this.this$0.sourceInfoOf(channel);
        return sourceInfoOf;
    }
}
