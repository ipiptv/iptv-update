package tv.live;

/* loaded from: classes.dex */
public final class MainActivity$onCreate$4 extends d0.c implements c0.b {
    final /* synthetic */ MainActivity this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MainActivity$onCreate$4(MainActivity mainActivity) {
        super(1);
        this.this$0 = mainActivity;
    }

    @Override // c0.b
    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Number) obj).intValue());
        return t.g.f554a;
    }

    /* JADX WARN: Code restructure failed: missing block: B:4:0x0019, code lost:
    
        if (r2 != false) goto L8;
     */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final void invoke(int r2) {
        /*
            r1 = this;
            tv.live.MainActivity r0 = r1.this$0
            tv.live.MainActivity.access$setChannelPos$p(r0, r2)
            tv.live.MainActivity r0 = r1.this$0
            java.util.List r0 = tv.live.MainActivity.access$getChannelListData$p(r0)
            java.lang.Object r2 = u.i.P(r0, r2)
            tv.live.Channel r2 = (tv.live.Channel) r2
            if (r2 == 0) goto L1c
            tv.live.MainActivity r0 = r1.this$0
            boolean r2 = tv.live.MainActivity.access$isPlayingChannel(r0, r2)
            if (r2 == 0) goto L1c
            goto L21
        L1c:
            tv.live.MainActivity r2 = r1.this$0
            tv.live.MainActivity.access$playSelectedChannel(r2)
        L21:
            tv.live.MainActivity r2 = r1.this$0
            tv.live.MainActivity.access$closePanel(r2)
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: tv.live.MainActivity$onCreate$4.invoke(int):void");
    }
}
