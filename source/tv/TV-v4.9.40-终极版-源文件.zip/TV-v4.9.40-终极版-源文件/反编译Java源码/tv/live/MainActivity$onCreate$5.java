package tv.live;

/* loaded from: classes.dex */
public final class MainActivity$onCreate$5 extends d0.c implements c0.b {
    final /* synthetic */ MainActivity this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MainActivity$onCreate$5(MainActivity mainActivity) {
        super(1);
        this.this$0 = mainActivity;
    }

    @Override // c0.b
    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Number) obj).intValue());
        return t.g.f554a;
    }

    public final void invoke(int i2) {
        this.this$0.channelPos = i2;
    }
}
