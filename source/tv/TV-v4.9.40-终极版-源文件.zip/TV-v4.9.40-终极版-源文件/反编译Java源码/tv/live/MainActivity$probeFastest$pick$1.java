package tv.live;

/* loaded from: classes.dex */
public final class MainActivity$probeFastest$pick$1 extends d0.c implements c0.b {
    final /* synthetic */ d0.d $decided;
    final /* synthetic */ Object $lock;
    final /* synthetic */ c0.b $onPick;
    final /* synthetic */ MainActivity this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MainActivity$probeFastest$pick$1(Object obj, d0.d dVar, MainActivity mainActivity, c0.b bVar) {
        super(1);
        this.$lock = obj;
        this.$decided = dVar;
        this.this$0 = mainActivity;
        this.$onPick = bVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void invoke$lambda$1$lambda$0(c0.b bVar, int i2) {
        b0.d.k(bVar, "$onPick");
        bVar.invoke(Integer.valueOf(i2));
    }

    @Override // c0.b
    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke(((Number) obj).intValue());
        return t.g.f554a;
    }

    public final void invoke(int i2) {
        Object obj = this.$lock;
        d0.d dVar = this.$decided;
        MainActivity mainActivity = this.this$0;
        c0.b bVar = this.$onPick;
        synchronized (obj) {
            if (!dVar.f390a) {
                dVar.f390a = true;
                mainActivity.runOnUiThread(new q(i2, 0, bVar));
            }
        }
    }
}
