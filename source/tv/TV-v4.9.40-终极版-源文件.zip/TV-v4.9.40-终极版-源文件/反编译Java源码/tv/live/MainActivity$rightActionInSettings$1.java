package tv.live;

/* loaded from: classes.dex */
public final class MainActivity$rightActionInSettings$1 extends d0.c implements c0.b {
    final /* synthetic */ ManageItem $item;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MainActivity$rightActionInSettings$1(ManageItem manageItem) {
        super(1);
        this.$item = manageItem;
    }

    @Override // c0.b
    public final Boolean invoke(SourceItem sourceItem) {
        b0.d.k(sourceItem, "it");
        return Boolean.valueOf(b0.d.b(sourceItem.getId(), this.$item.getPayload()));
    }
}
