package tv.live;

import android.view.View;
import android.widget.Toast;
import java.util.Iterator;
import java.util.List;

/* loaded from: classes.dex */
public final class MainActivity$showConfig$1 extends d0.c implements c0.e {
    final /* synthetic */ MainActivity this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MainActivity$showConfig$1(MainActivity mainActivity) {
        super(4);
        this.this$0 = mainActivity;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void invoke$lambda$3(MainActivity mainActivity, String str, String str2, String str3, boolean z2) {
        Object obj;
        Object obj2;
        Object obj3;
        View view;
        b0.d.k(mainActivity, "this$0");
        b0.d.k(str, "$name");
        b0.d.k(str2, "$url");
        b0.d.k(str3, "$ua");
        List<SourceItem> load = SourceStore.INSTANCE.load(mainActivity);
        Iterator<T> it = load.iterator();
        while (true) {
            if (!it.hasNext()) {
                obj = null;
                break;
            } else {
                obj = it.next();
                if (b0.d.b(((SourceItem) obj).getUrl(), str2)) {
                    break;
                }
            }
        }
        SourceItem sourceItem = (SourceItem) obj;
        if (sourceItem == null) {
            load.add(new SourceItem(SourceStore.INSTANCE.newId(), str, str2, 0L, str3, false, 40, null));
        } else {
            sourceItem.setName(str);
            sourceItem.setUa(str3);
        }
        SourceStore sourceStore = SourceStore.INSTANCE;
        sourceStore.save(mainActivity, load);
        Iterator<T> it2 = sourceStore.load(mainActivity).iterator();
        while (true) {
            if (!it2.hasNext()) {
                obj2 = null;
                break;
            } else {
                obj2 = it2.next();
                if (b0.d.b(((SourceItem) obj2).getUrl(), str2)) {
                    break;
                }
            }
        }
        SourceItem sourceItem2 = (SourceItem) obj2;
        if (sourceItem2 != null) {
            sourceItem2.setEnabled(true);
        }
        SourceStore sourceStore2 = SourceStore.INSTANCE;
        sourceStore2.save(mainActivity, sourceStore2.load(mainActivity));
        Iterator<T> it3 = sourceStore2.load(mainActivity).iterator();
        while (true) {
            if (!it3.hasNext()) {
                obj3 = null;
                break;
            } else {
                obj3 = it3.next();
                if (b0.d.b(((SourceItem) obj3).getUrl(), str2)) {
                    break;
                }
            }
        }
        SourceItem sourceItem3 = (SourceItem) obj3;
        if (z2 && sourceItem3 != null) {
            SourceStore.INSTANCE.setCurrentId(mainActivity, sourceItem3.getId());
        }
        if (sourceItem3 != null) {
            view = mainActivity.configOverlay;
            if (view == null) {
                b0.d.G("configOverlay");
                throw null;
            }
            view.setVisibility(8);
            mainActivity.stopConfigServer();
            mainActivity.reloadMergedFromCache();
            MainActivity.refreshFromNetwork$default(mainActivity, null, null, 3, null);
        }
        Toast.makeText(mainActivity, "已添加「" + str + "」并启用", 0).show();
    }

    @Override // c0.e
    public /* bridge */ /* synthetic */ Object invoke(Object obj, Object obj2, Object obj3, Object obj4) {
        invoke((String) obj, (String) obj2, (String) obj3, ((Boolean) obj4).booleanValue());
        return t.g.f554a;
    }

    public final void invoke(final String str, final String str2, final String str3, final boolean z2) {
        b0.d.k(str, "name");
        b0.d.k(str2, "url");
        b0.d.k(str3, "ua");
        final MainActivity mainActivity = this.this$0;
        mainActivity.runOnUiThread(new Runnable() { // from class: tv.live.s
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity$showConfig$1.invoke$lambda$3(MainActivity.this, str, str2, str3, z2);
            }
        });
    }
}
