package tv.live;

/* loaded from: classes.dex */
public final class MainActivity$showConfig$2 extends d0.c implements c0.a {
    final /* synthetic */ MainActivity this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MainActivity$showConfig$2(MainActivity mainActivity) {
        super(0);
        this.this$0 = mainActivity;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void invoke$lambda$0(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        mainActivity.startUpdateCheck();
    }

    @Override // c0.a
    public /* bridge */ /* synthetic */ Object invoke() {
        m2invoke();
        return t.g.f554a;
    }

    /* renamed from: invoke, reason: collision with other method in class */
    public final void m2invoke() {
        MainActivity mainActivity = this.this$0;
        mainActivity.runOnUiThread(new t(mainActivity, 0));
    }
}
