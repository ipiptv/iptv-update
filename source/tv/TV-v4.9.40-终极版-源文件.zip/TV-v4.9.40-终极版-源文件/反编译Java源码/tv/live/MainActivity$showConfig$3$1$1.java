package tv.live;

import android.widget.Toast;

/* loaded from: classes.dex */
public final class MainActivity$showConfig$3$1$1 extends d0.c implements c0.b {
    final /* synthetic */ MainActivity this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MainActivity$showConfig$3$1$1(MainActivity mainActivity) {
        super(1);
        this.this$0 = mainActivity;
    }

    @Override // c0.b
    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke((String) obj);
        return t.g.f554a;
    }

    public final void invoke(String str) {
        b0.d.k(str, "msg");
        Toast.makeText(this.this$0, str, 1).show();
    }
}
