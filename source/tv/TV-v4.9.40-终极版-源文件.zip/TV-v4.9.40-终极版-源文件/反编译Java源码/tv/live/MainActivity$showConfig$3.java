package tv.live;

import android.widget.Toast;
import java.io.File;

/* loaded from: classes.dex */
public final class MainActivity$showConfig$3 extends d0.c implements c0.b {
    final /* synthetic */ MainActivity this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MainActivity$showConfig$3(MainActivity mainActivity) {
        super(1);
        this.this$0 = mainActivity;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void invoke$lambda$0(MainActivity mainActivity, File file) {
        b0.d.k(mainActivity, "this$0");
        b0.d.k(file, "$apkFile");
        try {
            UpdateChecker.INSTANCE.installLocalFile(mainActivity, file, new MainActivity$showConfig$3$1$1(mainActivity));
        } catch (Throwable th) {
            String message = th.getMessage();
            if (message == null) {
                message = "未知错误";
            }
            Toast.makeText(mainActivity, "安装失败：".concat(message), 1).show();
        }
    }

    @Override // c0.b
    public /* bridge */ /* synthetic */ Object invoke(Object obj) {
        invoke((File) obj);
        return t.g.f554a;
    }

    public final void invoke(File file) {
        b0.d.k(file, "apkFile");
        MainActivity mainActivity = this.this$0;
        mainActivity.runOnUiThread(new o(mainActivity, file, 1));
    }
}
