package tv.live;

/* loaded from: classes.dex */
public final class MainActivity$silentUpdateNow$1$2$newHead$1 extends d0.c implements c0.b {
    public static final MainActivity$silentUpdateNow$1$2$newHead$1 INSTANCE = new MainActivity$silentUpdateNow$1$2$newHead$1();

    public MainActivity$silentUpdateNow$1$2$newHead$1() {
        super(1);
    }

    @Override // c0.b
    public final CharSequence invoke(Channel channel) {
        b0.d.k(channel, "it");
        return channel.getName() + channel.getGroup();
    }
}
