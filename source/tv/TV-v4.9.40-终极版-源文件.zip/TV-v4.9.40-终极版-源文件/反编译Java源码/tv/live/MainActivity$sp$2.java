package tv.live;

import android.content.SharedPreferences;

/* loaded from: classes.dex */
public final class MainActivity$sp$2 extends d0.c implements c0.a {
    final /* synthetic */ MainActivity this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MainActivity$sp$2(MainActivity mainActivity) {
        super(0);
        this.this$0 = mainActivity;
    }

    @Override // c0.a
    public final SharedPreferences invoke() {
        return this.this$0.getSharedPreferences("tv", 0);
    }
}
