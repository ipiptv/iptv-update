package tv.live;

/* loaded from: classes.dex */
public final class MainActivity$startEpgDelayed$1$1 extends d0.c implements c0.a {
    final /* synthetic */ MainActivity this$0;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public MainActivity$startEpgDelayed$1$1(MainActivity mainActivity) {
        super(0);
        this.this$0 = mainActivity;
    }

    @Override // c0.a
    public /* bridge */ /* synthetic */ Object invoke() {
        m3invoke();
        return t.g.f554a;
    }

    /* renamed from: invoke, reason: collision with other method in class */
    public final void m3invoke() {
        this.this$0.refreshProgramUi();
    }
}
