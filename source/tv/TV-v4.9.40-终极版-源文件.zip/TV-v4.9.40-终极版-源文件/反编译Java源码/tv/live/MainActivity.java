package tv.live;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Paint;
import android.graphics.drawable.GradientDrawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Process;
import android.os.SystemClock;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.VideoView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.c0;
import androidx.recyclerview.widget.t0;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.NetworkInterface;
import java.net.URL;
import java.net.URLConnection;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Date;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.NoSuchElementException;
import java.util.RandomAccess;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.zip.GZIPInputStream;
import tv.live.UpdateChecker;

/* loaded from: classes.dex */
public final class MainActivity extends Activity {
    public static final Companion Companion = new Companion(null);
    public static final String DEFAULT_URL = "https://gitee.com/IptvIptv/Iptv/raw/master/bbxx365_hotel.m3u";
    public static final long EPG_DELAY_MS = 60000;
    public static final long LIST_PARSE_AFTER_FRAME_MS = 2000;
    public static final long LIST_PARSE_FALLBACK_MS = 8000;
    public static final long NUMBER_COMMIT_MS = 1500;
    public static final long PANEL_AUTO_HIDE_MS = 5000;
    public static final long SILENT_UPDATE_DELAY_MS = 120000;
    public static final long SILENT_UPDATE_INTERVAL_MS = 86400000;
    public static final int TIMEOUT_DEFAULT_SEC = 5;
    private long backArmedAt;
    private View bottomBar;
    private TextView bottomName;
    private TextView bottomNextProgram;
    private TextView bottomNextRes;
    private TextView bottomNowProgram;
    private TextView bottomNowRes;
    private TextView bottomNum;
    private boolean centerDownPending;
    private boolean centerLongPressFired;
    private ChannelAdapter channelAdapter;
    private int channelIndex;
    private RecyclerView channelListRv;
    private int channelPos;
    private float channelTextPx;
    private View configOverlay;
    private ConfigServer configServer;
    private int deadChannelCount;
    private ProgressBar dlBar;
    private TextView dlLabel;
    private LinearLayout dlPanel;
    private EpgAdapter epgAdapter;
    private View epgContainer;
    private TextView epgHint;
    private RecyclerView epgListRv;
    private boolean epgOpen;
    private int epgPos;
    private boolean epgRequested;
    private boolean epgStarted;
    private volatile boolean exiting;
    private int failoverCount;
    private GroupAdapter groupAdapter;
    private int groupIndex;
    private RecyclerView groupListRv;
    private int groupPos;
    private float groupTextPx;
    private TextView hintStrip;
    private long lastBackKeyAt;
    private boolean listLoading;
    private boolean listParsed;
    private LoadingSpinner loading;
    private TextView numberInput;
    private int panelAvailPx;
    private View panelContainer;
    private int panelState;
    private boolean pendingAutoPlayFirst;
    private boolean playCallbackFired;
    private int playSeq;
    private ImageView qrImage;
    private boolean quietResume;
    private int rowHeightPx;
    private ManageAdapter settingsAdapter;
    private TextView settingsHint;
    private int settingsLevel;
    private RecyclerView settingsList;
    private View settingsPanel;
    private int settingsPos;
    private TextView settingsTitle;
    private boolean silentUpdateStarted;
    private int sourceIndex;
    private TextView tvTime;
    private boolean uaHeaderUsed;
    private VideoView video;
    private final ExecutorService bgPool = Executors.newFixedThreadPool(2);
    private final long CENTER_LONG_PRESS_MS = 350;
    private final Handler centerHandler = new Handler(Looper.getMainLooper());
    private final Runnable centerLongPressRunnable = new t(this, 1);
    private final Handler bottomBarHandler = new Handler(Looper.getMainLooper());
    private final Runnable bottomBarHide = new t(this, 3);
    private String currentRes = "";
    private final List<ManageItem> settingsItems = new ArrayList();
    private final List<Channel> allChannels = new ArrayList();
    private final List<String> groups = new ArrayList();
    private int focusIndex = 1;
    private final List<Channel> channelListData = new ArrayList();
    private final List<EpgProgram> epgData = new ArrayList();
    private final Handler timeoutHandler = new Handler(Looper.getMainLooper());
    private final Runnable timeoutRunnable = new t(this, 4);
    private final Handler loadingHandler = new Handler(Looper.getMainLooper());
    private final Runnable loadingRunnable = new t(this, 5);
    private final Handler settingsHideHandler = new Handler(Looper.getMainLooper());
    private final Runnable settingsHideRunnable = new t(this, 6);
    private final Handler hideHandler = new Handler(Looper.getMainLooper());
    private final Runnable hideRunnable = new t(this, 7);
    private final Handler numHandler = new Handler(Looper.getMainLooper());
    private String numBuffer = "";
    private final Runnable numCommitRunnable = new t(this, 8);
    private final Handler timeHandler = new Handler(Looper.getMainLooper());
    private final MainActivity$timeRunnable$1 timeRunnable = new Runnable() { // from class: tv.live.MainActivity$timeRunnable$1
        @Override // java.lang.Runnable
        public void run() {
            TextView textView;
            Handler handler;
            textView = MainActivity.this.tvTime;
            if (textView == null) {
                b0.d.G("tvTime");
                throw null;
            }
            textView.setText(new SimpleDateFormat("HH:mm EEE", Locale.CHINESE).format(new Date()));
            handler = MainActivity.this.timeHandler;
            handler.postDelayed(this, 30000L);
        }
    };
    private final t.a sp$delegate = new t.d(new MainActivity$sp$2(this));
    private final long LIST_WATCHDOG_MS = 20000;
    private final Runnable listWatchdog = new t(this, 9);
    private final Runnable listParseRunnable = new t(this, 10);
    private final Runnable dlHide = new t(this, 11);
    private final Handler dlUi = new Handler(Looper.getMainLooper());
    private final long BUNDLED_STAMP = 2026111623;
    private final HashMap<String, List<Channel>> groupCache = new HashMap<>();
    private final int MAX_FAILOVER_PER_CHANNEL = 3;
    private final int MAX_DEAD_CHANNELS = 5;
    private final long BACK_CONFIRM_MS = LIST_PARSE_AFTER_FRAME_MS;
    private final Handler backHandler = new Handler(Looper.getMainLooper());
    private final Runnable backResetRunnable = new t(this, 2);

    public static final class Companion {
        private Companion() {
        }

        public /* synthetic */ Companion(d0.a aVar) {
            this();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void activateSettingsItem() {
        String str;
        Object obj;
        StringBuilder sb;
        int i2;
        int i3 = this.settingsPos;
        if (i3 < 0 || i3 >= this.settingsItems.size()) {
            return;
        }
        ManageItem manageItem = this.settingsItems.get(this.settingsPos);
        GroupStore groupStore = GroupStore.INSTANCE;
        Set<String> loadHidden = groupStore.loadHidden(this);
        int i4 = this.settingsLevel;
        if (i4 == 0) {
            String payload = manageItem.getPayload();
            switch (payload.hashCode()) {
                case 49:
                    if (payload.equals("1")) {
                        this.settingsLevel = 1;
                        this.settingsPos = 0;
                        buildSettingsItems();
                        return;
                    }
                    return;
                case 50:
                    if (payload.equals("2")) {
                        this.settingsLevel = 2;
                        this.settingsPos = 0;
                        buildSettingsItems();
                        return;
                    }
                    return;
                case 51:
                    if (payload.equals("3")) {
                        showConfig();
                        return;
                    }
                    return;
                case 52:
                    if (payload.equals("4")) {
                        this.settingsLevel = 3;
                        this.settingsPos = 0;
                        buildSettingsItems();
                        return;
                    }
                    return;
                case 53:
                    if (payload.equals("5")) {
                        refreshCurrentSource();
                        return;
                    }
                    return;
                case 54:
                    if (payload.equals("6")) {
                        boolean z2 = !getSp().getBoolean("show_clock", true);
                        getSp().edit().putBoolean("show_clock", z2).apply();
                        applyClockVisibility();
                        buildSettingsItems();
                        str = z2 ? "已开启时间显示" : "已关闭时间显示";
                        Toast.makeText(this, str, 0).show();
                        return;
                    }
                    return;
                case 55:
                    if (payload.equals("7")) {
                        startUpdateCheck();
                        return;
                    }
                    return;
                case 56:
                    if (payload.equals("8")) {
                        int i5 = getSp().getInt("load_timeout", 5);
                        int[] iArr = {3, 5, 6, 7, 9, 10};
                        int i6 = 0;
                        while (true) {
                            if (i6 >= 6) {
                                i6 = -1;
                            } else if (i5 != iArr[i6]) {
                                i6++;
                            }
                        }
                        if (i6 < 0) {
                            i6 = 1;
                        }
                        int i7 = iArr[(i6 + 1) % 6];
                        getSp().edit().putInt("load_timeout", i7).apply();
                        buildSettingsItems();
                        str = "加载超时改为 " + i7 + " 秒，到点没画面自动换";
                        Toast.makeText(this, str, 0).show();
                        return;
                    }
                    return;
                case 57:
                    if (payload.equals("9")) {
                        this.settingsLevel = 9;
                        this.settingsPos = 0;
                        buildSettingsItems();
                        return;
                    }
                    return;
                default:
                    return;
            }
        }
        if (i4 != 1) {
            if (i4 == 2) {
                if (manageItem.getPayload().length() == 0) {
                    return;
                }
                boolean contains = loadHidden.contains(manageItem.getPayload());
                String payload2 = manageItem.getPayload();
                if (contains) {
                    loadHidden.remove(payload2);
                } else {
                    loadHidden.add(payload2);
                }
                groupStore.saveHidden(this, loadHidden);
                applyGroupSettings();
                return;
            }
            if (i4 == 3) {
                if (b0.d.b(manageItem.getPayload(), "7")) {
                    closeSettings();
                    startUpdateCheck();
                    return;
                }
                return;
            }
            if (i4 != 9) {
                return;
            }
            String payload3 = manageItem.getPayload();
            if (b0.d.b(payload3, "1")) {
                this.settingsLevel = 1;
            } else if (!b0.d.b(payload3, "2")) {
                return;
            } else {
                this.settingsLevel = 2;
            }
            this.settingsPos = 0;
            buildSettingsItems();
            return;
        }
        int type = manageItem.getType();
        if (type != 0) {
            if (type == 1) {
                showConfig();
                return;
            }
            if (type != 3) {
                return;
            }
            String payload4 = manageItem.getPayload();
            if (b0.d.b(payload4, "5")) {
                refreshCurrentSource();
                return;
            } else {
                if (b0.d.b(payload4, "2")) {
                    this.settingsLevel = 2;
                    this.settingsPos = 0;
                    buildSettingsItems();
                    return;
                }
                return;
            }
        }
        List<SourceItem> load = SourceStore.INSTANCE.load(this);
        Iterator<T> it = load.iterator();
        while (true) {
            if (!it.hasNext()) {
                obj = null;
                break;
            } else {
                obj = it.next();
                if (b0.d.b(((SourceItem) obj).getId(), manageItem.getPayload())) {
                    break;
                }
            }
        }
        SourceItem sourceItem = (SourceItem) obj;
        if (sourceItem == null) {
            return;
        }
        if (sourceItem.getEnabled()) {
            if (load.isEmpty()) {
                i2 = 0;
            } else {
                Iterator<T> it2 = load.iterator();
                i2 = 0;
                while (it2.hasNext()) {
                    if (((SourceItem) it2.next()).getEnabled() && (i2 = i2 + 1) < 0) {
                        throw new ArithmeticException("Count overflow has happened.");
                    }
                }
            }
            if (i2 <= 1) {
                Toast.makeText(this, "至少要保留一个启用的源", 0).show();
                return;
            }
        }
        SourceStore.INSTANCE.setEnabled(this, manageItem.getPayload(), true ^ sourceItem.getEnabled());
        if (sourceItem.getEnabled()) {
            sb = new StringBuilder("已停用「");
            sb.append(manageItem.getTitle());
            sb.append((char) 12301);
        } else {
            sb = new StringBuilder("已启用「");
            sb.append(manageItem.getTitle());
            sb.append("」，合并显示");
        }
        Toast.makeText(this, sb.toString(), 0).show();
        buildSettingsItems();
        reloadMergedFromCache();
    }

    private final String appVersion() {
        try {
            String str = getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            return str == null ? "1.0" : str;
        } catch (Exception unused) {
            return "4.5";
        }
    }

    private final void applyClockVisibility() {
        boolean z2 = getSp().getBoolean("show_clock", true);
        TextView textView = this.tvTime;
        if (textView == null) {
            b0.d.G("tvTime");
            throw null;
        }
        textView.setVisibility(z2 ? 0 : 8);
        if (z2) {
            this.timeHandler.post(this.timeRunnable);
        }
    }

    private final void applyFillScreen(MediaPlayer mediaPlayer) {
        int videoWidth = mediaPlayer.getVideoWidth();
        int videoHeight = mediaPlayer.getVideoHeight();
        if (videoWidth <= 0 || videoHeight <= 0) {
            return;
        }
        int i2 = getResources().getDisplayMetrics().widthPixels;
        int i3 = getResources().getDisplayMetrics().heightPixels;
        float f2 = videoWidth / videoHeight;
        float f3 = i2;
        float f4 = i3;
        float f5 = f3 / f4;
        VideoView videoView = this.video;
        if (videoView == null) {
            b0.d.G("video");
            throw null;
        }
        ViewGroup.LayoutParams layoutParams = videoView.getLayoutParams();
        if (f2 < f5) {
            layoutParams.width = i2;
            layoutParams.height = (int) (f3 / f2);
        } else {
            layoutParams.width = (int) (f4 * f2);
            layoutParams.height = i3;
        }
        VideoView videoView2 = this.video;
        if (videoView2 != null) {
            videoView2.setLayoutParams(layoutParams);
        } else {
            b0.d.G("video");
            throw null;
        }
    }

    private final void applyFocusStyle() {
        GroupAdapter groupAdapter = this.groupAdapter;
        if (groupAdapter == null) {
            b0.d.G("groupAdapter");
            throw null;
        }
        groupAdapter.setFocused(this.focusIndex == 0);
        ChannelAdapter channelAdapter = this.channelAdapter;
        if (channelAdapter == null) {
            b0.d.G("channelAdapter");
            throw null;
        }
        channelAdapter.setFocused(this.focusIndex == 1);
        GroupAdapter groupAdapter2 = this.groupAdapter;
        if (groupAdapter2 == null) {
            b0.d.G("groupAdapter");
            throw null;
        }
        groupAdapter2.notifyDataSetChanged();
        ChannelAdapter channelAdapter2 = this.channelAdapter;
        if (channelAdapter2 == null) {
            b0.d.G("channelAdapter");
            throw null;
        }
        channelAdapter2.notifyDataSetChanged();
        EpgAdapter epgAdapter = this.epgAdapter;
        if (epgAdapter == null) {
            b0.d.G("epgAdapter");
            throw null;
        }
        epgAdapter.setFocused(this.focusIndex == 2);
        EpgAdapter epgAdapter2 = this.epgAdapter;
        if (epgAdapter2 != null) {
            epgAdapter2.notifyDataSetChanged();
        } else {
            b0.d.G("epgAdapter");
            throw null;
        }
    }

    private final void applyGroupSettings() {
        this.groups.clear();
        this.groups.addAll(GroupStore.INSTANCE.apply(this, rawGroupNames()));
        int i2 = 0;
        if (this.groups.isEmpty()) {
            this.groupIndex = 0;
        } else {
            int m2 = b0.d.m(this.groupIndex, 0, this.groups.size() - 1);
            this.groupIndex = m2;
            int size = channelsOfGroup(m2).size();
            if (size != 0) {
                i2 = b0.d.m(this.channelIndex, 0, size - 1);
            }
        }
        this.channelIndex = i2;
        this.groupPos = this.groupIndex;
        this.channelPos = this.channelIndex;
        GroupAdapter groupAdapter = this.groupAdapter;
        if (groupAdapter == null) {
            b0.d.G("groupAdapter");
            throw null;
        }
        groupAdapter.notifyDataSetChanged();
        buildSettingsItems();
    }

    private final void armSettingsAutoHide() {
        this.settingsHideHandler.removeCallbacks(this.settingsHideRunnable);
        this.settingsHideHandler.postDelayed(this.settingsHideRunnable, PANEL_AUTO_HIDE_MS);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void backResetRunnable$lambda$93(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        mainActivity.backArmedAt = 0L;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void bottomBarHide$lambda$2(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        if (mainActivity.panelState == 0) {
            View view = mainActivity.bottomBar;
            if (view != null) {
                view.setVisibility(8);
            } else {
                b0.d.G("bottomBar");
                throw null;
            }
        }
    }

    private final void buildGroups() {
        this.groups.clear();
        List<String> apply = GroupStore.INSTANCE.apply(this, rawGroupNames());
        List<String> list = this.groups;
        if (apply.isEmpty()) {
            apply = rawGroupNames();
        }
        list.addAll(apply);
        int i2 = 0;
        for (Object obj : this.allChannels) {
            int i3 = i2 + 1;
            if (i2 < 0) {
                throw new ArithmeticException("Index overflow has happened.");
            }
            ((Channel) obj).setNumber(i3);
            i2 = i3;
        }
        rebuildGroupCache();
        this.groupIndex = 0;
        this.channelIndex = 0;
        this.groupPos = 0;
        this.channelPos = 0;
    }

    /* JADX WARN: Removed duplicated region for block: B:23:0x0384  */
    /* JADX WARN: Removed duplicated region for block: B:26:0x0392  */
    /* JADX WARN: Removed duplicated region for block: B:40:0x03b8  */
    /* JADX WARN: Removed duplicated region for block: B:53:0x03e2  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final void buildSettingsItems() {
        /*
            Method dump skipped, instructions count: 1006
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: tv.live.MainActivity.buildSettingsItems():void");
    }

    private final boolean bundledNeedApply() {
        return !cacheExists() || getSp().getLong("bundled_stamp", 0L) < this.BUNDLED_STAMP;
    }

    private final boolean cacheExists() {
        return getCacheFile().exists() && getCacheFile().length() > 0;
    }

    private final void centerEpgOn(int i2) {
        RecyclerView recyclerView = this.epgListRv;
        if (recyclerView != null) {
            recyclerView.post(new q(i2, 2, this));
        } else {
            b0.d.G("epgListRv");
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void centerEpgOn$lambda$89(MainActivity mainActivity, int i2) {
        int i3;
        b0.d.k(mainActivity, "this$0");
        RecyclerView recyclerView = mainActivity.epgListRv;
        if (recyclerView == null) {
            b0.d.G("epgListRv");
            throw null;
        }
        t0 layoutManager = recyclerView.getLayoutManager();
        LinearLayoutManager linearLayoutManager = layoutManager instanceof LinearLayoutManager ? (LinearLayoutManager) layoutManager : null;
        if (linearLayoutManager == null) {
            return;
        }
        RecyclerView recyclerView2 = mainActivity.epgListRv;
        if (recyclerView2 == null) {
            b0.d.G("epgListRv");
            throw null;
        }
        int height = recyclerView2.getHeight();
        EpgAdapter epgAdapter = mainActivity.epgAdapter;
        if (epgAdapter == null) {
            i3 = mainActivity.rowHeightPx;
        } else {
            if (epgAdapter == null) {
                b0.d.G("epgAdapter");
                throw null;
            }
            i3 = epgAdapter.getRowHeightPx();
        }
        int i4 = (height - i3) / 2;
        if (i4 < 0) {
            i4 = 0;
        }
        linearLayoutManager.f59w = i2;
        linearLayoutManager.f60x = i4;
        c0 c0Var = linearLayoutManager.f61y;
        if (c0Var != null) {
            c0Var.f138a = -1;
        }
        linearLayoutManager.h0();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void centerLongPressRunnable$lambda$1(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        mainActivity.centerLongPressFired = true;
        Channel channel = (Channel) u.i.P(mainActivity.channelsOfGroup(mainActivity.groupIndex), mainActivity.channelIndex);
        if (channel != null) {
            mainActivity.showOsd(channel, mainActivity.channelIndex);
        }
    }

    private final List<Channel> channelsOfGroup(int i2) {
        List<Channel> list;
        String str = (String) u.i.P(this.groups, i2);
        u.k kVar = u.k.f624a;
        if (str != null) {
            list = this.groupCache.get(str);
            if (list == null) {
                list = kVar;
            }
        } else {
            list = null;
        }
        return list == null ? kVar : list;
    }

    private final void clearNumberInput() {
        this.numHandler.removeCallbacks(this.numCommitRunnable);
        this.numBuffer = "";
        TextView textView = this.numberInput;
        if (textView != null) {
            textView.setVisibility(8);
        } else {
            b0.d.G("numberInput");
            throw null;
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void closePanel() {
        this.panelState = 0;
        this.epgOpen = false;
        View view = this.epgContainer;
        if (view == null) {
            b0.d.G("epgContainer");
            throw null;
        }
        view.setVisibility(8);
        TextView textView = this.hintStrip;
        if (textView == null) {
            b0.d.G("hintStrip");
            throw null;
        }
        textView.setVisibility(0);
        View view2 = this.panelContainer;
        if (view2 == null) {
            b0.d.G("panelContainer");
            throw null;
        }
        view2.setVisibility(8);
        this.bottomBarHandler.removeCallbacks(this.bottomBarHide);
        View view3 = this.bottomBar;
        if (view3 == null) {
            b0.d.G("bottomBar");
            throw null;
        }
        view3.setVisibility(8);
        this.hideHandler.removeCallbacks(this.hideRunnable);
    }

    private final void closeSettings() {
        this.settingsHideHandler.removeCallbacks(this.settingsHideRunnable);
        View view = this.settingsPanel;
        if (view == null) {
            b0.d.G("settingsPanel");
            throw null;
        }
        view.setVisibility(8);
        if (this.panelState == 3) {
            this.panelState = 0;
        }
    }

    private final void commitNumberInput() {
        int indexOf;
        this.numHandler.removeCallbacks(this.numCommitRunnable);
        if (this.numBuffer.length() == 0) {
            return;
        }
        Integer L = h0.f.L(this.numBuffer);
        this.numBuffer = "";
        TextView textView = this.numberInput;
        Object obj = null;
        if (textView == null) {
            b0.d.G("numberInput");
            throw null;
        }
        textView.setVisibility(8);
        if (L == null) {
            return;
        }
        Iterator<T> it = this.allChannels.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            Object next = it.next();
            if (((Channel) next).getNumber() == L.intValue()) {
                obj = next;
                break;
            }
        }
        Channel channel = (Channel) obj;
        if (channel == null) {
            Toast.makeText(this, "频道 " + L + " 不存在", 0).show();
            return;
        }
        int indexOf2 = this.groups.indexOf(channel.getGroup());
        if (indexOf2 >= 0 && (indexOf = channelsOfGroup(indexOf2).indexOf(channel)) >= 0) {
            this.groupIndex = indexOf2;
            this.channelIndex = indexOf;
            this.sourceIndex = 0;
            playSource(channel, 0);
            showOsd(channel, indexOf);
            if (this.panelState != 0) {
                closePanel();
            }
            this.groupPos = indexOf2;
            this.channelPos = indexOf;
        }
    }

    private final void computeRowMetrics(int i2) {
        ViewGroup.LayoutParams layoutParams;
        ViewGroup.LayoutParams layoutParams2;
        int i3 = getResources().getDisplayMetrics().heightPixels;
        int i4 = getResources().getDisplayMetrics().widthPixels;
        int dp = i3 - dp(80);
        int dp2 = dp(240);
        if (dp < dp2) {
            dp = dp2;
        }
        int dp3 = dp(14) + dp;
        int i5 = dp / 10;
        int dp4 = dp(28);
        if (i5 < dp4) {
            i5 = dp4;
        }
        int i6 = dp3 / 8;
        int dp5 = dp(40);
        if (i6 < dp5) {
            i6 = dp5;
        }
        dp(28);
        int i7 = dp / 7;
        dp(44);
        this.panelAvailPx = dp;
        View view = this.settingsPanel;
        if (view != null && (layoutParams2 = view.getLayoutParams()) != null && layoutParams2.height != dp) {
            layoutParams2.height = dp;
            View view2 = this.settingsPanel;
            if (view2 == null) {
                b0.d.G("settingsPanel");
                throw null;
            }
            view2.setLayoutParams(layoutParams2);
        }
        this.rowHeightPx = i5;
        float f2 = i3 / 1080.0f;
        if (f2 < 0.9f) {
            f2 = 0.9f;
        } else if (f2 > 2.2f) {
            f2 = 2.2f;
        }
        float f3 = 32.0f * f2;
        this.groupTextPx = f3;
        this.channelTextPx = f3;
        GroupAdapter groupAdapter = this.groupAdapter;
        if (groupAdapter != null) {
            groupAdapter.setRowHeightPx(i5);
            GroupAdapter groupAdapter2 = this.groupAdapter;
            if (groupAdapter2 == null) {
                b0.d.G("groupAdapter");
                throw null;
            }
            groupAdapter2.setTextSizePx(this.groupTextPx);
            GroupAdapter groupAdapter3 = this.groupAdapter;
            if (groupAdapter3 == null) {
                b0.d.G("groupAdapter");
                throw null;
            }
            groupAdapter3.notifyDataSetChanged();
        }
        ChannelAdapter channelAdapter = this.channelAdapter;
        if (channelAdapter != null) {
            channelAdapter.setRowHeightPx(i6);
            ChannelAdapter channelAdapter2 = this.channelAdapter;
            if (channelAdapter2 == null) {
                b0.d.G("channelAdapter");
                throw null;
            }
            channelAdapter2.setTextSizePx(this.channelTextPx);
            ChannelAdapter channelAdapter3 = this.channelAdapter;
            if (channelAdapter3 == null) {
                b0.d.G("channelAdapter");
                throw null;
            }
            channelAdapter3.notifyDataSetChanged();
        }
        EpgAdapter epgAdapter = this.epgAdapter;
        if (epgAdapter != null) {
            epgAdapter.setRowHeightPx(i6);
            EpgAdapter epgAdapter2 = this.epgAdapter;
            if (epgAdapter2 == null) {
                b0.d.G("epgAdapter");
                throw null;
            }
            epgAdapter2.setTextSizePx(f2 * 34.0f);
            EpgAdapter epgAdapter3 = this.epgAdapter;
            if (epgAdapter3 == null) {
                b0.d.G("epgAdapter");
                throw null;
            }
            epgAdapter3.notifyDataSetChanged();
        }
        ManageAdapter manageAdapter = this.settingsAdapter;
        if (manageAdapter != null) {
            manageAdapter.setRowHeightPx(i5);
            ManageAdapter manageAdapter2 = this.settingsAdapter;
            if (manageAdapter2 == null) {
                b0.d.G("settingsAdapter");
                throw null;
            }
            manageAdapter2.setTextSizePx(f3);
            ManageAdapter manageAdapter3 = this.settingsAdapter;
            if (manageAdapter3 == null) {
                b0.d.G("settingsAdapter");
                throw null;
            }
            manageAdapter3.notifyDataSetChanged();
        }
        int i8 = (int) (i4 * 0.2f);
        View view3 = this.settingsPanel;
        if (view3 != null && (layoutParams = view3.getLayoutParams()) != null && (layoutParams.width != i8 || layoutParams.height != dp)) {
            layoutParams.width = i8;
            layoutParams.height = dp;
            View view4 = this.settingsPanel;
            if (view4 == null) {
                b0.d.G("settingsPanel");
                throw null;
            }
            view4.setLayoutParams(layoutParams);
        }
        RecyclerView recyclerView = this.groupListRv;
        if (recyclerView == null) {
            b0.d.G("groupListRv");
            throw null;
        }
        ViewGroup.LayoutParams layoutParams3 = recyclerView.getLayoutParams();
        layoutParams3.height = dp;
        RecyclerView recyclerView2 = this.groupListRv;
        if (recyclerView2 == null) {
            b0.d.G("groupListRv");
            throw null;
        }
        recyclerView2.setLayoutParams(layoutParams3);
        RecyclerView recyclerView3 = this.channelListRv;
        if (recyclerView3 == null) {
            b0.d.G("channelListRv");
            throw null;
        }
        ViewGroup.LayoutParams layoutParams4 = recyclerView3.getLayoutParams();
        layoutParams4.height = dp3;
        RecyclerView recyclerView4 = this.channelListRv;
        if (recyclerView4 == null) {
            b0.d.G("channelListRv");
            throw null;
        }
        recyclerView4.setLayoutParams(layoutParams4);
        View view5 = this.epgContainer;
        if (view5 == null) {
            b0.d.G("epgContainer");
            throw null;
        }
        ViewGroup.LayoutParams layoutParams5 = view5.getLayoutParams();
        layoutParams5.height = dp3;
        View view6 = this.epgContainer;
        if (view6 == null) {
            b0.d.G("epgContainer");
            throw null;
        }
        view6.setLayoutParams(layoutParams5);
        int dp6 = dp(2);
        int dp7 = dp(20);
        View[] viewArr = new View[2];
        RecyclerView recyclerView5 = this.channelListRv;
        if (recyclerView5 == null) {
            b0.d.G("channelListRv");
            throw null;
        }
        viewArr[0] = recyclerView5;
        View view7 = this.epgContainer;
        if (view7 == null) {
            b0.d.G("epgContainer");
            throw null;
        }
        viewArr[1] = view7;
        for (View view8 : b0.d.z(viewArr)) {
            ViewGroup.LayoutParams layoutParams6 = view8.getLayoutParams();
            b0.d.i(layoutParams6, "null cannot be cast to non-null type android.view.ViewGroup.MarginLayoutParams");
            ViewGroup.MarginLayoutParams marginLayoutParams = (ViewGroup.MarginLayoutParams) layoutParams6;
            marginLayoutParams.setMarginStart(dp6);
            view8.setLayoutParams(marginLayoutParams);
        }
        TextView textView = this.hintStrip;
        if (textView == null) {
            b0.d.G("hintStrip");
            throw null;
        }
        ViewGroup.LayoutParams layoutParams7 = textView.getLayoutParams();
        layoutParams7.width = dp7;
        layoutParams7.height = dp3;
        TextView textView2 = this.hintStrip;
        if (textView2 == null) {
            b0.d.G("hintStrip");
            throw null;
        }
        textView2.setLayoutParams(layoutParams7);
        int dp8 = i4 - dp(36);
        Paint paint = new Paint(1);
        paint.setTextSize(this.groupTextPx);
        List<String> list = this.groups;
        ArrayList arrayList = new ArrayList(b0.c.M(list));
        Iterator<T> it = list.iterator();
        while (it.hasNext()) {
            arrayList.add(Float.valueOf(paint.measureText((String) it.next())));
        }
        float f4 = dp8;
        int m2 = b0.d.m((int) ((arrayList.isEmpty() ? dp(90) : p85(arrayList)) + dp(34)), dp(120), (int) (0.22f * f4));
        paint.setTextSize(this.channelTextPx);
        float measureText = paint.measureText("888") + dp(8);
        int dp9 = dp(16) + dp(8);
        List<Channel> channelsOfGroup = channelsOfGroup(i2);
        if (!(!channelsOfGroup.isEmpty())) {
            channelsOfGroup = this.allChannels;
        }
        ArrayList arrayList2 = new ArrayList(b0.c.M(channelsOfGroup));
        Iterator<T> it2 = channelsOfGroup.iterator();
        while (it2.hasNext()) {
            arrayList2.add(Float.valueOf(paint.measureText(((Channel) it2.next()).getName())));
        }
        int m3 = b0.d.m((int) (((arrayList2.isEmpty() ? dp(80) : p85(arrayList2)) * 1.7f) + dp(4) + measureText + dp9 + dp(30)), dp(200), (int) (f4 * 0.4f));
        int i9 = (((dp8 - m2) - m3) - (dp6 * 2)) - dp7;
        int dp10 = dp(320);
        if (i9 < dp10) {
            i9 = dp10;
        }
        RecyclerView recyclerView6 = this.groupListRv;
        if (recyclerView6 == null) {
            b0.d.G("groupListRv");
            throw null;
        }
        ViewGroup.LayoutParams layoutParams8 = recyclerView6.getLayoutParams();
        layoutParams8.width = m2;
        RecyclerView recyclerView7 = this.groupListRv;
        if (recyclerView7 == null) {
            b0.d.G("groupListRv");
            throw null;
        }
        recyclerView7.setLayoutParams(layoutParams8);
        RecyclerView recyclerView8 = this.channelListRv;
        if (recyclerView8 == null) {
            b0.d.G("channelListRv");
            throw null;
        }
        ViewGroup.LayoutParams layoutParams9 = recyclerView8.getLayoutParams();
        layoutParams9.width = m3;
        RecyclerView recyclerView9 = this.channelListRv;
        if (recyclerView9 == null) {
            b0.d.G("channelListRv");
            throw null;
        }
        recyclerView9.setLayoutParams(layoutParams9);
        View view9 = this.epgContainer;
        if (view9 == null) {
            b0.d.G("epgContainer");
            throw null;
        }
        ViewGroup.LayoutParams layoutParams10 = view9.getLayoutParams();
        layoutParams10.width = i9;
        View view10 = this.epgContainer;
        if (view10 == null) {
            b0.d.G("epgContainer");
            throw null;
        }
        view10.setLayoutParams(layoutParams10);
    }

    public static /* synthetic */ void computeRowMetrics$default(MainActivity mainActivity, int i2, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            i2 = mainActivity.groupIndex;
        }
        mainActivity.computeRowMetrics(i2);
    }

    private final void confirmUpdate(final UpdateChecker.Remote remote) {
        StringBuilder sb = new StringBuilder("当前版本 v");
        sb.append(appVersion());
        sb.append("  →  新版本 v");
        sb.append(remote.getVersionName());
        sb.append("\n\n");
        if (remote.getNote().length() > 0) {
            sb.append(remote.getNote());
        }
        new AlertDialog.Builder(this).setTitle("发现新版本").setMessage(sb.toString()).setPositiveButton("立即更新", new DialogInterface.OnClickListener() { // from class: tv.live.i
            @Override // android.content.DialogInterface.OnClickListener
            public final void onClick(DialogInterface dialogInterface, int i2) {
                MainActivity.confirmUpdate$lambda$23(MainActivity.this, remote, dialogInterface, i2);
            }
        }).setNegativeButton("以后再说", (DialogInterface.OnClickListener) null).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void confirmUpdate$lambda$23(MainActivity mainActivity, UpdateChecker.Remote remote, DialogInterface dialogInterface, int i2) {
        b0.d.k(mainActivity, "this$0");
        b0.d.k(remote, "$remote");
        mainActivity.downloadAndInstall(remote);
    }

    private final void copyBundledToCache() {
        try {
            InputStream openBundledM3u = openBundledM3u();
            try {
                FileOutputStream fileOutputStream = new FileOutputStream(getCacheFile());
                try {
                    b0.d.q(openBundledM3u, fileOutputStream, 8192);
                    b0.d.l(fileOutputStream, null);
                    b0.d.l(openBundledM3u, null);
                    getSp().edit().putLong("bundled_stamp", this.BUNDLED_STAMP).apply();
                } finally {
                }
            } finally {
            }
        } catch (Throwable unused) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String currentProgramOf(String str) {
        EpgProgram epgProgram = (EpgProgram) EpgRepository.INSTANCE.nowNext(str).f547a;
        if (epgProgram != null) {
            return epgProgram.getTitle();
        }
        return null;
    }

    private final SourceItem currentSourceItem() {
        Object obj;
        List<SourceItem> load = SourceStore.INSTANCE.load(this);
        Iterator<T> it = load.iterator();
        while (true) {
            if (!it.hasNext()) {
                obj = null;
                break;
            }
            obj = it.next();
            if (b0.d.b(((SourceItem) obj).getId(), SourceStore.INSTANCE.currentId(this))) {
                break;
            }
        }
        SourceItem sourceItem = (SourceItem) obj;
        if (sourceItem != null) {
            return sourceItem;
        }
        b0.d.k(load, "<this>");
        return load.isEmpty() ? null : load.get(0);
    }

    private final String customUaOfLine(Channel channel, String str) {
        String str2;
        Object obj;
        String ua;
        String srcIdOfLine = srcIdOfLine(channel, str);
        Iterator<T> it = SourceStore.INSTANCE.load(this).iterator();
        while (true) {
            str2 = null;
            if (!it.hasNext()) {
                obj = null;
                break;
            }
            obj = it.next();
            if (b0.d.b(((SourceItem) obj).getId(), srcIdOfLine)) {
                break;
            }
        }
        SourceItem sourceItem = (SourceItem) obj;
        if (sourceItem != null && (ua = sourceItem.getUa()) != null) {
            str2 = h0.h.j0(ua).toString();
        }
        return str2 == null ? "" : str2;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void dlHide$lambda$26(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        mainActivity.hideDownloadPanel();
    }

    private final void downloadAndInstall(UpdateChecker.Remote remote) {
        showDownloadPanel("正在下载 v" + remote.getVersionName() + "   0%");
        this.bgPool.execute(new j(this, remote));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void downloadAndInstall$lambda$25(MainActivity mainActivity, UpdateChecker.Remote remote) {
        b0.d.k(mainActivity, "this$0");
        b0.d.k(remote, "$remote");
        try {
            UpdateChecker.INSTANCE.checkAndInstall(mainActivity, remote.getApkUrl(), new MainActivity$downloadAndInstall$1$1(mainActivity), new MainActivity$downloadAndInstall$1$2(mainActivity, remote));
        } catch (Throwable th) {
            mainActivity.runOnUiThread(new o(mainActivity, th, 4));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void downloadAndInstall$lambda$25$lambda$24(MainActivity mainActivity, Throwable th) {
        b0.d.k(mainActivity, "this$0");
        b0.d.k(th, "$e");
        String message = th.getMessage();
        if (message == null) {
            message = "未知错误";
        }
        mainActivity.setDownloadText("下载失败：".concat(message));
        mainActivity.hideDownloadPanelDelayed(BootReceiver.START_DELAY_MS);
    }

    private final int dp(int i2) {
        return (int) (i2 * getResources().getDisplayMetrics().density);
    }

    private final LinearLayout ensureDownloadPanel() {
        LinearLayout linearLayout = this.dlPanel;
        if (linearLayout != null) {
            return linearLayout;
        }
        ViewGroup viewGroup = (ViewGroup) findViewById(android.R.id.content);
        if (viewGroup == null) {
            return null;
        }
        LinearLayout linearLayout2 = new LinearLayout(this);
        linearLayout2.setOrientation(1);
        GradientDrawable gradientDrawable = new GradientDrawable();
        gradientDrawable.setColor(-435154928);
        gradientDrawable.setCornerRadius(dp(10));
        linearLayout2.setBackgroundDrawable(gradientDrawable);
        linearLayout2.setPadding(dp(24), dp(12), dp(24), dp(14));
        TextView textView = new TextView(this);
        textView.setTextColor(-1);
        textView.setTextSize(15.0f);
        textView.setText("");
        linearLayout2.addView(textView, new LinearLayout.LayoutParams(-1, -2));
        ProgressBar progressBar = new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal);
        progressBar.setMax(100);
        progressBar.setProgress(0);
        LinearLayout.LayoutParams layoutParams = new LinearLayout.LayoutParams(-1, dp(6));
        layoutParams.topMargin = dp(8);
        linearLayout2.addView(progressBar, layoutParams);
        FrameLayout.LayoutParams layoutParams2 = new FrameLayout.LayoutParams((int) (getResources().getDisplayMetrics().widthPixels * 0.45f), -2);
        layoutParams2.gravity = 81;
        layoutParams2.bottomMargin = dp(96);
        linearLayout2.setLayoutParams(layoutParams2);
        linearLayout2.setVisibility(8);
        viewGroup.addView(linearLayout2);
        this.dlPanel = linearLayout2;
        this.dlBar = progressBar;
        this.dlLabel = textView;
        return linearLayout2;
    }

    private final void exitToHome() {
        VideoView videoView;
        if (this.exiting) {
            return;
        }
        this.exiting = true;
        this.loadingHandler.removeCallbacksAndMessages(null);
        this.timeoutHandler.removeCallbacksAndMessages(null);
        this.centerHandler.removeCallbacksAndMessages(null);
        this.hideHandler.removeCallbacksAndMessages(null);
        this.settingsHideHandler.removeCallbacksAndMessages(null);
        this.bottomBarHandler.removeCallbacksAndMessages(null);
        this.timeHandler.removeCallbacksAndMessages(null);
        this.backHandler.removeCallbacksAndMessages(null);
        LoadingSpinner loadingSpinner = this.loading;
        if (loadingSpinner == null) {
            b0.d.G("loading");
            throw null;
        }
        loadingSpinner.setVisibility(8);
        try {
            videoView = this.video;
        } catch (Throwable unused) {
        }
        if (videoView == null) {
            b0.d.G("video");
            throw null;
        }
        videoView.stopPlayback();
        try {
            Intent intent = new Intent("android.intent.action.MAIN");
            intent.addCategory("android.intent.category.HOME");
            intent.addFlags(268435456);
            startActivity(intent);
        } catch (Throwable unused2) {
        }
        try {
            finishAndRemoveTask();
        } catch (Throwable unused3) {
            finish();
        }
    }

    private final File getCacheFile() {
        return SourceStore.INSTANCE.cacheFile(this);
    }

    private final SharedPreferences getSp() {
        return (SharedPreferences) ((t.d) this.sp$delegate).a();
    }

    private final List<String> groupsInSavedOrder() {
        List<String> rawGroupNames = rawGroupNames();
        List<String> loadOrder = GroupStore.INSTANCE.loadOrder(this);
        ArrayList arrayList = new ArrayList(rawGroupNames.size());
        for (String str : loadOrder) {
            if (rawGroupNames.contains(str) && !arrayList.contains(str)) {
                arrayList.add(str);
            }
        }
        for (String str2 : rawGroupNames) {
            if (!arrayList.contains(str2)) {
                arrayList.add(str2);
            }
        }
        return arrayList;
    }

    private final void handleBackExit() {
        long elapsedRealtime = SystemClock.elapsedRealtime();
        if (elapsedRealtime - this.lastBackKeyAt < 250) {
            return;
        }
        this.lastBackKeyAt = elapsedRealtime;
        this.backHandler.removeCallbacks(this.backResetRunnable);
        long j2 = this.backArmedAt;
        if (j2 > 0 && elapsedRealtime - j2 <= this.BACK_CONFIRM_MS) {
            this.backArmedAt = 0L;
            exitToHome();
        } else {
            this.backArmedAt = elapsedRealtime;
            Toast.makeText(this, "再按一次返回桌面", 0).show();
            this.backHandler.postDelayed(this.backResetRunnable, this.BACK_CONFIRM_MS);
        }
    }

    private final boolean handleBackOnUp(int i2) {
        if (i2 != 4) {
            return false;
        }
        View view = this.settingsPanel;
        if (view == null) {
            b0.d.G("settingsPanel");
            throw null;
        }
        if (view.getVisibility() == 0) {
            if (this.settingsLevel > 0) {
                this.settingsLevel = 0;
                this.settingsPos = 0;
                buildSettingsItems();
            } else {
                closeSettings();
            }
            return true;
        }
        View view2 = this.configOverlay;
        if (view2 == null) {
            b0.d.G("configOverlay");
            throw null;
        }
        if (view2.getVisibility() == 0) {
            hideConfig();
            return true;
        }
        if (this.panelState == 1) {
            closePanel();
            return true;
        }
        handleBackExit();
        return true;
    }

    private final boolean handleNumberKey(int i2) {
        int i3 = 7;
        if (!(7 <= i2 && i2 < 17)) {
            i3 = 144;
            if (!(144 <= i2 && i2 < 154)) {
                return false;
            }
        }
        int i4 = i2 - i3;
        if (this.numBuffer.length() >= 4) {
            this.numBuffer = "";
        }
        this.numBuffer += i4;
        updateNumberInputText();
        TextView textView = this.numberInput;
        if (textView == null) {
            b0.d.G("numberInput");
            throw null;
        }
        textView.setVisibility(0);
        this.numHandler.removeCallbacks(this.numCommitRunnable);
        this.numHandler.postDelayed(this.numCommitRunnable, NUMBER_COMMIT_MS);
        return true;
    }

    private final boolean handlePanelKey(int i2) {
        if (i2 != 4) {
            if (i2 != 66) {
                if (i2 != 82 && i2 != 176) {
                    switch (i2) {
                        case 19:
                            moveInPanel(-1);
                            return true;
                        case 20:
                            moveInPanel(1);
                            return true;
                        case 21:
                            int i3 = this.focusIndex;
                            if (i3 == 1) {
                                this.focusIndex = 0;
                                applyFocusStyle();
                            } else if (i3 != 2) {
                                closePanel();
                            } else {
                                hideEpgPanel();
                            }
                            return true;
                        case 22:
                            int i4 = this.focusIndex;
                            if (i4 == 0) {
                                this.focusIndex = 1;
                                applyFocusStyle();
                            } else if (i4 == 1) {
                                showEpgPanel();
                            }
                            return true;
                        case 23:
                            break;
                        default:
                            return false;
                    }
                }
            }
            if (this.focusIndex == 0) {
                this.focusIndex = 1;
                applyFocusStyle();
            } else {
                playSelectedChannel();
                closePanel();
            }
            return true;
        }
        closePanel();
        return true;
    }

    private final boolean handleSettingsKey(int i2) {
        int i3;
        ManageItem manageItem;
        armSettingsAutoHide();
        if (i2 == 4) {
            settingsBack();
            return true;
        }
        if (i2 != 66) {
            if (i2 == 82 || i2 == 176) {
                closeSettings();
                return true;
            }
            switch (i2) {
                case 19:
                    int i4 = this.settingsPos - 1;
                    i3 = i4 >= 0 ? i4 : 0;
                    this.settingsPos = i3;
                    ManageAdapter manageAdapter = this.settingsAdapter;
                    if (manageAdapter == null) {
                        b0.d.G("settingsAdapter");
                        throw null;
                    }
                    manageAdapter.setSelected(i3);
                    ManageAdapter manageAdapter2 = this.settingsAdapter;
                    if (manageAdapter2 == null) {
                        b0.d.G("settingsAdapter");
                        throw null;
                    }
                    manageAdapter2.notifyDataSetChanged();
                    RecyclerView recyclerView = this.settingsList;
                    if (recyclerView != null) {
                        recyclerView.a0(this.settingsPos);
                        return true;
                    }
                    b0.d.G("settingsList");
                    throw null;
                case 20:
                    int i5 = this.settingsPos + 1;
                    int size = this.settingsItems.size() - 1;
                    i3 = size >= 0 ? size : 0;
                    if (i5 > i3) {
                        i5 = i3;
                    }
                    this.settingsPos = i5;
                    ManageAdapter manageAdapter3 = this.settingsAdapter;
                    if (manageAdapter3 == null) {
                        b0.d.G("settingsAdapter");
                        throw null;
                    }
                    manageAdapter3.setSelected(i5);
                    ManageAdapter manageAdapter4 = this.settingsAdapter;
                    if (manageAdapter4 == null) {
                        b0.d.G("settingsAdapter");
                        throw null;
                    }
                    manageAdapter4.notifyDataSetChanged();
                    RecyclerView recyclerView2 = this.settingsList;
                    if (recyclerView2 != null) {
                        recyclerView2.a0(this.settingsPos);
                        return true;
                    }
                    b0.d.G("settingsList");
                    throw null;
                case 21:
                    int i6 = this.settingsLevel;
                    if (i6 == 2) {
                        moveGroupInSettings(-1);
                        return true;
                    }
                    if (i6 == 1 && (manageItem = (ManageItem) u.i.P(this.settingsItems, this.settingsPos)) != null && manageItem.getType() == 0) {
                        refreshSourceById(manageItem.getPayload(), manageItem.getTitle());
                        return true;
                    }
                    settingsBack();
                    return true;
                case 22:
                    if (this.settingsLevel == 2) {
                        moveGroupInSettings(1);
                        return true;
                    }
                    rightActionInSettings();
                    return true;
                case 23:
                    break;
                default:
                    return false;
            }
        }
        activateSettingsItem();
        return true;
    }

    private final void hideConfig() {
        View view = this.configOverlay;
        if (view == null) {
            b0.d.G("configOverlay");
            throw null;
        }
        view.setVisibility(8);
        stopConfigServer();
    }

    private final void hideDownloadPanel() {
        LinearLayout linearLayout = this.dlPanel;
        if (linearLayout != null) {
            linearLayout.setVisibility(8);
        }
        ProgressBar progressBar = this.dlBar;
        if (progressBar == null) {
            return;
        }
        progressBar.setProgress(0);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void hideDownloadPanelDelayed(long j2) {
        this.dlUi.removeCallbacks(this.dlHide);
        this.dlUi.postDelayed(this.dlHide, j2);
    }

    private final void hideEpgPanel() {
        this.epgOpen = false;
        View view = this.epgContainer;
        if (view == null) {
            b0.d.G("epgContainer");
            throw null;
        }
        view.setVisibility(8);
        TextView textView = this.hintStrip;
        if (textView == null) {
            b0.d.G("hintStrip");
            throw null;
        }
        textView.setVisibility(0);
        this.focusIndex = 1;
        applyFocusStyle();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void hideRunnable$lambda$6(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        mainActivity.closePanel();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final boolean isPlayingChannel(Channel channel) {
        return b0.d.b(channel.getName(), memGet$default(this, "last_name", null, 2, null)) && b0.d.b(channel.getGroup(), memGet$default(this, "last_group", null, 2, null));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void listParseRunnable$lambda$11(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        if (mainActivity.listParsed) {
            return;
        }
        mainActivity.listParsed = true;
        new Thread(new t(mainActivity, 14)).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void listParseRunnable$lambda$11$lambda$10(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        try {
            Process.setThreadPriority(10);
            mainActivity.loadCache();
        } catch (Throwable unused) {
        }
        mainActivity.runOnUiThread(new t(mainActivity, 16));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void listParseRunnable$lambda$11$lambda$10$lambda$9(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        if (mainActivity.allChannels.isEmpty()) {
            refreshFromNetwork$default(mainActivity, null, null, 3, null);
            return;
        }
        computeRowMetrics$default(mainActivity, 0, 1, null);
        GroupAdapter groupAdapter = mainActivity.groupAdapter;
        if (groupAdapter == null) {
            b0.d.G("groupAdapter");
            throw null;
        }
        groupAdapter.notifyDataSetChanged();
        if (mainActivity.pendingAutoPlayFirst) {
            mainActivity.pendingAutoPlayFirst = false;
            mainActivity.playChannel(0, false);
        } else {
            mainActivity.restoreSelectionFromPrefs();
            mainActivity.syncPlayingStateWithUrl(memGet$default(mainActivity, "last_url", null, 2, null), memGet$default(mainActivity, "last_name", null, 2, null));
        }
        if (mainActivity.panelState == 1) {
            mainActivity.reloadChannelList(mainActivity.groupIndex, mainActivity.channelIndex);
            mainActivity.refreshEpgPreview();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void listWatchdog$lambda$8(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        if (!mainActivity.allChannels.isEmpty()) {
            return;
        }
        LoadingSpinner loadingSpinner = mainActivity.loading;
        if (loadingSpinner == null) {
            b0.d.G("loading");
            throw null;
        }
        loadingSpinner.setVisibility(8);
        Toast.makeText(mainActivity, "内置频道列表没加载出来，正在联网重试", 1).show();
        refreshFromNetwork$default(mainActivity, "频道列表获取失败，请检查网络后进设置刷新源", null, 2, null);
    }

    private final void loadCache() {
        migrateLegacyCache();
        ArrayList arrayList = new ArrayList();
        HashMap<String, Channel> hashMap = new HashMap<>();
        for (SourceItem sourceItem : SourceStore.INSTANCE.enabledSources(this)) {
            List<Channel> list = u.k.f624a;
            File cacheFileFor = SourceStore.INSTANCE.cacheFileFor(this, sourceItem.getId());
            if (cacheFileFor.exists() && cacheFileFor.length() > 0) {
                try {
                    InputStreamReader inputStreamReader = new InputStreamReader(new FileInputStream(cacheFileFor), h0.a.f474a);
                    try {
                        List<Channel> parse = M3UParser.INSTANCE.parse(inputStreamReader);
                        b0.d.l(inputStreamReader, null);
                        list = parse;
                    } finally {
                    }
                } catch (Throwable unused) {
                }
            }
            if (list.isEmpty() && b0.d.b(sourceItem.getId(), SourceStore.DEFAULT_SOURCE_ID)) {
                list = parseBundled();
                if (!list.isEmpty()) {
                    copyBundledToCache();
                }
            }
            if (!list.isEmpty()) {
                mergeParsed(arrayList, hashMap, list, sourceItem.getId());
            }
        }
        if (arrayList.isEmpty()) {
            List<Channel> parseBundled = parseBundled();
            if (parseBundled.isEmpty()) {
                return;
            } else {
                mergeParsed(arrayList, hashMap, parseBundled, SourceStore.DEFAULT_SOURCE_ID);
            }
        }
        this.allChannels.clear();
        this.allChannels.addAll(arrayList);
        buildGroups();
    }

    private final void loadEpgOnDemand() {
        EpgRepository epgRepository = EpgRepository.INSTANCE;
        if (epgRepository.isLoaded() || this.epgRequested) {
            return;
        }
        this.epgRequested = true;
        epgRepository.load(this, new MainActivity$loadEpgOnDemand$1(this));
    }

    private final long loadTimeoutMs() {
        return b0.d.m(getSp().getInt("load_timeout", 5), 3, 10) * 1000;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void loadingRunnable$lambda$4(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        if (mainActivity.playCallbackFired || mainActivity.quietResume) {
            return;
        }
        LoadingSpinner loadingSpinner = mainActivity.loading;
        if (loadingSpinner != null) {
            loadingSpinner.setVisibility(0);
        } else {
            b0.d.G("loading");
            throw null;
        }
    }

    private final String localIpAddress() {
        String hostAddress;
        try {
            Enumeration<NetworkInterface> networkInterfaces = NetworkInterface.getNetworkInterfaces();
            while (networkInterfaces.hasMoreElements()) {
                NetworkInterface nextElement = networkInterfaces.nextElement();
                if (!nextElement.isLoopback() && nextElement.isUp()) {
                    Enumeration<InetAddress> inetAddresses = nextElement.getInetAddresses();
                    while (inetAddresses.hasMoreElements()) {
                        InetAddress nextElement2 = inetAddresses.nextElement();
                        if (!nextElement2.isLoopbackAddress() && (nextElement2 instanceof Inet4Address) && (hostAddress = ((Inet4Address) nextElement2).getHostAddress()) != null && (h0.h.d0(hostAddress, "192.168.", false) || h0.h.d0(hostAddress, "10.", false) || h0.h.d0(hostAddress, "172.", false))) {
                            return hostAddress;
                        }
                    }
                }
            }
            return "0.0.0.0";
        } catch (Exception unused) {
            return "0.0.0.0";
        }
    }

    private final String memGet(String str, String str2) {
        String string = getSp().getString(str + '_' + str2, null);
        if (!(string == null || string.length() == 0)) {
            return string;
        }
        if (b0.d.b(getSp().getString("last_url_source", null), str2)) {
            return getSp().getString(str, null);
        }
        return null;
    }

    public static /* synthetic */ String memGet$default(MainActivity mainActivity, String str, String str2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            str2 = SourceStore.INSTANCE.currentId(mainActivity);
        }
        return mainActivity.memGet(str, str2);
    }

    private final void memPut(String str, String str2) {
        String currentId = SourceStore.INSTANCE.currentId(this);
        getSp().edit().putString(str + '_' + currentId, str2).putString("last_url_source", currentId).apply();
    }

    private final void mergeParsed(List<Channel> list, HashMap<String, Channel> hashMap, List<Channel> list2, String str) {
        for (Channel channel : list2) {
            String str2 = channel.getGroup() + (char) 1 + channel.getName();
            Channel channel2 = hashMap.get(str2);
            if (channel2 == null) {
                Channel channel3 = new Channel(channel.getName(), channel.getGroup(), u.i.T(channel.getUrls()));
                Iterator<T> it = channel.getUrls().iterator();
                while (it.hasNext()) {
                    channel3.getUrlSrc().put((String) it.next(), str);
                }
                list.add(channel3);
                hashMap.put(str2, channel3);
            } else {
                for (String str3 : channel.getUrls()) {
                    if (!channel2.getUrls().contains(str3) && channel2.getUrls().size() < 500) {
                        channel2.getUrls().add(str3);
                        channel2.getUrlSrc().put(str3, str);
                    }
                }
            }
        }
    }

    private final void migrateLegacyCache() {
        try {
            File cacheFile = getCacheFile();
            File file = new File(getFilesDir(), "channels.m3u");
            if (cacheFile.exists() || !file.exists() || file.length() <= 0) {
                return;
            }
            b0.c.N(file, cacheFile);
            file.delete();
        } catch (Exception unused) {
        }
    }

    private final void moveGroupInSettings(int i2) {
        ArrayList T;
        int indexOf;
        int i3 = this.settingsPos;
        if (i3 < 0 || i3 >= this.settingsItems.size()) {
            return;
        }
        ManageItem manageItem = this.settingsItems.get(this.settingsPos);
        if (manageItem.getType() == 2) {
            if (!(manageItem.getPayload().length() == 0) && (indexOf = (T = u.i.T(groupsInSavedOrder())).indexOf(manageItem.getPayload())) >= 0) {
                int i4 = indexOf + i2;
                if (i4 < 0 || i4 >= T.size()) {
                    Toast.makeText(this, i2 < 0 ? "已经在最上面了" : "已经在最下面了", 0).show();
                    return;
                }
                String str = (String) T.get(i4);
                T.set(i4, T.get(indexOf));
                T.set(indexOf, str);
                ArrayList T2 = u.i.T(T);
                for (String str2 : rawGroupNames()) {
                    if (!T2.contains(str2)) {
                        T2.add(str2);
                    }
                }
                GroupStore.INSTANCE.saveOrder(this, T2);
                this.settingsPos = i4;
                applyGroupSettings();
            }
        }
    }

    private final void moveInPanel(int i2) {
        int i3;
        int i4 = this.focusIndex;
        if (i4 != 0) {
            if (i4 != 1) {
                if (this.epgData.isEmpty()) {
                    return;
                }
                int m2 = b0.d.m(this.epgPos + i2, 0, this.epgData.size() - 1);
                this.epgPos = m2;
                EpgAdapter epgAdapter = this.epgAdapter;
                if (epgAdapter == null) {
                    b0.d.G("epgAdapter");
                    throw null;
                }
                epgAdapter.setSelected(m2);
                EpgAdapter epgAdapter2 = this.epgAdapter;
                if (epgAdapter2 == null) {
                    b0.d.G("epgAdapter");
                    throw null;
                }
                epgAdapter2.notifyDataSetChanged();
                RecyclerView recyclerView = this.epgListRv;
                if (recyclerView != null) {
                    recyclerView.a0(this.epgPos);
                    return;
                } else {
                    b0.d.G("epgListRv");
                    throw null;
                }
            }
            int size = this.channelListData.size();
            if (size == 0) {
                return;
            }
            int m3 = b0.d.m(this.channelPos + i2, 0, size - 1);
            this.channelPos = m3;
            ChannelAdapter channelAdapter = this.channelAdapter;
            if (channelAdapter == null) {
                b0.d.G("channelAdapter");
                throw null;
            }
            channelAdapter.setSelected(m3);
            ChannelAdapter channelAdapter2 = this.channelAdapter;
            if (channelAdapter2 == null) {
                b0.d.G("channelAdapter");
                throw null;
            }
            channelAdapter2.notifyDataSetChanged();
            RecyclerView recyclerView2 = this.channelListRv;
            if (recyclerView2 == null) {
                b0.d.G("channelListRv");
                throw null;
            }
            recyclerView2.a0(this.channelPos);
        } else {
            if (this.groups.isEmpty()) {
                return;
            }
            if (i2 > 0) {
                i3 = (this.groupPos + 1) % this.groups.size();
            } else {
                int i5 = this.groupPos;
                if (i5 - 1 < 0) {
                    i5 = this.groups.size();
                }
                i3 = i5 - 1;
            }
            this.groupPos = i3;
            GroupAdapter groupAdapter = this.groupAdapter;
            if (groupAdapter == null) {
                b0.d.G("groupAdapter");
                throw null;
            }
            groupAdapter.setSelected(i3);
            GroupAdapter groupAdapter2 = this.groupAdapter;
            if (groupAdapter2 == null) {
                b0.d.G("groupAdapter");
                throw null;
            }
            groupAdapter2.notifyDataSetChanged();
            RecyclerView recyclerView3 = this.groupListRv;
            if (recyclerView3 == null) {
                b0.d.G("groupListRv");
                throw null;
            }
            recyclerView3.a0(this.groupPos);
            reloadChannelList(this.groupPos, 0);
        }
        refreshEpgPreview();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void numCommitRunnable$lambda$7(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        mainActivity.commitNumberInput();
    }

    private final void onPlaySuccess() {
        if (this.playCallbackFired) {
            return;
        }
        this.playCallbackFired = true;
        this.failoverCount = 0;
        this.deadChannelCount = 0;
        this.quietResume = false;
        this.timeoutHandler.removeCallbacks(this.timeoutRunnable);
        this.loadingHandler.removeCallbacks(this.loadingRunnable);
        LoadingSpinner loadingSpinner = this.loading;
        if (loadingSpinner == null) {
            b0.d.G("loading");
            throw null;
        }
        loadingSpinner.setVisibility(8);
        Channel channel = (Channel) u.i.P(channelsOfGroup(this.groupIndex), this.channelIndex);
        if (channel != null) {
            SourceMemory.INSTANCE.put(this, channel.getGroup(), channel.getName(), this.sourceIndex);
        }
        requestListParse(LIST_PARSE_AFTER_FRAME_MS);
        startEpgDelayed();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onResume$lambda$92(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        VideoView videoView = mainActivity.video;
        if (videoView == null) {
            b0.d.G("video");
            throw null;
        }
        if (videoView.isPlaying()) {
            return;
        }
        if (mainActivity.channelIndex < mainActivity.channelsOfGroup(mainActivity.groupIndex).size()) {
            mainActivity.quietResume = true;
            mainActivity.playChannel(mainActivity.channelIndex, false);
        }
    }

    private final void onVideoSize(int i2, int i3) {
        String sb;
        if (i2 <= 0 || i3 <= 0) {
            return;
        }
        int min = Math.min(i2, i3);
        if (min >= 2000) {
            sb = "4K";
        } else if (min >= 1000) {
            sb = "1080P";
        } else if (min >= 700) {
            sb = "720P";
        } else if (min >= 500) {
            sb = "576P";
        } else {
            StringBuilder sb2 = new StringBuilder();
            sb2.append(min);
            sb2.append('P');
            sb = sb2.toString();
        }
        this.currentRes = sb;
    }

    private final InputStream openBundledM3u() {
        try {
            return new GZIPInputStream(getAssets().open("default_channels.m3u.gz"));
        } catch (Throwable unused) {
            InputStream open = getAssets().open("default_channels.m3u");
            b0.d.h(open);
            return open;
        }
    }

    private final void openPanel() {
        this.panelState = 1;
        this.focusIndex = 1;
        View view = this.panelContainer;
        if (view == null) {
            b0.d.G("panelContainer");
            throw null;
        }
        view.setVisibility(0);
        if (this.allChannels.isEmpty() && !this.listParsed) {
            requestListParse(0L);
        }
        this.epgOpen = false;
        View view2 = this.epgContainer;
        if (view2 == null) {
            b0.d.G("epgContainer");
            throw null;
        }
        view2.setVisibility(8);
        TextView textView = this.hintStrip;
        if (textView == null) {
            b0.d.G("hintStrip");
            throw null;
        }
        textView.setVisibility(0);
        this.bottomBarHandler.removeCallbacks(this.bottomBarHide);
        View view3 = this.bottomBar;
        if (view3 == null) {
            b0.d.G("bottomBar");
            throw null;
        }
        view3.setVisibility(8);
        int i2 = this.groupIndex;
        this.groupPos = i2;
        this.channelPos = this.channelIndex;
        GroupAdapter groupAdapter = this.groupAdapter;
        if (groupAdapter == null) {
            b0.d.G("groupAdapter");
            throw null;
        }
        groupAdapter.setSelected(i2);
        reloadChannelList(this.groupPos, this.channelIndex);
        Channel channel = (Channel) u.i.P(channelsOfGroup(this.groupPos), this.channelIndex);
        if (channel != null) {
            updateBottomBar(channel);
        }
        RecyclerView recyclerView = this.groupListRv;
        if (recyclerView == null) {
            b0.d.G("groupListRv");
            throw null;
        }
        recyclerView.a0(this.groupPos);
        applyFocusStyle();
        refreshEpgPreview();
        loadEpgOnDemand();
        resetHideTimer();
    }

    private final float p85(List<Float> list) {
        List L;
        if (list.isEmpty()) {
            return RecyclerView.B0;
        }
        if (list.size() <= 1) {
            L = u.i.S(list);
        } else {
            Object[] array = list.toArray(new Comparable[0]);
            Comparable[] comparableArr = (Comparable[]) array;
            b0.d.k(comparableArr, "<this>");
            if (comparableArr.length > 1) {
                Arrays.sort(comparableArr);
            }
            L = b0.c.L(array);
        }
        return ((Number) L.get(b0.d.m((int) ((L.size() - 1) * 0.85f), 0, L.size() - 1))).floatValue();
    }

    private final List<Channel> parseBundled() {
        try {
            InputStream openBundledM3u = openBundledM3u();
            try {
                M3UParser m3UParser = M3UParser.INSTANCE;
                Reader inputStreamReader = new InputStreamReader(openBundledM3u, h0.a.f474a);
                List<Channel> parse = m3UParser.parse(inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192));
                b0.d.l(openBundledM3u, null);
                return parse;
            } finally {
            }
        } catch (Throwable unused) {
            return u.k.f624a;
        }
    }

    private final List<Channel> parseCacheFile() {
        u.k kVar = u.k.f624a;
        try {
            if (!cacheExists()) {
                return kVar;
            }
            FileInputStream fileInputStream = new FileInputStream(getCacheFile());
            try {
                M3UParser m3UParser = M3UParser.INSTANCE;
                Reader inputStreamReader = new InputStreamReader(fileInputStream, h0.a.f474a);
                List<Channel> parse = m3UParser.parse(inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192));
                b0.d.l(fileInputStream, null);
                return parse;
            } finally {
            }
        } catch (Throwable unused) {
            return kVar;
        }
    }

    private final void playChannel(int i2, boolean z2) {
        if (this.groups.isEmpty()) {
            return;
        }
        if (channelsOfGroup(this.groupIndex).isEmpty()) {
            Iterator<String> it = this.groups.iterator();
            int i3 = 0;
            while (true) {
                if (!it.hasNext()) {
                    i3 = -1;
                    break;
                }
                if (!channelsOfGroup(this.groups.indexOf(it.next())).isEmpty()) {
                    break;
                } else {
                    i3++;
                }
            }
            if (i3 >= 0) {
                this.groupIndex = i3;
                this.groupPos = i3;
                this.channelIndex = 0;
            }
        }
        List<Channel> channelsOfGroup = channelsOfGroup(this.groupIndex);
        if (i2 < 0 || i2 >= channelsOfGroup.size()) {
            return;
        }
        this.channelIndex = i2;
        Channel channel = channelsOfGroup.get(i2);
        int startIndexOf = startIndexOf(channel);
        this.sourceIndex = startIndexOf;
        showOsd(channel, i2);
        playWithProbe(channel, startIndexOf, z2);
    }

    public static /* synthetic */ void playChannel$default(MainActivity mainActivity, int i2, boolean z2, int i3, Object obj) {
        if ((i3 & 2) != 0) {
            z2 = true;
        }
        mainActivity.playChannel(i2, z2);
    }

    private final void playCurrentChannel() {
        if (channelsOfGroup(this.groupIndex).isEmpty()) {
            return;
        }
        int m2 = b0.d.m(this.channelIndex, 0, r0.size() - 1);
        this.channelIndex = m2;
        playChannel(m2, false);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void playSelectedChannel() {
        List<Channel> channelsOfGroup = channelsOfGroup(this.groupPos);
        int i2 = this.channelPos;
        if (i2 < 0 || i2 >= channelsOfGroup.size()) {
            return;
        }
        Channel channel = channelsOfGroup.get(this.channelPos);
        if (isPlayingChannel(channel)) {
            closePanel();
            return;
        }
        this.groupIndex = this.groupPos;
        this.channelIndex = this.channelPos;
        int startIndexOf = startIndexOf(channel);
        this.sourceIndex = startIndexOf;
        showOsd(channel, this.channelPos);
        playWithProbe(channel, startIndexOf, true);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void playSource(Channel channel, int i2) {
        String str;
        String str2;
        int i3;
        String str3 = null;
        if (i2 >= channel.getUrls().size()) {
            LoadingSpinner loadingSpinner = this.loading;
            if (loadingSpinner != null) {
                loadingSpinner.setVisibility(8);
                return;
            } else {
                b0.d.G("loading");
                throw null;
            }
        }
        this.sourceIndex = i2;
        String str4 = channel.getUrls().get(i2);
        memPut("last_url", str4);
        memPut("last_name", channel.getName());
        memPut("last_group", channel.getGroup());
        String customUaOfLine = customUaOfLine(channel, str4);
        Log.i("TVLIVE", "play ch=" + channel.getName() + " idx=" + i2 + " ua=[" + customUaOfLine + "] src=" + channel.getUrlSrc().get(str4) + " url=" + str4);
        int i4 = 12;
        if (!(customUaOfLine.length() == 0) || h0.h.d0(str4, "https://", false)) {
            String localUrl = StreamProxy.INSTANCE.localUrl(str4, customUaOfLine);
            Log.i("TVLIVE", "via proxy -> " + localUrl);
            if (h0.h.d0(localUrl, "http://127.0.0.1", false)) {
                str = localUrl;
                str2 = null;
                i3 = 12;
                startVideo$default(this, str, true, false, str2, i3, null);
            }
            str3 = customUaOfLine;
            i4 = 4;
        }
        str = str4;
        str2 = str3;
        i3 = i4;
        startVideo$default(this, str, true, false, str2, i3, null);
    }

    private final void playUrlDirect(String str) {
        startVideo$default(this, str, false, false, null, 12, null);
    }

    private final void playWithProbe(Channel channel, int i2, boolean z2) {
        if (!z2 || channel.getUrls().size() <= 1) {
            playSource(channel, i2);
        } else {
            probeFastest(channel, i2, new MainActivity$playWithProbe$1(this, channel));
        }
    }

    private final void probeFastest(Channel channel, int i2, c0.b bVar) {
        int size = channel.getUrls().size();
        int i3 = 1;
        if (size <= 1) {
            bVar.invoke(Integer.valueOf(i2));
            return;
        }
        ArrayList arrayList = new ArrayList(4);
        arrayList.add(Integer.valueOf(i2));
        for (int i4 = 0; i4 < size && arrayList.size() < 4; i4++) {
            if (i4 != i2) {
                arrayList.add(Integer.valueOf(i4));
            }
        }
        MainActivity$probeFastest$pick$1 mainActivity$probeFastest$pick$1 = new MainActivity$probeFastest$pick$1(new Object(), new d0.d(), this, bVar);
        Iterator it = arrayList.iterator();
        while (it.hasNext()) {
            new Thread(new m(this, channel, (Integer) it.next(), mainActivity$probeFastest$pick$1)).start();
        }
        new Thread(new q(i2, i3, mainActivity$probeFastest$pick$1)).start();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void probeFastest$lambda$59(MainActivity mainActivity, Channel channel, Integer num, c0.b bVar) {
        b0.d.k(mainActivity, "this$0");
        b0.d.k(channel, "$ch");
        b0.d.k(num, "$idx");
        b0.d.k(bVar, "$pick");
        if (mainActivity.quickConnect(channel.getUrls().get(num.intValue()), channel)) {
            bVar.invoke(num);
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void probeFastest$lambda$60(c0.b bVar, int i2) {
        b0.d.k(bVar, "$pick");
        try {
            Thread.sleep(500L);
        } catch (Throwable unused) {
        }
        bVar.invoke(Integer.valueOf(i2));
    }

    private final boolean quickConnect(String str, Channel channel) {
        try {
            URLConnection openConnection = new URL(str).openConnection();
            b0.d.i(openConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
            HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
            httpURLConnection.setConnectTimeout(450);
            httpURLConnection.setReadTimeout(450);
            httpURLConnection.setRequestMethod("GET");
            httpURLConnection.setInstanceFollowRedirects(true);
            httpURLConnection.setRequestProperty("User-Agent", channel != null ? uaOfLine(channel, str) : SourceStore.INSTANCE.currentUa(this));
            int responseCode = httpURLConnection.getResponseCode();
            if (200 <= responseCode && responseCode < 400) {
                try {
                    InputStream inputStream = httpURLConnection.getInputStream();
                    if (inputStream != null) {
                        inputStream.read();
                    }
                } catch (Throwable unused) {
                }
            }
            httpURLConnection.disconnect();
            return 200 <= responseCode && responseCode < 400;
        } catch (Throwable unused2) {
            return false;
        }
    }

    public static /* synthetic */ boolean quickConnect$default(MainActivity mainActivity, String str, Channel channel, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            channel = null;
        }
        return mainActivity.quickConnect(str, channel);
    }

    private final List<String> rawGroupNames() {
        LinkedHashSet linkedHashSet = new LinkedHashSet();
        Iterator<T> it = this.allChannels.iterator();
        while (it.hasNext()) {
            linkedHashSet.add(((Channel) it.next()).getGroup());
        }
        return u.i.S(linkedHashSet);
    }

    private final void rebuildGroupCache() {
        this.groupCache.clear();
        for (String str : this.groups) {
            HashMap<String, List<Channel>> hashMap = this.groupCache;
            List<Channel> list = this.allChannels;
            ArrayList arrayList = new ArrayList();
            for (Object obj : list) {
                if (b0.d.b(((Channel) obj).getGroup(), str)) {
                    arrayList.add(obj);
                }
            }
            hashMap.put(str, arrayList);
        }
    }

    private final void refreshCurrentSource() {
        String str;
        SourceItem currentSourceItem = currentSourceItem();
        closeSettings();
        StringBuilder sb = new StringBuilder("正在刷新「");
        if (currentSourceItem == null || (str = currentSourceItem.getName()) == null) {
            str = "当前源";
        }
        sb.append(str);
        sb.append((char) 12301);
        Toast.makeText(this, sb.toString(), 0).show();
        refreshFromNetwork$default(this, "刷新失败，已保留原有频道列表", null, 2, null);
    }

    private final void refreshEpgPreview() {
        if (this.channelListData.isEmpty()) {
            this.epgData.clear();
            EpgAdapter epgAdapter = this.epgAdapter;
            if (epgAdapter == null) {
                b0.d.G("epgAdapter");
                throw null;
            }
            epgAdapter.notifyDataSetChanged();
            TextView textView = this.epgHint;
            if (textView == null) {
                b0.d.G("epgHint");
                throw null;
            }
            textView.setVisibility(0);
            TextView textView2 = this.epgHint;
            if (textView2 != null) {
                textView2.setText("未选择频道");
                return;
            } else {
                b0.d.G("epgHint");
                throw null;
            }
        }
        List<EpgProgram> programsFor = EpgRepository.INSTANCE.programsFor(this.channelListData.get(this.channelPos).getName());
        this.epgData.clear();
        this.epgData.addAll(programsFor);
        if (!programsFor.isEmpty()) {
            long currentTimeMillis = System.currentTimeMillis();
            Iterator<EpgProgram> it = programsFor.iterator();
            int i2 = 0;
            while (true) {
                if (!it.hasNext()) {
                    i2 = -1;
                    break;
                }
                EpgProgram next = it.next();
                if (currentTimeMillis >= next.getStartMillis() && currentTimeMillis < next.getEndMillis()) {
                    break;
                } else {
                    i2++;
                }
            }
            if (i2 < 0) {
                i2 = 0;
            }
            this.epgPos = i2;
        } else {
            this.epgPos = 0;
        }
        EpgAdapter epgAdapter2 = this.epgAdapter;
        if (epgAdapter2 == null) {
            b0.d.G("epgAdapter");
            throw null;
        }
        epgAdapter2.setSelected(this.epgPos);
        EpgAdapter epgAdapter3 = this.epgAdapter;
        if (epgAdapter3 == null) {
            b0.d.G("epgAdapter");
            throw null;
        }
        epgAdapter3.notifyDataSetChanged();
        if (!programsFor.isEmpty()) {
            centerEpgOn(this.epgPos);
        }
        if (!programsFor.isEmpty()) {
            TextView textView3 = this.epgHint;
            if (textView3 != null) {
                textView3.setVisibility(8);
                return;
            } else {
                b0.d.G("epgHint");
                throw null;
            }
        }
        TextView textView4 = this.epgHint;
        if (textView4 == null) {
            b0.d.G("epgHint");
            throw null;
        }
        textView4.setVisibility(0);
        TextView textView5 = this.epgHint;
        if (textView5 != null) {
            textView5.setText(!EpgRepository.INSTANCE.isLoaded() ? "节目单加载中…" : "暂无节目信息");
        } else {
            b0.d.G("epgHint");
            throw null;
        }
    }

    private final void refreshFromNetwork(String str, String str2) {
        if (this.listLoading) {
            return;
        }
        this.listLoading = true;
        LoadingSpinner loadingSpinner = this.loading;
        if (loadingSpinner == null) {
            b0.d.G("loading");
            throw null;
        }
        loadingSpinner.setVisibility(0);
        runBg(new m(u.i.S(SourceStore.INSTANCE.enabledSources(this)), this, str, str2));
    }

    public static /* synthetic */ void refreshFromNetwork$default(MainActivity mainActivity, String str, String str2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            str = "列表获取失败";
        }
        if ((i2 & 2) != 0) {
            str2 = null;
        }
        mainActivity.refreshFromNetwork(str, str2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void refreshFromNetwork$lambda$54(List list, final MainActivity mainActivity, final String str, final String str2) {
        SourceStore sourceStore;
        String str3;
        List<Channel> list2;
        b0.d.k(list, "$srcs");
        b0.d.k(mainActivity, "this$0");
        b0.d.k(str, "$failToast");
        final ArrayList arrayList = new ArrayList();
        HashMap<String, Channel> hashMap = new HashMap<>();
        final ArrayList arrayList2 = new ArrayList();
        final ArrayList arrayList3 = new ArrayList();
        Iterator it = list.iterator();
        while (it.hasNext()) {
            SourceItem sourceItem = (SourceItem) it.next();
            try {
                M3UParser m3UParser = M3UParser.INSTANCE;
                String url = sourceItem.getUrl();
                sourceStore = SourceStore.INSTANCE;
                t.b fetchAndParse = m3UParser.fetchAndParse(url, sourceStore.uaFor(mainActivity, sourceItem.getId()));
                str3 = (String) fetchAndParse.f547a;
                list2 = (List) fetchAndParse.f548b;
            } catch (Throwable unused) {
                arrayList3.add(sourceItem.getName());
            }
            if (list2.isEmpty()) {
                throw new IllegalStateException("empty list");
            }
            mainActivity.mergeParsed(arrayList, hashMap, list2, sourceItem.getId());
            try {
                b0.d.K(sourceStore.cacheFileFor(mainActivity, sourceItem.getId()), str3);
            } catch (Exception unused2) {
            }
            arrayList2.add(sourceItem.getId());
        }
        mainActivity.runOnUiThread(new Runnable() { // from class: tv.live.h
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.refreshFromNetwork$lambda$54$lambda$53(MainActivity.this, arrayList, arrayList3, str, str2, arrayList2);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void refreshFromNetwork$lambda$54$lambda$53(MainActivity mainActivity, List list, List list2, String str, String str2, List list3) {
        b0.d.k(mainActivity, "this$0");
        b0.d.k(list, "$merged");
        b0.d.k(list2, "$failed");
        b0.d.k(str, "$failToast");
        b0.d.k(list3, "$okIds");
        mainActivity.listLoading = false;
        LoadingSpinner loadingSpinner = mainActivity.loading;
        if (loadingSpinner == null) {
            b0.d.G("loading");
            throw null;
        }
        loadingSpinner.setVisibility(8);
        if (list.isEmpty()) {
            if (!list2.isEmpty()) {
                str = str + (char) 65288 + u.i.Q(list2, "、", null, null, null, 62) + (char) 65289;
            }
            Toast.makeText(mainActivity, str, 0).show();
            return;
        }
        mainActivity.getSp().edit().putLong("last_auto_update", System.currentTimeMillis()).apply();
        SourceMemory.INSTANCE.clear(mainActivity);
        mainActivity.allChannels.clear();
        mainActivity.allChannels.addAll(list);
        mainActivity.buildGroups();
        GroupAdapter groupAdapter = mainActivity.groupAdapter;
        if (groupAdapter == null) {
            b0.d.G("groupAdapter");
            throw null;
        }
        groupAdapter.notifyDataSetChanged();
        ChannelAdapter channelAdapter = mainActivity.channelAdapter;
        if (channelAdapter == null) {
            b0.d.G("channelAdapter");
            throw null;
        }
        channelAdapter.notifyDataSetChanged();
        if (str2 == null) {
            str2 = memGet$default(mainActivity, "last_name", null, 2, null);
        }
        if (!mainActivity.restoreSelectionByName(str2, memGet$default(mainActivity, "last_group", null, 2, null))) {
            mainActivity.groupIndex = 0;
            mainActivity.channelIndex = 0;
        }
        mainActivity.playCurrentChannel();
        List<SourceItem> load = SourceStore.INSTANCE.load(mainActivity);
        for (SourceItem sourceItem : load) {
            if (list3.contains(sourceItem.getId())) {
                sourceItem.setUpdatedAt(System.currentTimeMillis());
            }
        }
        SourceStore.INSTANCE.save(mainActivity, load);
        if (!list2.isEmpty()) {
            Toast.makeText(mainActivity, "部分源拉取失败：".concat(u.i.Q(list2, "、", null, null, null, 62)), 0).show();
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void refreshProgramUi() {
        ChannelAdapter channelAdapter = this.channelAdapter;
        if (channelAdapter != null) {
            if (channelAdapter == null) {
                b0.d.G("channelAdapter");
                throw null;
            }
            channelAdapter.notifyDataSetChanged();
        }
        List<Channel> channelsOfGroup = channelsOfGroup(this.groupIndex);
        int size = channelsOfGroup.size();
        int i2 = this.channelIndex;
        boolean z2 = false;
        if (i2 >= 0 && i2 < size) {
            z2 = true;
        }
        if (z2) {
            updateBottomBar(channelsOfGroup.get(i2));
        }
        if (this.panelState == 1) {
            refreshEpgPreview();
        }
    }

    private final void refreshSourceById(String str, String str2) {
        Object obj;
        if (this.listLoading) {
            Toast.makeText(this, "正在刷新，请稍候", 0).show();
            return;
        }
        Iterator<T> it = SourceStore.INSTANCE.load(this).iterator();
        while (true) {
            if (!it.hasNext()) {
                obj = null;
                break;
            } else {
                obj = it.next();
                if (b0.d.b(((SourceItem) obj).getId(), str)) {
                    break;
                }
            }
        }
        SourceItem sourceItem = (SourceItem) obj;
        if (sourceItem == null) {
            Toast.makeText(this, "源不存在", 0).show();
        } else {
            this.listLoading = true;
            runBg(new a(sourceItem, this, str2, 3));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void refreshSourceById$lambda$86(final SourceItem sourceItem, final MainActivity mainActivity, final String str) {
        SourceStore sourceStore;
        String str2;
        List list;
        b0.d.k(mainActivity, "this$0");
        b0.d.k(str, "$name");
        final d0.e eVar = new d0.e();
        final d0.d dVar = new d0.d();
        try {
            M3UParser m3UParser = M3UParser.INSTANCE;
            String url = sourceItem.getUrl();
            sourceStore = SourceStore.INSTANCE;
            t.b fetchAndParse = m3UParser.fetchAndParse(url, sourceStore.uaFor(mainActivity, sourceItem.getId()));
            str2 = (String) fetchAndParse.f547a;
            list = (List) fetchAndParse.f548b;
        } catch (Throwable unused) {
            dVar.f390a = true;
        }
        if (list.isEmpty()) {
            throw new IllegalStateException("empty list");
        }
        try {
            b0.d.K(sourceStore.cacheFileFor(mainActivity, sourceItem.getId()), str2);
        } catch (Exception unused2) {
        }
        eVar.f391a = list.size();
        try {
            mainActivity.loadCache();
        } catch (Throwable unused3) {
        }
        mainActivity.runOnUiThread(new Runnable() { // from class: tv.live.n
            @Override // java.lang.Runnable
            public final void run() {
                MainActivity.refreshSourceById$lambda$86$lambda$85(MainActivity.this, dVar, str, eVar, sourceItem);
            }
        });
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void refreshSourceById$lambda$86$lambda$85(MainActivity mainActivity, d0.d dVar, String str, d0.e eVar, SourceItem sourceItem) {
        StringBuilder sb;
        String str2;
        b0.d.k(mainActivity, "this$0");
        b0.d.k(dVar, "$failed");
        b0.d.k(str, "$name");
        b0.d.k(eVar, "$count");
        mainActivity.listLoading = false;
        if (dVar.f390a) {
            sb = new StringBuilder("刷新失败：");
            sb.append(str);
            str2 = "（网络或源地址有问题）";
        } else {
            List<SourceItem> load = SourceStore.INSTANCE.load(mainActivity);
            for (SourceItem sourceItem2 : load) {
                if (b0.d.b(sourceItem2.getId(), sourceItem.getId())) {
                    sourceItem2.setUpdatedAt(System.currentTimeMillis());
                }
            }
            SourceStore.INSTANCE.save(mainActivity, load);
            GroupAdapter groupAdapter = mainActivity.groupAdapter;
            if (groupAdapter == null) {
                b0.d.G("groupAdapter");
                throw null;
            }
            groupAdapter.notifyDataSetChanged();
            ChannelAdapter channelAdapter = mainActivity.channelAdapter;
            if (channelAdapter == null) {
                b0.d.G("channelAdapter");
                throw null;
            }
            channelAdapter.notifyDataSetChanged();
            mainActivity.restoreSelectionByName(memGet$default(mainActivity, "last_name", null, 2, null), memGet$default(mainActivity, "last_group", null, 2, null));
            mainActivity.playCurrentChannel();
            mainActivity.buildSettingsItems();
            sb = new StringBuilder("已刷新：");
            sb.append(str);
            sb.append((char) 65288);
            sb.append(eVar.f391a);
            str2 = " 个频道）";
        }
        sb.append(str2);
        Toast.makeText(mainActivity, sb.toString(), 0).show();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void reloadChannelList(int i2, int i3) {
        List<Channel> channelsOfGroup = channelsOfGroup(i2);
        this.channelListData.clear();
        this.channelListData.addAll(channelsOfGroup);
        int m2 = channelsOfGroup.isEmpty() ? 0 : b0.d.m(i3, 0, channelsOfGroup.size() - 1);
        this.channelPos = m2;
        ChannelAdapter channelAdapter = this.channelAdapter;
        if (channelAdapter == null) {
            b0.d.G("channelAdapter");
            throw null;
        }
        channelAdapter.setSelected(m2);
        ChannelAdapter channelAdapter2 = this.channelAdapter;
        if (channelAdapter2 == null) {
            b0.d.G("channelAdapter");
            throw null;
        }
        channelAdapter2.notifyDataSetChanged();
        if (!channelsOfGroup.isEmpty()) {
            RecyclerView recyclerView = this.channelListRv;
            if (recyclerView == null) {
                b0.d.G("channelListRv");
                throw null;
            }
            recyclerView.a0(this.channelPos);
        }
        computeRowMetrics(i2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void reloadMergedFromCache() {
        runBg(new t(this, 15));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void reloadMergedFromCache$lambda$41(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        try {
            mainActivity.loadCache();
        } catch (Throwable unused) {
        }
        mainActivity.runOnUiThread(new t(mainActivity, 19));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void reloadMergedFromCache$lambda$41$lambda$40(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        GroupAdapter groupAdapter = mainActivity.groupAdapter;
        if (groupAdapter == null) {
            b0.d.G("groupAdapter");
            throw null;
        }
        groupAdapter.notifyDataSetChanged();
        ChannelAdapter channelAdapter = mainActivity.channelAdapter;
        if (channelAdapter == null) {
            b0.d.G("channelAdapter");
            throw null;
        }
        channelAdapter.notifyDataSetChanged();
        mainActivity.restoreSelectionByName(memGet$default(mainActivity, "last_name", null, 2, null), memGet$default(mainActivity, "last_group", null, 2, null));
        mainActivity.playCurrentChannel();
    }

    private final void requestListParse(long j2) {
        if (this.listParsed) {
            return;
        }
        this.timeHandler.removeCallbacks(this.listParseRunnable);
        this.timeHandler.postDelayed(this.listParseRunnable, j2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void resetHideTimer() {
        this.hideHandler.removeCallbacks(this.hideRunnable);
        if (this.panelState == 1) {
            this.hideHandler.postDelayed(this.hideRunnable, PANEL_AUTO_HIDE_MS);
        }
    }

    /* JADX WARN: Removed duplicated region for block: B:26:0x006b A[Catch: all -> 0x008e, TryCatch #0 {all -> 0x008e, blocks: (B:14:0x001e, B:21:0x005f, B:26:0x006b, B:31:0x0076), top: B:13:0x001e }] */
    /* JADX WARN: Removed duplicated region for block: B:34:0x008e A[SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final java.lang.String resolveFinalUrl(java.lang.String r9, java.lang.String r10) {
        /*
            r8 = this;
            java.lang.String r0 = "http"
            r1 = 0
            boolean r2 = h0.h.d0(r9, r0, r1)
            if (r2 != 0) goto La
            return r9
        La:
            int r2 = r10.length()
            r3 = 1
            if (r2 != 0) goto L13
            r2 = 1
            goto L14
        L13:
            r2 = 0
        L14:
            if (r2 == 0) goto L18
            java.lang.String r10 = "Mozilla/5.0 (Linux; Android) TV/1.0"
        L18:
            r5 = r9
            r2 = 0
            r4 = 0
        L1b:
            r6 = 5
            if (r2 >= r6) goto L8f
            java.net.URL r4 = new java.net.URL     // Catch: java.lang.Throwable -> L8e
            r4.<init>(r5)     // Catch: java.lang.Throwable -> L8e
            java.net.URLConnection r4 = r4.openConnection()     // Catch: java.lang.Throwable -> L8e
            java.lang.String r6 = "null cannot be cast to non-null type java.net.HttpURLConnection"
            b0.d.i(r4, r6)     // Catch: java.lang.Throwable -> L8e
            java.net.HttpURLConnection r4 = (java.net.HttpURLConnection) r4     // Catch: java.lang.Throwable -> L8e
            r4.setInstanceFollowRedirects(r1)     // Catch: java.lang.Throwable -> L8e
            r6 = 2500(0x9c4, float:3.503E-42)
            r4.setConnectTimeout(r6)     // Catch: java.lang.Throwable -> L8e
            r4.setReadTimeout(r6)     // Catch: java.lang.Throwable -> L8e
            java.lang.String r6 = "GET"
            r4.setRequestMethod(r6)     // Catch: java.lang.Throwable -> L8e
            java.lang.String r6 = "User-Agent"
            r4.setRequestProperty(r6, r10)     // Catch: java.lang.Throwable -> L8e
            int r6 = r4.getResponseCode()     // Catch: java.lang.Throwable -> L8e
            java.lang.String r7 = "Location"
            java.lang.String r7 = r4.getHeaderField(r7)     // Catch: java.lang.Throwable -> L8e
            r4.disconnect()     // Catch: java.lang.Throwable -> L8e
            r4 = 301(0x12d, float:4.22E-43)
            if (r4 > r6) goto L5a
            r4 = 309(0x135, float:4.33E-43)
            if (r6 >= r4) goto L5a
            r4 = 1
            goto L5b
        L5a:
            r4 = 0
        L5b:
            if (r4 == 0) goto L8e
            if (r7 == 0) goto L68
            int r4 = r7.length()     // Catch: java.lang.Throwable -> L8e
            if (r4 != 0) goto L66
            goto L68
        L66:
            r4 = 0
            goto L69
        L68:
            r4 = 1
        L69:
            if (r4 != 0) goto L8e
            b0.d.h(r7)     // Catch: java.lang.Throwable -> L8e
            boolean r4 = h0.h.d0(r7, r0, r1)     // Catch: java.lang.Throwable -> L8e
            if (r4 == 0) goto L76
            r5 = r7
            goto L8a
        L76:
            java.net.URL r4 = new java.net.URL     // Catch: java.lang.Throwable -> L8e
            java.net.URL r6 = new java.net.URL     // Catch: java.lang.Throwable -> L8e
            r6.<init>(r5)     // Catch: java.lang.Throwable -> L8e
            r4.<init>(r6, r7)     // Catch: java.lang.Throwable -> L8e
            java.lang.String r4 = r4.toString()     // Catch: java.lang.Throwable -> L8e
            java.lang.String r6 = "toString(...)"
            b0.d.j(r4, r6)     // Catch: java.lang.Throwable -> L8e
            r5 = r4
        L8a:
            int r2 = r2 + 1
            r4 = 1
            goto L1b
        L8e:
            return r5
        L8f:
            if (r4 == 0) goto L92
            r9 = r5
        L92:
            return r9
        */
        throw new UnsupportedOperationException("Method not decompiled: tv.live.MainActivity.resolveFinalUrl(java.lang.String, java.lang.String):java.lang.String");
    }

    /* JADX WARN: Removed duplicated region for block: B:24:0x004e A[EDGE_INSN: B:24:0x004e->B:25:0x004e BREAK  A[LOOP:0: B:10:0x0017->B:47:?], SYNTHETIC] */
    /* JADX WARN: Removed duplicated region for block: B:47:? A[LOOP:0: B:10:0x0017->B:47:?, LOOP_END, SYNTHETIC] */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    private final boolean restoreSelectionByName(java.lang.String r8, java.lang.String r9) {
        /*
            r7 = this;
            r0 = 1
            r1 = 0
            if (r8 == 0) goto Ld
            int r2 = r8.length()
            if (r2 != 0) goto Lb
            goto Ld
        Lb:
            r2 = 0
            goto Le
        Ld:
            r2 = 1
        Le:
            if (r2 == 0) goto L11
            return r1
        L11:
            java.util.List<tv.live.Channel> r2 = r7.allChannels
            java.util.Iterator r2 = r2.iterator()
        L17:
            boolean r3 = r2.hasNext()
            r4 = 0
            if (r3 == 0) goto L4d
            java.lang.Object r3 = r2.next()
            r5 = r3
            tv.live.Channel r5 = (tv.live.Channel) r5
            java.lang.String r6 = r5.getName()
            boolean r6 = b0.d.b(r6, r8)
            if (r6 == 0) goto L49
            if (r9 == 0) goto L3a
            int r6 = r9.length()
            if (r6 != 0) goto L38
            goto L3a
        L38:
            r6 = 0
            goto L3b
        L3a:
            r6 = 1
        L3b:
            if (r6 != 0) goto L47
            java.lang.String r5 = r5.getGroup()
            boolean r5 = b0.d.b(r5, r9)
            if (r5 == 0) goto L49
        L47:
            r5 = 1
            goto L4a
        L49:
            r5 = 0
        L4a:
            if (r5 == 0) goto L17
            goto L4e
        L4d:
            r3 = r4
        L4e:
            tv.live.Channel r3 = (tv.live.Channel) r3
            if (r3 != 0) goto L76
            java.util.List<tv.live.Channel> r9 = r7.allChannels
            java.util.Iterator r9 = r9.iterator()
        L58:
            boolean r2 = r9.hasNext()
            if (r2 == 0) goto L70
            java.lang.Object r2 = r9.next()
            r3 = r2
            tv.live.Channel r3 = (tv.live.Channel) r3
            java.lang.String r3 = r3.getName()
            boolean r3 = b0.d.b(r3, r8)
            if (r3 == 0) goto L58
            r4 = r2
        L70:
            r3 = r4
            tv.live.Channel r3 = (tv.live.Channel) r3
            if (r3 != 0) goto L76
            return r1
        L76:
            java.util.List<java.lang.String> r8 = r7.groups
            java.lang.String r9 = r3.getGroup()
            int r8 = r8.indexOf(r9)
            if (r8 >= 0) goto L83
            return r1
        L83:
            java.util.List r9 = r7.channelsOfGroup(r8)
            int r9 = r9.indexOf(r3)
            if (r9 >= 0) goto L8e
            return r1
        L8e:
            r7.groupIndex = r8
            r7.channelIndex = r9
            r7.groupPos = r8
            r7.channelPos = r9
            r7.sourceIndex = r1
            return r0
        */
        throw new UnsupportedOperationException("Method not decompiled: tv.live.MainActivity.restoreSelectionByName(java.lang.String, java.lang.String):boolean");
    }

    public static /* synthetic */ boolean restoreSelectionByName$default(MainActivity mainActivity, String str, String str2, int i2, Object obj) {
        if ((i2 & 2) != 0) {
            str2 = null;
        }
        return mainActivity.restoreSelectionByName(str, str2);
    }

    private final void restoreSelectionFromPrefs() {
        restoreSelectionByName$default(this, memGet$default(this, "last_name", null, 2, null), null, 2, null);
    }

    private final void rightActionInSettings() {
        int x2;
        int i2;
        String str;
        int i3 = this.settingsPos;
        if (i3 < 0 || i3 >= this.settingsItems.size()) {
            return;
        }
        ManageItem manageItem = this.settingsItems.get(this.settingsPos);
        if (this.settingsLevel != 1 || manageItem.getType() != 0) {
            if (this.settingsLevel == 2 && manageItem.getType() == 2) {
                moveGroupInSettings(1);
                return;
            }
            return;
        }
        String payload = manageItem.getPayload();
        SourceStore sourceStore = SourceStore.INSTANCE;
        if (b0.d.b(payload, sourceStore.currentId(this))) {
            refreshCurrentSource();
            str = "正在重新拉取「" + manageItem.getTitle() + (char) 12301;
        } else {
            if (!b0.d.b(manageItem.getPayload(), SourceStore.DEFAULT_SOURCE_ID)) {
                List<SourceItem> load = sourceStore.load(this);
                MainActivity$rightActionInSettings$1 mainActivity$rightActionInSettings$1 = new MainActivity$rightActionInSettings$1(manageItem);
                b0.d.k(load, "<this>");
                Object obj = null;
                if (load instanceof RandomAccess) {
                    f0.c cVar = new f0.c(0, b0.d.x(load));
                    int i4 = cVar.f397b;
                    int i5 = cVar.f398c;
                    boolean z2 = i5 <= 0 ? i4 <= 0 : i4 >= 0;
                    int i6 = z2 ? 0 : i4;
                    int i7 = 0;
                    while (z2) {
                        if (i6 != i4) {
                            i2 = i5 + i6;
                        } else {
                            if (!z2) {
                                throw new NoSuchElementException();
                            }
                            i2 = i6;
                            z2 = false;
                        }
                        SourceItem sourceItem = load.get(i6);
                        if (!((Boolean) mainActivity$rightActionInSettings$1.invoke((Object) sourceItem)).booleanValue()) {
                            if (i7 != i6) {
                                load.set(i7, sourceItem);
                            }
                            i7++;
                        }
                        i6 = i2;
                    }
                    if (i7 < load.size() && i7 <= (x2 = b0.d.x(load))) {
                        while (true) {
                            load.remove(x2);
                            if (x2 == i7) {
                                break;
                            } else {
                                x2--;
                            }
                        }
                    }
                } else {
                    if (load instanceof e0.a) {
                        b0.d.E(load, "kotlin.collections.MutableIterable");
                        throw null;
                    }
                    Iterator<T> it = load.iterator();
                    while (it.hasNext()) {
                        if (((Boolean) mainActivity$rightActionInSettings$1.invoke(it.next())).booleanValue()) {
                            it.remove();
                        }
                    }
                }
                SourceStore sourceStore2 = SourceStore.INSTANCE;
                sourceStore2.save(this, load);
                if (b0.d.b(sourceStore2.currentId(this), manageItem.getPayload())) {
                    Iterator<T> it2 = sourceStore2.load(this).iterator();
                    while (true) {
                        if (!it2.hasNext()) {
                            break;
                        }
                        Object next = it2.next();
                        if (!b0.d.b(((SourceItem) next).getId(), manageItem.getPayload())) {
                            obj = next;
                            break;
                        }
                    }
                    SourceItem sourceItem2 = (SourceItem) obj;
                    if (sourceItem2 != null) {
                        SourceStore.INSTANCE.setCurrentId(this, sourceItem2.getId());
                    }
                }
                try {
                    SourceStore.INSTANCE.cacheFileFor(this, manageItem.getPayload()).delete();
                } catch (Exception unused) {
                }
                Toast.makeText(this, "已删除「" + manageItem.getTitle() + (char) 12301, 0).show();
                int i8 = this.settingsPos - 1;
                this.settingsPos = i8 >= 0 ? i8 : 0;
                buildSettingsItems();
                reloadMergedFromCache();
                return;
            }
            str = "默认源不能删除";
        }
        Toast.makeText(this, str, 0).show();
    }

    private final void runBg(Runnable runnable) {
        this.bgPool.execute(runnable);
    }

    private final void scheduleSilentUpdate() {
        if (this.silentUpdateStarted) {
            return;
        }
        this.silentUpdateStarted = true;
        this.timeHandler.postDelayed(new t(this, 18), SILENT_UPDATE_DELAY_MS);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void scheduleSilentUpdate$lambda$12(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        mainActivity.silentUpdateNow();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void setDownloadProgress(int i2, String str) {
        ProgressBar progressBar;
        TextView textView = this.dlLabel;
        if (textView != null) {
            textView.setText(str);
        }
        if (i2 < 0 || (progressBar = this.dlBar) == null) {
            return;
        }
        progressBar.setProgress(b0.d.m(i2, 0, 100));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void setDownloadText(String str) {
        TextView textView = this.dlLabel;
        if (textView != null) {
            textView.setText(str);
        }
        ProgressBar progressBar = this.dlBar;
        if (progressBar == null) {
            return;
        }
        progressBar.setProgress(100);
    }

    private final void settingsBack() {
        int i2 = this.settingsLevel;
        this.settingsLevel = (i2 == 1 || i2 == 2) ? 9 : 0;
        this.settingsPos = 0;
        buildSettingsItems();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void settingsHideRunnable$lambda$5(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        View view = mainActivity.settingsPanel;
        if (view == null) {
            b0.d.G("settingsPanel");
            throw null;
        }
        if (view.getVisibility() == 0) {
            mainActivity.closeSettings();
        }
    }

    private final void showConfig() {
        View view = this.panelContainer;
        if (view == null) {
            b0.d.G("panelContainer");
            throw null;
        }
        view.setVisibility(8);
        View view2 = this.settingsPanel;
        if (view2 == null) {
            b0.d.G("settingsPanel");
            throw null;
        }
        view2.setVisibility(8);
        this.panelState = 0;
        this.hideHandler.removeCallbacks(this.hideRunnable);
        View view3 = this.configOverlay;
        if (view3 == null) {
            b0.d.G("configOverlay");
            throw null;
        }
        view3.setVisibility(0);
        String str = "http://" + localIpAddress() + ":8888";
        ImageView imageView = this.qrImage;
        if (imageView == null) {
            b0.d.G("qrImage");
            throw null;
        }
        imageView.setImageBitmap(QrGenerator.INSTANCE.generate(str, dp(300)));
        ConfigServer configServer = this.configServer;
        if (configServer != null) {
            configServer.stop();
        }
        ConfigServer configServer2 = new ConfigServer(this, 8888, new MainActivity$showConfig$1(this), new MainActivity$showConfig$2(this), new MainActivity$showConfig$3(this));
        configServer2.start();
        this.configServer = configServer2;
    }

    private final void showDownloadPanel(String str) {
        this.dlUi.removeCallbacks(this.dlHide);
        LinearLayout ensureDownloadPanel = ensureDownloadPanel();
        if (ensureDownloadPanel == null) {
            return;
        }
        TextView textView = this.dlLabel;
        if (textView != null) {
            textView.setText(str);
        }
        ProgressBar progressBar = this.dlBar;
        if (progressBar != null) {
            progressBar.setProgress(0);
        }
        ensureDownloadPanel.setVisibility(0);
    }

    private final void showEpgPanel() {
        this.epgOpen = true;
        View view = this.epgContainer;
        if (view == null) {
            b0.d.G("epgContainer");
            throw null;
        }
        view.setVisibility(0);
        TextView textView = this.hintStrip;
        if (textView == null) {
            b0.d.G("hintStrip");
            throw null;
        }
        textView.setVisibility(8);
        this.focusIndex = 2;
        refreshEpgPreview();
        applyFocusStyle();
        loadEpgOnDemand();
    }

    private final void showOsd(Channel channel, int i2) {
        updateBottomBar(channel);
        View view = this.bottomBar;
        if (view == null) {
            b0.d.G("bottomBar");
            throw null;
        }
        view.setVisibility(0);
        this.bottomBarHandler.removeCallbacks(this.bottomBarHide);
        this.bottomBarHandler.postDelayed(this.bottomBarHide, PANEL_AUTO_HIDE_MS);
    }

    private final void showSettings() {
        View view = this.panelContainer;
        if (view == null) {
            b0.d.G("panelContainer");
            throw null;
        }
        view.setVisibility(8);
        View view2 = this.configOverlay;
        if (view2 == null) {
            b0.d.G("configOverlay");
            throw null;
        }
        view2.setVisibility(8);
        this.panelState = 3;
        this.settingsLevel = 0;
        this.settingsPos = 0;
        View view3 = this.settingsPanel;
        if (view3 == null) {
            b0.d.G("settingsPanel");
            throw null;
        }
        view3.setVisibility(0);
        buildSettingsItems();
        armSettingsAutoHide();
    }

    private final void silentUpdateNow() {
        if (System.currentTimeMillis() - getSp().getLong("last_silent_update", 0L) < SILENT_UPDATE_INTERVAL_MS) {
            return;
        }
        runBg(new l(u.i.S(SourceStore.INSTANCE.enabledSources(this)), this));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void silentUpdateNow$lambda$15(List list, MainActivity mainActivity) {
        b0.d.k(list, "$srcs");
        b0.d.k(mainActivity, "this$0");
        ArrayList arrayList = new ArrayList();
        HashMap<String, Channel> hashMap = new HashMap<>();
        Iterator it = list.iterator();
        boolean z2 = false;
        while (it.hasNext()) {
            SourceItem sourceItem = (SourceItem) it.next();
            try {
                M3UParser m3UParser = M3UParser.INSTANCE;
                String url = sourceItem.getUrl();
                SourceStore sourceStore = SourceStore.INSTANCE;
                t.b fetchAndParse = m3UParser.fetchAndParse(url, sourceStore.uaFor(mainActivity, sourceItem.getId()));
                String str = (String) fetchAndParse.f547a;
                List<Channel> list2 = (List) fetchAndParse.f548b;
                if (!list2.isEmpty()) {
                    mainActivity.mergeParsed(arrayList, hashMap, list2, sourceItem.getId());
                    try {
                        b0.d.K(sourceStore.cacheFileFor(mainActivity, sourceItem.getId()), str);
                    } catch (Exception unused) {
                    }
                    z2 = true;
                }
            } catch (Exception unused2) {
            }
        }
        if (z2) {
            mainActivity.runOnUiThread(new l(mainActivity, arrayList));
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void silentUpdateNow$lambda$15$lambda$14(MainActivity mainActivity, List list) {
        b0.d.k(mainActivity, "this$0");
        b0.d.k(list, "$fresh");
        mainActivity.getSp().edit().putLong("last_silent_update", System.currentTimeMillis()).apply();
        String Q = u.i.Q(u.i.R(mainActivity.allChannels, 60), "|", null, null, MainActivity$silentUpdateNow$1$2$oldHead$1.INSTANCE, 30);
        String Q2 = u.i.Q(u.i.R(list, 60), "|", null, null, MainActivity$silentUpdateNow$1$2$newHead$1.INSTANCE, 30);
        if (list.size() == mainActivity.allChannels.size() && b0.d.b(Q, Q2)) {
            return;
        }
        mainActivity.allChannels.clear();
        mainActivity.allChannels.addAll(list);
        mainActivity.buildGroups();
        mainActivity.restoreSelectionByName(memGet$default(mainActivity, "last_name", null, 2, null), memGet$default(mainActivity, "last_group", null, 2, null));
        GroupAdapter groupAdapter = mainActivity.groupAdapter;
        if (groupAdapter == null) {
            b0.d.G("groupAdapter");
            throw null;
        }
        groupAdapter.notifyDataSetChanged();
        if (mainActivity.panelState != 1) {
            mainActivity.reloadChannelList(mainActivity.groupIndex, mainActivity.channelIndex);
        }
        mainActivity.refreshEpgPreview();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final String sourceInfoOf(Channel channel) {
        int intValue;
        int size = channel.getUrls().size();
        if (size <= 0) {
            return null;
        }
        if (isPlayingChannel(channel)) {
            String memGet$default = memGet$default(this, "last_url", null, 2, null);
            int indexOf = ((memGet$default == null || memGet$default.length() == 0) ? 1 : 0) != 0 ? -1 : channel.getUrls().indexOf(memGet$default);
            intValue = indexOf >= 0 ? indexOf + 1 : b0.d.m(this.sourceIndex + 1, 1, size);
        } else {
            Integer num = SourceMemory.INSTANCE.get(this, channel.getGroup(), channel.getName());
            intValue = (num != null ? num.intValue() : 0) + 1;
        }
        return "源 " + b0.d.m(intValue, 1, size) + '/' + size;
    }

    private final String srcIdOfLine(Channel channel, String str) {
        String str2 = channel.getUrlSrc().get(str);
        return str2 == null ? SourceStore.INSTANCE.currentId(this) : str2;
    }

    private final void startEpgDelayed() {
        if (this.epgStarted) {
            return;
        }
        this.epgStarted = true;
        this.timeHandler.postDelayed(new t(this, 20), EPG_DELAY_MS);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startEpgDelayed$lambda$91(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        EpgRepository epgRepository = EpgRepository.INSTANCE;
        if (epgRepository.isLoaded() || mainActivity.epgRequested) {
            return;
        }
        mainActivity.epgRequested = true;
        epgRepository.load(mainActivity, new MainActivity$startEpgDelayed$1$1(mainActivity));
    }

    private final int startIndexOf(Channel channel) {
        Integer num = SourceMemory.INSTANCE.get(this, channel.getGroup(), channel.getName());
        int intValue = num != null ? num.intValue() : 0;
        int size = channel.getUrls().size();
        if (size <= 0) {
            return 0;
        }
        return b0.d.m(intValue, 0, size - 1);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void startUpdateCheck() {
        Toast.makeText(this, "正在检查更新…", 0).show();
        this.bgPool.execute(new t(this, 13));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startUpdateCheck$lambda$22(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        mainActivity.runOnUiThread(new j(UpdateChecker.INSTANCE.fetchRemote(), mainActivity));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startUpdateCheck$lambda$22$lambda$21(UpdateChecker.Remote remote, MainActivity mainActivity) {
        String str;
        int i2;
        b0.d.k(mainActivity, "this$0");
        if (remote == null) {
            str = "检查更新失败，请稍后再试";
            i2 = 1;
        } else {
            if (remote.getVersionCode() > UpdateChecker.INSTANCE.currentVersionCode(mainActivity)) {
                mainActivity.confirmUpdate(remote);
                return;
            }
            str = "已是最新版本 v" + mainActivity.appVersion();
            i2 = 0;
        }
        Toast.makeText(mainActivity, str, i2).show();
    }

    private final void startVideo(final String str, final boolean z2, boolean z3, final String str2) {
        if (this.exiting) {
            return;
        }
        this.playCallbackFired = false;
        LoadingSpinner loadingSpinner = this.loading;
        if (loadingSpinner == null) {
            b0.d.G("loading");
            throw null;
        }
        loadingSpinner.setVisibility(8);
        this.loadingHandler.removeCallbacks(this.loadingRunnable);
        this.loadingHandler.postDelayed(this.loadingRunnable, 1200L);
        String currentCustomUa = z3 ? "" : str2 == null ? SourceStore.INSTANCE.currentCustomUa(this) : str2;
        boolean z4 = currentCustomUa.length() > 0;
        this.uaHeaderUsed = z4;
        if (z4) {
            VideoView videoView = this.video;
            if (videoView == null) {
                b0.d.G("video");
                throw null;
            }
            Uri parse = Uri.parse(str);
            Map<String, String> singletonMap = Collections.singletonMap("User-Agent", currentCustomUa);
            b0.d.j(singletonMap, "singletonMap(...)");
            videoView.setVideoURI(parse, singletonMap);
        } else {
            VideoView videoView2 = this.video;
            if (videoView2 == null) {
                b0.d.G("video");
                throw null;
            }
            videoView2.setVideoURI(Uri.parse(str));
        }
        VideoView videoView3 = this.video;
        if (videoView3 == null) {
            b0.d.G("video");
            throw null;
        }
        videoView3.setOnPreparedListener(new MediaPlayer.OnPreparedListener() { // from class: tv.live.e
            @Override // android.media.MediaPlayer.OnPreparedListener
            public final void onPrepared(MediaPlayer mediaPlayer) {
                MainActivity.startVideo$lambda$66(MainActivity.this, mediaPlayer);
            }
        });
        VideoView videoView4 = this.video;
        if (videoView4 == null) {
            b0.d.G("video");
            throw null;
        }
        videoView4.setOnInfoListener(new MediaPlayer.OnInfoListener() { // from class: tv.live.f
            @Override // android.media.MediaPlayer.OnInfoListener
            public final boolean onInfo(MediaPlayer mediaPlayer, int i2, int i3) {
                boolean startVideo$lambda$67;
                startVideo$lambda$67 = MainActivity.startVideo$lambda$67(MainActivity.this, mediaPlayer, i2, i3);
                return startVideo$lambda$67;
            }
        });
        VideoView videoView5 = this.video;
        if (videoView5 == null) {
            b0.d.G("video");
            throw null;
        }
        videoView5.setOnErrorListener(new MediaPlayer.OnErrorListener() { // from class: tv.live.g
            @Override // android.media.MediaPlayer.OnErrorListener
            public final boolean onError(MediaPlayer mediaPlayer, int i2, int i3) {
                boolean startVideo$lambda$68;
                startVideo$lambda$68 = MainActivity.startVideo$lambda$68(str, this, z2, str2, mediaPlayer, i2, i3);
                return startVideo$lambda$68;
            }
        });
        VideoView videoView6 = this.video;
        if (videoView6 == null) {
            b0.d.G("video");
            throw null;
        }
        videoView6.start();
        this.timeoutHandler.removeCallbacks(this.timeoutRunnable);
        this.timeoutHandler.postDelayed(this.timeoutRunnable, loadTimeoutMs());
    }

    public static /* synthetic */ void startVideo$default(MainActivity mainActivity, String str, boolean z2, boolean z3, String str2, int i2, Object obj) {
        if ((i2 & 4) != 0) {
            z3 = false;
        }
        if ((i2 & 8) != 0) {
            str2 = null;
        }
        mainActivity.startVideo(str, z2, z3, str2);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startVideo$lambda$66(final MainActivity mainActivity, MediaPlayer mediaPlayer) {
        b0.d.k(mainActivity, "this$0");
        b0.d.h(mediaPlayer);
        mainActivity.applyFillScreen(mediaPlayer);
        try {
            mediaPlayer.setOnVideoSizeChangedListener(new MediaPlayer.OnVideoSizeChangedListener() { // from class: tv.live.k
                @Override // android.media.MediaPlayer.OnVideoSizeChangedListener
                public final void onVideoSizeChanged(MediaPlayer mediaPlayer2, int i2, int i3) {
                    MainActivity.startVideo$lambda$66$lambda$65(MainActivity.this, mediaPlayer2, i2, i3);
                }
            });
            mainActivity.onVideoSize(mediaPlayer.getVideoWidth(), mediaPlayer.getVideoHeight());
        } catch (Throwable unused) {
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startVideo$lambda$66$lambda$65(MainActivity mainActivity, MediaPlayer mediaPlayer, int i2, int i3) {
        b0.d.k(mainActivity, "this$0");
        mainActivity.onVideoSize(i2, i3);
        mainActivity.runOnUiThread(new t(mainActivity, 12));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void startVideo$lambda$66$lambda$65$lambda$64(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        mainActivity.updateBottomBarOnResChanged();
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean startVideo$lambda$67(MainActivity mainActivity, MediaPlayer mediaPlayer, int i2, int i3) {
        b0.d.k(mainActivity, "this$0");
        if (i2 != 3 && i2 != 702) {
            return false;
        }
        mainActivity.onPlaySuccess();
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final boolean startVideo$lambda$68(String str, MainActivity mainActivity, boolean z2, String str2, MediaPlayer mediaPlayer, int i2, int i3) {
        b0.d.k(str, "$url");
        b0.d.k(mainActivity, "this$0");
        Log.i("TVLIVE", "onError url=" + str + " what=" + i2 + " extra=" + i3 + " uaHeader=" + mainActivity.uaHeaderUsed);
        if (mainActivity.uaHeaderUsed) {
            mainActivity.uaHeaderUsed = false;
            mainActivity.startVideo(str, z2, true, str2);
        } else if (z2) {
            mainActivity.tryNextSource();
        } else if (mainActivity.allChannels.isEmpty()) {
            refreshFromNetwork$default(mainActivity, null, null, 3, null);
        } else {
            LoadingSpinner loadingSpinner = mainActivity.loading;
            if (loadingSpinner == null) {
                b0.d.G("loading");
                throw null;
            }
            loadingSpinner.setVisibility(8);
            mainActivity.playChannel(0, false);
        }
        return true;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public final void stopConfigServer() {
        ConfigServer configServer = this.configServer;
        if (configServer != null) {
            configServer.stop();
        }
        this.configServer = null;
    }

    private final void switchSource(int i2) {
        List<Channel> channelsOfGroup = channelsOfGroup(this.groupIndex);
        if (this.channelIndex >= channelsOfGroup.size()) {
            return;
        }
        Channel channel = channelsOfGroup.get(this.channelIndex);
        if (channel.getUrls().size() <= 1) {
            Toast.makeText(this, "当前频道只有 1 条线路", 0).show();
            return;
        }
        int i3 = this.sourceIndex + i2;
        if (i3 < 0 || i3 >= channel.getUrls().size()) {
            Toast.makeText(this, i2 > 0 ? "已是最后一条线路" : "已是第一条线路", 0).show();
        } else {
            playSource(channel, i3);
            showOsd(channel, this.channelIndex);
        }
    }

    private final void switchToSource(String str, String str2) {
        SourceStore sourceStore = SourceStore.INSTANCE;
        if (b0.d.b(sourceStore.currentId(this), str)) {
            Toast.makeText(this, "这个源正在使用中", 0).show();
            return;
        }
        sourceStore.setCurrentId(this, str);
        closeSettings();
        Toast.makeText(this, "已切换到「" + str2 + (char) 12301, 0).show();
        runBg(new a(this, str, str2, 2));
    }

    /* JADX INFO: Access modifiers changed from: private */
    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r1v2, types: [t.c] */
    public static final void switchToSource$lambda$57(MainActivity mainActivity, String str, String str2) {
        List<Channel> cVar;
        b0.d.k(mainActivity, "this$0");
        b0.d.k(str, "$srcId");
        b0.d.k(str2, "$srcName");
        File cacheFileFor = SourceStore.INSTANCE.cacheFileFor(mainActivity, str);
        boolean exists = cacheFileFor.exists();
        List<Channel> list = u.k.f624a;
        if (exists && cacheFileFor.length() > 0) {
            try {
                cVar = M3UParser.INSTANCE.parse(b0.d.C(cacheFileFor));
            } catch (Throwable th) {
                cVar = new t.c(th);
            }
            if (!(cVar instanceof t.c)) {
                list = cVar;
            }
            list = list;
        }
        mainActivity.runOnUiThread(new m(mainActivity, str, list, str2));
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void switchToSource$lambda$57$lambda$56(MainActivity mainActivity, String str, List list, String str2) {
        b0.d.k(mainActivity, "this$0");
        b0.d.k(str, "$srcId");
        b0.d.k(list, "$cached");
        b0.d.k(str2, "$srcName");
        if (b0.d.b(SourceStore.INSTANCE.currentId(mainActivity), str)) {
            if (!list.isEmpty()) {
                mainActivity.allChannels.clear();
                mainActivity.allChannels.addAll(list);
                mainActivity.buildGroups();
                GroupAdapter groupAdapter = mainActivity.groupAdapter;
                if (groupAdapter == null) {
                    b0.d.G("groupAdapter");
                    throw null;
                }
                groupAdapter.notifyDataSetChanged();
                ChannelAdapter channelAdapter = mainActivity.channelAdapter;
                if (channelAdapter == null) {
                    b0.d.G("channelAdapter");
                    throw null;
                }
                channelAdapter.notifyDataSetChanged();
                if (!restoreSelectionByName$default(mainActivity, mainActivity.memGet("last_name", str), null, 2, null)) {
                    mainActivity.groupIndex = 0;
                    mainActivity.channelIndex = 0;
                }
                mainActivity.playCurrentChannel();
            }
            refreshFromNetwork$default(mainActivity, "「" + str2 + "」拉取失败，继续使用原有频道列表", null, 2, null);
        }
    }

    private final void syncBottomBarWithPlaying() {
        int indexOf;
        Object obj = null;
        String memGet$default = memGet$default(this, "last_url", null, 2, null);
        if (memGet$default == null) {
            return;
        }
        Iterator<T> it = this.allChannels.iterator();
        while (true) {
            if (!it.hasNext()) {
                break;
            }
            Object next = it.next();
            if (((Channel) next).getUrls().contains(memGet$default)) {
                obj = next;
                break;
            }
        }
        Channel channel = (Channel) obj;
        if (channel != null && (indexOf = this.groups.indexOf(channel.getGroup())) >= 0) {
            Iterator<Channel> it2 = channelsOfGroup(indexOf).iterator();
            int i2 = 0;
            while (true) {
                if (!it2.hasNext()) {
                    i2 = -1;
                    break;
                } else if (b0.d.b(it2.next().getName(), channel.getName())) {
                    break;
                } else {
                    i2++;
                }
            }
            this.groupIndex = indexOf;
            int i3 = i2 > 0 ? i2 : 0;
            this.channelIndex = i3;
            this.groupPos = indexOf;
            this.channelPos = i3;
            updateBottomBar(channel);
        }
    }

    private final void syncPlayingStateWithUrl(String str, String str2) {
        Object obj;
        int i2;
        Object obj2;
        Iterator<T> it = this.allChannels.iterator();
        while (true) {
            obj = null;
            i2 = 0;
            if (!it.hasNext()) {
                obj2 = null;
                break;
            }
            obj2 = it.next();
            if (!(str == null || str.length() == 0) && ((Channel) obj2).getUrls().contains(str)) {
                break;
            }
        }
        Channel channel = (Channel) obj2;
        if (channel == null) {
            Iterator<T> it2 = this.allChannels.iterator();
            while (true) {
                if (!it2.hasNext()) {
                    break;
                }
                Object next = it2.next();
                if (!(str2 == null || str2.length() == 0) && b0.d.b(((Channel) next).getName(), str2)) {
                    obj = next;
                    break;
                }
            }
            channel = (Channel) obj;
            if (channel == null) {
                return;
            }
        }
        int indexOf = this.groups.indexOf(channel.getGroup());
        if (indexOf < 0) {
            return;
        }
        Iterator<Channel> it3 = channelsOfGroup(indexOf).iterator();
        while (true) {
            if (!it3.hasNext()) {
                i2 = -1;
                break;
            } else if (b0.d.b(it3.next().getName(), channel.getName())) {
                break;
            } else {
                i2++;
            }
        }
        if (i2 < 0) {
            return;
        }
        this.groupIndex = indexOf;
        this.groupPos = indexOf;
        this.channelIndex = i2;
        this.channelPos = i2;
        updateBottomBar(channel);
    }

    private final void syncSelectionByUrl() {
        Object obj;
        String memGet$default = memGet$default(this, "last_url", null, 2, null);
        if (memGet$default == null) {
            return;
        }
        Iterator<T> it = this.allChannels.iterator();
        while (true) {
            if (!it.hasNext()) {
                obj = null;
                break;
            } else {
                obj = it.next();
                if (((Channel) obj).getUrls().contains(memGet$default)) {
                    break;
                }
            }
        }
        Channel channel = (Channel) obj;
        if (channel == null) {
            return;
        }
        restoreSelectionByName$default(this, channel.getName(), null, 2, null);
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void timeoutRunnable$lambda$3(MainActivity mainActivity) {
        b0.d.k(mainActivity, "this$0");
        mainActivity.tryNextSource();
    }

    private final void tryNextSource() {
        int i2;
        List<Channel> channelsOfGroup = channelsOfGroup(this.groupIndex);
        if (channelsOfGroup.isEmpty() || this.channelIndex >= channelsOfGroup.size()) {
            this.timeoutHandler.removeCallbacks(this.timeoutRunnable);
            if (this.allChannels.isEmpty()) {
                refreshFromNetwork$default(this, null, null, 3, null);
                return;
            }
            LoadingSpinner loadingSpinner = this.loading;
            if (loadingSpinner == null) {
                b0.d.G("loading");
                throw null;
            }
            loadingSpinner.setVisibility(8);
            playChannel(0, false);
            return;
        }
        Channel channel = channelsOfGroup.get(this.channelIndex);
        int i3 = this.sourceIndex + 1 < channel.getUrls().size() ? this.sourceIndex + 1 : 0;
        if (i3 < channel.getUrls().size() && (i2 = this.failoverCount) < this.MAX_FAILOVER_PER_CHANNEL) {
            this.failoverCount = i2 + 1;
            playSource(channel, i3);
            return;
        }
        this.failoverCount = 0;
        this.deadChannelCount++;
        this.timeoutHandler.removeCallbacks(this.timeoutRunnable);
        if (this.deadChannelCount < this.MAX_DEAD_CHANNELS) {
            int size = (this.channelIndex + 1) % channelsOfGroup.size();
            this.channelIndex = size;
            playChannel(size, false);
            return;
        }
        this.deadChannelCount = 0;
        LoadingSpinner loadingSpinner2 = this.loading;
        if (loadingSpinner2 == null) {
            b0.d.G("loading");
            throw null;
        }
        loadingSpinner2.setVisibility(8);
        Toast.makeText(this, "这些频道暂时都连不上，可在设置里刷新源后再试", 1).show();
    }

    private final String uaOfLine(Channel channel, String str) {
        String customUaOfLine = customUaOfLine(channel, str);
        return customUaOfLine.length() == 0 ? SourceStore.DEFAULT_UA : customUaOfLine;
    }

    private final void updateBottomBar(Channel channel) {
        String str;
        TextView textView = this.bottomNum;
        if (textView == null) {
            b0.d.G("bottomNum");
            throw null;
        }
        textView.setText(channel.getNumber() > 0 ? String.valueOf(channel.getNumber()) : "");
        TextView textView2 = this.bottomName;
        if (textView2 == null) {
            b0.d.G("bottomName");
            throw null;
        }
        textView2.setText(channel.getName());
        EpgRepository epgRepository = EpgRepository.INSTANCE;
        t.b nowNext = epgRepository.nowNext(channel.getName());
        EpgProgram epgProgram = (EpgProgram) nowNext.f547a;
        EpgProgram epgProgram2 = (EpgProgram) nowNext.f548b;
        TextView textView3 = this.bottomNowProgram;
        if (textView3 == null) {
            b0.d.G("bottomNowProgram");
            throw null;
        }
        if (epgProgram == null || (str = epgProgram.getTitle()) == null) {
            str = "";
        }
        textView3.setText(str);
        if (epgProgram2 != null) {
            TextView textView4 = this.bottomNextProgram;
            if (textView4 == null) {
                b0.d.G("bottomNextProgram");
                throw null;
            }
            textView4.setText(epgRepository.timeText(epgProgram2.getStartMillis()) + "  " + epgProgram2.getTitle());
        } else {
            TextView textView5 = this.bottomNextProgram;
            if (textView5 == null) {
                b0.d.G("bottomNextProgram");
                throw null;
            }
            textView5.setText("");
        }
        TextView textView6 = this.bottomNowRes;
        if (textView6 == null) {
            b0.d.G("bottomNowRes");
            throw null;
        }
        textView6.setText(this.currentRes);
        updateSourceInfo(channel);
        if (epgProgram != null || epgRepository.isLoaded()) {
            return;
        }
        loadEpgOnDemand();
    }

    private final void updateBottomBarOnResChanged() {
        TextView textView = this.bottomNowRes;
        if (textView == null) {
            b0.d.G("bottomNowRes");
            throw null;
        }
        textView.setText(this.currentRes);
        updateSourceInfo((Channel) u.i.P(channelsOfGroup(this.groupIndex), this.channelIndex));
    }

    private final void updateNumberInputText() {
        Channel channel;
        String str;
        Object obj;
        Integer L = h0.f.L(this.numBuffer);
        if (L != null) {
            Iterator<T> it = this.allChannels.iterator();
            while (true) {
                if (!it.hasNext()) {
                    obj = null;
                    break;
                } else {
                    obj = it.next();
                    if (((Channel) obj).getNumber() == L.intValue()) {
                        break;
                    }
                }
            }
            channel = (Channel) obj;
        } else {
            channel = null;
        }
        TextView textView = this.numberInput;
        if (textView == null) {
            b0.d.G("numberInput");
            throw null;
        }
        if (channel != null) {
            str = this.numBuffer + "  " + channel.getName();
        } else {
            str = this.numBuffer;
        }
        textView.setText(str);
    }

    private final void updateSourceInfo(Channel channel) {
        String str;
        TextView textView = this.bottomNextRes;
        if (textView == null) {
            b0.d.G("bottomNextRes");
            throw null;
        }
        if (channel == null || (str = sourceInfoOf(channel)) == null) {
            str = "";
        }
        textView.setText(str);
    }

    public static /* synthetic */ void updateSourceInfo$default(MainActivity mainActivity, Channel channel, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            channel = null;
        }
        mainActivity.updateSourceInfo(channel);
    }

    @Override // android.app.Activity
    public void onBackPressed() {
        if (this.panelState != 0) {
            closePanel();
        } else {
            handleBackExit();
        }
    }

    @Override // android.app.Activity
    public void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(R.layout.activity_main);
        View findViewById = findViewById(R.id.videoView);
        b0.d.j(findViewById, "findViewById(...)");
        this.video = (VideoView) findViewById;
        View findViewById2 = findViewById(R.id.loading);
        b0.d.j(findViewById2, "findViewById(...)");
        this.loading = (LoadingSpinner) findViewById2;
        View findViewById3 = findViewById(R.id.tvTime);
        b0.d.j(findViewById3, "findViewById(...)");
        this.tvTime = (TextView) findViewById3;
        View findViewById4 = findViewById(R.id.panelContainer);
        b0.d.j(findViewById4, "findViewById(...)");
        this.panelContainer = findViewById4;
        View findViewById5 = findViewById(R.id.groupList);
        b0.d.j(findViewById5, "findViewById(...)");
        this.groupListRv = (RecyclerView) findViewById5;
        View findViewById6 = findViewById(R.id.channelList);
        b0.d.j(findViewById6, "findViewById(...)");
        this.channelListRv = (RecyclerView) findViewById6;
        View findViewById7 = findViewById(R.id.epgList);
        b0.d.j(findViewById7, "findViewById(...)");
        this.epgListRv = (RecyclerView) findViewById7;
        View findViewById8 = findViewById(R.id.epgContainer);
        b0.d.j(findViewById8, "findViewById(...)");
        this.epgContainer = findViewById8;
        View findViewById9 = findViewById(R.id.epgHint);
        b0.d.j(findViewById9, "findViewById(...)");
        this.epgHint = (TextView) findViewById9;
        View findViewById10 = findViewById(R.id.bottomBar);
        b0.d.j(findViewById10, "findViewById(...)");
        this.bottomBar = findViewById10;
        findViewById10.setVisibility(8);
        View findViewById11 = findViewById(R.id.bottomNum);
        b0.d.j(findViewById11, "findViewById(...)");
        this.bottomNum = (TextView) findViewById11;
        View findViewById12 = findViewById(R.id.bottomName);
        b0.d.j(findViewById12, "findViewById(...)");
        this.bottomName = (TextView) findViewById12;
        View findViewById13 = findViewById(R.id.bottomNowProgram);
        b0.d.j(findViewById13, "findViewById(...)");
        this.bottomNowProgram = (TextView) findViewById13;
        View findViewById14 = findViewById(R.id.bottomNextProgram);
        b0.d.j(findViewById14, "findViewById(...)");
        this.bottomNextProgram = (TextView) findViewById14;
        View findViewById15 = findViewById(R.id.bottomNowRes);
        b0.d.j(findViewById15, "findViewById(...)");
        this.bottomNowRes = (TextView) findViewById15;
        View findViewById16 = findViewById(R.id.bottomNextRes);
        b0.d.j(findViewById16, "findViewById(...)");
        this.bottomNextRes = (TextView) findViewById16;
        View findViewById17 = findViewById(R.id.hintStrip);
        b0.d.j(findViewById17, "findViewById(...)");
        this.hintStrip = (TextView) findViewById17;
        View findViewById18 = findViewById(R.id.numberInput);
        b0.d.j(findViewById18, "findViewById(...)");
        this.numberInput = (TextView) findViewById18;
        View findViewById19 = findViewById(R.id.configOverlay);
        b0.d.j(findViewById19, "findViewById(...)");
        this.configOverlay = findViewById19;
        View findViewById20 = findViewById(R.id.qrImage);
        b0.d.j(findViewById20, "findViewById(...)");
        this.qrImage = (ImageView) findViewById20;
        View findViewById21 = findViewById(R.id.settingsPanel);
        b0.d.j(findViewById21, "findViewById(...)");
        this.settingsPanel = findViewById21;
        View findViewById22 = findViewById(R.id.settingsList);
        b0.d.j(findViewById22, "findViewById(...)");
        this.settingsList = (RecyclerView) findViewById22;
        View findViewById23 = findViewById(R.id.settingsTitle);
        b0.d.j(findViewById23, "findViewById(...)");
        this.settingsTitle = (TextView) findViewById23;
        View findViewById24 = findViewById(R.id.settingsHint);
        b0.d.j(findViewById24, "findViewById(...)");
        this.settingsHint = (TextView) findViewById24;
        if (getSp().contains("fav_channels")) {
            getSp().edit().remove("fav_channels").apply();
        }
        applyClockVisibility();
        RecyclerView recyclerView = this.groupListRv;
        if (recyclerView == null) {
            b0.d.G("groupListRv");
            throw null;
        }
        recyclerView.setLayoutManager(new LinearLayoutManager());
        RecyclerView recyclerView2 = this.channelListRv;
        if (recyclerView2 == null) {
            b0.d.G("channelListRv");
            throw null;
        }
        recyclerView2.setLayoutManager(new LinearLayoutManager());
        RecyclerView recyclerView3 = this.epgListRv;
        if (recyclerView3 == null) {
            b0.d.G("epgListRv");
            throw null;
        }
        recyclerView3.setLayoutManager(new LinearLayoutManager());
        computeRowMetrics$default(this, 0, 1, null);
        this.groupAdapter = new GroupAdapter(this.groups, 0, this.rowHeightPx, this.groupTextPx, false, 0, new MainActivity$onCreate$1(this), 32, null);
        this.channelAdapter = new ChannelAdapter(this.channelListData, 0, this.rowHeightPx, this.channelTextPx, true, new MainActivity$onCreate$2(this), new MainActivity$onCreate$3(this), new MainActivity$onCreate$4(this), new MainActivity$onCreate$5(this));
        this.epgAdapter = new EpgAdapter(this.epgData, 0, this.rowHeightPx, this.channelTextPx, true, null, 32, null);
        RecyclerView recyclerView4 = this.groupListRv;
        if (recyclerView4 == null) {
            b0.d.G("groupListRv");
            throw null;
        }
        GroupAdapter groupAdapter = this.groupAdapter;
        if (groupAdapter == null) {
            b0.d.G("groupAdapter");
            throw null;
        }
        recyclerView4.setAdapter(groupAdapter);
        RecyclerView recyclerView5 = this.channelListRv;
        if (recyclerView5 == null) {
            b0.d.G("channelListRv");
            throw null;
        }
        ChannelAdapter channelAdapter = this.channelAdapter;
        if (channelAdapter == null) {
            b0.d.G("channelAdapter");
            throw null;
        }
        recyclerView5.setAdapter(channelAdapter);
        RecyclerView recyclerView6 = this.epgListRv;
        if (recyclerView6 == null) {
            b0.d.G("epgListRv");
            throw null;
        }
        EpgAdapter epgAdapter = this.epgAdapter;
        if (epgAdapter == null) {
            b0.d.G("epgAdapter");
            throw null;
        }
        recyclerView6.setAdapter(epgAdapter);
        RecyclerView recyclerView7 = this.settingsList;
        if (recyclerView7 == null) {
            b0.d.G("settingsList");
            throw null;
        }
        recyclerView7.setLayoutManager(new LinearLayoutManager());
        ManageAdapter manageAdapter = new ManageAdapter(this.settingsItems, 0, this.rowHeightPx, this.channelTextPx, new MainActivity$onCreate$6(this));
        this.settingsAdapter = manageAdapter;
        RecyclerView recyclerView8 = this.settingsList;
        if (recyclerView8 == null) {
            b0.d.G("settingsList");
            throw null;
        }
        recyclerView8.setAdapter(manageAdapter);
        String memGet = memGet("last_url", SourceStore.INSTANCE.currentId(this));
        if (memGet == null || memGet.length() == 0) {
            this.loadingHandler.postDelayed(this.loadingRunnable, 1200L);
        } else {
            playUrlDirect(memGet);
        }
        boolean z2 = memGet == null || memGet.length() == 0;
        this.pendingAutoPlayFirst = z2;
        requestListParse(z2 ? 0L : LIST_PARSE_FALLBACK_MS);
        this.timeHandler.postDelayed(this.listWatchdog, this.LIST_WATCHDOG_MS);
        scheduleSilentUpdate();
    }

    @Override // android.app.Activity
    public void onDestroy() {
        super.onDestroy();
        try {
            this.bgPool.shutdownNow();
        } catch (Throwable unused) {
        }
        this.timeoutHandler.removeCallbacksAndMessages(null);
        this.loadingHandler.removeCallbacksAndMessages(null);
        this.timeHandler.removeCallbacksAndMessages(null);
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyDown(int i2, KeyEvent keyEvent) {
        int i3;
        if (keyEvent != null && keyEvent.getRepeatCount() > 0 && (i2 == 23 || i2 == 66)) {
            return true;
        }
        if ((i2 == 23 || i2 == 66 || i2 == 82) && keyEvent != null) {
            keyEvent.startTracking();
        }
        if (this.numBuffer.length() > 0) {
            if (i2 == 4) {
                clearNumberInput();
                return true;
            }
            if (i2 == 23 || i2 == 66) {
                commitNumberInput();
                return true;
            }
        }
        if (handleNumberKey(i2)) {
            return true;
        }
        View view = this.settingsPanel;
        if (view == null) {
            b0.d.G("settingsPanel");
            throw null;
        }
        if (view.getVisibility() == 0) {
            handleSettingsKey(i2);
            return true;
        }
        View view2 = this.configOverlay;
        if (view2 == null) {
            b0.d.G("configOverlay");
            throw null;
        }
        if (view2.getVisibility() == 0) {
            if (i2 == 4) {
                hideConfig();
            }
            return true;
        }
        if (this.panelState == 1) {
            resetHideTimer();
            handlePanelKey(i2);
            return true;
        }
        if (i2 == 4) {
            handleBackExit();
            return true;
        }
        if (i2 != 66) {
            if (i2 == 82 || i2 == 176) {
                showSettings();
                return true;
            }
            switch (i2) {
                case 19:
                    int i4 = this.channelIndex;
                    if (i4 <= 0) {
                        return true;
                    }
                    i3 = i4 - 1;
                    break;
                case 20:
                    if (this.channelIndex >= channelsOfGroup(this.groupIndex).size() - 1) {
                        return true;
                    }
                    i3 = this.channelIndex + 1;
                    break;
                case 21:
                    switchSource(-1);
                    return true;
                case 22:
                    switchSource(1);
                    return true;
                case 23:
                    break;
                default:
                    return super.onKeyDown(i2, keyEvent);
            }
            playChannel(i3, false);
            return true;
        }
        this.centerDownPending = true;
        this.centerLongPressFired = false;
        this.centerHandler.removeCallbacks(this.centerLongPressRunnable);
        this.centerHandler.postDelayed(this.centerLongPressRunnable, this.CENTER_LONG_PRESS_MS);
        return true;
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyLongPress(int i2, KeyEvent keyEvent) {
        return super.onKeyLongPress(i2, keyEvent);
    }

    @Override // android.app.Activity, android.view.KeyEvent.Callback
    public boolean onKeyUp(int i2, KeyEvent keyEvent) {
        if (handleBackOnUp(i2)) {
            return true;
        }
        if (i2 != 23 && i2 != 66) {
            return super.onKeyUp(i2, keyEvent);
        }
        if (this.centerDownPending) {
            this.centerDownPending = false;
            this.centerHandler.removeCallbacks(this.centerLongPressRunnable);
            boolean z2 = this.centerLongPressFired;
            this.centerLongPressFired = false;
            if (!z2) {
                openPanel();
            }
        }
        return true;
    }

    @Override // android.app.Activity
    public void onPause() {
        super.onPause();
        this.timeoutHandler.removeCallbacks(this.timeoutRunnable);
        this.timeHandler.removeCallbacks(this.timeRunnable);
        this.hideHandler.removeCallbacks(this.hideRunnable);
        this.numHandler.removeCallbacks(this.numCommitRunnable);
        stopConfigServer();
    }

    /* JADX WARN: Removed duplicated region for block: B:15:0x0036  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0069  */
    @Override // android.app.Activity
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void onResume() {
        /*
            r5 = this;
            super.onResume()
            android.os.Handler r0 = r5.timeHandler
            tv.live.MainActivity$timeRunnable$1 r1 = r5.timeRunnable
            r0.post(r1)
            java.util.List<tv.live.Channel> r0 = r5.allChannels
            boolean r0 = r0.isEmpty()
            if (r0 != 0) goto L83
            android.widget.VideoView r0 = r5.video
            java.lang.String r1 = "video"
            r2 = 0
            if (r0 == 0) goto L7f
            boolean r0 = r0.isPlaying()
            if (r0 == 0) goto L20
            goto L83
        L20:
            r0 = 1
            r3 = 0
            android.widget.VideoView r4 = r5.video     // Catch: java.lang.Exception -> L32
            if (r4 == 0) goto L2e
            int r4 = r4.getDuration()     // Catch: java.lang.Exception -> L32
            if (r4 <= 0) goto L33
            r4 = 1
            goto L34
        L2e:
            b0.d.G(r1)     // Catch: java.lang.Exception -> L32
            throw r2     // Catch: java.lang.Exception -> L32
        L32:
        L33:
            r4 = 0
        L34:
            if (r4 == 0) goto L69
            tv.live.LoadingSpinner r3 = r5.loading
            if (r3 == 0) goto L63
            r4 = 8
            r3.setVisibility(r4)
            android.os.Handler r3 = r5.timeoutHandler
            java.lang.Runnable r4 = r5.timeoutRunnable
            r3.removeCallbacks(r4)
            r5.playCallbackFired = r0
            android.widget.VideoView r0 = r5.video     // Catch: java.lang.Throwable -> L54
            if (r0 == 0) goto L50
            r0.start()     // Catch: java.lang.Throwable -> L54
            goto L54
        L50:
            b0.d.G(r1)     // Catch: java.lang.Throwable -> L54
            throw r2     // Catch: java.lang.Throwable -> L54
        L54:
            android.os.Handler r0 = r5.timeoutHandler
            tv.live.t r1 = new tv.live.t
            r2 = 17
            r1.<init>(r5, r2)
            r2 = 1500(0x5dc, double:7.41E-321)
            r0.postDelayed(r1, r2)
            goto L7e
        L63:
            java.lang.String r0 = "loading"
            b0.d.G(r0)
            throw r2
        L69:
            int r1 = r5.groupIndex
            java.util.List r1 = r5.channelsOfGroup(r1)
            int r2 = r5.channelIndex
            int r1 = r1.size()
            if (r2 >= r1) goto L7e
            r5.quietResume = r0
            int r0 = r5.channelIndex
            r5.playChannel(r0, r3)
        L7e:
            return
        L7f:
            b0.d.G(r1)
            throw r2
        L83:
            return
        */
        throw new UnsupportedOperationException("Method not decompiled: tv.live.MainActivity.onResume():void");
    }

    @Override // android.app.Activity
    public void onStop() {
        super.onStop();
        if (isFinishing()) {
            try {
                VideoView videoView = this.video;
                if (videoView == null) {
                    b0.d.G("video");
                    throw null;
                }
                if (videoView.isPlaying()) {
                    VideoView videoView2 = this.video;
                    if (videoView2 != null) {
                        videoView2.pause();
                    } else {
                        b0.d.G("video");
                        throw null;
                    }
                }
            } catch (Throwable unused) {
            }
        }
    }
}
