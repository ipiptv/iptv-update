package tv.live;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import androidx.recyclerview.widget.i0;
import androidx.recyclerview.widget.i1;
import java.util.List;

/* loaded from: classes.dex */
public final class ManageAdapter extends i0 {
    private final List<ManageItem> list;
    private final c0.b onClick;
    private int rowHeightPx;
    private int selected;
    private float textSizePx;

    public static final class VH extends i1 {
        private final TextView action;
        private final View bar;
        private final TextView sub;
        private final TextView title;

        /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
        public VH(View view) {
            super(view);
            b0.d.k(view, "v");
            View findViewById = view.findViewById(R.id.manageTitle);
            b0.d.j(findViewById, "findViewById(...)");
            this.title = (TextView) findViewById;
            View findViewById2 = view.findViewById(R.id.manageSub);
            b0.d.j(findViewById2, "findViewById(...)");
            this.sub = (TextView) findViewById2;
            View findViewById3 = view.findViewById(R.id.manageBar);
            b0.d.j(findViewById3, "findViewById(...)");
            this.bar = findViewById3;
            View findViewById4 = view.findViewById(R.id.manageAction);
            b0.d.j(findViewById4, "findViewById(...)");
            this.action = (TextView) findViewById4;
        }

        public final TextView getAction() {
            return this.action;
        }

        public final View getBar() {
            return this.bar;
        }

        public final TextView getSub() {
            return this.sub;
        }

        public final TextView getTitle() {
            return this.title;
        }
    }

    public ManageAdapter(List<ManageItem> list, int i2, int i3, float f2, c0.b bVar) {
        b0.d.k(list, "list");
        this.list = list;
        this.selected = i2;
        this.rowHeightPx = i3;
        this.textSizePx = f2;
        this.onClick = bVar;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void onBindViewHolder$lambda$0(ManageAdapter manageAdapter, int i2, View view) {
        b0.d.k(manageAdapter, "this$0");
        c0.b bVar = manageAdapter.onClick;
        if (bVar != null) {
            bVar.invoke(Integer.valueOf(i2));
        }
    }

    @Override // androidx.recyclerview.widget.i0
    public int getItemCount() {
        return this.list.size();
    }

    public final int getRowHeightPx() {
        return this.rowHeightPx;
    }

    public final int getSelected() {
        return this.selected;
    }

    public final float getTextSizePx() {
        return this.textSizePx;
    }

    public final void setRowHeightPx(int i2) {
        this.rowHeightPx = i2;
    }

    public final void setSelected(int i2) {
        this.selected = i2;
    }

    public final void setTextSizePx(float f2) {
        this.textSizePx = f2;
    }

    public /* synthetic */ ManageAdapter(List list, int i2, int i3, float f2, c0.b bVar, int i4, d0.a aVar) {
        this(list, (i4 & 2) != 0 ? 0 : i2, (i4 & 4) != 0 ? 0 : i3, (i4 & 8) != 0 ? RecyclerView.B0 : f2, (i4 & 16) != 0 ? null : bVar);
    }

    /* JADX WARN: Code restructure failed: missing block: B:8:0x0029, code lost:
    
        if ((r0.getSubtitle().length() > 0) != false) goto L13;
     */
    /* JADX WARN: Removed duplicated region for block: B:12:0x0031  */
    /* JADX WARN: Removed duplicated region for block: B:15:0x0065  */
    /* JADX WARN: Removed duplicated region for block: B:24:0x00ef  */
    /* JADX WARN: Removed duplicated region for block: B:30:0x0126  */
    /* JADX WARN: Removed duplicated region for block: B:37:0x015a  */
    /* JADX WARN: Removed duplicated region for block: B:57:0x019d  */
    /* JADX WARN: Removed duplicated region for block: B:63:0x0147  */
    /* JADX WARN: Removed duplicated region for block: B:65:0x014c  */
    /* JADX WARN: Removed duplicated region for block: B:66:0x0149  */
    /* JADX WARN: Removed duplicated region for block: B:67:0x0128  */
    /* JADX WARN: Removed duplicated region for block: B:70:0x0103  */
    /* JADX WARN: Removed duplicated region for block: B:71:0x0115  */
    /* JADX WARN: Removed duplicated region for block: B:74:0x00a0  */
    /* JADX WARN: Removed duplicated region for block: B:75:0x00b3  */
    /* JADX WARN: Removed duplicated region for block: B:84:0x004b  */
    @Override // androidx.recyclerview.widget.i0
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public void onBindViewHolder(tv.live.ManageAdapter.VH r9, int r10) {
        /*
            Method dump skipped, instructions count: 436
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: tv.live.ManageAdapter.onBindViewHolder(tv.live.ManageAdapter$VH, int):void");
    }

    @Override // androidx.recyclerview.widget.i0
    public VH onCreateViewHolder(ViewGroup viewGroup, int i2) {
        b0.d.k(viewGroup, "parent");
        View inflate = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_manage, viewGroup, false);
        b0.d.h(inflate);
        return new VH(inflate);
    }
}
