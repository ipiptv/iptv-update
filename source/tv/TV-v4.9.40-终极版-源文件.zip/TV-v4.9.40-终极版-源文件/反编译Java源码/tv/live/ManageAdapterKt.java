package tv.live;

import android.view.View;

/* loaded from: classes.dex */
public final class ManageAdapterKt {
    private static final int FOCUS_BG = -871736167;

    /* JADX INFO: Access modifiers changed from: private */
    public static final int dpOf(View view, int i2) {
        return (int) (i2 * view.getResources().getDisplayMetrics().density);
    }
}
