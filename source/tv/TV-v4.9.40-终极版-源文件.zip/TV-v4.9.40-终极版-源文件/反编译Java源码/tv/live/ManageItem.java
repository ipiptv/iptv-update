package tv.live;

/* loaded from: classes.dex */
public final class ManageItem {
    private final boolean checked;
    private final String payload;
    private final String subtitle;
    private final String title;
    private final int type;

    public ManageItem(String str, String str2, int i2, boolean z2, String str3) {
        b0.d.k(str, "title");
        b0.d.k(str2, "subtitle");
        b0.d.k(str3, "payload");
        this.title = str;
        this.subtitle = str2;
        this.type = i2;
        this.checked = z2;
        this.payload = str3;
    }

    public static /* synthetic */ ManageItem copy$default(ManageItem manageItem, String str, String str2, int i2, boolean z2, String str3, int i3, Object obj) {
        if ((i3 & 1) != 0) {
            str = manageItem.title;
        }
        if ((i3 & 2) != 0) {
            str2 = manageItem.subtitle;
        }
        String str4 = str2;
        if ((i3 & 4) != 0) {
            i2 = manageItem.type;
        }
        int i4 = i2;
        if ((i3 & 8) != 0) {
            z2 = manageItem.checked;
        }
        boolean z3 = z2;
        if ((i3 & 16) != 0) {
            str3 = manageItem.payload;
        }
        return manageItem.copy(str, str4, i4, z3, str3);
    }

    public final String component1() {
        return this.title;
    }

    public final String component2() {
        return this.subtitle;
    }

    public final int component3() {
        return this.type;
    }

    public final boolean component4() {
        return this.checked;
    }

    public final String component5() {
        return this.payload;
    }

    public final ManageItem copy(String str, String str2, int i2, boolean z2, String str3) {
        b0.d.k(str, "title");
        b0.d.k(str2, "subtitle");
        b0.d.k(str3, "payload");
        return new ManageItem(str, str2, i2, z2, str3);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof ManageItem)) {
            return false;
        }
        ManageItem manageItem = (ManageItem) obj;
        return b0.d.b(this.title, manageItem.title) && b0.d.b(this.subtitle, manageItem.subtitle) && this.type == manageItem.type && this.checked == manageItem.checked && b0.d.b(this.payload, manageItem.payload);
    }

    public final boolean getChecked() {
        return this.checked;
    }

    public final String getPayload() {
        return this.payload;
    }

    public final String getSubtitle() {
        return this.subtitle;
    }

    public final String getTitle() {
        return this.title;
    }

    public final int getType() {
        return this.type;
    }

    public int hashCode() {
        return this.payload.hashCode() + ((((((this.subtitle.hashCode() + (this.title.hashCode() * 31)) * 31) + this.type) * 31) + (this.checked ? 1231 : 1237)) * 31);
    }

    public String toString() {
        return "ManageItem(title=" + this.title + ", subtitle=" + this.subtitle + ", type=" + this.type + ", checked=" + this.checked + ", payload=" + this.payload + ')';
    }

    public /* synthetic */ ManageItem(String str, String str2, int i2, boolean z2, String str3, int i3, d0.a aVar) {
        this(str, str2, i2, (i3 & 8) != 0 ? false : z2, (i3 & 16) != 0 ? "" : str3);
    }
}
