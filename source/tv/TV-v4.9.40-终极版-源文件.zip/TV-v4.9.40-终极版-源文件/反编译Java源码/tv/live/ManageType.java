package tv.live;

/* loaded from: classes.dex */
public final class ManageType {
    public static final int ADD = 1;
    public static final int GROUP = 2;
    public static final int INFO = 4;
    public static final ManageType INSTANCE = new ManageType();
    public static final int NAV = 3;
    public static final int SOURCE = 0;

    private ManageType() {
    }
}
