package tv.live;

import android.graphics.Bitmap;
import java.util.HashMap;

/* loaded from: classes.dex */
public final class QrGenerator {
    public static final QrGenerator INSTANCE = new QrGenerator();

    private QrGenerator() {
    }

    public final Bitmap generate(String str, int i2) {
        b0.d.k(str, "text");
        if (!(str.length() == 0) && i2 > 0) {
            try {
                HashMap hashMap = new HashMap();
                hashMap.put(n.b.MARGIN, 1);
                hashMap.put(n.b.CHARACTER_SET, "UTF-8");
                o.b u2 = b0.d.u(str, i2, i2, hashMap);
                int i3 = u2.f513a;
                int i4 = u2.f514b;
                int[] iArr = new int[i3 * i4];
                for (int i5 = 0; i5 < i4; i5++) {
                    for (int i6 = 0; i6 < i3; i6++) {
                        iArr[(i5 * i3) + i6] = ((u2.f516d[(i6 / 32) + (u2.f515c * i5)] >>> (i6 & 31)) & 1) != 0 ? -16777216 : -1;
                    }
                }
                Bitmap createBitmap = Bitmap.createBitmap(i3, i4, Bitmap.Config.RGB_565);
                b0.d.j(createBitmap, "createBitmap(...)");
                createBitmap.setPixels(iArr, 0, i3, 0, 0, i3, i4);
                return createBitmap;
            } catch (Exception unused) {
            }
        }
        return null;
    }
}
