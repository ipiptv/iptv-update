package tv.live;

/* loaded from: classes.dex */
public final class R {

    public static final class drawable {
        public static int ic_channel = 0x7f040006;
        public static int panel_bg = 0x7f040014;
        public static int settings_bg = 0x7f040015;
        public static int tv_banner = 0x7f040016;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer = 0x7f040000;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer_low = 0x7f040001;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer_video = 0x7f040002;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_answer_video_low = 0x7f040003;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_decline = 0x7f040004;

        /* JADX INFO: Added by JADX */
        public static final int ic_call_decline_low = 0x7f040005;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_background = 0x7f040007;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg = 0x7f040008;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_low = 0x7f040009;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_low_normal = 0x7f04000a;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_low_pressed = 0x7f04000b;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_normal = 0x7f04000c;

        /* JADX INFO: Added by JADX */
        public static final int notification_bg_normal_pressed = 0x7f04000d;

        /* JADX INFO: Added by JADX */
        public static final int notification_icon_background = 0x7f04000e;

        /* JADX INFO: Added by JADX */
        public static final int notification_oversize_large_icon_bg = 0x7f04000f;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_bg = 0x7f040010;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_low_bg = 0x7f040011;

        /* JADX INFO: Added by JADX */
        public static final int notification_tile_bg = 0x7f040012;

        /* JADX INFO: Added by JADX */
        public static final int notify_panel_notification_icon_bg = 0x7f040013;

        private drawable() {
        }
    }

    public static final class id {
        public static int bottomBar = 0x7f050028;
        public static int bottomName = 0x7f050029;
        public static int bottomNextProgram = 0x7f05002a;
        public static int bottomNextRes = 0x7f05002b;
        public static int bottomNowProgram = 0x7f05002c;
        public static int bottomNowRes = 0x7f05002d;
        public static int bottomNum = 0x7f05002e;
        public static int channelIcon = 0x7f05002f;
        public static int channelList = 0x7f050030;
        public static int channelName = 0x7f050031;
        public static int channelNum = 0x7f050032;
        public static int configOverlay = 0x7f050034;
        public static int epgBadge = 0x7f050037;
        public static int epgContainer = 0x7f050038;
        public static int epgHint = 0x7f050039;
        public static int epgList = 0x7f05003a;
        public static int epgTime = 0x7f05003b;
        public static int epgTitle = 0x7f05003c;
        public static int groupList = 0x7f05003e;
        public static int hintStrip = 0x7f050040;
        public static int loading = 0x7f050049;
        public static int manageAction = 0x7f05004a;
        public static int manageBar = 0x7f05004b;
        public static int manageSub = 0x7f05004c;
        public static int manageTitle = 0x7f05004d;
        public static int numberInput = 0x7f050052;
        public static int panelContainer = 0x7f050053;
        public static int programLabel = 0x7f050055;
        public static int programName = 0x7f050056;
        public static int programRow = 0x7f050057;
        public static int qrImage = 0x7f050058;
        public static int rootView = 0x7f05005b;
        public static int settingsHint = 0x7f05005c;
        public static int settingsList = 0x7f05005d;
        public static int settingsPanel = 0x7f05005e;
        public static int settingsTitle = 0x7f05005f;
        public static int sourceInfo = 0x7f050060;
        public static int tvTime = 0x7f050072;
        public static int videoView = 0x7f050073;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_action_clickable_span = 0x7f050000;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_0 = 0x7f050001;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_1 = 0x7f050002;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_10 = 0x7f050003;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_11 = 0x7f050004;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_12 = 0x7f050005;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_13 = 0x7f050006;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_14 = 0x7f050007;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_15 = 0x7f050008;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_16 = 0x7f050009;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_17 = 0x7f05000a;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_18 = 0x7f05000b;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_19 = 0x7f05000c;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_2 = 0x7f05000d;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_20 = 0x7f05000e;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_21 = 0x7f05000f;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_22 = 0x7f050010;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_23 = 0x7f050011;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_24 = 0x7f050012;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_25 = 0x7f050013;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_26 = 0x7f050014;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_27 = 0x7f050015;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_28 = 0x7f050016;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_29 = 0x7f050017;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_3 = 0x7f050018;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_30 = 0x7f050019;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_31 = 0x7f05001a;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_4 = 0x7f05001b;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_5 = 0x7f05001c;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_6 = 0x7f05001d;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_7 = 0x7f05001e;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_8 = 0x7f05001f;

        /* JADX INFO: Added by JADX */
        public static final int accessibility_custom_action_9 = 0x7f050020;

        /* JADX INFO: Added by JADX */
        public static final int action_container = 0x7f050021;

        /* JADX INFO: Added by JADX */
        public static final int action_divider = 0x7f050022;

        /* JADX INFO: Added by JADX */
        public static final int action_image = 0x7f050023;

        /* JADX INFO: Added by JADX */
        public static final int action_text = 0x7f050024;

        /* JADX INFO: Added by JADX */
        public static final int actions = 0x7f050025;

        /* JADX INFO: Added by JADX */
        public static final int async = 0x7f050026;

        /* JADX INFO: Added by JADX */
        public static final int blocking = 0x7f050027;

        /* JADX INFO: Added by JADX */
        public static final int chronometer = 0x7f050033;

        /* JADX INFO: Added by JADX */
        public static final int dialog_button = 0x7f050035;

        /* JADX INFO: Added by JADX */
        public static final int edit_text_id = 0x7f050036;

        /* JADX INFO: Added by JADX */
        public static final int forever = 0x7f05003d;

        /* JADX INFO: Added by JADX */
        public static final int hide_ime_id = 0x7f05003f;

        /* JADX INFO: Added by JADX */
        public static final int icon = 0x7f050041;

        /* JADX INFO: Added by JADX */
        public static final int icon_group = 0x7f050042;

        /* JADX INFO: Added by JADX */
        public static final int info = 0x7f050043;

        /* JADX INFO: Added by JADX */
        public static final int is_pooling_container_tag = 0x7f050044;

        /* JADX INFO: Added by JADX */
        public static final int italic = 0x7f050045;

        /* JADX INFO: Added by JADX */
        public static final int item_touch_helper_previous_elevation = 0x7f050046;

        /* JADX INFO: Added by JADX */
        public static final int line1 = 0x7f050047;

        /* JADX INFO: Added by JADX */
        public static final int line3 = 0x7f050048;

        /* JADX INFO: Added by JADX */
        public static final int normal = 0x7f05004e;

        /* JADX INFO: Added by JADX */
        public static final int notification_background = 0x7f05004f;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column = 0x7f050050;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column_container = 0x7f050051;

        /* JADX INFO: Added by JADX */
        public static final int pooling_container_listener_holder_tag = 0x7f050054;

        /* JADX INFO: Added by JADX */
        public static final int right_icon = 0x7f050059;

        /* JADX INFO: Added by JADX */
        public static final int right_side = 0x7f05005a;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_actions = 0x7f050061;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_clickable_spans = 0x7f050062;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_heading = 0x7f050063;

        /* JADX INFO: Added by JADX */
        public static final int tag_accessibility_pane_title = 0x7f050064;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_apply_window_listener = 0x7f050065;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_receive_content_listener = 0x7f050066;

        /* JADX INFO: Added by JADX */
        public static final int tag_on_receive_content_mime_types = 0x7f050067;

        /* JADX INFO: Added by JADX */
        public static final int tag_screen_reader_focusable = 0x7f050068;

        /* JADX INFO: Added by JADX */
        public static final int tag_state_description = 0x7f050069;

        /* JADX INFO: Added by JADX */
        public static final int tag_transition_group = 0x7f05006a;

        /* JADX INFO: Added by JADX */
        public static final int tag_unhandled_key_event_manager = 0x7f05006b;

        /* JADX INFO: Added by JADX */
        public static final int tag_unhandled_key_listeners = 0x7f05006c;

        /* JADX INFO: Added by JADX */
        public static final int tag_window_insets_animation_callback = 0x7f05006d;

        /* JADX INFO: Added by JADX */
        public static final int text = 0x7f05006e;

        /* JADX INFO: Added by JADX */
        public static final int text2 = 0x7f05006f;

        /* JADX INFO: Added by JADX */
        public static final int time = 0x7f050070;

        /* JADX INFO: Added by JADX */
        public static final int title = 0x7f050071;

        /* JADX INFO: Added by JADX */
        public static final int view_tree_lifecycle_owner = 0x7f050074;

        private id() {
        }
    }

    public static final class layout {
        public static int activity_main = 0x7f070000;
        public static int item_channel = 0x7f070004;
        public static int item_epg = 0x7f070005;
        public static int item_group = 0x7f070006;
        public static int item_manage = 0x7f070007;

        /* JADX INFO: Added by JADX */
        public static final int custom_dialog = 0x7f070001;

        /* JADX INFO: Added by JADX */
        public static final int ime_base_split_test_activity = 0x7f070002;

        /* JADX INFO: Added by JADX */
        public static final int ime_secondary_split_test_activity = 0x7f070003;

        /* JADX INFO: Added by JADX */
        public static final int notification_action = 0x7f070008;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_tombstone = 0x7f070009;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_custom_big = 0x7f07000a;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_icon_group = 0x7f07000b;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_part_chronometer = 0x7f07000c;

        /* JADX INFO: Added by JADX */
        public static final int notification_template_part_time = 0x7f07000d;

        private layout() {
        }
    }

    public static final class mipmap {
        public static int ic_launcher = 0x7f080000;
        public static int ic_launcher_round = 0x7f080001;

        private mipmap() {
        }
    }

    public static final class string {
        public static int app_name = 0x7f090000;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_action = 0x7f090001;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_video_action = 0x7f090002;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_decline_action = 0x7f090003;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_hang_up_action = 0x7f090004;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_incoming_text = 0x7f090005;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_ongoing_text = 0x7f090006;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_screening_text = 0x7f090007;

        /* JADX INFO: Added by JADX */
        public static final int status_bar_notification_info_overflow = 0x7f090008;

        private string() {
        }
    }

    public static final class style {
        public static int Theme_TV = 0x7f0a0005;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification = 0x7f0a0000;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Info = 0x7f0a0001;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Line2 = 0x7f0a0002;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Time = 0x7f0a0003;

        /* JADX INFO: Added by JADX */
        public static final int TextAppearance_Compat_Notification_Title = 0x7f0a0004;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Compat_NotificationActionContainer = 0x7f0a0006;

        /* JADX INFO: Added by JADX */
        public static final int Widget_Compat_NotificationActionText = 0x7f0a0007;

        private style() {
        }
    }

    public static final class xml {
        public static int file_paths = 0x7f0c0000;
        public static int network_security_config = 0x7f0c0001;

        private xml() {
        }
    }

    /* JADX INFO: Added by JADX */
    public static final class attr {

        /* JADX INFO: Added by JADX */
        public static final int alpha = 0x7f010000;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollEnabled = 0x7f010001;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollHorizontalThumbDrawable = 0x7f010002;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollHorizontalTrackDrawable = 0x7f010003;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollVerticalThumbDrawable = 0x7f010004;

        /* JADX INFO: Added by JADX */
        public static final int fastScrollVerticalTrackDrawable = 0x7f010005;

        /* JADX INFO: Added by JADX */
        public static final int font = 0x7f010006;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderAuthority = 0x7f010007;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderCerts = 0x7f010008;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFetchStrategy = 0x7f010009;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderFetchTimeout = 0x7f01000a;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderPackage = 0x7f01000b;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderQuery = 0x7f01000c;

        /* JADX INFO: Added by JADX */
        public static final int fontProviderSystemFontFamily = 0x7f01000d;

        /* JADX INFO: Added by JADX */
        public static final int fontStyle = 0x7f01000e;

        /* JADX INFO: Added by JADX */
        public static final int fontVariationSettings = 0x7f01000f;

        /* JADX INFO: Added by JADX */
        public static final int fontWeight = 0x7f010010;

        /* JADX INFO: Added by JADX */
        public static final int lStar = 0x7f010011;

        /* JADX INFO: Added by JADX */
        public static final int layoutManager = 0x7f010012;

        /* JADX INFO: Added by JADX */
        public static final int nestedScrollViewStyle = 0x7f010013;

        /* JADX INFO: Added by JADX */
        public static final int queryPatterns = 0x7f010014;

        /* JADX INFO: Added by JADX */
        public static final int recyclerViewStyle = 0x7f010015;

        /* JADX INFO: Added by JADX */
        public static final int reverseLayout = 0x7f010016;

        /* JADX INFO: Added by JADX */
        public static final int shortcutMatchRequired = 0x7f010017;

        /* JADX INFO: Added by JADX */
        public static final int spanCount = 0x7f010018;

        /* JADX INFO: Added by JADX */
        public static final int stackFromEnd = 0x7f010019;

        /* JADX INFO: Added by JADX */
        public static final int ttcIndex = 0x7f01001a;
    }

    /* JADX INFO: Added by JADX */
    public static final class color {

        /* JADX INFO: Added by JADX */
        public static final int androidx_core_ripple_material_light = 0x7f020000;

        /* JADX INFO: Added by JADX */
        public static final int androidx_core_secondary_text_default_material_light = 0x7f020001;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_answer_color = 0x7f020002;

        /* JADX INFO: Added by JADX */
        public static final int call_notification_decline_color = 0x7f020003;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_color_filter = 0x7f020004;

        /* JADX INFO: Added by JADX */
        public static final int notification_icon_bg_color = 0x7f020005;
    }

    /* JADX INFO: Added by JADX */
    public static final class dimen {

        /* JADX INFO: Added by JADX */
        public static final int compat_button_inset_horizontal_material = 0x7f030000;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_inset_vertical_material = 0x7f030001;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_padding_horizontal_material = 0x7f030002;

        /* JADX INFO: Added by JADX */
        public static final int compat_button_padding_vertical_material = 0x7f030003;

        /* JADX INFO: Added by JADX */
        public static final int compat_control_corner_material = 0x7f030004;

        /* JADX INFO: Added by JADX */
        public static final int compat_notification_large_icon_max_height = 0x7f030005;

        /* JADX INFO: Added by JADX */
        public static final int compat_notification_large_icon_max_width = 0x7f030006;

        /* JADX INFO: Added by JADX */
        public static final int fastscroll_default_thickness = 0x7f030007;

        /* JADX INFO: Added by JADX */
        public static final int fastscroll_margin = 0x7f030008;

        /* JADX INFO: Added by JADX */
        public static final int fastscroll_minimum_range = 0x7f030009;

        /* JADX INFO: Added by JADX */
        public static final int item_touch_helper_max_drag_scroll_per_frame = 0x7f03000a;

        /* JADX INFO: Added by JADX */
        public static final int item_touch_helper_swipe_escape_max_velocity = 0x7f03000b;

        /* JADX INFO: Added by JADX */
        public static final int item_touch_helper_swipe_escape_velocity = 0x7f03000c;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_icon_size = 0x7f03000d;

        /* JADX INFO: Added by JADX */
        public static final int notification_action_text_size = 0x7f03000e;

        /* JADX INFO: Added by JADX */
        public static final int notification_big_circle_margin = 0x7f03000f;

        /* JADX INFO: Added by JADX */
        public static final int notification_content_margin_start = 0x7f030010;

        /* JADX INFO: Added by JADX */
        public static final int notification_large_icon_height = 0x7f030011;

        /* JADX INFO: Added by JADX */
        public static final int notification_large_icon_width = 0x7f030012;

        /* JADX INFO: Added by JADX */
        public static final int notification_main_column_padding_top = 0x7f030013;

        /* JADX INFO: Added by JADX */
        public static final int notification_media_narrow_margin = 0x7f030014;

        /* JADX INFO: Added by JADX */
        public static final int notification_right_icon_size = 0x7f030015;

        /* JADX INFO: Added by JADX */
        public static final int notification_right_side_padding_top = 0x7f030016;

        /* JADX INFO: Added by JADX */
        public static final int notification_small_icon_background_padding = 0x7f030017;

        /* JADX INFO: Added by JADX */
        public static final int notification_small_icon_size_as_large = 0x7f030018;

        /* JADX INFO: Added by JADX */
        public static final int notification_subtext_size = 0x7f030019;

        /* JADX INFO: Added by JADX */
        public static final int notification_top_pad = 0x7f03001a;

        /* JADX INFO: Added by JADX */
        public static final int notification_top_pad_large_text = 0x7f03001b;
    }

    /* JADX INFO: Added by JADX */
    public static final class integer {

        /* JADX INFO: Added by JADX */
        public static final int status_bar_notification_info_maxnum = 0x7f060000;
    }

    private R() {
    }
}
