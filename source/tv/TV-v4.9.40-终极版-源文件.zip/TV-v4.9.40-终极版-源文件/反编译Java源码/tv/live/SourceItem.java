package tv.live;

/* loaded from: classes.dex */
public final class SourceItem {
    private boolean enabled;
    private final String id;
    private String name;
    private String ua;
    private long updatedAt;
    private String url;

    public SourceItem(String str, String str2, String str3, long j2, String str4, boolean z2) {
        b0.d.k(str, "id");
        b0.d.k(str2, "name");
        b0.d.k(str3, "url");
        b0.d.k(str4, "ua");
        this.id = str;
        this.name = str2;
        this.url = str3;
        this.updatedAt = j2;
        this.ua = str4;
        this.enabled = z2;
    }

    public static /* synthetic */ SourceItem copy$default(SourceItem sourceItem, String str, String str2, String str3, long j2, String str4, boolean z2, int i2, Object obj) {
        if ((i2 & 1) != 0) {
            str = sourceItem.id;
        }
        if ((i2 & 2) != 0) {
            str2 = sourceItem.name;
        }
        String str5 = str2;
        if ((i2 & 4) != 0) {
            str3 = sourceItem.url;
        }
        String str6 = str3;
        if ((i2 & 8) != 0) {
            j2 = sourceItem.updatedAt;
        }
        long j3 = j2;
        if ((i2 & 16) != 0) {
            str4 = sourceItem.ua;
        }
        String str7 = str4;
        if ((i2 & 32) != 0) {
            z2 = sourceItem.enabled;
        }
        return sourceItem.copy(str, str5, str6, j3, str7, z2);
    }

    public final String component1() {
        return this.id;
    }

    public final String component2() {
        return this.name;
    }

    public final String component3() {
        return this.url;
    }

    public final long component4() {
        return this.updatedAt;
    }

    public final String component5() {
        return this.ua;
    }

    public final boolean component6() {
        return this.enabled;
    }

    public final SourceItem copy(String str, String str2, String str3, long j2, String str4, boolean z2) {
        b0.d.k(str, "id");
        b0.d.k(str2, "name");
        b0.d.k(str3, "url");
        b0.d.k(str4, "ua");
        return new SourceItem(str, str2, str3, j2, str4, z2);
    }

    public boolean equals(Object obj) {
        if (this == obj) {
            return true;
        }
        if (!(obj instanceof SourceItem)) {
            return false;
        }
        SourceItem sourceItem = (SourceItem) obj;
        return b0.d.b(this.id, sourceItem.id) && b0.d.b(this.name, sourceItem.name) && b0.d.b(this.url, sourceItem.url) && this.updatedAt == sourceItem.updatedAt && b0.d.b(this.ua, sourceItem.ua) && this.enabled == sourceItem.enabled;
    }

    public final boolean getEnabled() {
        return this.enabled;
    }

    public final String getId() {
        return this.id;
    }

    public final String getName() {
        return this.name;
    }

    public final String getUa() {
        return this.ua;
    }

    public final long getUpdatedAt() {
        return this.updatedAt;
    }

    public final String getUrl() {
        return this.url;
    }

    public int hashCode() {
        int hashCode = (this.url.hashCode() + ((this.name.hashCode() + (this.id.hashCode() * 31)) * 31)) * 31;
        long j2 = this.updatedAt;
        return ((this.ua.hashCode() + ((hashCode + ((int) (j2 ^ (j2 >>> 32)))) * 31)) * 31) + (this.enabled ? 1231 : 1237);
    }

    public final void setEnabled(boolean z2) {
        this.enabled = z2;
    }

    public final void setName(String str) {
        b0.d.k(str, "<set-?>");
        this.name = str;
    }

    public final void setUa(String str) {
        b0.d.k(str, "<set-?>");
        this.ua = str;
    }

    public final void setUpdatedAt(long j2) {
        this.updatedAt = j2;
    }

    public final void setUrl(String str) {
        b0.d.k(str, "<set-?>");
        this.url = str;
    }

    public String toString() {
        return "SourceItem(id=" + this.id + ", name=" + this.name + ", url=" + this.url + ", updatedAt=" + this.updatedAt + ", ua=" + this.ua + ", enabled=" + this.enabled + ')';
    }

    public /* synthetic */ SourceItem(String str, String str2, String str3, long j2, String str4, boolean z2, int i2, d0.a aVar) {
        this(str, str2, str3, (i2 & 8) != 0 ? 0L : j2, (i2 & 16) != 0 ? "" : str4, (i2 & 32) != 0 ? true : z2);
    }
}
