package tv.live;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashMap;
import java.util.Map;

/* loaded from: classes.dex */
public final class SourceMemory {
    public static final SourceMemory INSTANCE = new SourceMemory();
    private static final String KEY = "src_mem";
    private static final char SEP = 1;

    private SourceMemory() {
    }

    private final String keyOf(String str, String str2) {
        return str + SEP + str2;
    }

    private final HashMap<String, Integer> load(Context context) {
        String string = prefs(context).getString(KEY, null);
        HashMap<String, Integer> hashMap = new HashMap<>();
        if (string == null) {
            return hashMap;
        }
        if (string.length() == 0) {
            return hashMap;
        }
        for (String str : h0.h.b0(string, new char[]{'\n'})) {
            int U = h0.h.U(str, '=');
            if (U > 0) {
                String substring = str.substring(U + 1);
                b0.d.j(substring, "substring(...)");
                Integer L = h0.f.L(substring);
                if (L != null) {
                    Integer valueOf = Integer.valueOf(L.intValue());
                    String substring2 = str.substring(0, U);
                    b0.d.j(substring2, "substring(...)");
                    hashMap.put(substring2, valueOf);
                }
            }
        }
        return hashMap;
    }

    private final SharedPreferences prefs(Context context) {
        return context.getSharedPreferences("tv", 0);
    }

    private final void save(Context context, Map<String, Integer> map) {
        StringBuilder sb = new StringBuilder();
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            String key = entry.getKey();
            int intValue = entry.getValue().intValue();
            if (sb.length() > 0) {
                sb.append('\n');
            }
            sb.append(key);
            sb.append('=');
            sb.append(intValue);
        }
        prefs(context).edit().putString(KEY, sb.toString()).apply();
    }

    public final void clear(Context context) {
        b0.d.k(context, "ctx");
        prefs(context).edit().remove(KEY).apply();
    }

    public final Integer get(Context context, String str, String str2) {
        b0.d.k(context, "ctx");
        b0.d.k(str, "group");
        b0.d.k(str2, "name");
        return load(context).get(keyOf(str, str2));
    }

    public final void put(Context context, String str, String str2, int i2) {
        b0.d.k(context, "ctx");
        b0.d.k(str, "group");
        b0.d.k(str2, "name");
        if (i2 < 0) {
            return;
        }
        HashMap<String, Integer> load = load(context);
        String keyOf = keyOf(str, str2);
        Integer num = load.get(keyOf);
        if (num != null && num.intValue() == i2) {
            return;
        }
        load.put(keyOf, Integer.valueOf(i2));
        save(context, load);
    }
}
