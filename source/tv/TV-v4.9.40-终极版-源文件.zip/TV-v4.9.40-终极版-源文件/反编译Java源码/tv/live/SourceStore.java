package tv.live;

import android.content.Context;
import android.content.SharedPreferences;
import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class SourceStore {
    public static final String DEFAULT_SOURCE_ID = "default";
    public static final String DEFAULT_UA = "Mozilla/5.0 (Linux; Android) TV/1.0";
    public static final SourceStore INSTANCE = new SourceStore();
    private static List<SourceItem> cachedList;

    private SourceStore() {
    }

    private final SharedPreferences sp(Context context) {
        return context.getSharedPreferences("tv", 0);
    }

    public final File cacheFile(Context context) {
        b0.d.k(context, "ctx");
        return cacheFileFor(context, currentId(context));
    }

    public final File cacheFileFor(Context context, String str) {
        b0.d.k(context, "ctx");
        b0.d.k(str, "id");
        return new File(context.getFilesDir(), "channels_" + str + ".m3u");
    }

    public final String currentCustomUa(Context context) {
        String str;
        Object obj;
        String ua;
        b0.d.k(context, "ctx");
        Iterator<T> it = load(context).iterator();
        while (true) {
            str = null;
            if (!it.hasNext()) {
                obj = null;
                break;
            }
            obj = it.next();
            if (b0.d.b(((SourceItem) obj).getId(), INSTANCE.currentId(context))) {
                break;
            }
        }
        SourceItem sourceItem = (SourceItem) obj;
        if (sourceItem != null && (ua = sourceItem.getUa()) != null) {
            str = h0.h.j0(ua).toString();
        }
        return str == null ? "" : str;
    }

    public final String currentId(Context context) {
        b0.d.k(context, "ctx");
        String string = sp(context).getString("current_source_id", DEFAULT_SOURCE_ID);
        return string == null ? DEFAULT_SOURCE_ID : string;
    }

    public final String currentUa(Context context) {
        b0.d.k(context, "ctx");
        return uaFor(context, currentId(context));
    }

    public final String currentUrl(Context context) {
        Object obj;
        String url;
        b0.d.k(context, "ctx");
        Iterator<T> it = load(context).iterator();
        while (true) {
            if (!it.hasNext()) {
                obj = null;
                break;
            }
            obj = it.next();
            if (b0.d.b(((SourceItem) obj).getId(), INSTANCE.currentId(context))) {
                break;
            }
        }
        SourceItem sourceItem = (SourceItem) obj;
        return (sourceItem == null || (url = sourceItem.getUrl()) == null) ? MainActivity.DEFAULT_URL : url;
    }

    public final SourceItem defaultSource() {
        return new SourceItem(DEFAULT_SOURCE_ID, "默认源", MainActivity.DEFAULT_URL, 0L, null, false, 56, null);
    }

    public final List<SourceItem> enabledSources(Context context) {
        b0.d.k(context, "ctx");
        List<SourceItem> load = load(context);
        ArrayList arrayList = new ArrayList();
        for (Object obj : load) {
            if (((SourceItem) obj).getEnabled()) {
                arrayList.add(obj);
            }
        }
        if (!arrayList.isEmpty()) {
            return arrayList;
        }
        ArrayList arrayList2 = new ArrayList();
        for (Object obj2 : load) {
            if (b0.d.b(((SourceItem) obj2).getId(), INSTANCE.currentId(context))) {
                arrayList2.add(obj2);
            }
        }
        return arrayList2.isEmpty() ? u.i.R(load, 1) : arrayList2;
    }

    public final void invalidate() {
        cachedList = null;
    }

    public final List<SourceItem> load(Context context) {
        String str;
        boolean z2;
        Object obj;
        Object obj2;
        b0.d.k(context, "ctx");
        List<SourceItem> list = cachedList;
        if (list != null) {
            return list;
        }
        ArrayList arrayList = new ArrayList();
        String string = sp(context).getString("sources_json", null);
        boolean z3 = true;
        if (string == null || string.length() == 0) {
            arrayList.add(defaultSource());
            String string2 = sp(context).getString("source_url", null);
            if (!(string2 == null || string2.length() == 0) && !b0.d.b(string2, MainActivity.DEFAULT_URL)) {
                arrayList.add(new SourceItem("s_old", "我的源", string2, 0L, null, false, 56, null));
            }
        } else {
            try {
                JSONArray jSONArray = new JSONArray(string);
                int length = jSONArray.length();
                for (int i2 = 0; i2 < length; i2++) {
                    JSONObject jSONObject = jSONArray.getJSONObject(i2);
                    String optString = jSONObject.optString("id");
                    b0.d.j(optString, "optString(...)");
                    String optString2 = jSONObject.optString("name");
                    b0.d.j(optString2, "optString(...)");
                    String optString3 = jSONObject.optString("url");
                    b0.d.j(optString3, "optString(...)");
                    long optLong = jSONObject.optLong("updatedAt");
                    String optString4 = jSONObject.optString("ua");
                    b0.d.j(optString4, "optString(...)");
                    if (jSONObject.has("enabled")) {
                        z2 = jSONObject.optBoolean("enabled", true);
                        str = optString4;
                    } else {
                        str = optString4;
                        z2 = true;
                    }
                    arrayList.add(new SourceItem(optString, optString2, optString3, optLong, str, z2));
                }
            } catch (Exception unused) {
                arrayList.clear();
            }
        }
        if (!arrayList.isEmpty()) {
            Iterator it = arrayList.iterator();
            while (true) {
                if (!it.hasNext()) {
                    break;
                }
                if (b0.d.b(((SourceItem) it.next()).getId(), DEFAULT_SOURCE_ID)) {
                    z3 = false;
                    break;
                }
            }
        }
        if (z3) {
            arrayList.add(0, defaultSource());
        }
        Iterator it2 = arrayList.iterator();
        while (true) {
            if (!it2.hasNext()) {
                obj = null;
                break;
            }
            obj = it2.next();
            if (b0.d.b(((SourceItem) obj).getId(), DEFAULT_SOURCE_ID)) {
                break;
            }
        }
        SourceItem sourceItem = (SourceItem) obj;
        if (sourceItem != null && !b0.d.b(sourceItem.getUrl(), MainActivity.DEFAULT_URL)) {
            sourceItem.setUrl(MainActivity.DEFAULT_URL);
        }
        Iterator it3 = arrayList.iterator();
        while (true) {
            if (!it3.hasNext()) {
                obj2 = null;
                break;
            }
            Object next = it3.next();
            if (b0.d.b(((SourceItem) next).getId(), DEFAULT_SOURCE_ID)) {
                obj2 = next;
                break;
            }
        }
        SourceItem sourceItem2 = (SourceItem) obj2;
        if (sourceItem2 != null && !b0.d.b(sourceItem2.getUrl(), MainActivity.DEFAULT_URL)) {
            sourceItem2.setUrl(MainActivity.DEFAULT_URL);
        }
        cachedList = arrayList;
        return arrayList;
    }

    public final boolean multiEnabled(Context context) {
        b0.d.k(context, "ctx");
        return enabledSources(context).size() > 1;
    }

    public final String newId() {
        return "s" + System.currentTimeMillis();
    }

    public final void save(Context context, List<SourceItem> list) {
        b0.d.k(context, "ctx");
        b0.d.k(list, "list");
        JSONArray jSONArray = new JSONArray();
        for (SourceItem sourceItem : list) {
            jSONArray.put(new JSONObject().put("id", sourceItem.getId()).put("name", sourceItem.getName()).put("url", sourceItem.getUrl()).put("updatedAt", sourceItem.getUpdatedAt()).put("ua", sourceItem.getUa()).put("enabled", sourceItem.getEnabled()));
        }
        sp(context).edit().putString("sources_json", jSONArray.toString()).apply();
        cachedList = u.i.T(list);
    }

    public final void setCurrentId(Context context, String str) {
        b0.d.k(context, "ctx");
        b0.d.k(str, "id");
        sp(context).edit().putString("current_source_id", str).apply();
    }

    public final void setEnabled(Context context, String str, boolean z2) {
        Object obj;
        b0.d.k(context, "ctx");
        b0.d.k(str, "id");
        List<SourceItem> load = load(context);
        Iterator<T> it = load.iterator();
        while (true) {
            if (!it.hasNext()) {
                obj = null;
                break;
            } else {
                obj = it.next();
                if (b0.d.b(((SourceItem) obj).getId(), str)) {
                    break;
                }
            }
        }
        SourceItem sourceItem = (SourceItem) obj;
        if (sourceItem == null) {
            return;
        }
        if (!z2) {
            int i2 = 0;
            if (!load.isEmpty()) {
                Iterator<T> it2 = load.iterator();
                while (it2.hasNext()) {
                    if (((SourceItem) it2.next()).getEnabled() && (i2 = i2 + 1) < 0) {
                        throw new ArithmeticException("Count overflow has happened.");
                    }
                }
            }
            if (i2 <= 1) {
                return;
            }
        }
        sourceItem.setEnabled(z2);
        save(context, load);
    }

    public final String uaFor(Context context, String str) {
        String str2;
        Object obj;
        String ua;
        b0.d.k(context, "ctx");
        b0.d.k(str, "id");
        Iterator<T> it = load(context).iterator();
        while (true) {
            str2 = null;
            if (!it.hasNext()) {
                obj = null;
                break;
            }
            obj = it.next();
            if (b0.d.b(((SourceItem) obj).getId(), str)) {
                break;
            }
        }
        SourceItem sourceItem = (SourceItem) obj;
        if (sourceItem != null && (ua = sourceItem.getUa()) != null) {
            str2 = h0.h.j0(ua).toString();
        }
        if (str2 == null) {
            str2 = "";
        }
        return str2.length() == 0 ? DEFAULT_UA : str2;
    }
}
