package tv.live;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.nio.charset.Charset;
import java.util.List;

/* loaded from: classes.dex */
public final class StreamProxy {
    public static final StreamProxy INSTANCE = new StreamProxy();
    private static volatile int port;
    private static ServerSocket server;

    private StreamProxy() {
    }

    private final String absolute(String str, String str2) {
        try {
            if (!h0.h.d0(str2, "http://", false) && !h0.h.d0(str2, "https://", false)) {
                String url = new URL(new URL(str), str2).toString();
                b0.d.j(url, "toString(...)");
                return url;
            }
            return str2;
        } catch (Throwable unused) {
            return null;
        }
    }

    private final String enc(String str) {
        String encode = URLEncoder.encode(str, "UTF-8");
        b0.d.j(encode, "encode(...)");
        return encode;
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void ensureStarted$lambda$3$lambda$1(ServerSocket serverSocket) {
        b0.d.k(serverSocket, "$ss");
        while (true) {
            try {
                new Thread(new d(2, serverSocket.accept())).start();
            } catch (Throwable unused) {
                return;
            }
        }
    }

    /* JADX INFO: Access modifiers changed from: private */
    public static final void ensureStarted$lambda$3$lambda$1$lambda$0(Socket socket) {
        StreamProxy streamProxy = INSTANCE;
        b0.d.h(socket);
        streamProxy.handle(socket);
    }

    private final void fetchAndServe(String str, String str2, String str3, BufferedOutputStream bufferedOutputStream) {
        HttpURLConnection httpURLConnection;
        boolean z2;
        int responseCode;
        HttpURLConnection httpURLConnection2 = null;
        try {
            try {
                URLConnection openConnection = new URL(str).openConnection();
                b0.d.i(openConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
                httpURLConnection = (HttpURLConnection) openConnection;
                z2 = true;
                try {
                    httpURLConnection.setInstanceFollowRedirects(true);
                    httpURLConnection.setConnectTimeout(8000);
                    httpURLConnection.setReadTimeout(12000);
                    httpURLConnection.setRequestMethod("GET");
                    httpURLConnection.setRequestProperty("User-Agent", str2.length() == 0 ? SourceStore.DEFAULT_UA : str2);
                    httpURLConnection.setRequestProperty("Accept", "*/*");
                    if (str3 != null) {
                        httpURLConnection.setRequestProperty("Range", str3);
                    }
                    responseCode = httpURLConnection.getResponseCode();
                } catch (Throwable unused) {
                    httpURLConnection2 = httpURLConnection;
                    try {
                        writeEmpty(bufferedOutputStream, 502);
                    } catch (Throwable unused2) {
                    }
                    if (httpURLConnection2 != null) {
                        httpURLConnection2.disconnect();
                    }
                    return;
                }
            } catch (Throwable unused3) {
                return;
            }
        } catch (Throwable unused4) {
        }
        if (!(200 <= responseCode && responseCode < 300) && responseCode != 206) {
            writeEmpty(bufferedOutputStream, 502);
            try {
                httpURLConnection.disconnect();
                return;
            } catch (Throwable unused5) {
                return;
            }
        }
        String url = httpURLConnection.getURL().toString();
        b0.d.j(url, "toString(...)");
        String contentType = httpURLConnection.getContentType();
        if (contentType == null) {
            contentType = "";
        }
        if (!(h0.h.M(contentType, "mpegurl", true) || h0.h.M(contentType, "m3u", true) || h0.h.N(h0.h.i0(url, '?'), ".m3u8", true))) {
            StringBuilder sb = new StringBuilder("HTTP/1.1 ");
            sb.append(responseCode);
            sb.append(" OK\r\nContent-Type: ");
            if (contentType.length() != 0) {
                z2 = false;
            }
            if (z2) {
                contentType = "application/octet-stream";
            }
            sb.append(contentType);
            sb.append("\r\nConnection: close\r\n\r\n");
            byte[] bytes = sb.toString().getBytes(h0.a.f475b);
            b0.d.j(bytes, "getBytes(...)");
            bufferedOutputStream.write(bytes);
            byte[] bArr = new byte[16384];
            InputStream inputStream = httpURLConnection.getInputStream();
            while (true) {
                int read = inputStream.read(bArr);
                if (read <= 0) {
                    break;
                } else {
                    bufferedOutputStream.write(bArr, 0, read);
                }
            }
        } else {
            InputStream inputStream2 = httpURLConnection.getInputStream();
            b0.d.j(inputStream2, "getInputStream(...)");
            Charset charset = h0.a.f474a;
            Reader inputStreamReader = new InputStreamReader(inputStream2, charset);
            BufferedReader bufferedReader = inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192);
            try {
                String B = b0.d.B(bufferedReader);
                b0.d.l(bufferedReader, null);
                byte[] bytes2 = rewriteIndex(B, url, str2).getBytes(charset);
                b0.d.j(bytes2, "getBytes(...)");
                byte[] bytes3 = ("HTTP/1.1 200 OK\r\nContent-Type: application/vnd.apple.mpegurl\r\nContent-Length: " + bytes2.length + "\r\nConnection: close\r\n\r\n").getBytes(h0.a.f475b);
                b0.d.j(bytes3, "getBytes(...)");
                bufferedOutputStream.write(bytes3);
                bufferedOutputStream.write(bytes2);
            } finally {
            }
        }
        bufferedOutputStream.flush();
        httpURLConnection.disconnect();
    }

    private final void handle(Socket socket) {
        BufferedInputStream bufferedInputStream;
        BufferedOutputStream bufferedOutputStream;
        String readLine;
        try {
            socket.setSoTimeout(15000);
            bufferedInputStream = new BufferedInputStream(socket.getInputStream());
            bufferedOutputStream = new BufferedOutputStream(socket.getOutputStream());
            readLine = readLine(bufferedInputStream);
        } catch (Throwable unused) {
        }
        if (readLine == null) {
            try {
                socket.close();
                return;
            } catch (Throwable unused2) {
                return;
            }
        }
        String str = null;
        while (true) {
            String readLine2 = readLine(bufferedInputStream);
            if (readLine2 == null) {
                break;
            }
            if (readLine2.length() == 0) {
                break;
            } else if (h0.h.d0(readLine2, "Range:", true)) {
                str = h0.h.j0(h0.h.f0(readLine2, ':', readLine2)).toString();
            }
        }
        List b02 = h0.h.b0(readLine, new char[]{' '});
        if (b02.size() < 2) {
            try {
                socket.close();
                return;
            } catch (Throwable unused3) {
                return;
            }
        }
        String f02 = h0.h.f0((String) b02.get(1), '?', "");
        String param = param(f02, "ua");
        String param2 = param(f02, "u");
        if (param2.length() == 0) {
            writeEmpty(bufferedOutputStream, 400);
            try {
                socket.close();
            } catch (Throwable unused4) {
            }
        } else {
            fetchAndServe(param2, param, str, bufferedOutputStream);
            try {
                socket.close();
            } catch (Throwable unused5) {
            }
        }
    }

    private final String param(String str, String str2) {
        for (String str3 : h0.h.b0(str, new char[]{'&'})) {
            if (b0.d.b(h0.h.i0(str3, '='), str2)) {
                try {
                    String decode = URLDecoder.decode(h0.h.f0(str3, '=', ""), "UTF-8");
                    b0.d.h(decode);
                    return decode;
                } catch (Throwable unused) {
                    return "";
                }
            }
        }
        return "";
    }

    private final String readLine(InputStream inputStream) {
        int read;
        StringBuilder sb = new StringBuilder();
        while (true) {
            read = inputStream.read();
            if (read == -1 || read == 10) {
                break;
            }
            if (read != 13) {
                sb.append((char) read);
            }
        }
        if (read == -1) {
            if (sb.length() == 0) {
                return null;
            }
        }
        return sb.toString();
    }

    /*  JADX ERROR: JadxOverflowException in pass: LoopRegionVisitor
        jadx.core.utils.exceptions.JadxOverflowException: LoopRegionVisitor.assignOnlyInLoop endless recursion
        	at jadx.core.utils.ErrorsCounter.addError(ErrorsCounter.java:59)
        	at jadx.core.utils.ErrorsCounter.error(ErrorsCounter.java:31)
        	at jadx.core.dex.attributes.nodes.NotificationAttrNode.addError(NotificationAttrNode.java:19)
        */
    private final java.lang.String rewriteAttrs(java.lang.String r10, java.lang.String r11, java.lang.String r12) {
        /*
            r9 = this;
            r0 = 6
            java.lang.String r1 = "URI=\""
            r2 = 0
            int r0 = h0.h.R(r10, r1, r2, r2, r0)
        L8:
            if (r0 < 0) goto L4d
            int r0 = r0 + 5
            r3 = 34
            r4 = 4
            int r3 = h0.h.Q(r10, r3, r0, r4)
            if (r3 < 0) goto L4d
            java.lang.String r5 = r10.substring(r0, r3)
            java.lang.String r6 = "substring(...)"
            b0.d.j(r5, r6)
            java.lang.String r5 = r9.absolute(r11, r5)
            if (r5 == 0) goto L48
            java.lang.StringBuilder r7 = new java.lang.StringBuilder
            r7.<init>()
            java.lang.String r8 = r10.substring(r2, r0)
            b0.d.j(r8, r6)
            r7.append(r8)
            java.lang.String r5 = r9.localUrl(r5, r12)
            r7.append(r5)
            java.lang.String r10 = r10.substring(r3)
            b0.d.j(r10, r6)
            r7.append(r10)
            java.lang.String r10 = r7.toString()
        L48:
            int r0 = h0.h.R(r10, r1, r0, r2, r4)
            goto L8
        L4d:
            return r10
        */
        throw new UnsupportedOperationException("Method not decompiled: tv.live.StreamProxy.rewriteAttrs(java.lang.String, java.lang.String, java.lang.String):java.lang.String");
    }

    private final String rewriteIndex(String str, String str2, String str3) {
        StringBuilder sb = new StringBuilder(str.length() + 256);
        h0.c V = h0.h.V(str, new String[]{"\r\n", "\n", "\r"}, false, 0);
        u.a aVar = new u.a(1, str);
        h0.b bVar = new h0.b(V);
        while (bVar.hasNext()) {
            String str4 = (String) aVar.invoke(bVar.next());
            String obj = h0.h.j0(str4).toString();
            if (!(obj.length() == 0)) {
                if (h0.h.d0(obj, "#", false)) {
                    str4 = INSTANCE.rewriteAttrs(str4, str2, str3);
                } else {
                    StreamProxy streamProxy = INSTANCE;
                    String absolute = streamProxy.absolute(str2, obj);
                    if (absolute != null) {
                        obj = streamProxy.localUrl(absolute, str3);
                    }
                    sb.append(obj);
                    sb.append('\n');
                }
            }
            sb.append(str4);
            sb.append('\n');
        }
        String sb2 = sb.toString();
        b0.d.j(sb2, "toString(...)");
        return sb2;
    }

    private final void writeEmpty(OutputStream outputStream, int i2) {
        byte[] bytes = ("HTTP/1.1 " + i2 + " ERR\r\nContent-Length: 0\r\nConnection: close\r\n\r\n").getBytes(h0.a.f475b);
        b0.d.j(bytes, "getBytes(...)");
        outputStream.write(bytes);
        outputStream.flush();
    }

    public final int ensureStarted() {
        if (port > 0) {
            return port;
        }
        synchronized (this) {
            if (port > 0) {
                return port;
            }
            int i2 = 0;
            try {
                ServerSocket serverSocket = new ServerSocket(0, 50, InetAddress.getByName("127.0.0.1"));
                server = serverSocket;
                port = serverSocket.getLocalPort();
                Thread thread = new Thread(new d(3, serverSocket));
                thread.setDaemon(true);
                thread.setName("tv-proxy");
                thread.start();
                i2 = port;
            } catch (Throwable unused) {
            }
            return i2;
        }
    }

    public final int getPort() {
        return port;
    }

    public final String localUrl(String str, String str2) {
        b0.d.k(str, "raw");
        b0.d.k(str2, "ua");
        int ensureStarted = ensureStarted();
        if (ensureStarted <= 0) {
            return str;
        }
        return "http://127.0.0.1:" + ensureStarted + "/p?ua=" + enc(str2) + "&u=" + enc(str);
    }
}
