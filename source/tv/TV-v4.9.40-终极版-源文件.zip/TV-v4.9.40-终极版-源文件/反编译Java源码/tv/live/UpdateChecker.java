package tv.live;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import androidx.core.content.FileProvider;
import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;

/* loaded from: classes.dex */
public final class UpdateChecker {
    public static final UpdateChecker INSTANCE = new UpdateChecker();
    private static final List<String> FEEDS = b0.d.z("https://raw.githubusercontent.com/ipiptv/iptv-update/main/update/tv-live/version.json", "https://gh-proxy.com/raw.githubusercontent.com/ipiptv/iptv-update/main/update/tv-live/version.json", "https://cdn.jsdelivr.net/gh/ipiptv/iptv-update@main/update/tv-live/version.json");

    public static final class Remote {
        private final String apkUrl;
        private final boolean force;
        private final String note;
        private final int versionCode;
        private final String versionName;

        public Remote(int i2, String str, String str2, String str3, boolean z2) {
            b0.d.k(str, "versionName");
            b0.d.k(str2, "apkUrl");
            b0.d.k(str3, "note");
            this.versionCode = i2;
            this.versionName = str;
            this.apkUrl = str2;
            this.note = str3;
            this.force = z2;
        }

        public static /* synthetic */ Remote copy$default(Remote remote, int i2, String str, String str2, String str3, boolean z2, int i3, Object obj) {
            if ((i3 & 1) != 0) {
                i2 = remote.versionCode;
            }
            if ((i3 & 2) != 0) {
                str = remote.versionName;
            }
            String str4 = str;
            if ((i3 & 4) != 0) {
                str2 = remote.apkUrl;
            }
            String str5 = str2;
            if ((i3 & 8) != 0) {
                str3 = remote.note;
            }
            String str6 = str3;
            if ((i3 & 16) != 0) {
                z2 = remote.force;
            }
            return remote.copy(i2, str4, str5, str6, z2);
        }

        public final int component1() {
            return this.versionCode;
        }

        public final String component2() {
            return this.versionName;
        }

        public final String component3() {
            return this.apkUrl;
        }

        public final String component4() {
            return this.note;
        }

        public final boolean component5() {
            return this.force;
        }

        public final Remote copy(int i2, String str, String str2, String str3, boolean z2) {
            b0.d.k(str, "versionName");
            b0.d.k(str2, "apkUrl");
            b0.d.k(str3, "note");
            return new Remote(i2, str, str2, str3, z2);
        }

        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (!(obj instanceof Remote)) {
                return false;
            }
            Remote remote = (Remote) obj;
            return this.versionCode == remote.versionCode && b0.d.b(this.versionName, remote.versionName) && b0.d.b(this.apkUrl, remote.apkUrl) && b0.d.b(this.note, remote.note) && this.force == remote.force;
        }

        public final String getApkUrl() {
            return this.apkUrl;
        }

        public final boolean getForce() {
            return this.force;
        }

        public final String getNote() {
            return this.note;
        }

        public final int getVersionCode() {
            return this.versionCode;
        }

        public final String getVersionName() {
            return this.versionName;
        }

        public int hashCode() {
            return ((this.note.hashCode() + ((this.apkUrl.hashCode() + ((this.versionName.hashCode() + (this.versionCode * 31)) * 31)) * 31)) * 31) + (this.force ? 1231 : 1237);
        }

        public String toString() {
            return "Remote(versionCode=" + this.versionCode + ", versionName=" + this.versionName + ", apkUrl=" + this.apkUrl + ", note=" + this.note + ", force=" + this.force + ')';
        }
    }

    private UpdateChecker() {
    }

    public static /* synthetic */ boolean checkAndInstall$default(UpdateChecker updateChecker, Context context, String str, c0.b bVar, c0.d dVar, int i2, Object obj) {
        if ((i2 & 8) != 0) {
            dVar = null;
        }
        return updateChecker.checkAndInstall(context, str, bVar, dVar);
    }

    private final void install(Context context, File file) {
        Uri fromFile;
        if (Build.VERSION.SDK_INT >= 24) {
            b.c b2 = FileProvider.b(context, "tv.live.fileprovider");
            try {
                String canonicalPath = file.getCanonicalPath();
                Map.Entry entry = null;
                for (Map.Entry entry2 : b2.f374b.entrySet()) {
                    String path = ((File) entry2.getValue()).getPath();
                    if (canonicalPath.startsWith(path) && (entry == null || path.length() > ((File) entry.getValue()).getPath().length())) {
                        entry = entry2;
                    }
                }
                if (entry == null) {
                    throw new IllegalArgumentException("Failed to find configured root that contains " + canonicalPath);
                }
                String path2 = ((File) entry.getValue()).getPath();
                boolean endsWith = path2.endsWith("/");
                int length = path2.length();
                if (!endsWith) {
                    length++;
                }
                fromFile = new Uri.Builder().scheme("content").authority(b2.f373a).encodedPath(Uri.encode((String) entry.getKey()) + '/' + Uri.encode(canonicalPath.substring(length), "/")).build();
                b0.d.h(fromFile);
            } catch (IOException unused) {
                throw new IllegalArgumentException("Failed to resolve canonical path for " + file);
            }
        } else {
            fromFile = Uri.fromFile(file);
            b0.d.j(fromFile, "fromFile(...)");
        }
        Intent intent = new Intent("android.intent.action.VIEW");
        intent.setDataAndType(fromFile, "application/vnd.android.package-archive");
        intent.addFlags(268435456);
        intent.addFlags(1);
        context.startActivity(intent);
    }

    /* JADX WARN: Removed duplicated region for block: B:54:0x0192  */
    /*
        Code decompiled incorrectly, please refer to instructions dump.
        To view partially-correct add '--show-bad-code' argument
    */
    public final boolean checkAndInstall(android.content.Context r18, java.lang.String r19, c0.b r20, c0.d r21) {
        /*
            Method dump skipped, instructions count: 420
            To view this dump add '--comments-level debug' option
        */
        throw new UnsupportedOperationException("Method not decompiled: tv.live.UpdateChecker.checkAndInstall(android.content.Context, java.lang.String, c0.b, c0.d):boolean");
    }

    public final int currentVersionCode(Context context) {
        long longVersionCode;
        b0.d.k(context, "ctx");
        PackageManager packageManager = context.getPackageManager();
        int i2 = Build.VERSION.SDK_INT;
        PackageInfo packageInfo = packageManager.getPackageInfo(context.getPackageName(), 0);
        if (i2 < 28) {
            return packageInfo.versionCode;
        }
        longVersionCode = packageInfo.getLongVersionCode();
        return (int) longVersionCode;
    }

    public final Remote fetchRemote() {
        Iterator<String> it = FEEDS.iterator();
        Remote remote = null;
        while (it.hasNext()) {
            try {
                URLConnection openConnection = new URL(it.next()).openConnection();
                b0.d.i(openConnection, "null cannot be cast to non-null type java.net.HttpURLConnection");
                HttpURLConnection httpURLConnection = (HttpURLConnection) openConnection;
                httpURLConnection.setConnectTimeout(5000);
                httpURLConnection.setReadTimeout(5000);
                httpURLConnection.setRequestMethod("GET");
                httpURLConnection.setRequestProperty("User-Agent", "TV/1.0");
                boolean z2 = true;
                httpURLConnection.setInstanceFollowRedirects(true);
                InputStream inputStream = httpURLConnection.getInputStream();
                b0.d.j(inputStream, "getInputStream(...)");
                Reader inputStreamReader = new InputStreamReader(inputStream, h0.a.f474a);
                BufferedReader bufferedReader = inputStreamReader instanceof BufferedReader ? (BufferedReader) inputStreamReader : new BufferedReader(inputStreamReader, 8192);
                try {
                    String B = b0.d.B(bufferedReader);
                    b0.d.l(bufferedReader, null);
                    httpURLConnection.disconnect();
                    JSONObject jSONObject = new JSONObject(B);
                    int optInt = jSONObject.optInt("versionCode", jSONObject.optInt("latestVersionCode", 0));
                    String optString = jSONObject.optString("versionName", jSONObject.optString("latestVersionName", ""));
                    String optString2 = jSONObject.optString("apkUrl", "");
                    if (optInt > 0) {
                        b0.d.h(optString2);
                        if (optString2.length() != 0) {
                            z2 = false;
                        }
                        if (!z2) {
                            b0.d.h(optString);
                            String optString3 = jSONObject.optString("note", jSONObject.optString("updateLog", ""));
                            b0.d.j(optString3, "optString(...)");
                            Remote remote2 = new Remote(optInt, optString, optString2, optString3, jSONObject.optBoolean("isForce", false));
                            if (remote == null || remote2.getVersionCode() > remote.getVersionCode()) {
                                remote = remote2;
                            }
                        }
                    }
                } finally {
                }
            } catch (Throwable unused) {
            }
        }
        return remote;
    }

    public final boolean installLocalFile(Context context, File file, c0.b bVar) {
        b0.d.k(context, "ctx");
        b0.d.k(file, "apk");
        b0.d.k(bVar, "onStatus");
        try {
            if (file.exists() && file.length() > 0) {
                PackageInfo packageArchiveInfo = context.getPackageManager().getPackageArchiveInfo(file.getAbsolutePath(), 0);
                if (packageArchiveInfo != null && b0.d.b(packageArchiveInfo.packageName, context.getPackageName())) {
                    if (Build.VERSION.SDK_INT >= 28) {
                        packageArchiveInfo.getLongVersionCode();
                    }
                    String str = packageArchiveInfo.versionName;
                    if (str == null) {
                        str = "?";
                    }
                    bVar.invoke("已收到 " + file.getName() + "（v" + str + "），正在打开安装器");
                    install(context, file);
                    return true;
                }
                bVar.invoke("安装包无效（不是本应用的安装包）");
                file.delete();
                return false;
            }
            bVar.invoke("安装包为空");
            return false;
        } catch (Throwable th) {
            String message = th.getMessage();
            if (message == null) {
                message = th.getClass().getSimpleName();
            }
            bVar.invoke("安装失败：".concat(message));
            return false;
        }
    }
}
