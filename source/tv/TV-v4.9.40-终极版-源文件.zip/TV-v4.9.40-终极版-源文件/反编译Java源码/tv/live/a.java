package tv.live;

import tv.live.ChannelAdapter;
import tv.live.GroupAdapter;

/* loaded from: classes.dex */
public final /* synthetic */ class a implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f556a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f557b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f558c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f559d;

    public /* synthetic */ a(Object obj, Object obj2, Object obj3, int i2) {
        this.f556a = i2;
        this.f557b = obj;
        this.f558c = obj2;
        this.f559d = obj3;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i2 = this.f556a;
        Object obj = this.f559d;
        Object obj2 = this.f558c;
        Object obj3 = this.f557b;
        switch (i2) {
            case 0:
                ChannelAdapter.onBindViewHolder$lambda$0((ChannelAdapter.VH) obj3, (ChannelAdapter) obj2, (Channel) obj);
                break;
            case 1:
                GroupAdapter.onBindViewHolder$lambda$0((GroupAdapter.VH) obj3, (GroupAdapter) obj2, (String) obj);
                break;
            case ManageType.GROUP /* 2 */:
                MainActivity.switchToSource$lambda$57((MainActivity) obj3, (String) obj2, (String) obj);
                break;
            default:
                MainActivity.refreshSourceById$lambda$86((SourceItem) obj3, (MainActivity) obj2, (String) obj);
                break;
        }
    }
}
