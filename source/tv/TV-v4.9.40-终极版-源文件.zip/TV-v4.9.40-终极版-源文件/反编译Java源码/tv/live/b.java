package tv.live;

import android.view.View;
import androidx.recyclerview.widget.i0;

/* loaded from: classes.dex */
public final /* synthetic */ class b implements View.OnClickListener {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f560a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ int f561b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ i0 f562c;

    public /* synthetic */ b(i0 i0Var, int i2, int i3) {
        this.f560a = i3;
        this.f562c = i0Var;
        this.f561b = i2;
    }

    @Override // android.view.View.OnClickListener
    public final void onClick(View view) {
        int i2 = this.f560a;
        int i3 = this.f561b;
        i0 i0Var = this.f562c;
        switch (i2) {
            case 0:
                ChannelAdapter.onBindViewHolder$lambda$2((ChannelAdapter) i0Var, i3, view);
                break;
            case 1:
                EpgAdapter.onBindViewHolder$lambda$0((EpgAdapter) i0Var, i3, view);
                break;
            case ManageType.GROUP /* 2 */:
                GroupAdapter.onBindViewHolder$lambda$1((GroupAdapter) i0Var, i3, view);
                break;
            default:
                ManageAdapter.onBindViewHolder$lambda$0((ManageAdapter) i0Var, i3, view);
                break;
        }
    }
}
