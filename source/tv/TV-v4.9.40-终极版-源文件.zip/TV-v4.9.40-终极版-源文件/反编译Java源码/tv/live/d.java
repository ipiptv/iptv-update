package tv.live;

import java.net.ServerSocket;
import java.net.Socket;

/* loaded from: classes.dex */
public final /* synthetic */ class d implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f565a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f566b;

    public /* synthetic */ d(int i2, Object obj) {
        this.f565a = i2;
        this.f566b = obj;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i2 = this.f565a;
        Object obj = this.f566b;
        switch (i2) {
            case 0:
                ConfigServer.start$lambda$0((ConfigServer) obj);
                break;
            case 1:
                EpgRepository.load$lambda$8$lambda$7((c0.a) obj);
                break;
            case ManageType.GROUP /* 2 */:
                StreamProxy.ensureStarted$lambda$3$lambda$1$lambda$0((Socket) obj);
                break;
            default:
                StreamProxy.ensureStarted$lambda$3$lambda$1((ServerSocket) obj);
                break;
        }
    }
}
