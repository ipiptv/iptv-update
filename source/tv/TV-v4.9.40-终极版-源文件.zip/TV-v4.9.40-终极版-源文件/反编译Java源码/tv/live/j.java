package tv.live;

import tv.live.UpdateChecker;

/* loaded from: classes.dex */
public final /* synthetic */ class j implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f581a = 1;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ MainActivity f582b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ UpdateChecker.Remote f583c;

    public /* synthetic */ j(MainActivity mainActivity, UpdateChecker.Remote remote) {
        this.f582b = mainActivity;
        this.f583c = remote;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i2 = this.f581a;
        MainActivity mainActivity = this.f582b;
        UpdateChecker.Remote remote = this.f583c;
        switch (i2) {
            case 0:
                MainActivity.startUpdateCheck$lambda$22$lambda$21(remote, mainActivity);
                break;
            default:
                MainActivity.downloadAndInstall$lambda$25(mainActivity, remote);
                break;
        }
    }

    public /* synthetic */ j(UpdateChecker.Remote remote, MainActivity mainActivity) {
        this.f583c = remote;
        this.f582b = mainActivity;
    }
}
