package tv.live;

import java.util.ArrayList;
import java.util.List;

/* loaded from: classes.dex */
public final /* synthetic */ class l implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f585a = 1;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ List f586b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ MainActivity f587c;

    public /* synthetic */ l(List list, MainActivity mainActivity) {
        this.f586b = list;
        this.f587c = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i2 = this.f585a;
        List list = this.f586b;
        MainActivity mainActivity = this.f587c;
        switch (i2) {
            case 0:
                MainActivity.silentUpdateNow$lambda$15$lambda$14(mainActivity, list);
                break;
            default:
                MainActivity.silentUpdateNow$lambda$15(list, mainActivity);
                break;
        }
    }

    public /* synthetic */ l(MainActivity mainActivity, ArrayList arrayList) {
        this.f587c = mainActivity;
        this.f586b = arrayList;
    }
}
