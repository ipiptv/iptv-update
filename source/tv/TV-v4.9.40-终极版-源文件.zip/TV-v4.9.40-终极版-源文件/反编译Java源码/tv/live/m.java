package tv.live;

import java.util.List;

/* loaded from: classes.dex */
public final /* synthetic */ class m implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f588a = 1;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f589b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ MainActivity f590c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f591d;

    /* renamed from: e, reason: collision with root package name */
    public final /* synthetic */ Object f592e;

    public /* synthetic */ m(List list, MainActivity mainActivity, String str, String str2) {
        this.f589b = list;
        this.f590c = mainActivity;
        this.f591d = str;
        this.f592e = str2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        Object obj = this.f592e;
        int i2 = this.f588a;
        MainActivity mainActivity = this.f590c;
        Object obj2 = this.f589b;
        Object obj3 = this.f591d;
        switch (i2) {
            case 0:
                MainActivity.switchToSource$lambda$57$lambda$56(mainActivity, (String) obj3, (List) obj2, (String) obj);
                break;
            case 1:
                MainActivity.refreshFromNetwork$lambda$54((List) obj2, mainActivity, (String) obj3, (String) obj);
                break;
            default:
                MainActivity.probeFastest$lambda$59(mainActivity, (Channel) obj3, (Integer) obj, (c0.b) obj2);
                break;
        }
    }

    public /* synthetic */ m(MainActivity mainActivity, String str, List list, String str2) {
        this.f590c = mainActivity;
        this.f591d = str;
        this.f589b = list;
        this.f592e = str2;
    }

    public /* synthetic */ m(MainActivity mainActivity, Channel channel, Integer num, c0.b bVar) {
        this.f590c = mainActivity;
        this.f591d = channel;
        this.f592e = num;
        this.f589b = bVar;
    }
}
