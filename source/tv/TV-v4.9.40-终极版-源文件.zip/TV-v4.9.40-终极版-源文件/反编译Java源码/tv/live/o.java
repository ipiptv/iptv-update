package tv.live;

import android.content.Context;
import java.io.File;
import tv.live.ChannelAdapter;

/* loaded from: classes.dex */
public final /* synthetic */ class o implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f598a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f599b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ Object f600c;

    public /* synthetic */ o(Object obj, Object obj2, int i2) {
        this.f598a = i2;
        this.f599b = obj;
        this.f600c = obj2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i2 = this.f598a;
        Object obj = this.f600c;
        Object obj2 = this.f599b;
        switch (i2) {
            case 0:
                MainActivity$downloadAndInstall$1$1.invoke$lambda$0((MainActivity) obj2, (String) obj);
                break;
            case 1:
                MainActivity$showConfig$3.invoke$lambda$0((MainActivity) obj2, (File) obj);
                break;
            case ManageType.GROUP /* 2 */:
                ChannelAdapter.onBindViewHolder$lambda$1((ChannelAdapter.VH) obj2, (String) obj);
                break;
            case ManageType.NAV /* 3 */:
                EpgRepository.load$lambda$8((Context) obj2, (c0.a) obj);
                break;
            default:
                MainActivity.downloadAndInstall$lambda$25$lambda$24((MainActivity) obj2, (Throwable) obj);
                break;
        }
    }
}
