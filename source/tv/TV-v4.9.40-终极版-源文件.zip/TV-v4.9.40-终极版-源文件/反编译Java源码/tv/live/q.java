package tv.live;

/* loaded from: classes.dex */
public final /* synthetic */ class q implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f605a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f606b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ int f607c;

    public /* synthetic */ q(int i2, int i3, Object obj) {
        this.f605a = i3;
        this.f606b = obj;
        this.f607c = i2;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i2 = this.f605a;
        int i3 = this.f607c;
        Object obj = this.f606b;
        switch (i2) {
            case 0:
                MainActivity$probeFastest$pick$1.invoke$lambda$1$lambda$0((c0.b) obj, i3);
                break;
            case 1:
                MainActivity.probeFastest$lambda$60((c0.b) obj, i3);
                break;
            default:
                MainActivity.centerEpgOn$lambda$89((MainActivity) obj, i3);
                break;
        }
    }
}
