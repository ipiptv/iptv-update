package tv.live;

/* loaded from: classes.dex */
public final /* synthetic */ class t implements Runnable {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f613a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ MainActivity f614b;

    public /* synthetic */ t(MainActivity mainActivity, int i2) {
        this.f613a = i2;
        this.f614b = mainActivity;
    }

    @Override // java.lang.Runnable
    public final void run() {
        int i2 = this.f613a;
        MainActivity mainActivity = this.f614b;
        switch (i2) {
            case 0:
                MainActivity$showConfig$2.invoke$lambda$0(mainActivity);
                break;
            case 1:
                MainActivity.centerLongPressRunnable$lambda$1(mainActivity);
                break;
            case ManageType.GROUP /* 2 */:
                MainActivity.backResetRunnable$lambda$93(mainActivity);
                break;
            case ManageType.NAV /* 3 */:
                MainActivity.bottomBarHide$lambda$2(mainActivity);
                break;
            case ManageType.INFO /* 4 */:
                MainActivity.timeoutRunnable$lambda$3(mainActivity);
                break;
            case MainActivity.TIMEOUT_DEFAULT_SEC /* 5 */:
                MainActivity.loadingRunnable$lambda$4(mainActivity);
                break;
            case 6:
                MainActivity.settingsHideRunnable$lambda$5(mainActivity);
                break;
            case 7:
                MainActivity.hideRunnable$lambda$6(mainActivity);
                break;
            case 8:
                MainActivity.numCommitRunnable$lambda$7(mainActivity);
                break;
            case 9:
                MainActivity.listWatchdog$lambda$8(mainActivity);
                break;
            case 10:
                MainActivity.listParseRunnable$lambda$11(mainActivity);
                break;
            case 11:
                MainActivity.dlHide$lambda$26(mainActivity);
                break;
            case 12:
                MainActivity.startVideo$lambda$66$lambda$65$lambda$64(mainActivity);
                break;
            case 13:
                MainActivity.startUpdateCheck$lambda$22(mainActivity);
                break;
            case 14:
                MainActivity.listParseRunnable$lambda$11$lambda$10(mainActivity);
                break;
            case 15:
                MainActivity.reloadMergedFromCache$lambda$41(mainActivity);
                break;
            case 16:
                MainActivity.listParseRunnable$lambda$11$lambda$10$lambda$9(mainActivity);
                break;
            case 17:
                MainActivity.onResume$lambda$92(mainActivity);
                break;
            case 18:
                MainActivity.scheduleSilentUpdate$lambda$12(mainActivity);
                break;
            case 19:
                MainActivity.reloadMergedFromCache$lambda$41$lambda$40(mainActivity);
                break;
            default:
                MainActivity.startEpgDelayed$lambda$91(mainActivity);
                break;
        }
    }
}
