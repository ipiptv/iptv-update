package u;

/* loaded from: classes.dex */
public final class a extends d0.c implements c0.b {

    /* renamed from: a, reason: collision with root package name */
    public final /* synthetic */ int f615a;

    /* renamed from: b, reason: collision with root package name */
    public final /* synthetic */ Object f616b;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public /* synthetic */ a(int i2, Object obj) {
        super(1);
        this.f615a = i2;
        this.f616b = obj;
    }

    @Override // c0.b
    public final Object invoke(Object obj) {
        int i2 = this.f615a;
        Object obj2 = this.f616b;
        switch (i2) {
            case 0:
                return obj == ((b) obj2) ? "(this Collection)" : String.valueOf(obj);
            default:
                f0.c cVar = (f0.c) obj;
                b0.d.k(cVar, "it");
                return h0.h.e0((CharSequence) obj2, cVar);
        }
    }
}
