package u;

import g.z;
import java.util.ListIterator;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public final class c extends z implements ListIterator {

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ e f617d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public c(e eVar, int i2) {
        super(1, eVar);
        this.f617d = eVar;
        int a2 = eVar.a();
        if (i2 >= 0 && i2 <= a2) {
            this.f459b = i2;
            return;
        }
        throw new IndexOutOfBoundsException("index: " + i2 + ", size: " + a2);
    }

    @Override // java.util.ListIterator
    public final void add(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }

    @Override // java.util.ListIterator
    public final boolean hasPrevious() {
        return this.f459b > 0;
    }

    @Override // java.util.ListIterator
    public final int nextIndex() {
        return this.f459b;
    }

    @Override // java.util.ListIterator
    public final Object previous() {
        if (!hasPrevious()) {
            throw new NoSuchElementException();
        }
        int i2 = this.f459b - 1;
        this.f459b = i2;
        return this.f617d.get(i2);
    }

    @Override // java.util.ListIterator
    public final int previousIndex() {
        return this.f459b - 1;
    }

    @Override // java.util.ListIterator
    public final void set(Object obj) {
        throw new UnsupportedOperationException("Operation is not supported for read-only collection");
    }
}
