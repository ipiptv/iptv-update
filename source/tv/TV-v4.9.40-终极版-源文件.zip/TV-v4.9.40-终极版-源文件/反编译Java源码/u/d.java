package u;

import java.util.RandomAccess;

/* loaded from: classes.dex */
public final class d extends e implements RandomAccess {

    /* renamed from: a, reason: collision with root package name */
    public final e f618a;

    /* renamed from: b, reason: collision with root package name */
    public final int f619b;

    /* renamed from: c, reason: collision with root package name */
    public final int f620c;

    public d(e eVar, int i2, int i3) {
        b0.d.k(eVar, "list");
        this.f618a = eVar;
        this.f619b = i2;
        int a2 = eVar.a();
        if (i2 < 0 || i3 > a2) {
            throw new IndexOutOfBoundsException("fromIndex: " + i2 + ", toIndex: " + i3 + ", size: " + a2);
        }
        if (i2 <= i3) {
            this.f620c = i3 - i2;
            return;
        }
        throw new IllegalArgumentException("fromIndex: " + i2 + " > toIndex: " + i3);
    }

    @Override // u.b
    public final int a() {
        return this.f620c;
    }

    @Override // java.util.List
    public final Object get(int i2) {
        int i3 = this.f620c;
        if (i2 >= 0 && i2 < i3) {
            return this.f618a.get(this.f619b + i2);
        }
        throw new IndexOutOfBoundsException("index: " + i2 + ", size: " + i3);
    }
}
