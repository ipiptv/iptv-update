package u;

/* loaded from: classes.dex */
public abstract class g extends b0.c {
}
