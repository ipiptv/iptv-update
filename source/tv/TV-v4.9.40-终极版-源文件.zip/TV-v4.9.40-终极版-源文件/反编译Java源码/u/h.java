package u;

/* loaded from: classes.dex */
public abstract class h extends g {
}
