package u;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;

/* loaded from: classes.dex */
public abstract class i extends h {
    public static final Object P(List list, int i2) {
        b0.d.k(list, "<this>");
        if (i2 < 0 || i2 > b0.d.x(list)) {
            return null;
        }
        return list.get(i2);
    }

    public static String Q(Iterable iterable, String str, String str2, String str3, c0.b bVar, int i2) {
        CharSequence charSequence;
        if ((i2 & 1) != 0) {
            str = ", ";
        }
        if ((i2 & 2) != 0) {
            str2 = "";
        }
        if ((i2 & 4) != 0) {
            str3 = "";
        }
        int i3 = 0;
        int i4 = (i2 & 8) != 0 ? -1 : 0;
        String str4 = (i2 & 16) != 0 ? "..." : null;
        if ((i2 & 32) != 0) {
            bVar = null;
        }
        b0.d.k(iterable, "<this>");
        b0.d.k(str2, "prefix");
        b0.d.k(str3, "postfix");
        b0.d.k(str4, "truncated");
        StringBuilder sb = new StringBuilder();
        sb.append((CharSequence) str2);
        Iterator it = iterable.iterator();
        while (it.hasNext()) {
            Object next = it.next();
            i3++;
            if (i3 > 1) {
                sb.append((CharSequence) str);
            }
            if (i4 >= 0 && i3 > i4) {
                break;
            }
            if (bVar != null) {
                next = bVar.invoke(next);
            } else {
                if (!(next != null ? next instanceof CharSequence : true)) {
                    if (next instanceof Character) {
                        sb.append(((Character) next).charValue());
                    } else {
                        charSequence = String.valueOf(next);
                        sb.append(charSequence);
                    }
                }
            }
            charSequence = (CharSequence) next;
            sb.append(charSequence);
        }
        if (i4 >= 0 && i3 > i4) {
            sb.append((CharSequence) str4);
        }
        sb.append((CharSequence) str3);
        String sb2 = sb.toString();
        b0.d.j(sb2, "toString(...)");
        return sb2;
    }

    public static final List R(Iterable iterable, int i2) {
        Object next;
        b0.d.k(iterable, "<this>");
        if (!(i2 >= 0)) {
            throw new IllegalArgumentException(("Requested element count " + i2 + " is less than zero.").toString());
        }
        k kVar = k.f624a;
        if (i2 == 0) {
            return kVar;
        }
        if (iterable instanceof Collection) {
            if (i2 >= ((Collection) iterable).size()) {
                return S(iterable);
            }
            if (i2 == 1) {
                if (iterable instanceof List) {
                    List list = (List) iterable;
                    if (list.isEmpty()) {
                        throw new NoSuchElementException("List is empty.");
                    }
                    next = list.get(0);
                } else {
                    Iterator it = iterable.iterator();
                    if (!it.hasNext()) {
                        throw new NoSuchElementException("Collection is empty.");
                    }
                    next = it.next();
                }
                List singletonList = Collections.singletonList(next);
                b0.d.j(singletonList, "singletonList(...)");
                return singletonList;
            }
        }
        ArrayList arrayList = new ArrayList(i2);
        Iterator it2 = iterable.iterator();
        int i3 = 0;
        while (it2.hasNext()) {
            arrayList.add(it2.next());
            i3++;
            if (i3 == i2) {
                break;
            }
        }
        int size = arrayList.size();
        if (size == 0) {
            return kVar;
        }
        if (size != 1) {
            return arrayList;
        }
        List singletonList2 = Collections.singletonList(arrayList.get(0));
        b0.d.j(singletonList2, "singletonList(...)");
        return singletonList2;
    }

    public static final List S(Iterable iterable) {
        ArrayList arrayList;
        b0.d.k(iterable, "<this>");
        boolean z2 = iterable instanceof Collection;
        k kVar = k.f624a;
        if (z2) {
            Collection collection = (Collection) iterable;
            int size = collection.size();
            if (size == 0) {
                return kVar;
            }
            if (size != 1) {
                return T(collection);
            }
            List singletonList = Collections.singletonList(iterable instanceof List ? ((List) iterable).get(0) : iterable.iterator().next());
            b0.d.j(singletonList, "singletonList(...)");
            return singletonList;
        }
        if (z2) {
            arrayList = T((Collection) iterable);
        } else {
            ArrayList arrayList2 = new ArrayList();
            Iterator it = iterable.iterator();
            while (it.hasNext()) {
                arrayList2.add(it.next());
            }
            arrayList = arrayList2;
        }
        int size2 = arrayList.size();
        if (size2 == 0) {
            return kVar;
        }
        if (size2 != 1) {
            return arrayList;
        }
        List singletonList2 = Collections.singletonList(arrayList.get(0));
        b0.d.j(singletonList2, "singletonList(...)");
        return singletonList2;
    }

    public static final ArrayList T(Collection collection) {
        b0.d.k(collection, "<this>");
        return new ArrayList(collection);
    }
}
