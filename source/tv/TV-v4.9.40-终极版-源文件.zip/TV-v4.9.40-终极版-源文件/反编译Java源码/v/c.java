package v;

import java.io.Serializable;

/* loaded from: classes.dex */
public final class c implements b, Serializable {

    /* renamed from: a, reason: collision with root package name */
    public static final c f625a = new c();

    public final int hashCode() {
        return 0;
    }

    public final String toString() {
        return "EmptyCoroutineContext";
    }
}
