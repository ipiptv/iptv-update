package w;

import c0.c;
import x.d;

/* loaded from: classes.dex */
public final class b extends d {

    /* renamed from: b, reason: collision with root package name */
    public int f628b;

    /* renamed from: c, reason: collision with root package name */
    public final /* synthetic */ c f629c;

    /* renamed from: d, reason: collision with root package name */
    public final /* synthetic */ Object f630d;

    /* JADX WARN: 'super' call moved to the top of the method (can break code semantics) */
    public b(g0.b bVar, g0.b bVar2, c cVar) {
        super(bVar2);
        this.f629c = cVar;
        this.f630d = bVar;
    }

    @Override // x.a
    public final Object e(Object obj) {
        int i2 = this.f628b;
        if (i2 != 0) {
            if (i2 != 1) {
                throw new IllegalStateException("This coroutine had already completed".toString());
            }
            this.f628b = 2;
            b0.d.F(obj);
            return obj;
        }
        this.f628b = 1;
        b0.d.F(obj);
        c cVar = this.f629c;
        b0.d.i(cVar, "null cannot be cast to non-null type kotlin.Function2<R of kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt.createCoroutineUnintercepted$lambda$1, kotlin.coroutines.Continuation<T of kotlin.coroutines.intrinsics.IntrinsicsKt__IntrinsicsJvmKt.createCoroutineUnintercepted$lambda$1>, kotlin.Any?>");
        b0.d.c(cVar);
        return cVar.c(this.f630d, this);
    }
}
