package x;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;

/* loaded from: classes.dex */
public abstract class a implements v.a, Serializable {

    /* renamed from: a, reason: collision with root package name */
    public final v.a f631a;

    public a(v.a aVar) {
        this.f631a = aVar;
    }

    @Override // v.a
    public final void a(Object obj) {
        v.a aVar = this;
        while (true) {
            a aVar2 = (a) aVar;
            v.a aVar3 = aVar2.f631a;
            b0.d.h(aVar3);
            try {
                obj = aVar2.e(obj);
                if (obj == w.a.f626a) {
                    return;
                }
            } catch (Throwable th) {
                obj = new t.c(th);
            }
            aVar2.f();
            if (!(aVar3 instanceof a)) {
                aVar3.a(obj);
                return;
            }
            aVar = aVar3;
        }
    }

    public v.a d(Object obj, v.a aVar) {
        throw new UnsupportedOperationException("create(Any?;Continuation) has not been overridden");
    }

    public abstract Object e(Object obj);

    public void f() {
    }

    /* JADX WARN: Multi-variable type inference failed */
    /* JADX WARN: Type inference failed for: r3v3, types: [java.lang.StackTraceElement] */
    /* JADX WARN: Type inference failed for: r3v7, types: [java.lang.Object] */
    public String toString() {
        int i2;
        String str;
        StringBuilder sb = new StringBuilder("Continuation at ");
        b bVar = (b) getClass().getAnnotation(b.class);
        String str2 = null;
        if (bVar != null) {
            int v2 = bVar.v();
            if (v2 > 1) {
                throw new IllegalStateException(("Debug metadata version mismatch. Expected: 1, got " + v2 + ". Please update the Kotlin standard library.").toString());
            }
            try {
                Field declaredField = getClass().getDeclaredField("label");
                declaredField.setAccessible(true);
                Object obj = declaredField.get(this);
                Integer num = obj instanceof Integer ? (Integer) obj : null;
                i2 = (num != null ? num.intValue() : 0) - 1;
            } catch (Exception unused) {
                i2 = -1;
            }
            int i3 = i2 >= 0 ? bVar.l()[i2] : -1;
            c cVar = b0.d.f384j;
            c cVar2 = b0.d.f383i;
            if (cVar == null) {
                try {
                    c cVar3 = new c(Class.class.getDeclaredMethod("getModule", new Class[0]), getClass().getClassLoader().loadClass("java.lang.Module").getDeclaredMethod("getDescriptor", new Class[0]), getClass().getClassLoader().loadClass("java.lang.module.ModuleDescriptor").getDeclaredMethod("name", new Class[0]));
                    b0.d.f384j = cVar3;
                    cVar = cVar3;
                } catch (Exception unused2) {
                    b0.d.f384j = cVar2;
                    cVar = cVar2;
                }
            }
            if (cVar != cVar2) {
                Method method = cVar.f632a;
                Object invoke = method != null ? method.invoke(getClass(), new Object[0]) : null;
                if (invoke != null) {
                    Method method2 = cVar.f633b;
                    Object invoke2 = method2 != null ? method2.invoke(invoke, new Object[0]) : null;
                    if (invoke2 != null) {
                        Method method3 = cVar.f634c;
                        String invoke3 = method3 != null ? method3.invoke(invoke2, new Object[0]) : null;
                        if (invoke3 instanceof String) {
                            str2 = invoke3;
                        }
                    }
                }
            }
            if (str2 == null) {
                str = bVar.c();
            } else {
                str = str2 + '/' + bVar.c();
            }
            str2 = new StackTraceElement(str, bVar.m(), bVar.f(), i3);
        }
        if (str2 == null) {
            str2 = getClass().getName();
        }
        sb.append((Object) str2);
        return sb.toString();
    }
}
