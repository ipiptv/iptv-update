package x;

import java.lang.reflect.Method;

/* loaded from: classes.dex */
public final class c {

    /* renamed from: a, reason: collision with root package name */
    public final Method f632a;

    /* renamed from: b, reason: collision with root package name */
    public final Method f633b;

    /* renamed from: c, reason: collision with root package name */
    public final Method f634c;

    public c(Method method, Method method2, Method method3) {
        this.f632a = method;
        this.f633b = method2;
        this.f634c = method3;
    }
}
