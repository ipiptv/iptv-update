package x;

/* loaded from: classes.dex */
public abstract class d extends a {
    public d(v.a aVar) {
        super(aVar);
        if (aVar != null) {
            if (!(aVar.b() == v.c.f625a)) {
                throw new IllegalArgumentException("Coroutines with restricted suspension must have EmptyCoroutineContext".toString());
            }
        }
    }

    @Override // v.a
    public final v.b b() {
        return v.c.f625a;
    }
}
