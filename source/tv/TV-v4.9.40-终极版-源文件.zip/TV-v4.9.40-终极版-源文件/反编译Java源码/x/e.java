package x;

import d0.f;
import d0.g;

/* loaded from: classes.dex */
public abstract class e extends d implements d0.b {

    /* renamed from: b, reason: collision with root package name */
    public final int f635b;

    public e(v.a aVar) {
        super(aVar);
        this.f635b = 2;
    }

    @Override // d0.b
    public final int getArity() {
        return this.f635b;
    }

    @Override // x.a
    public final String toString() {
        if (this.f631a != null) {
            return super.toString();
        }
        f.f392a.getClass();
        String a2 = g.a(this);
        b0.d.j(a2, "renderLambdaToString(...)");
        return a2;
    }
}
