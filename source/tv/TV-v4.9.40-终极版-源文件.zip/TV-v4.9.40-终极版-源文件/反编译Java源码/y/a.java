package y;

import b0.d;
import java.io.Serializable;
import u.e;

/* loaded from: classes.dex */
public final class a extends e implements Serializable {

    /* renamed from: a, reason: collision with root package name */
    public final Enum[] f636a;

    public a(Enum[] enumArr) {
        this.f636a = enumArr;
    }

    @Override // u.b
    public final int a() {
        return this.f636a.length;
    }

    @Override // u.b, java.util.Collection
    public final boolean contains(Object obj) {
        if (!(obj instanceof Enum)) {
            return false;
        }
        Enum r5 = (Enum) obj;
        d.k(r5, "element");
        int ordinal = r5.ordinal();
        Enum[] enumArr = this.f636a;
        d.k(enumArr, "<this>");
        return ((ordinal < 0 || ordinal > enumArr.length + (-1)) ? null : enumArr[ordinal]) == r5;
    }

    @Override // java.util.List
    public final Object get(int i2) {
        Enum[] enumArr = this.f636a;
        int length = enumArr.length;
        if (i2 >= 0 && i2 < length) {
            return enumArr[i2];
        }
        throw new IndexOutOfBoundsException("index: " + i2 + ", size: " + length);
    }

    @Override // u.e, java.util.List
    public final int indexOf(Object obj) {
        if (!(obj instanceof Enum)) {
            return -1;
        }
        Enum r5 = (Enum) obj;
        d.k(r5, "element");
        int ordinal = r5.ordinal();
        Enum[] enumArr = this.f636a;
        d.k(enumArr, "<this>");
        if (((ordinal < 0 || ordinal > enumArr.length + (-1)) ? null : enumArr[ordinal]) == r5) {
            return ordinal;
        }
        return -1;
    }

    @Override // u.e, java.util.List
    public final int lastIndexOf(Object obj) {
        if (!(obj instanceof Enum)) {
            return -1;
        }
        Enum r2 = (Enum) obj;
        d.k(r2, "element");
        return indexOf(r2);
    }
}
