.class public final La/d;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/util/Iterator;


# instance fields
.field public final a:I

.field public b:I

.field public c:I

.field public d:Z

.field public final synthetic e:La/a;


# direct methods
.method public constructor <init>(La/a;I)V
    .locals 1

    .line 1
    iput-object p1, p0, La/d;->e:La/a;

    .line 2
    .line 3
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 4
    .line 5
    .line 6
    const/4 v0, 0x0

    .line 7
    iput-boolean v0, p0, La/d;->d:Z

    .line 8
    .line 9
    iput p2, p0, La/d;->a:I

    .line 10
    .line 11
    iget-object p1, p1, La/a;->d:La/b;

    .line 12
    .line 13
    iget p1, p1, La/h;->c:I

    .line 14
    .line 15
    iput p1, p0, La/d;->b:I

    .line 16
    .line 17
    return-void
.end method


# virtual methods
.method public final hasNext()Z
    .locals 2

    .line 1
    iget v0, p0, La/d;->c:I

    iget v1, p0, La/d;->b:I

    if-ge v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final next()Ljava/lang/Object;
    .locals 3

    .line 1
    invoke-virtual {p0}, La/d;->hasNext()Z

    move-result v0

    if-eqz v0, :cond_0

    iget v0, p0, La/d;->c:I

    iget v1, p0, La/d;->a:I

    iget-object v2, p0, La/d;->e:La/a;

    invoke-virtual {v2, v0, v1}, La/a;->a(II)Ljava/lang/Object;

    move-result-object v0

    iget v1, p0, La/d;->c:I

    const/4 v2, 0x1

    add-int/2addr v1, v2

    iput v1, p0, La/d;->c:I

    iput-boolean v2, p0, La/d;->d:Z

    return-object v0

    :cond_0
    new-instance v0, Ljava/util/NoSuchElementException;

    invoke-direct {v0}, Ljava/util/NoSuchElementException;-><init>()V

    throw v0
.end method

.method public final remove()V
    .locals 2

    .line 1
    iget-boolean v0, p0, La/d;->d:Z

    if-eqz v0, :cond_0

    iget v0, p0, La/d;->c:I

    add-int/lit8 v0, v0, -0x1

    iput v0, p0, La/d;->c:I

    iget v1, p0, La/d;->b:I

    add-int/lit8 v1, v1, -0x1

    iput v1, p0, La/d;->b:I

    const/4 v1, 0x0

    iput-boolean v1, p0, La/d;->d:Z

    iget-object v1, p0, La/d;->e:La/a;

    invoke-virtual {v1, v0}, La/a;->b(I)V

    return-void

    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    invoke-direct {v0}, Ljava/lang/IllegalStateException;-><init>()V

    throw v0
.end method
