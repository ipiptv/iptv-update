.class public Landroidx/recyclerview/widget/LinearLayoutManager;
.super Landroidx/recyclerview/widget/t0;
.source "SourceFile"


# instance fields
.field public final A:Landroidx/recyclerview/widget/z;

.field public final B:I

.field public final C:[I

.field public o:I

.field public p:Landroidx/recyclerview/widget/a0;

.field public q:Landroidx/recyclerview/widget/d0;

.field public r:Z

.field public s:Z

.field public t:Z

.field public u:Z

.field public final v:Z

.field public w:I

.field public x:I

.field public y:Landroidx/recyclerview/widget/c0;

.field public final z:Landroidx/recyclerview/widget/y;


# direct methods
.method public constructor <init>()V
    .locals 4

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/t0;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    const/4 v1, 0x0

    iput-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->s:Z

    iput-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    iput-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->u:Z

    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->v:Z

    const/4 v2, -0x1

    iput v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->w:I

    const/high16 v2, -0x80000000

    iput v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->x:I

    const/4 v2, 0x0

    iput-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->y:Landroidx/recyclerview/widget/c0;

    new-instance v3, Landroidx/recyclerview/widget/y;

    invoke-direct {v3}, Landroidx/recyclerview/widget/y;-><init>()V

    iput-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->z:Landroidx/recyclerview/widget/y;

    new-instance v3, Landroidx/recyclerview/widget/z;

    invoke-direct {v3}, Landroidx/recyclerview/widget/z;-><init>()V

    iput-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->A:Landroidx/recyclerview/widget/z;

    const/4 v3, 0x2

    iput v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->B:I

    new-array v3, v3, [I

    iput-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->C:[I

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->R0(I)V

    .line 2
    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/LinearLayoutManager;->b(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->s:Z

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iput-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->s:Z

    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->h0()V

    :goto_0
    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;II)V
    .locals 2
    .annotation build Landroid/annotation/SuppressLint;
        value = {
            "UnknownNullness"
        }
    .end annotation

    invoke-direct {p0}, Landroidx/recyclerview/widget/t0;-><init>()V

    const/4 v0, 0x1

    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    const/4 v1, 0x0

    iput-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->s:Z

    iput-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    iput-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->u:Z

    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->v:Z

    const/4 v0, -0x1

    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->w:I

    const/high16 v0, -0x80000000

    iput v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->x:I

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->y:Landroidx/recyclerview/widget/c0;

    new-instance v1, Landroidx/recyclerview/widget/y;

    invoke-direct {v1}, Landroidx/recyclerview/widget/y;-><init>()V

    iput-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->z:Landroidx/recyclerview/widget/y;

    new-instance v1, Landroidx/recyclerview/widget/z;

    invoke-direct {v1}, Landroidx/recyclerview/widget/z;-><init>()V

    iput-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->A:Landroidx/recyclerview/widget/z;

    const/4 v1, 0x2

    iput v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->B:I

    new-array v1, v1, [I

    iput-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->C:[I

    invoke-static {p1, p2, p3, p4}, Landroidx/recyclerview/widget/t0;->D(Landroid/content/Context;Landroid/util/AttributeSet;II)Landroidx/recyclerview/widget/s0;

    move-result-object p1

    iget p2, p1, Landroidx/recyclerview/widget/s0;->a:I

    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->R0(I)V

    iget-boolean p2, p1, Landroidx/recyclerview/widget/s0;->c:Z

    .line 3
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->b(Ljava/lang/String;)V

    iget-boolean p3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->s:Z

    if-ne p2, p3, :cond_0

    goto :goto_0

    :cond_0
    iput-boolean p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->s:Z

    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->h0()V

    .line 4
    :goto_0
    iget-boolean p1, p1, Landroidx/recyclerview/widget/s0;->d:Z

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->S0(Z)V

    return-void
.end method


# virtual methods
.method public final A0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/a0;Landroidx/recyclerview/widget/e1;Z)I
    .locals 7

    .line 1
    iget v0, p2, Landroidx/recyclerview/widget/a0;->c:I

    .line 2
    .line 3
    iget v1, p2, Landroidx/recyclerview/widget/a0;->g:I

    .line 4
    .line 5
    const/high16 v2, -0x80000000

    .line 6
    .line 7
    if-eq v1, v2, :cond_1

    .line 8
    .line 9
    if-gez v0, :cond_0

    .line 10
    .line 11
    add-int/2addr v1, v0

    .line 12
    iput v1, p2, Landroidx/recyclerview/widget/a0;->g:I

    .line 13
    .line 14
    :cond_0
    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->N0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/a0;)V

    .line 15
    .line 16
    .line 17
    :cond_1
    iget v1, p2, Landroidx/recyclerview/widget/a0;->c:I

    .line 18
    .line 19
    iget v3, p2, Landroidx/recyclerview/widget/a0;->h:I

    .line 20
    .line 21
    add-int/2addr v1, v3

    .line 22
    :cond_2
    iget-boolean v3, p2, Landroidx/recyclerview/widget/a0;->l:Z

    .line 23
    .line 24
    if-nez v3, :cond_3

    .line 25
    .line 26
    if-lez v1, :cond_a

    .line 27
    .line 28
    :cond_3
    iget v3, p2, Landroidx/recyclerview/widget/a0;->d:I

    .line 29
    .line 30
    const/4 v4, 0x0

    .line 31
    if-ltz v3, :cond_4

    .line 32
    .line 33
    invoke-virtual {p3}, Landroidx/recyclerview/widget/e1;->b()I

    .line 34
    .line 35
    .line 36
    move-result v5

    .line 37
    if-ge v3, v5, :cond_4

    .line 38
    .line 39
    const/4 v3, 0x1

    .line 40
    goto :goto_0

    .line 41
    :cond_4
    const/4 v3, 0x0

    .line 42
    :goto_0
    if-eqz v3, :cond_a

    .line 43
    .line 44
    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->A:Landroidx/recyclerview/widget/z;

    .line 45
    .line 46
    iput v4, v3, Landroidx/recyclerview/widget/z;->a:I

    .line 47
    .line 48
    iput-boolean v4, v3, Landroidx/recyclerview/widget/z;->b:Z

    .line 49
    .line 50
    iput-boolean v4, v3, Landroidx/recyclerview/widget/z;->c:Z

    .line 51
    .line 52
    iput-boolean v4, v3, Landroidx/recyclerview/widget/z;->d:Z

    .line 53
    .line 54
    invoke-virtual {p0, p1, p3, p2, v3}, Landroidx/recyclerview/widget/LinearLayoutManager;->L0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;Landroidx/recyclerview/widget/a0;Landroidx/recyclerview/widget/z;)V

    .line 55
    .line 56
    .line 57
    iget-boolean v4, v3, Landroidx/recyclerview/widget/z;->b:Z

    .line 58
    .line 59
    if-eqz v4, :cond_5

    .line 60
    .line 61
    goto :goto_1

    .line 62
    :cond_5
    iget v4, p2, Landroidx/recyclerview/widget/a0;->b:I

    .line 63
    .line 64
    iget v5, v3, Landroidx/recyclerview/widget/z;->a:I

    .line 65
    .line 66
    iget v6, p2, Landroidx/recyclerview/widget/a0;->f:I

    .line 67
    .line 68
    mul-int v6, v6, v5

    .line 69
    .line 70
    add-int/2addr v6, v4

    .line 71
    iput v6, p2, Landroidx/recyclerview/widget/a0;->b:I

    .line 72
    .line 73
    iget-boolean v4, v3, Landroidx/recyclerview/widget/z;->c:Z

    .line 74
    .line 75
    if-eqz v4, :cond_6

    .line 76
    .line 77
    iget-object v4, p2, Landroidx/recyclerview/widget/a0;->k:Ljava/util/List;

    .line 78
    .line 79
    if-nez v4, :cond_6

    .line 80
    .line 81
    iget-boolean v4, p3, Landroidx/recyclerview/widget/e1;->f:Z

    .line 82
    .line 83
    if-nez v4, :cond_7

    .line 84
    .line 85
    :cond_6
    iget v4, p2, Landroidx/recyclerview/widget/a0;->c:I

    .line 86
    .line 87
    sub-int/2addr v4, v5

    .line 88
    iput v4, p2, Landroidx/recyclerview/widget/a0;->c:I

    .line 89
    .line 90
    sub-int/2addr v1, v5

    .line 91
    :cond_7
    iget v4, p2, Landroidx/recyclerview/widget/a0;->g:I

    .line 92
    .line 93
    if-eq v4, v2, :cond_9

    .line 94
    .line 95
    add-int/2addr v4, v5

    .line 96
    iput v4, p2, Landroidx/recyclerview/widget/a0;->g:I

    .line 97
    .line 98
    iget v5, p2, Landroidx/recyclerview/widget/a0;->c:I

    .line 99
    .line 100
    if-gez v5, :cond_8

    .line 101
    .line 102
    add-int/2addr v4, v5

    .line 103
    iput v4, p2, Landroidx/recyclerview/widget/a0;->g:I

    .line 104
    .line 105
    :cond_8
    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->N0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/a0;)V

    .line 106
    .line 107
    .line 108
    :cond_9
    if-eqz p4, :cond_2

    .line 109
    .line 110
    iget-boolean v3, v3, Landroidx/recyclerview/widget/z;->d:Z

    .line 111
    .line 112
    if-eqz v3, :cond_2

    .line 113
    .line 114
    :cond_a
    :goto_1
    iget p1, p2, Landroidx/recyclerview/widget/a0;->c:I

    .line 115
    .line 116
    sub-int/2addr v0, p1

    .line 117
    return v0
.end method

.method public final B0(Z)Landroid/view/View;
    .locals 2

    .line 1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    move-result v0

    const/4 v1, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    move-result v0

    const/4 v1, -0x1

    add-int/2addr v0, v1

    move v1, v0

    const/4 v0, -0x1

    :goto_0
    invoke-virtual {p0, v1, v0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->E0(IIZ)Landroid/view/View;

    move-result-object p1

    return-object p1
.end method

.method public final C0(Z)Landroid/view/View;
    .locals 2

    .line 1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    move-result v0

    const/4 v1, -0x1

    add-int/2addr v0, v1

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    move-result v1

    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0, v0, v1, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->E0(IIZ)Landroid/view/View;

    move-result-object p1

    return-object p1
.end method

.method public final D0(II)Landroid/view/View;
    .locals 3

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->z0()V

    if-le p2, p1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    if-ge p2, p1, :cond_1

    const/4 v0, -0x1

    goto :goto_0

    :cond_1
    const/4 v0, 0x0

    :goto_0
    if-nez v0, :cond_2

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/t0;->t(I)Landroid/view/View;

    move-result-object p1

    return-object p1

    :cond_2
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/t0;->t(I)Landroid/view/View;

    move-result-object v1

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/d0;->d(Landroid/view/View;)I

    move-result v0

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/d0;->h()I

    move-result v1

    if-ge v0, v1, :cond_3

    const/16 v0, 0x4104

    const/16 v1, 0x4004

    goto :goto_1

    :cond_3
    const/16 v0, 0x1041

    const/16 v1, 0x1001

    :goto_1
    iget v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    if-nez v2, :cond_4

    iget-object v2, p0, Landroidx/recyclerview/widget/t0;->c:Landroidx/recyclerview/widget/t1;

    goto :goto_2

    :cond_4
    iget-object v2, p0, Landroidx/recyclerview/widget/t0;->d:Landroidx/recyclerview/widget/t1;

    :goto_2
    invoke-virtual {v2, p1, p2, v0, v1}, Landroidx/recyclerview/widget/t1;->g(IIII)Landroid/view/View;

    move-result-object p1

    return-object p1
.end method

.method public final E0(IIZ)Landroid/view/View;
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->z0()V

    const/16 v0, 0x140

    if-eqz p3, :cond_0

    const/16 p3, 0x6003

    goto :goto_0

    :cond_0
    const/16 p3, 0x140

    :goto_0
    iget v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    if-nez v1, :cond_1

    iget-object v1, p0, Landroidx/recyclerview/widget/t0;->c:Landroidx/recyclerview/widget/t1;

    goto :goto_1

    :cond_1
    iget-object v1, p0, Landroidx/recyclerview/widget/t0;->d:Landroidx/recyclerview/widget/t1;

    :goto_1
    invoke-virtual {v1, p1, p2, p3, v0}, Landroidx/recyclerview/widget/t1;->g(IIII)Landroid/view/View;

    move-result-object p1

    return-object p1
.end method

.method public F0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;ZZ)Landroid/view/View;
    .locals 16

    .line 1
    move-object/from16 v0, p0

    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->z0()V

    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/t0;->u()I

    move-result v1

    const/4 v2, 0x0

    const/4 v3, 0x1

    if-eqz p4, :cond_0

    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/t0;->u()I

    move-result v1

    sub-int/2addr v1, v3

    const/4 v4, -0x1

    const/4 v5, -0x1

    goto :goto_0

    :cond_0
    move v4, v1

    const/4 v1, 0x0

    const/4 v5, 0x1

    :goto_0
    invoke-virtual/range {p2 .. p2}, Landroidx/recyclerview/widget/e1;->b()I

    move-result v6

    iget-object v7, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    invoke-virtual {v7}, Landroidx/recyclerview/widget/d0;->h()I

    move-result v7

    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    invoke-virtual {v8}, Landroidx/recyclerview/widget/d0;->f()I

    move-result v8

    const/4 v9, 0x0

    move-object v10, v9

    move-object v11, v10

    :goto_1
    if-eq v1, v4, :cond_a

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/t0;->t(I)Landroid/view/View;

    move-result-object v12

    invoke-static {v12}, Landroidx/recyclerview/widget/t0;->C(Landroid/view/View;)I

    move-result v13

    iget-object v14, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    invoke-virtual {v14, v12}, Landroidx/recyclerview/widget/d0;->d(Landroid/view/View;)I

    move-result v14

    iget-object v15, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    invoke-virtual {v15, v12}, Landroidx/recyclerview/widget/d0;->b(Landroid/view/View;)I

    move-result v15

    if-ltz v13, :cond_9

    if-ge v13, v6, :cond_9

    invoke-virtual {v12}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v13

    check-cast v13, Landroidx/recyclerview/widget/u0;

    invoke-virtual {v13}, Landroidx/recyclerview/widget/u0;->c()Z

    move-result v13

    if-eqz v13, :cond_1

    if-nez v11, :cond_9

    move-object v11, v12

    goto :goto_7

    :cond_1
    if-gt v15, v7, :cond_2

    if-ge v14, v7, :cond_2

    const/4 v13, 0x1

    goto :goto_2

    :cond_2
    const/4 v13, 0x0

    :goto_2
    if-lt v14, v8, :cond_3

    if-le v15, v8, :cond_3

    const/4 v14, 0x1

    goto :goto_3

    :cond_3
    const/4 v14, 0x0

    :goto_3
    if-nez v13, :cond_5

    if-eqz v14, :cond_4

    goto :goto_4

    :cond_4
    return-object v12

    :cond_5
    :goto_4
    if-eqz p3, :cond_7

    if-eqz v14, :cond_6

    goto :goto_5

    :cond_6
    if-nez v9, :cond_9

    goto :goto_6

    :cond_7
    if-eqz v13, :cond_8

    :goto_5
    move-object v10, v12

    goto :goto_7

    :cond_8
    if-nez v9, :cond_9

    :goto_6
    move-object v9, v12

    :cond_9
    :goto_7
    add-int/2addr v1, v5

    goto :goto_1

    :cond_a
    if-eqz v9, :cond_b

    goto :goto_8

    :cond_b
    if-eqz v10, :cond_c

    move-object v9, v10

    goto :goto_8

    :cond_c
    move-object v9, v11

    :goto_8
    return-object v9
.end method

.method public final G()Z
    .locals 1

    .line 1
    const/4 v0, 0x1

    return v0
.end method

.method public final G0(ILandroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;Z)I
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/d0;->f()I

    move-result v0

    sub-int/2addr v0, p1

    if-lez v0, :cond_1

    neg-int v0, v0

    invoke-virtual {p0, v0, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->Q0(ILandroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;)I

    move-result p2

    neg-int p2, p2

    add-int/2addr p1, p2

    if-eqz p4, :cond_0

    iget-object p3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    invoke-virtual {p3}, Landroidx/recyclerview/widget/d0;->f()I

    move-result p3

    sub-int/2addr p3, p1

    if-lez p3, :cond_0

    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    invoke-virtual {p1, p3}, Landroidx/recyclerview/widget/d0;->l(I)V

    add-int/2addr p3, p2

    return p3

    :cond_0
    return p2

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public final H0(ILandroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;Z)I
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/d0;->h()I

    move-result v0

    sub-int v0, p1, v0

    if-lez v0, :cond_1

    invoke-virtual {p0, v0, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->Q0(ILandroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;)I

    move-result p2

    neg-int p2, p2

    add-int/2addr p1, p2

    if-eqz p4, :cond_0

    iget-object p3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    invoke-virtual {p3}, Landroidx/recyclerview/widget/d0;->h()I

    move-result p3

    sub-int/2addr p1, p3

    if-lez p1, :cond_0

    iget-object p3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    neg-int p4, p1

    invoke-virtual {p3, p4}, Landroidx/recyclerview/widget/d0;->l(I)V

    sub-int/2addr p2, p1

    :cond_0
    return p2

    :cond_1
    const/4 p1, 0x0

    return p1
.end method

.method public final I0()Landroid/view/View;
    .locals 1

    .line 1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    if-eqz v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    :goto_0
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/t0;->t(I)Landroid/view/View;

    move-result-object v0

    return-object v0
.end method

.method public final J0()Landroid/view/View;
    .locals 1

    .line 1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    move-result v0

    add-int/lit8 v0, v0, -0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/t0;->t(I)Landroid/view/View;

    move-result-object v0

    return-object v0
.end method

.method public final K0()Z
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/t0;->b:Landroidx/recyclerview/widget/RecyclerView;

    .line 2
    .line 3
    sget-object v1, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 4
    .line 5
    invoke-static {v0}, Lg/k;->d(Landroid/view/View;)I

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    const/4 v1, 0x1

    .line 10
    if-ne v0, v1, :cond_0

    .line 11
    .line 12
    goto :goto_0

    .line 13
    :cond_0
    const/4 v1, 0x0

    .line 14
    :goto_0
    return v1
.end method

.method public L0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;Landroidx/recyclerview/widget/a0;Landroidx/recyclerview/widget/z;)V
    .locals 10

    .line 1
    invoke-virtual {p3, p1}, Landroidx/recyclerview/widget/a0;->b(Landroidx/recyclerview/widget/a1;)Landroid/view/View;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    const/4 p2, 0x1

    .line 6
    if-nez p1, :cond_0

    .line 7
    .line 8
    iput-boolean p2, p4, Landroidx/recyclerview/widget/z;->b:Z

    .line 9
    .line 10
    return-void

    .line 11
    :cond_0
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    check-cast v0, Landroidx/recyclerview/widget/u0;

    .line 16
    .line 17
    iget-object v1, p3, Landroidx/recyclerview/widget/a0;->k:Ljava/util/List;

    .line 18
    .line 19
    const/4 v2, -0x1

    .line 20
    const/4 v3, 0x0

    .line 21
    if-nez v1, :cond_3

    .line 22
    .line 23
    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    .line 24
    .line 25
    iget v4, p3, Landroidx/recyclerview/widget/a0;->f:I

    .line 26
    .line 27
    if-ne v4, v2, :cond_1

    .line 28
    .line 29
    const/4 v4, 0x1

    .line 30
    goto :goto_0

    .line 31
    :cond_1
    const/4 v4, 0x0

    .line 32
    :goto_0
    if-ne v1, v4, :cond_2

    .line 33
    .line 34
    invoke-virtual {p0, p1, v2, v3}, Landroidx/recyclerview/widget/t0;->a(Landroid/view/View;IZ)V

    .line 35
    .line 36
    .line 37
    goto :goto_2

    .line 38
    :cond_2
    invoke-virtual {p0, p1, v3, v3}, Landroidx/recyclerview/widget/t0;->a(Landroid/view/View;IZ)V

    .line 39
    .line 40
    .line 41
    goto :goto_2

    .line 42
    :cond_3
    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    .line 43
    .line 44
    iget v4, p3, Landroidx/recyclerview/widget/a0;->f:I

    .line 45
    .line 46
    if-ne v4, v2, :cond_4

    .line 47
    .line 48
    const/4 v4, 0x1

    .line 49
    goto :goto_1

    .line 50
    :cond_4
    const/4 v4, 0x0

    .line 51
    :goto_1
    if-ne v1, v4, :cond_5

    .line 52
    .line 53
    invoke-virtual {p0, p1, v2, p2}, Landroidx/recyclerview/widget/t0;->a(Landroid/view/View;IZ)V

    .line 54
    .line 55
    .line 56
    goto :goto_2

    .line 57
    :cond_5
    invoke-virtual {p0, p1, v3, p2}, Landroidx/recyclerview/widget/t0;->a(Landroid/view/View;IZ)V

    .line 58
    .line 59
    .line 60
    :goto_2
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    check-cast v1, Landroidx/recyclerview/widget/u0;

    .line 65
    .line 66
    iget-object v4, p0, Landroidx/recyclerview/widget/t0;->b:Landroidx/recyclerview/widget/RecyclerView;

    .line 67
    .line 68
    invoke-virtual {v4, p1}, Landroidx/recyclerview/widget/RecyclerView;->J(Landroid/view/View;)Landroid/graphics/Rect;

    .line 69
    .line 70
    .line 71
    move-result-object v4

    .line 72
    iget v5, v4, Landroid/graphics/Rect;->left:I

    .line 73
    .line 74
    iget v6, v4, Landroid/graphics/Rect;->right:I

    .line 75
    .line 76
    add-int/2addr v5, v6

    .line 77
    add-int/2addr v5, v3

    .line 78
    iget v6, v4, Landroid/graphics/Rect;->top:I

    .line 79
    .line 80
    iget v4, v4, Landroid/graphics/Rect;->bottom:I

    .line 81
    .line 82
    add-int/2addr v6, v4

    .line 83
    add-int/2addr v6, v3

    .line 84
    iget v3, p0, Landroidx/recyclerview/widget/t0;->m:I

    .line 85
    .line 86
    iget v4, p0, Landroidx/recyclerview/widget/t0;->k:I

    .line 87
    .line 88
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->z()I

    .line 89
    .line 90
    .line 91
    move-result v7

    .line 92
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->A()I

    .line 93
    .line 94
    .line 95
    move-result v8

    .line 96
    add-int/2addr v8, v7

    .line 97
    iget v7, v1, Landroid/view/ViewGroup$MarginLayoutParams;->leftMargin:I

    .line 98
    .line 99
    add-int/2addr v8, v7

    .line 100
    iget v7, v1, Landroid/view/ViewGroup$MarginLayoutParams;->rightMargin:I

    .line 101
    .line 102
    add-int/2addr v8, v7

    .line 103
    add-int/2addr v8, v5

    .line 104
    iget v5, v1, Landroid/view/ViewGroup$MarginLayoutParams;->width:I

    .line 105
    .line 106
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->c()Z

    .line 107
    .line 108
    .line 109
    move-result v7

    .line 110
    invoke-static {v3, v4, v8, v5, v7}, Landroidx/recyclerview/widget/t0;->v(IIIIZ)I

    .line 111
    .line 112
    .line 113
    move-result v3

    .line 114
    iget v4, p0, Landroidx/recyclerview/widget/t0;->n:I

    .line 115
    .line 116
    iget v5, p0, Landroidx/recyclerview/widget/t0;->l:I

    .line 117
    .line 118
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->B()I

    .line 119
    .line 120
    .line 121
    move-result v7

    .line 122
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->y()I

    .line 123
    .line 124
    .line 125
    move-result v8

    .line 126
    add-int/2addr v8, v7

    .line 127
    iget v7, v1, Landroid/view/ViewGroup$MarginLayoutParams;->topMargin:I

    .line 128
    .line 129
    add-int/2addr v8, v7

    .line 130
    iget v7, v1, Landroid/view/ViewGroup$MarginLayoutParams;->bottomMargin:I

    .line 131
    .line 132
    add-int/2addr v8, v7

    .line 133
    add-int/2addr v8, v6

    .line 134
    iget v6, v1, Landroid/view/ViewGroup$MarginLayoutParams;->height:I

    .line 135
    .line 136
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->d()Z

    .line 137
    .line 138
    .line 139
    move-result v7

    .line 140
    invoke-static {v4, v5, v8, v6, v7}, Landroidx/recyclerview/widget/t0;->v(IIIIZ)I

    .line 141
    .line 142
    .line 143
    move-result v4

    .line 144
    invoke-virtual {p0, p1, v3, v4, v1}, Landroidx/recyclerview/widget/t0;->q0(Landroid/view/View;IILandroidx/recyclerview/widget/u0;)Z

    .line 145
    .line 146
    .line 147
    move-result v1

    .line 148
    if-eqz v1, :cond_6

    .line 149
    .line 150
    invoke-virtual {p1, v3, v4}, Landroid/view/View;->measure(II)V

    .line 151
    .line 152
    .line 153
    :cond_6
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 154
    .line 155
    invoke-virtual {v1, p1}, Landroidx/recyclerview/widget/d0;->c(Landroid/view/View;)I

    .line 156
    .line 157
    .line 158
    move-result v1

    .line 159
    iput v1, p4, Landroidx/recyclerview/widget/z;->a:I

    .line 160
    .line 161
    iget v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    .line 162
    .line 163
    if-ne v1, p2, :cond_9

    .line 164
    .line 165
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->K0()Z

    .line 166
    .line 167
    .line 168
    move-result v1

    .line 169
    if-eqz v1, :cond_7

    .line 170
    .line 171
    iget v1, p0, Landroidx/recyclerview/widget/t0;->m:I

    .line 172
    .line 173
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->A()I

    .line 174
    .line 175
    .line 176
    move-result v3

    .line 177
    sub-int/2addr v1, v3

    .line 178
    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 179
    .line 180
    invoke-virtual {v3, p1}, Landroidx/recyclerview/widget/d0;->m(Landroid/view/View;)I

    .line 181
    .line 182
    .line 183
    move-result v3

    .line 184
    sub-int v3, v1, v3

    .line 185
    .line 186
    goto :goto_3

    .line 187
    :cond_7
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->z()I

    .line 188
    .line 189
    .line 190
    move-result v3

    .line 191
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 192
    .line 193
    invoke-virtual {v1, p1}, Landroidx/recyclerview/widget/d0;->m(Landroid/view/View;)I

    .line 194
    .line 195
    .line 196
    move-result v1

    .line 197
    add-int/2addr v1, v3

    .line 198
    :goto_3
    iget v4, p3, Landroidx/recyclerview/widget/a0;->f:I

    .line 199
    .line 200
    iget p3, p3, Landroidx/recyclerview/widget/a0;->b:I

    .line 201
    .line 202
    if-ne v4, v2, :cond_8

    .line 203
    .line 204
    iget v2, p4, Landroidx/recyclerview/widget/z;->a:I

    .line 205
    .line 206
    sub-int v2, p3, v2

    .line 207
    .line 208
    move v9, v3

    .line 209
    move v3, p3

    .line 210
    move p3, v2

    .line 211
    goto :goto_4

    .line 212
    :cond_8
    iget v2, p4, Landroidx/recyclerview/widget/z;->a:I

    .line 213
    .line 214
    add-int/2addr v2, p3

    .line 215
    move v9, v3

    .line 216
    move v3, v2

    .line 217
    :goto_4
    move v2, v9

    .line 218
    goto :goto_5

    .line 219
    :cond_9
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->B()I

    .line 220
    .line 221
    .line 222
    move-result v1

    .line 223
    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 224
    .line 225
    invoke-virtual {v3, p1}, Landroidx/recyclerview/widget/d0;->m(Landroid/view/View;)I

    .line 226
    .line 227
    .line 228
    move-result v3

    .line 229
    add-int/2addr v3, v1

    .line 230
    iget v4, p3, Landroidx/recyclerview/widget/a0;->f:I

    .line 231
    .line 232
    iget p3, p3, Landroidx/recyclerview/widget/a0;->b:I

    .line 233
    .line 234
    if-ne v4, v2, :cond_a

    .line 235
    .line 236
    iget v2, p4, Landroidx/recyclerview/widget/z;->a:I

    .line 237
    .line 238
    sub-int v2, p3, v2

    .line 239
    .line 240
    move v9, v1

    .line 241
    move v1, p3

    .line 242
    move p3, v9

    .line 243
    goto :goto_5

    .line 244
    :cond_a
    iget v2, p4, Landroidx/recyclerview/widget/z;->a:I

    .line 245
    .line 246
    add-int/2addr v2, p3

    .line 247
    move v9, v2

    .line 248
    move v2, p3

    .line 249
    move p3, v1

    .line 250
    move v1, v9

    .line 251
    :goto_5
    invoke-static {p1, v2, p3, v1, v3}, Landroidx/recyclerview/widget/t0;->I(Landroid/view/View;IIII)V

    .line 252
    .line 253
    .line 254
    invoke-virtual {v0}, Landroidx/recyclerview/widget/u0;->c()Z

    .line 255
    .line 256
    .line 257
    move-result p3

    .line 258
    if-nez p3, :cond_b

    .line 259
    .line 260
    invoke-virtual {v0}, Landroidx/recyclerview/widget/u0;->b()Z

    .line 261
    .line 262
    .line 263
    move-result p3

    .line 264
    if-eqz p3, :cond_c

    .line 265
    .line 266
    :cond_b
    iput-boolean p2, p4, Landroidx/recyclerview/widget/z;->c:Z

    .line 267
    .line 268
    :cond_c
    invoke-virtual {p1}, Landroid/view/View;->hasFocusable()Z

    .line 269
    .line 270
    .line 271
    move-result p1

    .line 272
    iput-boolean p1, p4, Landroidx/recyclerview/widget/z;->d:Z

    .line 273
    .line 274
    return-void
.end method

.method public final M(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 0

    .line 1
    return-void
.end method

.method public M0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;Landroidx/recyclerview/widget/y;I)V
    .locals 0

    .line 1
    return-void
.end method

.method public N(Landroid/view/View;ILandroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;)Landroid/view/View;
    .locals 3

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->P0()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    .line 5
    .line 6
    .line 7
    move-result p1

    .line 8
    const/4 v0, 0x0

    .line 9
    if-nez p1, :cond_0

    .line 10
    .line 11
    return-object v0

    .line 12
    :cond_0
    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->y0(I)I

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    const/high16 p2, -0x80000000

    .line 17
    .line 18
    if-ne p1, p2, :cond_1

    .line 19
    .line 20
    return-object v0

    .line 21
    :cond_1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->z0()V

    .line 22
    .line 23
    .line 24
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 25
    .line 26
    invoke-virtual {v1}, Landroidx/recyclerview/widget/d0;->i()I

    .line 27
    .line 28
    .line 29
    move-result v1

    .line 30
    int-to-float v1, v1

    .line 31
    const v2, 0x3eaaaaab

    .line 32
    .line 33
    .line 34
    mul-float v1, v1, v2

    .line 35
    .line 36
    float-to-int v1, v1

    .line 37
    const/4 v2, 0x0

    .line 38
    invoke-virtual {p0, p1, v1, v2, p4}, Landroidx/recyclerview/widget/LinearLayoutManager;->T0(IIZLandroidx/recyclerview/widget/e1;)V

    .line 39
    .line 40
    .line 41
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 42
    .line 43
    iput p2, v1, Landroidx/recyclerview/widget/a0;->g:I

    .line 44
    .line 45
    iput-boolean v2, v1, Landroidx/recyclerview/widget/a0;->a:Z

    .line 46
    .line 47
    const/4 p2, 0x1

    .line 48
    invoke-virtual {p0, p3, v1, p4, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->A0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/a0;Landroidx/recyclerview/widget/e1;Z)I

    .line 49
    .line 50
    .line 51
    const/4 p2, -0x1

    .line 52
    if-ne p1, p2, :cond_3

    .line 53
    .line 54
    iget-boolean p3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    .line 55
    .line 56
    if-eqz p3, :cond_2

    .line 57
    .line 58
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    .line 59
    .line 60
    .line 61
    move-result p3

    .line 62
    add-int/2addr p3, p2

    .line 63
    invoke-virtual {p0, p3, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->D0(II)Landroid/view/View;

    .line 64
    .line 65
    .line 66
    move-result-object p3

    .line 67
    goto :goto_0

    .line 68
    :cond_2
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    .line 69
    .line 70
    .line 71
    move-result p3

    .line 72
    invoke-virtual {p0, v2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->D0(II)Landroid/view/View;

    .line 73
    .line 74
    .line 75
    move-result-object p3

    .line 76
    goto :goto_0

    .line 77
    :cond_3
    iget-boolean p3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    .line 78
    .line 79
    if-eqz p3, :cond_4

    .line 80
    .line 81
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    .line 82
    .line 83
    .line 84
    move-result p3

    .line 85
    invoke-virtual {p0, v2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->D0(II)Landroid/view/View;

    .line 86
    .line 87
    .line 88
    move-result-object p3

    .line 89
    goto :goto_0

    .line 90
    :cond_4
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    .line 91
    .line 92
    .line 93
    move-result p3

    .line 94
    add-int/2addr p3, p2

    .line 95
    invoke-virtual {p0, p3, p2}, Landroidx/recyclerview/widget/LinearLayoutManager;->D0(II)Landroid/view/View;

    .line 96
    .line 97
    .line 98
    move-result-object p3

    .line 99
    :goto_0
    if-ne p1, p2, :cond_5

    .line 100
    .line 101
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->J0()Landroid/view/View;

    .line 102
    .line 103
    .line 104
    move-result-object p1

    .line 105
    goto :goto_1

    .line 106
    :cond_5
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->I0()Landroid/view/View;

    .line 107
    .line 108
    .line 109
    move-result-object p1

    .line 110
    :goto_1
    invoke-virtual {p1}, Landroid/view/View;->hasFocusable()Z

    .line 111
    .line 112
    .line 113
    move-result p2

    .line 114
    if-eqz p2, :cond_7

    .line 115
    .line 116
    if-nez p3, :cond_6

    .line 117
    .line 118
    return-object v0

    .line 119
    :cond_6
    return-object p1

    .line 120
    :cond_7
    return-object p3
.end method

.method public final N0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/a0;)V
    .locals 5

    .line 1
    iget-boolean v0, p2, Landroidx/recyclerview/widget/a0;->a:Z

    .line 2
    .line 3
    if-eqz v0, :cond_e

    .line 4
    .line 5
    iget-boolean v0, p2, Landroidx/recyclerview/widget/a0;->l:Z

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    goto/16 :goto_8

    .line 10
    .line 11
    :cond_0
    iget v0, p2, Landroidx/recyclerview/widget/a0;->g:I

    .line 12
    .line 13
    iget v1, p2, Landroidx/recyclerview/widget/a0;->i:I

    .line 14
    .line 15
    iget p2, p2, Landroidx/recyclerview/widget/a0;->f:I

    .line 16
    .line 17
    const/4 v2, -0x1

    .line 18
    const/4 v3, 0x0

    .line 19
    if-ne p2, v2, :cond_7

    .line 20
    .line 21
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    .line 22
    .line 23
    .line 24
    move-result p2

    .line 25
    if-gez v0, :cond_1

    .line 26
    .line 27
    goto/16 :goto_8

    .line 28
    .line 29
    :cond_1
    iget-object v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 30
    .line 31
    invoke-virtual {v4}, Landroidx/recyclerview/widget/d0;->e()I

    .line 32
    .line 33
    .line 34
    move-result v4

    .line 35
    sub-int/2addr v4, v0

    .line 36
    add-int/2addr v4, v1

    .line 37
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    .line 38
    .line 39
    if-eqz v0, :cond_4

    .line 40
    .line 41
    const/4 v0, 0x0

    .line 42
    :goto_0
    if-ge v0, p2, :cond_e

    .line 43
    .line 44
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/t0;->t(I)Landroid/view/View;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 49
    .line 50
    invoke-virtual {v2, v1}, Landroidx/recyclerview/widget/d0;->d(Landroid/view/View;)I

    .line 51
    .line 52
    .line 53
    move-result v2

    .line 54
    if-lt v2, v4, :cond_3

    .line 55
    .line 56
    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 57
    .line 58
    invoke-virtual {v2, v1}, Landroidx/recyclerview/widget/d0;->k(Landroid/view/View;)I

    .line 59
    .line 60
    .line 61
    move-result v1

    .line 62
    if-ge v1, v4, :cond_2

    .line 63
    .line 64
    goto :goto_1

    .line 65
    :cond_2
    add-int/lit8 v0, v0, 0x1

    .line 66
    .line 67
    goto :goto_0

    .line 68
    :cond_3
    :goto_1
    invoke-virtual {p0, p1, v3, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->O0(Landroidx/recyclerview/widget/a1;II)V

    .line 69
    .line 70
    .line 71
    goto/16 :goto_8

    .line 72
    .line 73
    :cond_4
    add-int/2addr p2, v2

    .line 74
    move v0, p2

    .line 75
    :goto_2
    if-ltz v0, :cond_e

    .line 76
    .line 77
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/t0;->t(I)Landroid/view/View;

    .line 78
    .line 79
    .line 80
    move-result-object v1

    .line 81
    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 82
    .line 83
    invoke-virtual {v2, v1}, Landroidx/recyclerview/widget/d0;->d(Landroid/view/View;)I

    .line 84
    .line 85
    .line 86
    move-result v2

    .line 87
    if-lt v2, v4, :cond_6

    .line 88
    .line 89
    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 90
    .line 91
    invoke-virtual {v2, v1}, Landroidx/recyclerview/widget/d0;->k(Landroid/view/View;)I

    .line 92
    .line 93
    .line 94
    move-result v1

    .line 95
    if-ge v1, v4, :cond_5

    .line 96
    .line 97
    goto :goto_3

    .line 98
    :cond_5
    add-int/lit8 v0, v0, -0x1

    .line 99
    .line 100
    goto :goto_2

    .line 101
    :cond_6
    :goto_3
    invoke-virtual {p0, p1, p2, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->O0(Landroidx/recyclerview/widget/a1;II)V

    .line 102
    .line 103
    .line 104
    goto :goto_8

    .line 105
    :cond_7
    if-gez v0, :cond_8

    .line 106
    .line 107
    goto :goto_8

    .line 108
    :cond_8
    sub-int/2addr v0, v1

    .line 109
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    .line 110
    .line 111
    .line 112
    move-result p2

    .line 113
    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    .line 114
    .line 115
    if-eqz v1, :cond_b

    .line 116
    .line 117
    add-int/2addr p2, v2

    .line 118
    move v1, p2

    .line 119
    :goto_4
    if-ltz v1, :cond_e

    .line 120
    .line 121
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/t0;->t(I)Landroid/view/View;

    .line 122
    .line 123
    .line 124
    move-result-object v2

    .line 125
    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 126
    .line 127
    invoke-virtual {v3, v2}, Landroidx/recyclerview/widget/d0;->b(Landroid/view/View;)I

    .line 128
    .line 129
    .line 130
    move-result v3

    .line 131
    if-gt v3, v0, :cond_a

    .line 132
    .line 133
    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 134
    .line 135
    invoke-virtual {v3, v2}, Landroidx/recyclerview/widget/d0;->j(Landroid/view/View;)I

    .line 136
    .line 137
    .line 138
    move-result v2

    .line 139
    if-le v2, v0, :cond_9

    .line 140
    .line 141
    goto :goto_5

    .line 142
    :cond_9
    add-int/lit8 v1, v1, -0x1

    .line 143
    .line 144
    goto :goto_4

    .line 145
    :cond_a
    :goto_5
    invoke-virtual {p0, p1, p2, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->O0(Landroidx/recyclerview/widget/a1;II)V

    .line 146
    .line 147
    .line 148
    goto :goto_8

    .line 149
    :cond_b
    const/4 v1, 0x0

    .line 150
    :goto_6
    if-ge v1, p2, :cond_e

    .line 151
    .line 152
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/t0;->t(I)Landroid/view/View;

    .line 153
    .line 154
    .line 155
    move-result-object v2

    .line 156
    iget-object v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 157
    .line 158
    invoke-virtual {v4, v2}, Landroidx/recyclerview/widget/d0;->b(Landroid/view/View;)I

    .line 159
    .line 160
    .line 161
    move-result v4

    .line 162
    if-gt v4, v0, :cond_d

    .line 163
    .line 164
    iget-object v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 165
    .line 166
    invoke-virtual {v4, v2}, Landroidx/recyclerview/widget/d0;->j(Landroid/view/View;)I

    .line 167
    .line 168
    .line 169
    move-result v2

    .line 170
    if-le v2, v0, :cond_c

    .line 171
    .line 172
    goto :goto_7

    .line 173
    :cond_c
    add-int/lit8 v1, v1, 0x1

    .line 174
    .line 175
    goto :goto_6

    .line 176
    :cond_d
    :goto_7
    invoke-virtual {p0, p1, v3, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->O0(Landroidx/recyclerview/widget/a1;II)V

    .line 177
    .line 178
    .line 179
    :cond_e
    :goto_8
    return-void
.end method

.method public final O(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 3

    .line 1
    invoke-super {p0, p1}, Landroidx/recyclerview/widget/t0;->O(Landroid/view/accessibility/AccessibilityEvent;)V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    .line 5
    .line 6
    .line 7
    move-result v0

    .line 8
    if-lez v0, :cond_2

    .line 9
    .line 10
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    const/4 v1, 0x0

    .line 15
    invoke-virtual {p0, v1, v0, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->E0(IIZ)Landroid/view/View;

    .line 16
    .line 17
    .line 18
    move-result-object v0

    .line 19
    const/4 v2, -0x1

    .line 20
    if-nez v0, :cond_0

    .line 21
    .line 22
    const/4 v0, -0x1

    .line 23
    goto :goto_0

    .line 24
    :cond_0
    invoke-static {v0}, Landroidx/recyclerview/widget/t0;->C(Landroid/view/View;)I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    :goto_0
    invoke-virtual {p1, v0}, Landroid/view/accessibility/AccessibilityRecord;->setFromIndex(I)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    .line 32
    .line 33
    .line 34
    move-result v0

    .line 35
    add-int/lit8 v0, v0, -0x1

    .line 36
    .line 37
    invoke-virtual {p0, v0, v2, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->E0(IIZ)Landroid/view/View;

    .line 38
    .line 39
    .line 40
    move-result-object v0

    .line 41
    if-nez v0, :cond_1

    .line 42
    .line 43
    goto :goto_1

    .line 44
    :cond_1
    invoke-static {v0}, Landroidx/recyclerview/widget/t0;->C(Landroid/view/View;)I

    .line 45
    .line 46
    .line 47
    move-result v2

    .line 48
    :goto_1
    invoke-virtual {p1, v2}, Landroid/view/accessibility/AccessibilityRecord;->setToIndex(I)V

    .line 49
    .line 50
    .line 51
    :cond_2
    return-void
.end method

.method public final O0(Landroidx/recyclerview/widget/a1;II)V
    .locals 1

    .line 1
    if-ne p2, p3, :cond_0

    .line 2
    .line 3
    return-void

    .line 4
    :cond_0
    if-le p3, p2, :cond_1

    .line 5
    .line 6
    :goto_0
    add-int/lit8 p3, p3, -0x1

    .line 7
    .line 8
    if-lt p3, p2, :cond_2

    .line 9
    .line 10
    invoke-virtual {p0, p3}, Landroidx/recyclerview/widget/t0;->t(I)Landroid/view/View;

    .line 11
    .line 12
    .line 13
    move-result-object v0

    .line 14
    invoke-virtual {p0, p3}, Landroidx/recyclerview/widget/t0;->f0(I)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/a1;->h(Landroid/view/View;)V

    .line 18
    .line 19
    .line 20
    goto :goto_0

    .line 21
    :cond_1
    :goto_1
    if-le p2, p3, :cond_2

    .line 22
    .line 23
    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/t0;->t(I)Landroid/view/View;

    .line 24
    .line 25
    .line 26
    move-result-object v0

    .line 27
    invoke-virtual {p0, p2}, Landroidx/recyclerview/widget/t0;->f0(I)V

    .line 28
    .line 29
    .line 30
    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/a1;->h(Landroid/view/View;)V

    .line 31
    .line 32
    .line 33
    add-int/lit8 p2, p2, -0x1

    .line 34
    .line 35
    goto :goto_1

    .line 36
    :cond_2
    return-void
.end method

.method public final P0()V
    .locals 2

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    const/4 v1, 0x1

    if-eq v0, v1, :cond_1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->K0()Z

    move-result v0

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->s:Z

    xor-int/2addr v0, v1

    goto :goto_1

    :cond_1
    :goto_0
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->s:Z

    :goto_1
    iput-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    return-void
.end method

.method public final Q0(ILandroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;)I
    .locals 5

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    move-result v0

    const/4 v1, 0x0

    if-eqz v0, :cond_4

    if-nez p1, :cond_0

    goto :goto_1

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->z0()V

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    const/4 v2, 0x1

    iput-boolean v2, v0, Landroidx/recyclerview/widget/a0;->a:Z

    if-lez p1, :cond_1

    const/4 v0, 0x1

    goto :goto_0

    :cond_1
    const/4 v0, -0x1

    :goto_0
    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result v3

    invoke-virtual {p0, v0, v3, v2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->T0(IIZLandroidx/recyclerview/widget/e1;)V

    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    iget v4, v2, Landroidx/recyclerview/widget/a0;->g:I

    invoke-virtual {p0, p2, v2, p3, v1}, Landroidx/recyclerview/widget/LinearLayoutManager;->A0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/a0;Landroidx/recyclerview/widget/e1;Z)I

    move-result p2

    add-int/2addr p2, v4

    if-gez p2, :cond_2

    return v1

    :cond_2
    if-le v3, p2, :cond_3

    mul-int p1, v0, p2

    :cond_3
    iget-object p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    neg-int p3, p1

    invoke-virtual {p2, p3}, Landroidx/recyclerview/widget/d0;->l(I)V

    iget-object p2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    iput p1, p2, Landroidx/recyclerview/widget/a0;->j:I

    return p1

    :cond_4
    :goto_1
    return v1
.end method

.method public final R0(I)V
    .locals 3

    .line 1
    if-eqz p1, :cond_1

    const/4 v0, 0x1

    if-ne p1, v0, :cond_0

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "invalid orientation:"

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    :goto_0
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->b(Ljava/lang/String;)V

    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    if-ne p1, v0, :cond_2

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    if-nez v0, :cond_3

    :cond_2
    invoke-static {p0, p1}, Landroidx/recyclerview/widget/e0;->a(Landroidx/recyclerview/widget/t0;I)Landroidx/recyclerview/widget/d0;

    move-result-object v0

    iput-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->z:Landroidx/recyclerview/widget/y;

    iput-object v0, v1, Landroidx/recyclerview/widget/y;->a:Landroidx/recyclerview/widget/d0;

    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->h0()V

    :cond_3
    return-void
.end method

.method public S0(Z)V
    .locals 1

    .line 1
    const/4 v0, 0x0

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->b(Ljava/lang/String;)V

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->u:Z

    if-ne v0, p1, :cond_0

    return-void

    :cond_0
    iput-boolean p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->u:Z

    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->h0()V

    return-void
.end method

.method public final T0(IIZLandroidx/recyclerview/widget/e1;)V
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 2
    .line 3
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 4
    .line 5
    invoke-virtual {v1}, Landroidx/recyclerview/widget/d0;->g()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x0

    .line 10
    const/4 v3, 0x1

    .line 11
    if-nez v1, :cond_0

    .line 12
    .line 13
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 14
    .line 15
    invoke-virtual {v1}, Landroidx/recyclerview/widget/d0;->e()I

    .line 16
    .line 17
    .line 18
    move-result v1

    .line 19
    if-nez v1, :cond_0

    .line 20
    .line 21
    const/4 v1, 0x1

    .line 22
    goto :goto_0

    .line 23
    :cond_0
    const/4 v1, 0x0

    .line 24
    :goto_0
    iput-boolean v1, v0, Landroidx/recyclerview/widget/a0;->l:Z

    .line 25
    .line 26
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 27
    .line 28
    iput p1, v0, Landroidx/recyclerview/widget/a0;->f:I

    .line 29
    .line 30
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->C:[I

    .line 31
    .line 32
    aput v2, v0, v2

    .line 33
    .line 34
    aput v2, v0, v3

    .line 35
    .line 36
    invoke-virtual {p4}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 37
    .line 38
    .line 39
    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 40
    .line 41
    iget p4, p4, Landroidx/recyclerview/widget/a0;->f:I

    .line 42
    .line 43
    aput v2, v0, v2

    .line 44
    .line 45
    aput v2, v0, v3

    .line 46
    .line 47
    invoke-static {v2, v2}, Ljava/lang/Math;->max(II)I

    .line 48
    .line 49
    .line 50
    move-result p4

    .line 51
    aget v0, v0, v3

    .line 52
    .line 53
    invoke-static {v2, v0}, Ljava/lang/Math;->max(II)I

    .line 54
    .line 55
    .line 56
    move-result v0

    .line 57
    if-ne p1, v3, :cond_1

    .line 58
    .line 59
    const/4 v2, 0x1

    .line 60
    :cond_1
    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 61
    .line 62
    if-eqz v2, :cond_2

    .line 63
    .line 64
    move v1, v0

    .line 65
    goto :goto_1

    .line 66
    :cond_2
    move v1, p4

    .line 67
    :goto_1
    iput v1, p1, Landroidx/recyclerview/widget/a0;->h:I

    .line 68
    .line 69
    if-eqz v2, :cond_3

    .line 70
    .line 71
    goto :goto_2

    .line 72
    :cond_3
    move p4, v0

    .line 73
    :goto_2
    iput p4, p1, Landroidx/recyclerview/widget/a0;->i:I

    .line 74
    .line 75
    const/4 p4, -0x1

    .line 76
    if-eqz v2, :cond_5

    .line 77
    .line 78
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 79
    .line 80
    iget v2, v0, Landroidx/recyclerview/widget/d0;->d:I

    .line 81
    .line 82
    iget-object v0, v0, Landroidx/recyclerview/widget/e0;->a:Landroidx/recyclerview/widget/t0;

    .line 83
    .line 84
    packed-switch v2, :pswitch_data_0

    .line 85
    .line 86
    .line 87
    goto :goto_3

    .line 88
    :pswitch_0
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->A()I

    .line 89
    .line 90
    .line 91
    move-result v0

    .line 92
    goto :goto_4

    .line 93
    :goto_3
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->y()I

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    :goto_4
    add-int/2addr v0, v1

    .line 98
    iput v0, p1, Landroidx/recyclerview/widget/a0;->h:I

    .line 99
    .line 100
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->I0()Landroid/view/View;

    .line 101
    .line 102
    .line 103
    move-result-object p1

    .line 104
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 105
    .line 106
    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    .line 107
    .line 108
    if-eqz v1, :cond_4

    .line 109
    .line 110
    const/4 v3, -0x1

    .line 111
    :cond_4
    iput v3, v0, Landroidx/recyclerview/widget/a0;->e:I

    .line 112
    .line 113
    invoke-static {p1}, Landroidx/recyclerview/widget/t0;->C(Landroid/view/View;)I

    .line 114
    .line 115
    .line 116
    move-result p4

    .line 117
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 118
    .line 119
    iget v2, v1, Landroidx/recyclerview/widget/a0;->e:I

    .line 120
    .line 121
    add-int/2addr p4, v2

    .line 122
    iput p4, v0, Landroidx/recyclerview/widget/a0;->d:I

    .line 123
    .line 124
    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 125
    .line 126
    invoke-virtual {p4, p1}, Landroidx/recyclerview/widget/d0;->b(Landroid/view/View;)I

    .line 127
    .line 128
    .line 129
    move-result p4

    .line 130
    iput p4, v1, Landroidx/recyclerview/widget/a0;->b:I

    .line 131
    .line 132
    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 133
    .line 134
    invoke-virtual {p4, p1}, Landroidx/recyclerview/widget/d0;->b(Landroid/view/View;)I

    .line 135
    .line 136
    .line 137
    move-result p1

    .line 138
    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 139
    .line 140
    invoke-virtual {p4}, Landroidx/recyclerview/widget/d0;->f()I

    .line 141
    .line 142
    .line 143
    move-result p4

    .line 144
    sub-int/2addr p1, p4

    .line 145
    goto :goto_6

    .line 146
    :cond_5
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->J0()Landroid/view/View;

    .line 147
    .line 148
    .line 149
    move-result-object p1

    .line 150
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 151
    .line 152
    iget v1, v0, Landroidx/recyclerview/widget/a0;->h:I

    .line 153
    .line 154
    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 155
    .line 156
    invoke-virtual {v2}, Landroidx/recyclerview/widget/d0;->h()I

    .line 157
    .line 158
    .line 159
    move-result v2

    .line 160
    add-int/2addr v2, v1

    .line 161
    iput v2, v0, Landroidx/recyclerview/widget/a0;->h:I

    .line 162
    .line 163
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 164
    .line 165
    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    .line 166
    .line 167
    if-eqz v1, :cond_6

    .line 168
    .line 169
    goto :goto_5

    .line 170
    :cond_6
    const/4 v3, -0x1

    .line 171
    :goto_5
    iput v3, v0, Landroidx/recyclerview/widget/a0;->e:I

    .line 172
    .line 173
    invoke-static {p1}, Landroidx/recyclerview/widget/t0;->C(Landroid/view/View;)I

    .line 174
    .line 175
    .line 176
    move-result p4

    .line 177
    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 178
    .line 179
    iget v2, v1, Landroidx/recyclerview/widget/a0;->e:I

    .line 180
    .line 181
    add-int/2addr p4, v2

    .line 182
    iput p4, v0, Landroidx/recyclerview/widget/a0;->d:I

    .line 183
    .line 184
    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 185
    .line 186
    invoke-virtual {p4, p1}, Landroidx/recyclerview/widget/d0;->d(Landroid/view/View;)I

    .line 187
    .line 188
    .line 189
    move-result p4

    .line 190
    iput p4, v1, Landroidx/recyclerview/widget/a0;->b:I

    .line 191
    .line 192
    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 193
    .line 194
    invoke-virtual {p4, p1}, Landroidx/recyclerview/widget/d0;->d(Landroid/view/View;)I

    .line 195
    .line 196
    .line 197
    move-result p1

    .line 198
    neg-int p1, p1

    .line 199
    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 200
    .line 201
    invoke-virtual {p4}, Landroidx/recyclerview/widget/d0;->h()I

    .line 202
    .line 203
    .line 204
    move-result p4

    .line 205
    add-int/2addr p1, p4

    .line 206
    :goto_6
    iget-object p4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 207
    .line 208
    iput p2, p4, Landroidx/recyclerview/widget/a0;->c:I

    .line 209
    .line 210
    if-eqz p3, :cond_7

    .line 211
    .line 212
    sub-int/2addr p2, p1

    .line 213
    iput p2, p4, Landroidx/recyclerview/widget/a0;->c:I

    .line 214
    .line 215
    :cond_7
    iput p1, p4, Landroidx/recyclerview/widget/a0;->g:I

    .line 216
    .line 217
    return-void

    .line 218
    nop

    .line 219
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public final U0(II)V
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/d0;->f()I

    move-result v1

    sub-int/2addr v1, p2

    iput v1, v0, Landroidx/recyclerview/widget/a0;->c:I

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    const/4 v2, 0x1

    if-eqz v1, :cond_0

    const/4 v1, -0x1

    goto :goto_0

    :cond_0
    const/4 v1, 0x1

    :goto_0
    iput v1, v0, Landroidx/recyclerview/widget/a0;->e:I

    iput p1, v0, Landroidx/recyclerview/widget/a0;->d:I

    iput v2, v0, Landroidx/recyclerview/widget/a0;->f:I

    iput p2, v0, Landroidx/recyclerview/widget/a0;->b:I

    const/high16 p1, -0x80000000

    iput p1, v0, Landroidx/recyclerview/widget/a0;->g:I

    return-void
.end method

.method public final V0(II)V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/d0;->h()I

    move-result v1

    sub-int v1, p2, v1

    iput v1, v0, Landroidx/recyclerview/widget/a0;->c:I

    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    iput p1, v0, Landroidx/recyclerview/widget/a0;->d:I

    iget-boolean p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    const/4 v1, -0x1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, -0x1

    :goto_0
    iput p1, v0, Landroidx/recyclerview/widget/a0;->e:I

    iput v1, v0, Landroidx/recyclerview/widget/a0;->f:I

    iput p2, v0, Landroidx/recyclerview/widget/a0;->b:I

    const/high16 p1, -0x80000000

    iput p1, v0, Landroidx/recyclerview/widget/a0;->g:I

    return-void
.end method

.method public X(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;)V
    .locals 17

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move-object/from16 v1, p1

    .line 4
    .line 5
    move-object/from16 v2, p2

    .line 6
    .line 7
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->y:Landroidx/recyclerview/widget/c0;

    .line 8
    .line 9
    const/4 v4, -0x1

    .line 10
    if-nez v3, :cond_0

    .line 11
    .line 12
    iget v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->w:I

    .line 13
    .line 14
    if-eq v3, v4, :cond_1

    .line 15
    .line 16
    :cond_0
    invoke-virtual/range {p2 .. p2}, Landroidx/recyclerview/widget/e1;->b()I

    .line 17
    .line 18
    .line 19
    move-result v3

    .line 20
    if-nez v3, :cond_1

    .line 21
    .line 22
    invoke-virtual/range {p0 .. p1}, Landroidx/recyclerview/widget/t0;->c0(Landroidx/recyclerview/widget/a1;)V

    .line 23
    .line 24
    .line 25
    return-void

    .line 26
    :cond_1
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->y:Landroidx/recyclerview/widget/c0;

    .line 27
    .line 28
    const/4 v5, 0x1

    .line 29
    const/4 v6, 0x0

    .line 30
    if-eqz v3, :cond_3

    .line 31
    .line 32
    iget v3, v3, Landroidx/recyclerview/widget/c0;->a:I

    .line 33
    .line 34
    if-ltz v3, :cond_2

    .line 35
    .line 36
    const/4 v7, 0x1

    .line 37
    goto :goto_0

    .line 38
    :cond_2
    const/4 v7, 0x0

    .line 39
    :goto_0
    if-eqz v7, :cond_3

    .line 40
    .line 41
    iput v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->w:I

    .line 42
    .line 43
    :cond_3
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->z0()V

    .line 44
    .line 45
    .line 46
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 47
    .line 48
    iput-boolean v6, v3, Landroidx/recyclerview/widget/a0;->a:Z

    .line 49
    .line 50
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->P0()V

    .line 51
    .line 52
    .line 53
    iget-object v3, v0, Landroidx/recyclerview/widget/t0;->b:Landroidx/recyclerview/widget/RecyclerView;

    .line 54
    .line 55
    if-nez v3, :cond_5

    .line 56
    .line 57
    :cond_4
    :goto_1
    const/4 v3, 0x0

    .line 58
    goto :goto_2

    .line 59
    :cond_5
    invoke-virtual {v3}, Landroid/view/ViewGroup;->getFocusedChild()Landroid/view/View;

    .line 60
    .line 61
    .line 62
    move-result-object v3

    .line 63
    if-eqz v3, :cond_4

    .line 64
    .line 65
    iget-object v8, v0, Landroidx/recyclerview/widget/t0;->a:Landroidx/recyclerview/widget/e;

    .line 66
    .line 67
    invoke-virtual {v8, v3}, Landroidx/recyclerview/widget/e;->j(Landroid/view/View;)Z

    .line 68
    .line 69
    .line 70
    move-result v8

    .line 71
    if-eqz v8, :cond_6

    .line 72
    .line 73
    goto :goto_1

    .line 74
    :cond_6
    :goto_2
    iget-object v8, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->z:Landroidx/recyclerview/widget/y;

    .line 75
    .line 76
    iget-boolean v9, v8, Landroidx/recyclerview/widget/y;->e:Z

    .line 77
    .line 78
    const/high16 v10, -0x80000000

    .line 79
    .line 80
    if-eqz v9, :cond_9

    .line 81
    .line 82
    iget v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->w:I

    .line 83
    .line 84
    if-ne v9, v4, :cond_9

    .line 85
    .line 86
    iget-object v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->y:Landroidx/recyclerview/widget/c0;

    .line 87
    .line 88
    if-eqz v9, :cond_7

    .line 89
    .line 90
    goto :goto_3

    .line 91
    :cond_7
    if-eqz v3, :cond_2e

    .line 92
    .line 93
    iget-object v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 94
    .line 95
    invoke-virtual {v9, v3}, Landroidx/recyclerview/widget/d0;->d(Landroid/view/View;)I

    .line 96
    .line 97
    .line 98
    move-result v9

    .line 99
    iget-object v11, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 100
    .line 101
    invoke-virtual {v11}, Landroidx/recyclerview/widget/d0;->f()I

    .line 102
    .line 103
    .line 104
    move-result v11

    .line 105
    if-ge v9, v11, :cond_8

    .line 106
    .line 107
    iget-object v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 108
    .line 109
    invoke-virtual {v9, v3}, Landroidx/recyclerview/widget/d0;->b(Landroid/view/View;)I

    .line 110
    .line 111
    .line 112
    move-result v9

    .line 113
    iget-object v11, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 114
    .line 115
    invoke-virtual {v11}, Landroidx/recyclerview/widget/d0;->h()I

    .line 116
    .line 117
    .line 118
    move-result v11

    .line 119
    if-gt v9, v11, :cond_2e

    .line 120
    .line 121
    :cond_8
    invoke-static {v3}, Landroidx/recyclerview/widget/t0;->C(Landroid/view/View;)I

    .line 122
    .line 123
    .line 124
    move-result v9

    .line 125
    invoke-virtual {v8, v3, v9}, Landroidx/recyclerview/widget/y;->b(Landroid/view/View;I)V

    .line 126
    .line 127
    .line 128
    goto/16 :goto_1d

    .line 129
    .line 130
    :cond_9
    :goto_3
    invoke-virtual {v8}, Landroidx/recyclerview/widget/y;->c()V

    .line 131
    .line 132
    .line 133
    iget-boolean v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    .line 134
    .line 135
    iget-boolean v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->u:Z

    .line 136
    .line 137
    xor-int/2addr v3, v9

    .line 138
    iput-boolean v3, v8, Landroidx/recyclerview/widget/y;->d:Z

    .line 139
    .line 140
    iget-boolean v3, v2, Landroidx/recyclerview/widget/e1;->f:Z

    .line 141
    .line 142
    if-nez v3, :cond_1c

    .line 143
    .line 144
    iget v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->w:I

    .line 145
    .line 146
    if-ne v3, v4, :cond_a

    .line 147
    .line 148
    goto/16 :goto_10

    .line 149
    .line 150
    :cond_a
    if-ltz v3, :cond_1b

    .line 151
    .line 152
    invoke-virtual/range {p2 .. p2}, Landroidx/recyclerview/widget/e1;->b()I

    .line 153
    .line 154
    .line 155
    move-result v9

    .line 156
    if-lt v3, v9, :cond_b

    .line 157
    .line 158
    goto/16 :goto_f

    .line 159
    .line 160
    :cond_b
    iget v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->w:I

    .line 161
    .line 162
    iput v3, v8, Landroidx/recyclerview/widget/y;->b:I

    .line 163
    .line 164
    iget-object v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->y:Landroidx/recyclerview/widget/c0;

    .line 165
    .line 166
    if-eqz v9, :cond_e

    .line 167
    .line 168
    iget v11, v9, Landroidx/recyclerview/widget/c0;->a:I

    .line 169
    .line 170
    if-ltz v11, :cond_c

    .line 171
    .line 172
    const/4 v11, 0x1

    .line 173
    goto :goto_4

    .line 174
    :cond_c
    const/4 v11, 0x0

    .line 175
    :goto_4
    if-eqz v11, :cond_e

    .line 176
    .line 177
    iget-boolean v3, v9, Landroidx/recyclerview/widget/c0;->c:Z

    .line 178
    .line 179
    iput-boolean v3, v8, Landroidx/recyclerview/widget/y;->d:Z

    .line 180
    .line 181
    if-eqz v3, :cond_d

    .line 182
    .line 183
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 184
    .line 185
    invoke-virtual {v3}, Landroidx/recyclerview/widget/d0;->f()I

    .line 186
    .line 187
    .line 188
    move-result v3

    .line 189
    iget-object v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->y:Landroidx/recyclerview/widget/c0;

    .line 190
    .line 191
    iget v9, v9, Landroidx/recyclerview/widget/c0;->b:I

    .line 192
    .line 193
    goto/16 :goto_b

    .line 194
    .line 195
    :cond_d
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 196
    .line 197
    invoke-virtual {v3}, Landroidx/recyclerview/widget/d0;->h()I

    .line 198
    .line 199
    .line 200
    move-result v3

    .line 201
    iget-object v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->y:Landroidx/recyclerview/widget/c0;

    .line 202
    .line 203
    iget v9, v9, Landroidx/recyclerview/widget/c0;->b:I

    .line 204
    .line 205
    goto/16 :goto_c

    .line 206
    .line 207
    :cond_e
    iget v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->x:I

    .line 208
    .line 209
    if-ne v9, v10, :cond_19

    .line 210
    .line 211
    invoke-virtual {v0, v3}, Landroidx/recyclerview/widget/LinearLayoutManager;->p(I)Landroid/view/View;

    .line 212
    .line 213
    .line 214
    move-result-object v3

    .line 215
    if-eqz v3, :cond_14

    .line 216
    .line 217
    iget-object v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 218
    .line 219
    invoke-virtual {v9, v3}, Landroidx/recyclerview/widget/d0;->c(Landroid/view/View;)I

    .line 220
    .line 221
    .line 222
    move-result v9

    .line 223
    iget-object v11, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 224
    .line 225
    invoke-virtual {v11}, Landroidx/recyclerview/widget/d0;->i()I

    .line 226
    .line 227
    .line 228
    move-result v11

    .line 229
    if-le v9, v11, :cond_f

    .line 230
    .line 231
    goto/16 :goto_9

    .line 232
    .line 233
    :cond_f
    iget-object v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 234
    .line 235
    invoke-virtual {v9, v3}, Landroidx/recyclerview/widget/d0;->d(Landroid/view/View;)I

    .line 236
    .line 237
    .line 238
    move-result v9

    .line 239
    iget-object v11, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 240
    .line 241
    invoke-virtual {v11}, Landroidx/recyclerview/widget/d0;->h()I

    .line 242
    .line 243
    .line 244
    move-result v11

    .line 245
    sub-int/2addr v9, v11

    .line 246
    if-gez v9, :cond_10

    .line 247
    .line 248
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 249
    .line 250
    invoke-virtual {v3}, Landroidx/recyclerview/widget/d0;->h()I

    .line 251
    .line 252
    .line 253
    move-result v3

    .line 254
    iput v3, v8, Landroidx/recyclerview/widget/y;->c:I

    .line 255
    .line 256
    iput-boolean v6, v8, Landroidx/recyclerview/widget/y;->d:Z

    .line 257
    .line 258
    goto/16 :goto_e

    .line 259
    .line 260
    :cond_10
    iget-object v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 261
    .line 262
    invoke-virtual {v9}, Landroidx/recyclerview/widget/d0;->f()I

    .line 263
    .line 264
    .line 265
    move-result v9

    .line 266
    iget-object v11, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 267
    .line 268
    invoke-virtual {v11, v3}, Landroidx/recyclerview/widget/d0;->b(Landroid/view/View;)I

    .line 269
    .line 270
    .line 271
    move-result v11

    .line 272
    sub-int/2addr v9, v11

    .line 273
    if-gez v9, :cond_11

    .line 274
    .line 275
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 276
    .line 277
    invoke-virtual {v3}, Landroidx/recyclerview/widget/d0;->f()I

    .line 278
    .line 279
    .line 280
    move-result v3

    .line 281
    iput v3, v8, Landroidx/recyclerview/widget/y;->c:I

    .line 282
    .line 283
    iput-boolean v5, v8, Landroidx/recyclerview/widget/y;->d:Z

    .line 284
    .line 285
    goto/16 :goto_e

    .line 286
    .line 287
    :cond_11
    iget-boolean v9, v8, Landroidx/recyclerview/widget/y;->d:Z

    .line 288
    .line 289
    if-eqz v9, :cond_13

    .line 290
    .line 291
    iget-object v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 292
    .line 293
    invoke-virtual {v9, v3}, Landroidx/recyclerview/widget/d0;->b(Landroid/view/View;)I

    .line 294
    .line 295
    .line 296
    move-result v3

    .line 297
    iget-object v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 298
    .line 299
    iget v11, v9, Landroidx/recyclerview/widget/e0;->b:I

    .line 300
    .line 301
    if-ne v10, v11, :cond_12

    .line 302
    .line 303
    const/4 v11, 0x0

    .line 304
    goto :goto_5

    .line 305
    :cond_12
    invoke-virtual {v9}, Landroidx/recyclerview/widget/d0;->i()I

    .line 306
    .line 307
    .line 308
    move-result v11

    .line 309
    iget v9, v9, Landroidx/recyclerview/widget/e0;->b:I

    .line 310
    .line 311
    sub-int/2addr v11, v9

    .line 312
    :goto_5
    add-int/2addr v11, v3

    .line 313
    goto :goto_6

    .line 314
    :cond_13
    iget-object v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 315
    .line 316
    invoke-virtual {v9, v3}, Landroidx/recyclerview/widget/d0;->d(Landroid/view/View;)I

    .line 317
    .line 318
    .line 319
    move-result v11

    .line 320
    :goto_6
    iput v11, v8, Landroidx/recyclerview/widget/y;->c:I

    .line 321
    .line 322
    goto :goto_e

    .line 323
    :cond_14
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/t0;->u()I

    .line 324
    .line 325
    .line 326
    move-result v3

    .line 327
    if-lez v3, :cond_17

    .line 328
    .line 329
    invoke-virtual {v0, v6}, Landroidx/recyclerview/widget/t0;->t(I)Landroid/view/View;

    .line 330
    .line 331
    .line 332
    move-result-object v3

    .line 333
    invoke-static {v3}, Landroidx/recyclerview/widget/t0;->C(Landroid/view/View;)I

    .line 334
    .line 335
    .line 336
    move-result v3

    .line 337
    iget v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->w:I

    .line 338
    .line 339
    if-ge v9, v3, :cond_15

    .line 340
    .line 341
    const/4 v3, 0x1

    .line 342
    goto :goto_7

    .line 343
    :cond_15
    const/4 v3, 0x0

    .line 344
    :goto_7
    iget-boolean v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    .line 345
    .line 346
    if-ne v3, v9, :cond_16

    .line 347
    .line 348
    const/4 v3, 0x1

    .line 349
    goto :goto_8

    .line 350
    :cond_16
    const/4 v3, 0x0

    .line 351
    :goto_8
    iput-boolean v3, v8, Landroidx/recyclerview/widget/y;->d:Z

    .line 352
    .line 353
    :cond_17
    :goto_9
    iget-boolean v3, v8, Landroidx/recyclerview/widget/y;->d:Z

    .line 354
    .line 355
    if-eqz v3, :cond_18

    .line 356
    .line 357
    iget-object v3, v8, Landroidx/recyclerview/widget/y;->a:Landroidx/recyclerview/widget/d0;

    .line 358
    .line 359
    invoke-virtual {v3}, Landroidx/recyclerview/widget/d0;->f()I

    .line 360
    .line 361
    .line 362
    move-result v3

    .line 363
    goto :goto_a

    .line 364
    :cond_18
    iget-object v3, v8, Landroidx/recyclerview/widget/y;->a:Landroidx/recyclerview/widget/d0;

    .line 365
    .line 366
    invoke-virtual {v3}, Landroidx/recyclerview/widget/d0;->h()I

    .line 367
    .line 368
    .line 369
    move-result v3

    .line 370
    :goto_a
    iput v3, v8, Landroidx/recyclerview/widget/y;->c:I

    .line 371
    .line 372
    goto :goto_e

    .line 373
    :cond_19
    iget-boolean v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    .line 374
    .line 375
    iput-boolean v3, v8, Landroidx/recyclerview/widget/y;->d:Z

    .line 376
    .line 377
    if-eqz v3, :cond_1a

    .line 378
    .line 379
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 380
    .line 381
    invoke-virtual {v3}, Landroidx/recyclerview/widget/d0;->f()I

    .line 382
    .line 383
    .line 384
    move-result v3

    .line 385
    iget v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->x:I

    .line 386
    .line 387
    :goto_b
    sub-int/2addr v3, v9

    .line 388
    goto :goto_d

    .line 389
    :cond_1a
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 390
    .line 391
    invoke-virtual {v3}, Landroidx/recyclerview/widget/d0;->h()I

    .line 392
    .line 393
    .line 394
    move-result v3

    .line 395
    iget v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->x:I

    .line 396
    .line 397
    :goto_c
    add-int/2addr v3, v9

    .line 398
    :goto_d
    iput v3, v8, Landroidx/recyclerview/widget/y;->c:I

    .line 399
    .line 400
    :goto_e
    const/4 v3, 0x1

    .line 401
    goto :goto_11

    .line 402
    :cond_1b
    :goto_f
    iput v4, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->w:I

    .line 403
    .line 404
    iput v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->x:I

    .line 405
    .line 406
    :cond_1c
    :goto_10
    const/4 v3, 0x0

    .line 407
    :goto_11
    if-eqz v3, :cond_1d

    .line 408
    .line 409
    goto/16 :goto_1c

    .line 410
    .line 411
    :cond_1d
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/t0;->u()I

    .line 412
    .line 413
    .line 414
    move-result v3

    .line 415
    if-nez v3, :cond_1e

    .line 416
    .line 417
    goto/16 :goto_18

    .line 418
    .line 419
    :cond_1e
    iget-object v3, v0, Landroidx/recyclerview/widget/t0;->b:Landroidx/recyclerview/widget/RecyclerView;

    .line 420
    .line 421
    if-nez v3, :cond_20

    .line 422
    .line 423
    :cond_1f
    :goto_12
    const/4 v3, 0x0

    .line 424
    goto :goto_13

    .line 425
    :cond_20
    invoke-virtual {v3}, Landroid/view/ViewGroup;->getFocusedChild()Landroid/view/View;

    .line 426
    .line 427
    .line 428
    move-result-object v3

    .line 429
    if-eqz v3, :cond_1f

    .line 430
    .line 431
    iget-object v9, v0, Landroidx/recyclerview/widget/t0;->a:Landroidx/recyclerview/widget/e;

    .line 432
    .line 433
    invoke-virtual {v9, v3}, Landroidx/recyclerview/widget/e;->j(Landroid/view/View;)Z

    .line 434
    .line 435
    .line 436
    move-result v9

    .line 437
    if-eqz v9, :cond_21

    .line 438
    .line 439
    goto :goto_12

    .line 440
    :cond_21
    :goto_13
    if-eqz v3, :cond_23

    .line 441
    .line 442
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 443
    .line 444
    .line 445
    move-result-object v9

    .line 446
    check-cast v9, Landroidx/recyclerview/widget/u0;

    .line 447
    .line 448
    invoke-virtual {v9}, Landroidx/recyclerview/widget/u0;->c()Z

    .line 449
    .line 450
    .line 451
    move-result v11

    .line 452
    if-nez v11, :cond_22

    .line 453
    .line 454
    invoke-virtual {v9}, Landroidx/recyclerview/widget/u0;->a()I

    .line 455
    .line 456
    .line 457
    move-result v11

    .line 458
    if-ltz v11, :cond_22

    .line 459
    .line 460
    invoke-virtual {v9}, Landroidx/recyclerview/widget/u0;->a()I

    .line 461
    .line 462
    .line 463
    move-result v9

    .line 464
    invoke-virtual/range {p2 .. p2}, Landroidx/recyclerview/widget/e1;->b()I

    .line 465
    .line 466
    .line 467
    move-result v11

    .line 468
    if-ge v9, v11, :cond_22

    .line 469
    .line 470
    const/4 v9, 0x1

    .line 471
    goto :goto_14

    .line 472
    :cond_22
    const/4 v9, 0x0

    .line 473
    :goto_14
    if-eqz v9, :cond_23

    .line 474
    .line 475
    invoke-static {v3}, Landroidx/recyclerview/widget/t0;->C(Landroid/view/View;)I

    .line 476
    .line 477
    .line 478
    move-result v9

    .line 479
    invoke-virtual {v8, v3, v9}, Landroidx/recyclerview/widget/y;->b(Landroid/view/View;I)V

    .line 480
    .line 481
    .line 482
    goto :goto_17

    .line 483
    :cond_23
    iget-boolean v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->r:Z

    .line 484
    .line 485
    iget-boolean v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->u:Z

    .line 486
    .line 487
    if-eq v3, v9, :cond_24

    .line 488
    .line 489
    goto :goto_18

    .line 490
    :cond_24
    iget-boolean v3, v8, Landroidx/recyclerview/widget/y;->d:Z

    .line 491
    .line 492
    invoke-virtual {v0, v1, v2, v3, v9}, Landroidx/recyclerview/widget/LinearLayoutManager;->F0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;ZZ)Landroid/view/View;

    .line 493
    .line 494
    .line 495
    move-result-object v3

    .line 496
    if-eqz v3, :cond_2a

    .line 497
    .line 498
    invoke-static {v3}, Landroidx/recyclerview/widget/t0;->C(Landroid/view/View;)I

    .line 499
    .line 500
    .line 501
    move-result v9

    .line 502
    invoke-virtual {v8, v3, v9}, Landroidx/recyclerview/widget/y;->a(Landroid/view/View;I)V

    .line 503
    .line 504
    .line 505
    iget-boolean v9, v2, Landroidx/recyclerview/widget/e1;->f:Z

    .line 506
    .line 507
    if-nez v9, :cond_29

    .line 508
    .line 509
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->t0()Z

    .line 510
    .line 511
    .line 512
    move-result v9

    .line 513
    if-eqz v9, :cond_29

    .line 514
    .line 515
    iget-object v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 516
    .line 517
    invoke-virtual {v9, v3}, Landroidx/recyclerview/widget/d0;->d(Landroid/view/View;)I

    .line 518
    .line 519
    .line 520
    move-result v9

    .line 521
    iget-object v11, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 522
    .line 523
    invoke-virtual {v11, v3}, Landroidx/recyclerview/widget/d0;->b(Landroid/view/View;)I

    .line 524
    .line 525
    .line 526
    move-result v3

    .line 527
    iget-object v11, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 528
    .line 529
    invoke-virtual {v11}, Landroidx/recyclerview/widget/d0;->h()I

    .line 530
    .line 531
    .line 532
    move-result v11

    .line 533
    iget-object v12, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 534
    .line 535
    invoke-virtual {v12}, Landroidx/recyclerview/widget/d0;->f()I

    .line 536
    .line 537
    .line 538
    move-result v12

    .line 539
    if-gt v3, v11, :cond_25

    .line 540
    .line 541
    if-ge v9, v11, :cond_25

    .line 542
    .line 543
    const/4 v13, 0x1

    .line 544
    goto :goto_15

    .line 545
    :cond_25
    const/4 v13, 0x0

    .line 546
    :goto_15
    if-lt v9, v12, :cond_26

    .line 547
    .line 548
    if-le v3, v12, :cond_26

    .line 549
    .line 550
    const/4 v3, 0x1

    .line 551
    goto :goto_16

    .line 552
    :cond_26
    const/4 v3, 0x0

    .line 553
    :goto_16
    if-nez v13, :cond_27

    .line 554
    .line 555
    if-eqz v3, :cond_29

    .line 556
    .line 557
    :cond_27
    iget-boolean v3, v8, Landroidx/recyclerview/widget/y;->d:Z

    .line 558
    .line 559
    if-eqz v3, :cond_28

    .line 560
    .line 561
    move v11, v12

    .line 562
    :cond_28
    iput v11, v8, Landroidx/recyclerview/widget/y;->c:I

    .line 563
    .line 564
    :cond_29
    :goto_17
    const/4 v3, 0x1

    .line 565
    goto :goto_19

    .line 566
    :cond_2a
    :goto_18
    const/4 v3, 0x0

    .line 567
    :goto_19
    if-eqz v3, :cond_2b

    .line 568
    .line 569
    goto :goto_1c

    .line 570
    :cond_2b
    iget-boolean v3, v8, Landroidx/recyclerview/widget/y;->d:Z

    .line 571
    .line 572
    if-eqz v3, :cond_2c

    .line 573
    .line 574
    iget-object v3, v8, Landroidx/recyclerview/widget/y;->a:Landroidx/recyclerview/widget/d0;

    .line 575
    .line 576
    invoke-virtual {v3}, Landroidx/recyclerview/widget/d0;->f()I

    .line 577
    .line 578
    .line 579
    move-result v3

    .line 580
    goto :goto_1a

    .line 581
    :cond_2c
    iget-object v3, v8, Landroidx/recyclerview/widget/y;->a:Landroidx/recyclerview/widget/d0;

    .line 582
    .line 583
    invoke-virtual {v3}, Landroidx/recyclerview/widget/d0;->h()I

    .line 584
    .line 585
    .line 586
    move-result v3

    .line 587
    :goto_1a
    iput v3, v8, Landroidx/recyclerview/widget/y;->c:I

    .line 588
    .line 589
    iget-boolean v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->u:Z

    .line 590
    .line 591
    if-eqz v3, :cond_2d

    .line 592
    .line 593
    invoke-virtual/range {p2 .. p2}, Landroidx/recyclerview/widget/e1;->b()I

    .line 594
    .line 595
    .line 596
    move-result v3

    .line 597
    add-int/2addr v3, v4

    .line 598
    goto :goto_1b

    .line 599
    :cond_2d
    const/4 v3, 0x0

    .line 600
    :goto_1b
    iput v3, v8, Landroidx/recyclerview/widget/y;->b:I

    .line 601
    .line 602
    :goto_1c
    iput-boolean v5, v8, Landroidx/recyclerview/widget/y;->e:Z

    .line 603
    .line 604
    :cond_2e
    :goto_1d
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 605
    .line 606
    iget v9, v3, Landroidx/recyclerview/widget/a0;->j:I

    .line 607
    .line 608
    if-ltz v9, :cond_2f

    .line 609
    .line 610
    const/4 v9, 0x1

    .line 611
    goto :goto_1e

    .line 612
    :cond_2f
    const/4 v9, -0x1

    .line 613
    :goto_1e
    iput v9, v3, Landroidx/recyclerview/widget/a0;->f:I

    .line 614
    .line 615
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->C:[I

    .line 616
    .line 617
    aput v6, v3, v6

    .line 618
    .line 619
    aput v6, v3, v5

    .line 620
    .line 621
    invoke-virtual/range {p2 .. p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 622
    .line 623
    .line 624
    iget-object v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 625
    .line 626
    iget v9, v9, Landroidx/recyclerview/widget/a0;->f:I

    .line 627
    .line 628
    aput v6, v3, v6

    .line 629
    .line 630
    aput v6, v3, v5

    .line 631
    .line 632
    invoke-static {v6, v6}, Ljava/lang/Math;->max(II)I

    .line 633
    .line 634
    .line 635
    move-result v9

    .line 636
    iget-object v11, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 637
    .line 638
    invoke-virtual {v11}, Landroidx/recyclerview/widget/d0;->h()I

    .line 639
    .line 640
    .line 641
    move-result v11

    .line 642
    add-int/2addr v11, v9

    .line 643
    aget v3, v3, v5

    .line 644
    .line 645
    invoke-static {v6, v3}, Ljava/lang/Math;->max(II)I

    .line 646
    .line 647
    .line 648
    move-result v3

    .line 649
    iget-object v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 650
    .line 651
    iget v12, v9, Landroidx/recyclerview/widget/d0;->d:I

    .line 652
    .line 653
    iget-object v9, v9, Landroidx/recyclerview/widget/e0;->a:Landroidx/recyclerview/widget/t0;

    .line 654
    .line 655
    packed-switch v12, :pswitch_data_0

    .line 656
    .line 657
    .line 658
    goto :goto_1f

    .line 659
    :pswitch_0
    invoke-virtual {v9}, Landroidx/recyclerview/widget/t0;->A()I

    .line 660
    .line 661
    .line 662
    move-result v9

    .line 663
    goto :goto_20

    .line 664
    :goto_1f
    invoke-virtual {v9}, Landroidx/recyclerview/widget/t0;->y()I

    .line 665
    .line 666
    .line 667
    move-result v9

    .line 668
    :goto_20
    add-int/2addr v9, v3

    .line 669
    iget-boolean v3, v2, Landroidx/recyclerview/widget/e1;->f:Z

    .line 670
    .line 671
    if-eqz v3, :cond_32

    .line 672
    .line 673
    iget v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->w:I

    .line 674
    .line 675
    if-eq v3, v4, :cond_32

    .line 676
    .line 677
    iget v12, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->x:I

    .line 678
    .line 679
    if-eq v12, v10, :cond_32

    .line 680
    .line 681
    invoke-virtual {v0, v3}, Landroidx/recyclerview/widget/LinearLayoutManager;->p(I)Landroid/view/View;

    .line 682
    .line 683
    .line 684
    move-result-object v3

    .line 685
    if-eqz v3, :cond_32

    .line 686
    .line 687
    iget-boolean v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    .line 688
    .line 689
    if-eqz v10, :cond_30

    .line 690
    .line 691
    iget-object v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 692
    .line 693
    invoke-virtual {v10}, Landroidx/recyclerview/widget/d0;->f()I

    .line 694
    .line 695
    .line 696
    move-result v10

    .line 697
    iget-object v12, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 698
    .line 699
    invoke-virtual {v12, v3}, Landroidx/recyclerview/widget/d0;->b(Landroid/view/View;)I

    .line 700
    .line 701
    .line 702
    move-result v3

    .line 703
    sub-int/2addr v10, v3

    .line 704
    iget v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->x:I

    .line 705
    .line 706
    goto :goto_21

    .line 707
    :cond_30
    iget-object v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 708
    .line 709
    invoke-virtual {v10, v3}, Landroidx/recyclerview/widget/d0;->d(Landroid/view/View;)I

    .line 710
    .line 711
    .line 712
    move-result v3

    .line 713
    iget-object v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 714
    .line 715
    invoke-virtual {v10}, Landroidx/recyclerview/widget/d0;->h()I

    .line 716
    .line 717
    .line 718
    move-result v10

    .line 719
    sub-int/2addr v3, v10

    .line 720
    iget v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->x:I

    .line 721
    .line 722
    :goto_21
    sub-int/2addr v10, v3

    .line 723
    if-lez v10, :cond_31

    .line 724
    .line 725
    add-int/2addr v11, v10

    .line 726
    goto :goto_22

    .line 727
    :cond_31
    sub-int/2addr v9, v10

    .line 728
    :cond_32
    :goto_22
    iget-boolean v3, v8, Landroidx/recyclerview/widget/y;->d:Z

    .line 729
    .line 730
    if-eqz v3, :cond_33

    .line 731
    .line 732
    iget-boolean v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    .line 733
    .line 734
    if-eqz v3, :cond_34

    .line 735
    .line 736
    goto :goto_23

    .line 737
    :cond_33
    iget-boolean v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    .line 738
    .line 739
    if-eqz v3, :cond_35

    .line 740
    .line 741
    :cond_34
    const/4 v3, -0x1

    .line 742
    goto :goto_24

    .line 743
    :cond_35
    :goto_23
    const/4 v3, 0x1

    .line 744
    :goto_24
    invoke-virtual {v0, v1, v2, v8, v3}, Landroidx/recyclerview/widget/LinearLayoutManager;->M0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;Landroidx/recyclerview/widget/y;I)V

    .line 745
    .line 746
    .line 747
    invoke-virtual/range {p0 .. p1}, Landroidx/recyclerview/widget/t0;->o(Landroidx/recyclerview/widget/a1;)V

    .line 748
    .line 749
    .line 750
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 751
    .line 752
    iget-object v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 753
    .line 754
    invoke-virtual {v10}, Landroidx/recyclerview/widget/d0;->g()I

    .line 755
    .line 756
    .line 757
    move-result v10

    .line 758
    if-nez v10, :cond_36

    .line 759
    .line 760
    iget-object v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 761
    .line 762
    invoke-virtual {v10}, Landroidx/recyclerview/widget/d0;->e()I

    .line 763
    .line 764
    .line 765
    move-result v10

    .line 766
    if-nez v10, :cond_36

    .line 767
    .line 768
    const/4 v10, 0x1

    .line 769
    goto :goto_25

    .line 770
    :cond_36
    const/4 v10, 0x0

    .line 771
    :goto_25
    iput-boolean v10, v3, Landroidx/recyclerview/widget/a0;->l:Z

    .line 772
    .line 773
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 774
    .line 775
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 776
    .line 777
    .line 778
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 779
    .line 780
    iput v6, v3, Landroidx/recyclerview/widget/a0;->i:I

    .line 781
    .line 782
    iget-boolean v3, v8, Landroidx/recyclerview/widget/y;->d:Z

    .line 783
    .line 784
    if-eqz v3, :cond_38

    .line 785
    .line 786
    iget v3, v8, Landroidx/recyclerview/widget/y;->b:I

    .line 787
    .line 788
    iget v10, v8, Landroidx/recyclerview/widget/y;->c:I

    .line 789
    .line 790
    invoke-virtual {v0, v3, v10}, Landroidx/recyclerview/widget/LinearLayoutManager;->V0(II)V

    .line 791
    .line 792
    .line 793
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 794
    .line 795
    iput v11, v3, Landroidx/recyclerview/widget/a0;->h:I

    .line 796
    .line 797
    invoke-virtual {v0, v1, v3, v2, v6}, Landroidx/recyclerview/widget/LinearLayoutManager;->A0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/a0;Landroidx/recyclerview/widget/e1;Z)I

    .line 798
    .line 799
    .line 800
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 801
    .line 802
    iget v10, v3, Landroidx/recyclerview/widget/a0;->b:I

    .line 803
    .line 804
    iget v11, v3, Landroidx/recyclerview/widget/a0;->d:I

    .line 805
    .line 806
    iget v3, v3, Landroidx/recyclerview/widget/a0;->c:I

    .line 807
    .line 808
    if-lez v3, :cond_37

    .line 809
    .line 810
    add-int/2addr v9, v3

    .line 811
    :cond_37
    iget v3, v8, Landroidx/recyclerview/widget/y;->b:I

    .line 812
    .line 813
    iget v12, v8, Landroidx/recyclerview/widget/y;->c:I

    .line 814
    .line 815
    invoke-virtual {v0, v3, v12}, Landroidx/recyclerview/widget/LinearLayoutManager;->U0(II)V

    .line 816
    .line 817
    .line 818
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 819
    .line 820
    iput v9, v3, Landroidx/recyclerview/widget/a0;->h:I

    .line 821
    .line 822
    iget v9, v3, Landroidx/recyclerview/widget/a0;->d:I

    .line 823
    .line 824
    iget v12, v3, Landroidx/recyclerview/widget/a0;->e:I

    .line 825
    .line 826
    add-int/2addr v9, v12

    .line 827
    iput v9, v3, Landroidx/recyclerview/widget/a0;->d:I

    .line 828
    .line 829
    invoke-virtual {v0, v1, v3, v2, v6}, Landroidx/recyclerview/widget/LinearLayoutManager;->A0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/a0;Landroidx/recyclerview/widget/e1;Z)I

    .line 830
    .line 831
    .line 832
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 833
    .line 834
    iget v9, v3, Landroidx/recyclerview/widget/a0;->b:I

    .line 835
    .line 836
    iget v3, v3, Landroidx/recyclerview/widget/a0;->c:I

    .line 837
    .line 838
    if-lez v3, :cond_3b

    .line 839
    .line 840
    invoke-virtual {v0, v11, v10}, Landroidx/recyclerview/widget/LinearLayoutManager;->V0(II)V

    .line 841
    .line 842
    .line 843
    iget-object v10, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 844
    .line 845
    iput v3, v10, Landroidx/recyclerview/widget/a0;->h:I

    .line 846
    .line 847
    invoke-virtual {v0, v1, v10, v2, v6}, Landroidx/recyclerview/widget/LinearLayoutManager;->A0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/a0;Landroidx/recyclerview/widget/e1;Z)I

    .line 848
    .line 849
    .line 850
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 851
    .line 852
    iget v10, v3, Landroidx/recyclerview/widget/a0;->b:I

    .line 853
    .line 854
    goto :goto_26

    .line 855
    :cond_38
    iget v3, v8, Landroidx/recyclerview/widget/y;->b:I

    .line 856
    .line 857
    iget v10, v8, Landroidx/recyclerview/widget/y;->c:I

    .line 858
    .line 859
    invoke-virtual {v0, v3, v10}, Landroidx/recyclerview/widget/LinearLayoutManager;->U0(II)V

    .line 860
    .line 861
    .line 862
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 863
    .line 864
    iput v9, v3, Landroidx/recyclerview/widget/a0;->h:I

    .line 865
    .line 866
    invoke-virtual {v0, v1, v3, v2, v6}, Landroidx/recyclerview/widget/LinearLayoutManager;->A0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/a0;Landroidx/recyclerview/widget/e1;Z)I

    .line 867
    .line 868
    .line 869
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 870
    .line 871
    iget v9, v3, Landroidx/recyclerview/widget/a0;->b:I

    .line 872
    .line 873
    iget v10, v3, Landroidx/recyclerview/widget/a0;->d:I

    .line 874
    .line 875
    iget v3, v3, Landroidx/recyclerview/widget/a0;->c:I

    .line 876
    .line 877
    if-lez v3, :cond_39

    .line 878
    .line 879
    add-int/2addr v11, v3

    .line 880
    :cond_39
    iget v3, v8, Landroidx/recyclerview/widget/y;->b:I

    .line 881
    .line 882
    iget v12, v8, Landroidx/recyclerview/widget/y;->c:I

    .line 883
    .line 884
    invoke-virtual {v0, v3, v12}, Landroidx/recyclerview/widget/LinearLayoutManager;->V0(II)V

    .line 885
    .line 886
    .line 887
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 888
    .line 889
    iput v11, v3, Landroidx/recyclerview/widget/a0;->h:I

    .line 890
    .line 891
    iget v11, v3, Landroidx/recyclerview/widget/a0;->d:I

    .line 892
    .line 893
    iget v12, v3, Landroidx/recyclerview/widget/a0;->e:I

    .line 894
    .line 895
    add-int/2addr v11, v12

    .line 896
    iput v11, v3, Landroidx/recyclerview/widget/a0;->d:I

    .line 897
    .line 898
    invoke-virtual {v0, v1, v3, v2, v6}, Landroidx/recyclerview/widget/LinearLayoutManager;->A0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/a0;Landroidx/recyclerview/widget/e1;Z)I

    .line 899
    .line 900
    .line 901
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 902
    .line 903
    iget v11, v3, Landroidx/recyclerview/widget/a0;->b:I

    .line 904
    .line 905
    iget v3, v3, Landroidx/recyclerview/widget/a0;->c:I

    .line 906
    .line 907
    if-lez v3, :cond_3a

    .line 908
    .line 909
    invoke-virtual {v0, v10, v9}, Landroidx/recyclerview/widget/LinearLayoutManager;->U0(II)V

    .line 910
    .line 911
    .line 912
    iget-object v9, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 913
    .line 914
    iput v3, v9, Landroidx/recyclerview/widget/a0;->h:I

    .line 915
    .line 916
    invoke-virtual {v0, v1, v9, v2, v6}, Landroidx/recyclerview/widget/LinearLayoutManager;->A0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/a0;Landroidx/recyclerview/widget/e1;Z)I

    .line 917
    .line 918
    .line 919
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 920
    .line 921
    iget v3, v3, Landroidx/recyclerview/widget/a0;->b:I

    .line 922
    .line 923
    move v9, v3

    .line 924
    :cond_3a
    move v10, v11

    .line 925
    :cond_3b
    :goto_26
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/t0;->u()I

    .line 926
    .line 927
    .line 928
    move-result v3

    .line 929
    if-lez v3, :cond_3d

    .line 930
    .line 931
    iget-boolean v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    .line 932
    .line 933
    iget-boolean v11, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->u:Z

    .line 934
    .line 935
    xor-int/2addr v3, v11

    .line 936
    if-eqz v3, :cond_3c

    .line 937
    .line 938
    invoke-virtual {v0, v9, v1, v2, v5}, Landroidx/recyclerview/widget/LinearLayoutManager;->G0(ILandroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;Z)I

    .line 939
    .line 940
    .line 941
    move-result v3

    .line 942
    add-int/2addr v10, v3

    .line 943
    add-int/2addr v9, v3

    .line 944
    invoke-virtual {v0, v10, v1, v2, v6}, Landroidx/recyclerview/widget/LinearLayoutManager;->H0(ILandroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;Z)I

    .line 945
    .line 946
    .line 947
    move-result v3

    .line 948
    goto :goto_27

    .line 949
    :cond_3c
    invoke-virtual {v0, v10, v1, v2, v5}, Landroidx/recyclerview/widget/LinearLayoutManager;->H0(ILandroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;Z)I

    .line 950
    .line 951
    .line 952
    move-result v3

    .line 953
    add-int/2addr v10, v3

    .line 954
    add-int/2addr v9, v3

    .line 955
    invoke-virtual {v0, v9, v1, v2, v6}, Landroidx/recyclerview/widget/LinearLayoutManager;->G0(ILandroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;Z)I

    .line 956
    .line 957
    .line 958
    move-result v3

    .line 959
    :goto_27
    add-int/2addr v10, v3

    .line 960
    add-int/2addr v9, v3

    .line 961
    :cond_3d
    iget-boolean v3, v2, Landroidx/recyclerview/widget/e1;->j:Z

    .line 962
    .line 963
    if-eqz v3, :cond_46

    .line 964
    .line 965
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/t0;->u()I

    .line 966
    .line 967
    .line 968
    move-result v3

    .line 969
    if-eqz v3, :cond_46

    .line 970
    .line 971
    iget-boolean v3, v2, Landroidx/recyclerview/widget/e1;->f:Z

    .line 972
    .line 973
    if-nez v3, :cond_46

    .line 974
    .line 975
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->t0()Z

    .line 976
    .line 977
    .line 978
    move-result v3

    .line 979
    if-nez v3, :cond_3e

    .line 980
    .line 981
    goto/16 :goto_2e

    .line 982
    .line 983
    :cond_3e
    iget-object v3, v1, Landroidx/recyclerview/widget/a1;->d:Ljava/util/List;

    .line 984
    .line 985
    invoke-interface {v3}, Ljava/util/List;->size()I

    .line 986
    .line 987
    .line 988
    move-result v11

    .line 989
    invoke-virtual {v0, v6}, Landroidx/recyclerview/widget/t0;->t(I)Landroid/view/View;

    .line 990
    .line 991
    .line 992
    move-result-object v12

    .line 993
    invoke-static {v12}, Landroidx/recyclerview/widget/t0;->C(Landroid/view/View;)I

    .line 994
    .line 995
    .line 996
    move-result v12

    .line 997
    const/4 v13, 0x0

    .line 998
    const/4 v14, 0x0

    .line 999
    const/4 v15, 0x0

    .line 1000
    :goto_28
    if-ge v13, v11, :cond_43

    .line 1001
    .line 1002
    invoke-interface {v3, v13}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 1003
    .line 1004
    .line 1005
    move-result-object v16

    .line 1006
    move-object/from16 v5, v16

    .line 1007
    .line 1008
    check-cast v5, Landroidx/recyclerview/widget/i1;

    .line 1009
    .line 1010
    invoke-virtual {v5}, Landroidx/recyclerview/widget/i1;->isRemoved()Z

    .line 1011
    .line 1012
    .line 1013
    move-result v16

    .line 1014
    if-eqz v16, :cond_3f

    .line 1015
    .line 1016
    goto :goto_2b

    .line 1017
    :cond_3f
    invoke-virtual {v5}, Landroidx/recyclerview/widget/i1;->getLayoutPosition()I

    .line 1018
    .line 1019
    .line 1020
    move-result v7

    .line 1021
    if-ge v7, v12, :cond_40

    .line 1022
    .line 1023
    const/4 v7, 0x1

    .line 1024
    goto :goto_29

    .line 1025
    :cond_40
    const/4 v7, 0x0

    .line 1026
    :goto_29
    iget-boolean v6, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    .line 1027
    .line 1028
    if-eq v7, v6, :cond_41

    .line 1029
    .line 1030
    const/4 v6, -0x1

    .line 1031
    goto :goto_2a

    .line 1032
    :cond_41
    const/4 v6, 0x1

    .line 1033
    :goto_2a
    iget-object v7, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 1034
    .line 1035
    iget-object v5, v5, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 1036
    .line 1037
    invoke-virtual {v7, v5}, Landroidx/recyclerview/widget/d0;->c(Landroid/view/View;)I

    .line 1038
    .line 1039
    .line 1040
    move-result v5

    .line 1041
    if-ne v6, v4, :cond_42

    .line 1042
    .line 1043
    add-int/2addr v14, v5

    .line 1044
    goto :goto_2b

    .line 1045
    :cond_42
    add-int/2addr v15, v5

    .line 1046
    :goto_2b
    add-int/lit8 v13, v13, 0x1

    .line 1047
    .line 1048
    const/4 v5, 0x1

    .line 1049
    const/4 v6, 0x0

    .line 1050
    goto :goto_28

    .line 1051
    :cond_43
    iget-object v4, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 1052
    .line 1053
    iput-object v3, v4, Landroidx/recyclerview/widget/a0;->k:Ljava/util/List;

    .line 1054
    .line 1055
    if-lez v14, :cond_44

    .line 1056
    .line 1057
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->J0()Landroid/view/View;

    .line 1058
    .line 1059
    .line 1060
    move-result-object v3

    .line 1061
    invoke-static {v3}, Landroidx/recyclerview/widget/t0;->C(Landroid/view/View;)I

    .line 1062
    .line 1063
    .line 1064
    move-result v3

    .line 1065
    invoke-virtual {v0, v3, v10}, Landroidx/recyclerview/widget/LinearLayoutManager;->V0(II)V

    .line 1066
    .line 1067
    .line 1068
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 1069
    .line 1070
    iput v14, v3, Landroidx/recyclerview/widget/a0;->h:I

    .line 1071
    .line 1072
    const/4 v4, 0x0

    .line 1073
    iput v4, v3, Landroidx/recyclerview/widget/a0;->c:I

    .line 1074
    .line 1075
    const/4 v5, 0x0

    .line 1076
    invoke-virtual {v3, v5}, Landroidx/recyclerview/widget/a0;->a(Landroid/view/View;)V

    .line 1077
    .line 1078
    .line 1079
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 1080
    .line 1081
    invoke-virtual {v0, v1, v3, v2, v4}, Landroidx/recyclerview/widget/LinearLayoutManager;->A0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/a0;Landroidx/recyclerview/widget/e1;Z)I

    .line 1082
    .line 1083
    .line 1084
    goto :goto_2c

    .line 1085
    :cond_44
    const/4 v4, 0x0

    .line 1086
    :goto_2c
    if-lez v15, :cond_45

    .line 1087
    .line 1088
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->I0()Landroid/view/View;

    .line 1089
    .line 1090
    .line 1091
    move-result-object v3

    .line 1092
    invoke-static {v3}, Landroidx/recyclerview/widget/t0;->C(Landroid/view/View;)I

    .line 1093
    .line 1094
    .line 1095
    move-result v3

    .line 1096
    invoke-virtual {v0, v3, v9}, Landroidx/recyclerview/widget/LinearLayoutManager;->U0(II)V

    .line 1097
    .line 1098
    .line 1099
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 1100
    .line 1101
    iput v15, v3, Landroidx/recyclerview/widget/a0;->h:I

    .line 1102
    .line 1103
    iput v4, v3, Landroidx/recyclerview/widget/a0;->c:I

    .line 1104
    .line 1105
    const/4 v5, 0x0

    .line 1106
    invoke-virtual {v3, v5}, Landroidx/recyclerview/widget/a0;->a(Landroid/view/View;)V

    .line 1107
    .line 1108
    .line 1109
    iget-object v3, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 1110
    .line 1111
    invoke-virtual {v0, v1, v3, v2, v4}, Landroidx/recyclerview/widget/LinearLayoutManager;->A0(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/a0;Landroidx/recyclerview/widget/e1;Z)I

    .line 1112
    .line 1113
    .line 1114
    goto :goto_2d

    .line 1115
    :cond_45
    const/4 v5, 0x0

    .line 1116
    :goto_2d
    iget-object v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 1117
    .line 1118
    iput-object v5, v1, Landroidx/recyclerview/widget/a0;->k:Ljava/util/List;

    .line 1119
    .line 1120
    :cond_46
    :goto_2e
    iget-boolean v1, v2, Landroidx/recyclerview/widget/e1;->f:Z

    .line 1121
    .line 1122
    if-nez v1, :cond_47

    .line 1123
    .line 1124
    iget-object v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 1125
    .line 1126
    invoke-virtual {v1}, Landroidx/recyclerview/widget/d0;->i()I

    .line 1127
    .line 1128
    .line 1129
    move-result v2

    .line 1130
    iput v2, v1, Landroidx/recyclerview/widget/e0;->b:I

    .line 1131
    .line 1132
    goto :goto_2f

    .line 1133
    :cond_47
    invoke-virtual {v8}, Landroidx/recyclerview/widget/y;->c()V

    .line 1134
    .line 1135
    .line 1136
    :goto_2f
    iget-boolean v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->u:Z

    .line 1137
    .line 1138
    iput-boolean v1, v0, Landroidx/recyclerview/widget/LinearLayoutManager;->r:Z

    .line 1139
    .line 1140
    return-void

    .line 1141
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method

.method public Y(Landroidx/recyclerview/widget/e1;)V
    .locals 0

    .line 1
    const/4 p1, 0x0

    iput-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->y:Landroidx/recyclerview/widget/c0;

    const/4 p1, -0x1

    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->w:I

    const/high16 p1, -0x80000000

    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->x:I

    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->z:Landroidx/recyclerview/widget/y;

    invoke-virtual {p1}, Landroidx/recyclerview/widget/y;->c()V

    return-void
.end method

.method public final Z(Landroid/os/Parcelable;)V
    .locals 2

    .line 1
    instance-of v0, p1, Landroidx/recyclerview/widget/c0;

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    check-cast p1, Landroidx/recyclerview/widget/c0;

    .line 6
    .line 7
    iput-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->y:Landroidx/recyclerview/widget/c0;

    .line 8
    .line 9
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->w:I

    .line 10
    .line 11
    const/4 v1, -0x1

    .line 12
    if-eq v0, v1, :cond_0

    .line 13
    .line 14
    iput v1, p1, Landroidx/recyclerview/widget/c0;->a:I

    .line 15
    .line 16
    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->h0()V

    .line 17
    .line 18
    .line 19
    :cond_1
    return-void
.end method

.method public final a0()Landroid/os/Parcelable;
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->y:Landroidx/recyclerview/widget/c0;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    new-instance v1, Landroidx/recyclerview/widget/c0;

    .line 6
    .line 7
    invoke-direct {v1, v0}, Landroidx/recyclerview/widget/c0;-><init>(Landroidx/recyclerview/widget/c0;)V

    .line 8
    .line 9
    .line 10
    return-object v1

    .line 11
    :cond_0
    new-instance v0, Landroidx/recyclerview/widget/c0;

    .line 12
    .line 13
    invoke-direct {v0}, Landroidx/recyclerview/widget/c0;-><init>()V

    .line 14
    .line 15
    .line 16
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    .line 17
    .line 18
    .line 19
    move-result v1

    .line 20
    if-lez v1, :cond_2

    .line 21
    .line 22
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->z0()V

    .line 23
    .line 24
    .line 25
    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->r:Z

    .line 26
    .line 27
    iget-boolean v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    .line 28
    .line 29
    xor-int/2addr v1, v2

    .line 30
    iput-boolean v1, v0, Landroidx/recyclerview/widget/c0;->c:Z

    .line 31
    .line 32
    if-eqz v1, :cond_1

    .line 33
    .line 34
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->I0()Landroid/view/View;

    .line 35
    .line 36
    .line 37
    move-result-object v1

    .line 38
    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 39
    .line 40
    invoke-virtual {v2}, Landroidx/recyclerview/widget/d0;->f()I

    .line 41
    .line 42
    .line 43
    move-result v2

    .line 44
    iget-object v3, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 45
    .line 46
    invoke-virtual {v3, v1}, Landroidx/recyclerview/widget/d0;->b(Landroid/view/View;)I

    .line 47
    .line 48
    .line 49
    move-result v3

    .line 50
    sub-int/2addr v2, v3

    .line 51
    iput v2, v0, Landroidx/recyclerview/widget/c0;->b:I

    .line 52
    .line 53
    invoke-static {v1}, Landroidx/recyclerview/widget/t0;->C(Landroid/view/View;)I

    .line 54
    .line 55
    .line 56
    move-result v1

    .line 57
    iput v1, v0, Landroidx/recyclerview/widget/c0;->a:I

    .line 58
    .line 59
    goto :goto_0

    .line 60
    :cond_1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->J0()Landroid/view/View;

    .line 61
    .line 62
    .line 63
    move-result-object v1

    .line 64
    invoke-static {v1}, Landroidx/recyclerview/widget/t0;->C(Landroid/view/View;)I

    .line 65
    .line 66
    .line 67
    move-result v2

    .line 68
    iput v2, v0, Landroidx/recyclerview/widget/c0;->a:I

    .line 69
    .line 70
    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 71
    .line 72
    invoke-virtual {v2, v1}, Landroidx/recyclerview/widget/d0;->d(Landroid/view/View;)I

    .line 73
    .line 74
    .line 75
    move-result v1

    .line 76
    iget-object v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    .line 77
    .line 78
    invoke-virtual {v2}, Landroidx/recyclerview/widget/d0;->h()I

    .line 79
    .line 80
    .line 81
    move-result v2

    .line 82
    sub-int/2addr v1, v2

    .line 83
    iput v1, v0, Landroidx/recyclerview/widget/c0;->b:I

    .line 84
    .line 85
    goto :goto_0

    .line 86
    :cond_2
    const/4 v1, -0x1

    .line 87
    iput v1, v0, Landroidx/recyclerview/widget/c0;->a:I

    .line 88
    .line 89
    :goto_0
    return-object v0
.end method

.method public final b(Ljava/lang/String;)V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->y:Landroidx/recyclerview/widget/c0;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    iget-object v0, p0, Landroidx/recyclerview/widget/t0;->b:Landroidx/recyclerview/widget/RecyclerView;

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/RecyclerView;->h(Ljava/lang/String;)V

    .line 10
    .line 11
    .line 12
    :cond_0
    return-void
.end method

.method public final c()Z
    .locals 1

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final d()Z
    .locals 2

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    goto :goto_0

    :cond_0
    const/4 v1, 0x0

    :goto_0
    return v1
.end method

.method public final g(IILandroidx/recyclerview/widget/e1;Landroidx/recyclerview/widget/s;)V
    .locals 1

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    if-nez v0, :cond_0

    goto :goto_0

    :cond_0
    move p1, p2

    :goto_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    move-result p2

    if-eqz p2, :cond_3

    if-nez p1, :cond_1

    goto :goto_2

    :cond_1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->z0()V

    const/4 p2, 0x1

    if-lez p1, :cond_2

    const/4 v0, 0x1

    goto :goto_1

    :cond_2
    const/4 v0, -0x1

    :goto_1
    invoke-static {p1}, Ljava/lang/Math;->abs(I)I

    move-result p1

    invoke-virtual {p0, v0, p1, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->T0(IIZLandroidx/recyclerview/widget/e1;)V

    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    invoke-virtual {p0, p3, p1, p4}, Landroidx/recyclerview/widget/LinearLayoutManager;->u0(Landroidx/recyclerview/widget/e1;Landroidx/recyclerview/widget/a0;Landroidx/recyclerview/widget/s;)V

    :cond_3
    :goto_2
    return-void
.end method

.method public final h(ILandroidx/recyclerview/widget/s;)V
    .locals 6

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->y:Landroidx/recyclerview/widget/c0;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    const/4 v2, -0x1

    .line 5
    const/4 v3, 0x0

    .line 6
    if-eqz v0, :cond_1

    .line 7
    .line 8
    iget v4, v0, Landroidx/recyclerview/widget/c0;->a:I

    .line 9
    .line 10
    if-ltz v4, :cond_0

    .line 11
    .line 12
    const/4 v5, 0x1

    .line 13
    goto :goto_0

    .line 14
    :cond_0
    const/4 v5, 0x0

    .line 15
    :goto_0
    if-eqz v5, :cond_1

    .line 16
    .line 17
    iget-boolean v0, v0, Landroidx/recyclerview/widget/c0;->c:Z

    .line 18
    .line 19
    goto :goto_1

    .line 20
    :cond_1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->P0()V

    .line 21
    .line 22
    .line 23
    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    .line 24
    .line 25
    iget v4, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->w:I

    .line 26
    .line 27
    if-ne v4, v2, :cond_3

    .line 28
    .line 29
    if-eqz v0, :cond_2

    .line 30
    .line 31
    add-int/lit8 v4, p1, -0x1

    .line 32
    .line 33
    goto :goto_1

    .line 34
    :cond_2
    const/4 v4, 0x0

    .line 35
    :cond_3
    :goto_1
    if-eqz v0, :cond_4

    .line 36
    .line 37
    const/4 v1, -0x1

    .line 38
    :cond_4
    const/4 v0, 0x0

    .line 39
    :goto_2
    iget v2, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->B:I

    .line 40
    .line 41
    if-ge v0, v2, :cond_5

    .line 42
    .line 43
    if-ltz v4, :cond_5

    .line 44
    .line 45
    if-ge v4, p1, :cond_5

    .line 46
    .line 47
    invoke-virtual {p2, v4, v3}, Landroidx/recyclerview/widget/s;->a(II)V

    .line 48
    .line 49
    .line 50
    add-int/2addr v4, v1

    .line 51
    add-int/lit8 v0, v0, 0x1

    .line 52
    .line 53
    goto :goto_2

    .line 54
    :cond_5
    return-void
.end method

.method public final i(Landroidx/recyclerview/widget/e1;)I
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->v0(Landroidx/recyclerview/widget/e1;)I

    move-result p1

    return p1
.end method

.method public i0(ILandroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;)I
    .locals 2

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    const/4 v1, 0x1

    if-ne v0, v1, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->Q0(ILandroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;)I

    move-result p1

    return p1
.end method

.method public j(Landroidx/recyclerview/widget/e1;)I
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->w0(Landroidx/recyclerview/widget/e1;)I

    move-result p1

    return p1
.end method

.method public final j0(I)V
    .locals 1

    .line 1
    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->w:I

    .line 2
    .line 3
    const/high16 p1, -0x80000000

    .line 4
    .line 5
    iput p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->x:I

    .line 6
    .line 7
    iget-object p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->y:Landroidx/recyclerview/widget/c0;

    .line 8
    .line 9
    if-eqz p1, :cond_0

    .line 10
    .line 11
    const/4 v0, -0x1

    .line 12
    iput v0, p1, Landroidx/recyclerview/widget/c0;->a:I

    .line 13
    .line 14
    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->h0()V

    .line 15
    .line 16
    .line 17
    return-void
.end method

.method public k(Landroidx/recyclerview/widget/e1;)I
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->x0(Landroidx/recyclerview/widget/e1;)I

    move-result p1

    return p1
.end method

.method public k0(ILandroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;)I
    .locals 1

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-virtual {p0, p1, p2, p3}, Landroidx/recyclerview/widget/LinearLayoutManager;->Q0(ILandroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;)I

    move-result p1

    return p1
.end method

.method public final l(Landroidx/recyclerview/widget/e1;)I
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->v0(Landroidx/recyclerview/widget/e1;)I

    move-result p1

    return p1
.end method

.method public m(Landroidx/recyclerview/widget/e1;)I
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->w0(Landroidx/recyclerview/widget/e1;)I

    move-result p1

    return p1
.end method

.method public n(Landroidx/recyclerview/widget/e1;)I
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/LinearLayoutManager;->x0(Landroidx/recyclerview/widget/e1;)I

    move-result p1

    return p1
.end method

.method public final p(I)Landroid/view/View;
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return-object p1

    :cond_0
    const/4 v1, 0x0

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/t0;->t(I)Landroid/view/View;

    move-result-object v1

    invoke-static {v1}, Landroidx/recyclerview/widget/t0;->C(Landroid/view/View;)I

    move-result v1

    sub-int v1, p1, v1

    if-ltz v1, :cond_1

    if-ge v1, v0, :cond_1

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/t0;->t(I)Landroid/view/View;

    move-result-object v0

    invoke-static {v0}, Landroidx/recyclerview/widget/t0;->C(Landroid/view/View;)I

    move-result v1

    if-ne v1, p1, :cond_1

    return-object v0

    :cond_1
    invoke-super {p0, p1}, Landroidx/recyclerview/widget/t0;->p(I)Landroid/view/View;

    move-result-object p1

    return-object p1
.end method

.method public q()Landroidx/recyclerview/widget/u0;
    .locals 2

    .line 1
    new-instance v0, Landroidx/recyclerview/widget/u0;

    const/4 v1, -0x2

    invoke-direct {v0, v1, v1}, Landroidx/recyclerview/widget/u0;-><init>(II)V

    return-object v0
.end method

.method public final r0()Z
    .locals 6

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/t0;->l:I

    .line 2
    .line 3
    const/high16 v1, 0x40000000    # 2.0f

    .line 4
    .line 5
    const/4 v2, 0x0

    .line 6
    if-eq v0, v1, :cond_2

    .line 7
    .line 8
    iget v0, p0, Landroidx/recyclerview/widget/t0;->k:I

    .line 9
    .line 10
    if-eq v0, v1, :cond_2

    .line 11
    .line 12
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    const/4 v1, 0x0

    .line 17
    :goto_0
    const/4 v3, 0x1

    .line 18
    if-ge v1, v0, :cond_1

    .line 19
    .line 20
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/t0;->t(I)Landroid/view/View;

    .line 21
    .line 22
    .line 23
    move-result-object v4

    .line 24
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 25
    .line 26
    .line 27
    move-result-object v4

    .line 28
    iget v5, v4, Landroid/view/ViewGroup$LayoutParams;->width:I

    .line 29
    .line 30
    if-gez v5, :cond_0

    .line 31
    .line 32
    iget v4, v4, Landroid/view/ViewGroup$LayoutParams;->height:I

    .line 33
    .line 34
    if-gez v4, :cond_0

    .line 35
    .line 36
    const/4 v0, 0x1

    .line 37
    goto :goto_1

    .line 38
    :cond_0
    add-int/lit8 v1, v1, 0x1

    .line 39
    .line 40
    goto :goto_0

    .line 41
    :cond_1
    const/4 v0, 0x0

    .line 42
    :goto_1
    if-eqz v0, :cond_2

    .line 43
    .line 44
    const/4 v2, 0x1

    .line 45
    :cond_2
    return v2
.end method

.method public t0()Z
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->y:Landroidx/recyclerview/widget/c0;

    if-nez v0, :cond_0

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->r:Z

    iget-boolean v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->u:Z

    if-ne v0, v1, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public u0(Landroidx/recyclerview/widget/e1;Landroidx/recyclerview/widget/a0;Landroidx/recyclerview/widget/s;)V
    .locals 1

    .line 1
    iget v0, p2, Landroidx/recyclerview/widget/a0;->d:I

    if-ltz v0, :cond_0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/e1;->b()I

    move-result p1

    if-ge v0, p1, :cond_0

    const/4 p1, 0x0

    iget p2, p2, Landroidx/recyclerview/widget/a0;->g:I

    invoke-static {p1, p2}, Ljava/lang/Math;->max(II)I

    move-result p1

    invoke-virtual {p3, v0, p1}, Landroidx/recyclerview/widget/s;->a(II)V

    :cond_0
    return-void
.end method

.method public final v0(Landroidx/recyclerview/widget/e1;)I
    .locals 6

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->z0()V

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->v:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->C0(Z)Landroid/view/View;

    move-result-object v2

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->B0(Z)Landroid/view/View;

    move-result-object v3

    iget-boolean v5, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->v:Z

    move-object v0, p1

    move-object v4, p0

    invoke-static/range {v0 .. v5}, Lb0/d;->n(Landroidx/recyclerview/widget/e1;Landroidx/recyclerview/widget/e0;Landroid/view/View;Landroid/view/View;Landroidx/recyclerview/widget/t0;Z)I

    move-result p1

    return p1
.end method

.method public final w0(Landroidx/recyclerview/widget/e1;)I
    .locals 7

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->z0()V

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->v:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->C0(Z)Landroid/view/View;

    move-result-object v2

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->B0(Z)Landroid/view/View;

    move-result-object v3

    iget-boolean v5, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->v:Z

    iget-boolean v6, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->t:Z

    move-object v0, p1

    move-object v4, p0

    invoke-static/range {v0 .. v6}, Lb0/d;->o(Landroidx/recyclerview/widget/e1;Landroidx/recyclerview/widget/e0;Landroid/view/View;Landroid/view/View;Landroidx/recyclerview/widget/t0;ZZ)I

    move-result p1

    return p1
.end method

.method public final x0(Landroidx/recyclerview/widget/e1;)I
    .locals 6

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/t0;->u()I

    move-result v0

    if-nez v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->z0()V

    iget-object v1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->q:Landroidx/recyclerview/widget/d0;

    iget-boolean v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->v:Z

    xor-int/lit8 v0, v0, 0x1

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->C0(Z)Landroid/view/View;

    move-result-object v2

    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/LinearLayoutManager;->B0(Z)Landroid/view/View;

    move-result-object v3

    iget-boolean v5, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->v:Z

    move-object v0, p1

    move-object v4, p0

    invoke-static/range {v0 .. v5}, Lb0/d;->p(Landroidx/recyclerview/widget/e1;Landroidx/recyclerview/widget/e0;Landroid/view/View;Landroid/view/View;Landroidx/recyclerview/widget/t0;Z)I

    move-result p1

    return p1
.end method

.method public final y0(I)I
    .locals 4

    .line 1
    const/4 v0, -0x1

    const/4 v1, 0x1

    if-eq p1, v1, :cond_b

    const/4 v2, 0x2

    if-eq p1, v2, :cond_8

    const/16 v2, 0x11

    const/high16 v3, -0x80000000

    if-eq p1, v2, :cond_6

    const/16 v2, 0x21

    if-eq p1, v2, :cond_4

    const/16 v0, 0x42

    if-eq p1, v0, :cond_2

    const/16 v0, 0x82

    if-eq p1, v0, :cond_0

    return v3

    :cond_0
    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    if-ne p1, v1, :cond_1

    goto :goto_0

    :cond_1
    const/high16 v1, -0x80000000

    :goto_0
    return v1

    :cond_2
    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    if-nez p1, :cond_3

    goto :goto_1

    :cond_3
    const/high16 v1, -0x80000000

    :goto_1
    return v1

    :cond_4
    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    if-ne p1, v1, :cond_5

    goto :goto_2

    :cond_5
    const/high16 v0, -0x80000000

    :goto_2
    return v0

    :cond_6
    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    if-nez p1, :cond_7

    goto :goto_3

    :cond_7
    const/high16 v0, -0x80000000

    :goto_3
    return v0

    :cond_8
    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    if-ne p1, v1, :cond_9

    return v1

    :cond_9
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->K0()Z

    move-result p1

    if-eqz p1, :cond_a

    return v0

    :cond_a
    return v1

    :cond_b
    iget p1, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->o:I

    if-ne p1, v1, :cond_c

    return v0

    :cond_c
    invoke-virtual {p0}, Landroidx/recyclerview/widget/LinearLayoutManager;->K0()Z

    move-result p1

    if-eqz p1, :cond_d

    return v1

    :cond_d
    return v0
.end method

.method public final z0()V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    new-instance v0, Landroidx/recyclerview/widget/a0;

    .line 6
    .line 7
    invoke-direct {v0}, Landroidx/recyclerview/widget/a0;-><init>()V

    .line 8
    .line 9
    .line 10
    iput-object v0, p0, Landroidx/recyclerview/widget/LinearLayoutManager;->p:Landroidx/recyclerview/widget/a0;

    .line 11
    .line 12
    :cond_0
    return-void
.end method
