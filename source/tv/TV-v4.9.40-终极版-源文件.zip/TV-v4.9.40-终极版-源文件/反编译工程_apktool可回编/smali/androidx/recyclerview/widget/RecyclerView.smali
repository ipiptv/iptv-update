.class public Landroidx/recyclerview/widget/RecyclerView;
.super Landroid/view/ViewGroup;
.source "SourceFile"


# static fields
.field public static final A0:[I

.field public static final B0:F

.field public static final C0:Z

.field public static final D0:Z

.field public static final E0:Z

.field public static final F0:[Ljava/lang/Class;

.field public static final G0:Landroidx/recyclerview/widget/g0;

.field public static final H0:Landroidx/recyclerview/widget/f1;

.field public static y0:Z = false

.field public static z0:Z = false


# instance fields
.field public A:Z

.field public final B:Landroid/view/accessibility/AccessibilityManager;

.field public C:Z

.field public D:Z

.field public E:I

.field public F:I

.field public G:Landroidx/recyclerview/widget/m0;

.field public H:Landroid/widget/EdgeEffect;

.field public I:Landroid/widget/EdgeEffect;

.field public J:Landroid/widget/EdgeEffect;

.field public K:Landroid/widget/EdgeEffect;

.field public L:Landroidx/recyclerview/widget/o0;

.field public M:I

.field public N:I

.field public O:Landroid/view/VelocityTracker;

.field public P:I

.field public Q:I

.field public R:I

.field public S:I

.field public T:I

.field public final U:I

.field public final V:I

.field public final W:F

.field public final a:F

.field public final a0:F

.field public final b:Landroidx/recyclerview/widget/c1;

.field public b0:Z

.field public final c:Landroidx/recyclerview/widget/a1;

.field public final c0:Landroidx/recyclerview/widget/h1;

.field public d:Landroidx/recyclerview/widget/d1;

.field public d0:Landroidx/recyclerview/widget/u;

.field public e:Landroidx/recyclerview/widget/b;

.field public final e0:Landroidx/recyclerview/widget/s;

.field public f:Landroidx/recyclerview/widget/e;

.field public final f0:Landroidx/recyclerview/widget/e1;

.field public final g:Landroidx/recyclerview/widget/t1;

.field public g0:Landroidx/recyclerview/widget/x0;

.field public h:Z

.field public h0:Ljava/util/ArrayList;

.field public final i:Landroidx/recyclerview/widget/f0;

.field public i0:Z

.field public final j:Landroid/graphics/Rect;

.field public j0:Z

.field public final k:Landroid/graphics/Rect;

.field public final k0:Landroidx/recyclerview/widget/p0;

.field public final l:Landroid/graphics/RectF;

.field public l0:Z

.field public m:Landroidx/recyclerview/widget/i0;

.field public m0:Landroidx/recyclerview/widget/k1;

.field public n:Landroidx/recyclerview/widget/t0;

.field public final n0:[I

.field public final o:Ljava/util/ArrayList;

.field public o0:Lg/f;

.field public final p:Ljava/util/ArrayList;

.field public final p0:[I

.field public final q:Ljava/util/ArrayList;

.field public final q0:[I

.field public r:Landroidx/recyclerview/widget/w0;

.field public final r0:[I

.field public s:Z

.field public final s0:Ljava/util/ArrayList;

.field public t:Z

.field public final t0:Landroidx/recyclerview/widget/f0;

.field public u:Z

.field public u0:Z

.field public v:I

.field public v0:I

.field public w:Z

.field public w0:I

.field public x:Z

.field public final x0:Landroidx/recyclerview/widget/p0;

.field public y:Z

.field public z:I


# direct methods
.method public static constructor <clinit>()V
    .locals 4

    const v0, 0x1010436

    filled-new-array {v0}, [I

    move-result-object v0

    sput-object v0, Landroidx/recyclerview/widget/RecyclerView;->A0:[I

    const-wide v0, 0x3fe8f5c28f5c28f6L    # 0.78

    invoke-static {v0, v1}, Ljava/lang/Math;->log(D)D

    move-result-wide v0

    const-wide v2, 0x3feccccccccccccdL    # 0.9

    invoke-static {v2, v3}, Ljava/lang/Math;->log(D)D

    move-result-wide v2

    div-double/2addr v0, v2

    double-to-float v0, v0

    sput v0, Landroidx/recyclerview/widget/RecyclerView;->B0:F

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/4 v1, 0x0

    const/16 v2, 0x17

    const/4 v3, 0x1

    if-lt v0, v2, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    sput-boolean v0, Landroidx/recyclerview/widget/RecyclerView;->C0:Z

    sput-boolean v3, Landroidx/recyclerview/widget/RecyclerView;->D0:Z

    sput-boolean v3, Landroidx/recyclerview/widget/RecyclerView;->E0:Z

    const/4 v0, 0x4

    new-array v0, v0, [Ljava/lang/Class;

    const-class v2, Landroid/content/Context;

    aput-object v2, v0, v1

    const-class v1, Landroid/util/AttributeSet;

    aput-object v1, v0, v3

    sget-object v1, Ljava/lang/Integer;->TYPE:Ljava/lang/Class;

    const/4 v2, 0x2

    aput-object v1, v0, v2

    const/4 v2, 0x3

    aput-object v1, v0, v2

    sput-object v0, Landroidx/recyclerview/widget/RecyclerView;->F0:[Ljava/lang/Class;

    new-instance v0, Landroidx/recyclerview/widget/g0;

    invoke-direct {v0}, Landroidx/recyclerview/widget/g0;-><init>()V

    sput-object v0, Landroidx/recyclerview/widget/RecyclerView;->G0:Landroidx/recyclerview/widget/g0;

    new-instance v0, Landroidx/recyclerview/widget/f1;

    invoke-direct {v0}, Landroidx/recyclerview/widget/f1;-><init>()V

    sput-object v0, Landroidx/recyclerview/widget/RecyclerView;->H0:Landroidx/recyclerview/widget/f1;

    return-void
.end method

.method public constructor <init>(Landroid/content/Context;Landroid/util/AttributeSet;)V
    .locals 18

    .line 1
    move-object/from16 v10, p0

    .line 2
    .line 3
    move-object/from16 v11, p1

    .line 4
    .line 5
    move-object/from16 v12, p2

    .line 6
    .line 7
    const v0, 0x7f010015

    .line 8
    .line 9
    .line 10
    invoke-direct {v10, v11, v12, v0}, Landroid/view/ViewGroup;-><init>(Landroid/content/Context;Landroid/util/AttributeSet;I)V

    .line 11
    .line 12
    .line 13
    new-instance v1, Landroidx/recyclerview/widget/c1;

    .line 14
    .line 15
    invoke-direct {v1, v10}, Landroidx/recyclerview/widget/c1;-><init>(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 16
    .line 17
    .line 18
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->b:Landroidx/recyclerview/widget/c1;

    .line 19
    .line 20
    new-instance v1, Landroidx/recyclerview/widget/a1;

    .line 21
    .line 22
    invoke-direct {v1, v10}, Landroidx/recyclerview/widget/a1;-><init>(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 23
    .line 24
    .line 25
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 26
    .line 27
    new-instance v1, Landroidx/recyclerview/widget/t1;

    .line 28
    .line 29
    const/4 v13, 0x0

    .line 30
    invoke-direct {v1, v13}, Landroidx/recyclerview/widget/t1;-><init>(I)V

    .line 31
    .line 32
    .line 33
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->g:Landroidx/recyclerview/widget/t1;

    .line 34
    .line 35
    new-instance v1, Landroidx/recyclerview/widget/f0;

    .line 36
    .line 37
    invoke-direct {v1, v10, v13}, Landroidx/recyclerview/widget/f0;-><init>(Landroidx/recyclerview/widget/RecyclerView;I)V

    .line 38
    .line 39
    .line 40
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->i:Landroidx/recyclerview/widget/f0;

    .line 41
    .line 42
    new-instance v1, Landroid/graphics/Rect;

    .line 43
    .line 44
    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    .line 45
    .line 46
    .line 47
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->j:Landroid/graphics/Rect;

    .line 48
    .line 49
    new-instance v1, Landroid/graphics/Rect;

    .line 50
    .line 51
    invoke-direct {v1}, Landroid/graphics/Rect;-><init>()V

    .line 52
    .line 53
    .line 54
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->k:Landroid/graphics/Rect;

    .line 55
    .line 56
    new-instance v1, Landroid/graphics/RectF;

    .line 57
    .line 58
    invoke-direct {v1}, Landroid/graphics/RectF;-><init>()V

    .line 59
    .line 60
    .line 61
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->l:Landroid/graphics/RectF;

    .line 62
    .line 63
    new-instance v1, Ljava/util/ArrayList;

    .line 64
    .line 65
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 66
    .line 67
    .line 68
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->o:Ljava/util/ArrayList;

    .line 69
    .line 70
    new-instance v1, Ljava/util/ArrayList;

    .line 71
    .line 72
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 73
    .line 74
    .line 75
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->p:Ljava/util/ArrayList;

    .line 76
    .line 77
    new-instance v1, Ljava/util/ArrayList;

    .line 78
    .line 79
    invoke-direct {v1}, Ljava/util/ArrayList;-><init>()V

    .line 80
    .line 81
    .line 82
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->q:Ljava/util/ArrayList;

    .line 83
    .line 84
    iput v13, v10, Landroidx/recyclerview/widget/RecyclerView;->v:I

    .line 85
    .line 86
    iput-boolean v13, v10, Landroidx/recyclerview/widget/RecyclerView;->C:Z

    .line 87
    .line 88
    iput-boolean v13, v10, Landroidx/recyclerview/widget/RecyclerView;->D:Z

    .line 89
    .line 90
    iput v13, v10, Landroidx/recyclerview/widget/RecyclerView;->E:I

    .line 91
    .line 92
    iput v13, v10, Landroidx/recyclerview/widget/RecyclerView;->F:I

    .line 93
    .line 94
    sget-object v1, Landroidx/recyclerview/widget/RecyclerView;->H0:Landroidx/recyclerview/widget/f1;

    .line 95
    .line 96
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->G:Landroidx/recyclerview/widget/m0;

    .line 97
    .line 98
    new-instance v1, Landroidx/recyclerview/widget/l;

    .line 99
    .line 100
    invoke-direct {v1}, Landroidx/recyclerview/widget/l;-><init>()V

    .line 101
    .line 102
    .line 103
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 104
    .line 105
    iput v13, v10, Landroidx/recyclerview/widget/RecyclerView;->M:I

    .line 106
    .line 107
    const/4 v8, -0x1

    .line 108
    iput v8, v10, Landroidx/recyclerview/widget/RecyclerView;->N:I

    .line 109
    .line 110
    const/4 v1, 0x1

    .line 111
    iput v1, v10, Landroidx/recyclerview/widget/RecyclerView;->W:F

    .line 112
    .line 113
    iput v1, v10, Landroidx/recyclerview/widget/RecyclerView;->a0:F

    .line 114
    .line 115
    const/4 v14, 0x1

    .line 116
    iput-boolean v14, v10, Landroidx/recyclerview/widget/RecyclerView;->b0:Z

    .line 117
    .line 118
    new-instance v1, Landroidx/recyclerview/widget/h1;

    .line 119
    .line 120
    invoke-direct {v1, v10}, Landroidx/recyclerview/widget/h1;-><init>(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 121
    .line 122
    .line 123
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->c0:Landroidx/recyclerview/widget/h1;

    .line 124
    .line 125
    sget-boolean v1, Landroidx/recyclerview/widget/RecyclerView;->E0:Z

    .line 126
    .line 127
    if-eqz v1, :cond_0

    .line 128
    .line 129
    new-instance v1, Landroidx/recyclerview/widget/s;

    .line 130
    .line 131
    invoke-direct {v1}, Landroidx/recyclerview/widget/s;-><init>()V

    .line 132
    .line 133
    .line 134
    goto :goto_0

    .line 135
    :cond_0
    const/4 v1, 0x0

    .line 136
    :goto_0
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->e0:Landroidx/recyclerview/widget/s;

    .line 137
    .line 138
    new-instance v1, Landroidx/recyclerview/widget/e1;

    .line 139
    .line 140
    invoke-direct {v1}, Landroidx/recyclerview/widget/e1;-><init>()V

    .line 141
    .line 142
    .line 143
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    .line 144
    .line 145
    iput-boolean v13, v10, Landroidx/recyclerview/widget/RecyclerView;->i0:Z

    .line 146
    .line 147
    iput-boolean v13, v10, Landroidx/recyclerview/widget/RecyclerView;->j0:Z

    .line 148
    .line 149
    new-instance v1, Landroidx/recyclerview/widget/p0;

    .line 150
    .line 151
    invoke-direct {v1, v10}, Landroidx/recyclerview/widget/p0;-><init>(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 152
    .line 153
    .line 154
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->k0:Landroidx/recyclerview/widget/p0;

    .line 155
    .line 156
    iput-boolean v13, v10, Landroidx/recyclerview/widget/RecyclerView;->l0:Z

    .line 157
    .line 158
    const/4 v9, 0x2

    .line 159
    new-array v2, v9, [I

    .line 160
    .line 161
    iput-object v2, v10, Landroidx/recyclerview/widget/RecyclerView;->n0:[I

    .line 162
    .line 163
    new-array v2, v9, [I

    .line 164
    .line 165
    iput-object v2, v10, Landroidx/recyclerview/widget/RecyclerView;->p0:[I

    .line 166
    .line 167
    new-array v2, v9, [I

    .line 168
    .line 169
    iput-object v2, v10, Landroidx/recyclerview/widget/RecyclerView;->q0:[I

    .line 170
    .line 171
    new-array v2, v9, [I

    .line 172
    .line 173
    iput-object v2, v10, Landroidx/recyclerview/widget/RecyclerView;->r0:[I

    .line 174
    .line 175
    new-instance v2, Ljava/util/ArrayList;

    .line 176
    .line 177
    invoke-direct {v2}, Ljava/util/ArrayList;-><init>()V

    .line 178
    .line 179
    .line 180
    iput-object v2, v10, Landroidx/recyclerview/widget/RecyclerView;->s0:Ljava/util/ArrayList;

    .line 181
    .line 182
    new-instance v2, Landroidx/recyclerview/widget/f0;

    .line 183
    .line 184
    invoke-direct {v2, v10, v14}, Landroidx/recyclerview/widget/f0;-><init>(Landroidx/recyclerview/widget/RecyclerView;I)V

    .line 185
    .line 186
    .line 187
    iput-object v2, v10, Landroidx/recyclerview/widget/RecyclerView;->t0:Landroidx/recyclerview/widget/f0;

    .line 188
    .line 189
    iput v13, v10, Landroidx/recyclerview/widget/RecyclerView;->v0:I

    .line 190
    .line 191
    iput v13, v10, Landroidx/recyclerview/widget/RecyclerView;->w0:I

    .line 192
    .line 193
    new-instance v2, Landroidx/recyclerview/widget/p0;

    .line 194
    .line 195
    invoke-direct {v2, v10}, Landroidx/recyclerview/widget/p0;-><init>(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 196
    .line 197
    .line 198
    iput-object v2, v10, Landroidx/recyclerview/widget/RecyclerView;->x0:Landroidx/recyclerview/widget/p0;

    .line 199
    .line 200
    invoke-virtual {v10, v14}, Landroid/view/View;->setScrollContainer(Z)V

    .line 201
    .line 202
    .line 203
    invoke-virtual {v10, v14}, Landroid/view/View;->setFocusableInTouchMode(Z)V

    .line 204
    .line 205
    .line 206
    invoke-static/range {p1 .. p1}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    .line 207
    .line 208
    .line 209
    move-result-object v2

    .line 210
    invoke-virtual {v2}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    .line 211
    .line 212
    .line 213
    move-result v3

    .line 214
    iput v3, v10, Landroidx/recyclerview/widget/RecyclerView;->T:I

    .line 215
    .line 216
    sget v3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 217
    .line 218
    const/16 v4, 0x1a

    .line 219
    .line 220
    if-lt v3, v4, :cond_1

    .line 221
    .line 222
    sget-object v5, Lg/x;->a:Ljava/lang/reflect/Method;

    .line 223
    .line 224
    invoke-static {v2}, Lg/w;->a(Landroid/view/ViewConfiguration;)F

    .line 225
    .line 226
    .line 227
    move-result v5

    .line 228
    goto :goto_1

    .line 229
    :cond_1
    invoke-static {v2, v11}, Lg/x;->a(Landroid/view/ViewConfiguration;Landroid/content/Context;)F

    .line 230
    .line 231
    .line 232
    move-result v5

    .line 233
    :goto_1
    iput v5, v10, Landroidx/recyclerview/widget/RecyclerView;->W:F

    .line 234
    .line 235
    if-lt v3, v4, :cond_2

    .line 236
    .line 237
    invoke-static {v2}, Lg/w;->b(Landroid/view/ViewConfiguration;)F

    .line 238
    .line 239
    .line 240
    move-result v5

    .line 241
    goto :goto_2

    .line 242
    :cond_2
    invoke-static {v2, v11}, Lg/x;->a(Landroid/view/ViewConfiguration;Landroid/content/Context;)F

    .line 243
    .line 244
    .line 245
    move-result v5

    .line 246
    :goto_2
    iput v5, v10, Landroidx/recyclerview/widget/RecyclerView;->a0:F

    .line 247
    .line 248
    invoke-virtual {v2}, Landroid/view/ViewConfiguration;->getScaledMinimumFlingVelocity()I

    .line 249
    .line 250
    .line 251
    move-result v5

    .line 252
    iput v5, v10, Landroidx/recyclerview/widget/RecyclerView;->U:I

    .line 253
    .line 254
    invoke-virtual {v2}, Landroid/view/ViewConfiguration;->getScaledMaximumFlingVelocity()I

    .line 255
    .line 256
    .line 257
    move-result v2

    .line 258
    iput v2, v10, Landroidx/recyclerview/widget/RecyclerView;->V:I

    .line 259
    .line 260
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 261
    .line 262
    .line 263
    move-result-object v2

    .line 264
    invoke-virtual {v2}, Landroid/content/res/Resources;->getDisplayMetrics()Landroid/util/DisplayMetrics;

    .line 265
    .line 266
    .line 267
    move-result-object v2

    .line 268
    iget v2, v2, Landroid/util/DisplayMetrics;->density:F

    .line 269
    .line 270
    const/high16 v5, 0x43200000    # 160.0f

    .line 271
    .line 272
    mul-float v2, v2, v5

    .line 273
    .line 274
    const v5, 0x43c10b3d

    .line 275
    .line 276
    .line 277
    mul-float v2, v2, v5

    .line 278
    .line 279
    const v5, 0x3f570a3d    # 0.84f

    .line 280
    .line 281
    .line 282
    mul-float v2, v2, v5

    .line 283
    .line 284
    iput v2, v10, Landroidx/recyclerview/widget/RecyclerView;->a:F

    .line 285
    .line 286
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getOverScrollMode()I

    .line 287
    .line 288
    .line 289
    move-result v2

    .line 290
    if-ne v2, v9, :cond_3

    .line 291
    .line 292
    const/4 v2, 0x1

    .line 293
    goto :goto_3

    .line 294
    :cond_3
    const/4 v2, 0x0

    .line 295
    :goto_3
    invoke-virtual {v10, v2}, Landroid/view/View;->setWillNotDraw(Z)V

    .line 296
    .line 297
    .line 298
    iget-object v2, v10, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 299
    .line 300
    iput-object v1, v2, Landroidx/recyclerview/widget/o0;->a:Landroidx/recyclerview/widget/p0;

    .line 301
    .line 302
    new-instance v1, Landroidx/recyclerview/widget/b;

    .line 303
    .line 304
    new-instance v2, Landroidx/recyclerview/widget/p0;

    .line 305
    .line 306
    invoke-direct {v2, v10}, Landroidx/recyclerview/widget/p0;-><init>(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 307
    .line 308
    .line 309
    invoke-direct {v1, v2}, Landroidx/recyclerview/widget/b;-><init>(Landroidx/recyclerview/widget/p0;)V

    .line 310
    .line 311
    .line 312
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->e:Landroidx/recyclerview/widget/b;

    .line 313
    .line 314
    new-instance v1, Landroidx/recyclerview/widget/e;

    .line 315
    .line 316
    new-instance v2, Landroidx/recyclerview/widget/p0;

    .line 317
    .line 318
    invoke-direct {v2, v10}, Landroidx/recyclerview/widget/p0;-><init>(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 319
    .line 320
    .line 321
    invoke-direct {v1, v2}, Landroidx/recyclerview/widget/e;-><init>(Landroidx/recyclerview/widget/p0;)V

    .line 322
    .line 323
    .line 324
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 325
    .line 326
    sget-object v1, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 327
    .line 328
    if-lt v3, v4, :cond_4

    .line 329
    .line 330
    invoke-static/range {p0 .. p0}, Lg/p;->c(Landroid/view/View;)I

    .line 331
    .line 332
    .line 333
    move-result v1

    .line 334
    goto :goto_4

    .line 335
    :cond_4
    const/4 v1, 0x0

    .line 336
    :goto_4
    const/16 v7, 0x8

    .line 337
    .line 338
    if-nez v1, :cond_5

    .line 339
    .line 340
    if-lt v3, v4, :cond_5

    .line 341
    .line 342
    invoke-static {v10, v7}, Lg/p;->m(Landroid/view/View;I)V

    .line 343
    .line 344
    .line 345
    :cond_5
    invoke-static/range {p0 .. p0}, Lg/j;->c(Landroid/view/View;)I

    .line 346
    .line 347
    .line 348
    move-result v1

    .line 349
    if-nez v1, :cond_6

    .line 350
    .line 351
    invoke-static {v10, v14}, Lg/j;->s(Landroid/view/View;I)V

    .line 352
    .line 353
    .line 354
    :cond_6
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 355
    .line 356
    .line 357
    move-result-object v1

    .line 358
    const-string v2, "accessibility"

    .line 359
    .line 360
    invoke-virtual {v1, v2}, Landroid/content/Context;->getSystemService(Ljava/lang/String;)Ljava/lang/Object;

    .line 361
    .line 362
    .line 363
    move-result-object v1

    .line 364
    check-cast v1, Landroid/view/accessibility/AccessibilityManager;

    .line 365
    .line 366
    iput-object v1, v10, Landroidx/recyclerview/widget/RecyclerView;->B:Landroid/view/accessibility/AccessibilityManager;

    .line 367
    .line 368
    new-instance v1, Landroidx/recyclerview/widget/k1;

    .line 369
    .line 370
    invoke-direct {v1, v10}, Landroidx/recyclerview/widget/k1;-><init>(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 371
    .line 372
    .line 373
    invoke-virtual {v10, v1}, Landroidx/recyclerview/widget/RecyclerView;->setAccessibilityDelegateCompat(Landroidx/recyclerview/widget/k1;)V

    .line 374
    .line 375
    .line 376
    sget-object v4, Ll/a;->a:[I

    .line 377
    .line 378
    invoke-virtual {v11, v12, v4, v0, v13}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 379
    .line 380
    .line 381
    move-result-object v0

    .line 382
    const v6, 0x7f010015

    .line 383
    .line 384
    .line 385
    const/16 v16, 0x0

    .line 386
    .line 387
    const/16 v1, 0x1d

    .line 388
    .line 389
    if-lt v3, v1, :cond_7

    .line 390
    .line 391
    move-object/from16 v1, p0

    .line 392
    .line 393
    move-object/from16 v2, p1

    .line 394
    .line 395
    move-object v3, v4

    .line 396
    move-object/from16 v4, p2

    .line 397
    .line 398
    move-object v5, v0

    .line 399
    const/16 v15, 0x8

    .line 400
    .line 401
    move/from16 v7, v16

    .line 402
    .line 403
    invoke-static/range {v1 .. v7}, Lg/s;->d(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V

    .line 404
    .line 405
    .line 406
    goto :goto_5

    .line 407
    :cond_7
    const/16 v15, 0x8

    .line 408
    .line 409
    :goto_5
    invoke-virtual {v0, v15}, Landroid/content/res/TypedArray;->getString(I)Ljava/lang/String;

    .line 410
    .line 411
    .line 412
    move-result-object v15

    .line 413
    invoke-virtual {v0, v9, v8}, Landroid/content/res/TypedArray;->getInt(II)I

    .line 414
    .line 415
    .line 416
    move-result v1

    .line 417
    if-ne v1, v8, :cond_8

    .line 418
    .line 419
    const/high16 v1, 0x40000

    .line 420
    .line 421
    invoke-virtual {v10, v1}, Landroid/view/ViewGroup;->setDescendantFocusability(I)V

    .line 422
    .line 423
    .line 424
    :cond_8
    invoke-virtual {v0, v14, v14}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 425
    .line 426
    .line 427
    move-result v1

    .line 428
    iput-boolean v1, v10, Landroidx/recyclerview/widget/RecyclerView;->h:Z

    .line 429
    .line 430
    const/4 v1, 0x3

    .line 431
    invoke-virtual {v0, v1, v13}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 432
    .line 433
    .line 434
    move-result v1

    .line 435
    const/4 v2, 0x4

    .line 436
    if-eqz v1, :cond_a

    .line 437
    .line 438
    const/4 v1, 0x6

    .line 439
    invoke-virtual {v0, v1}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 440
    .line 441
    .line 442
    move-result-object v1

    .line 443
    move-object v3, v1

    .line 444
    check-cast v3, Landroid/graphics/drawable/StateListDrawable;

    .line 445
    .line 446
    const/4 v1, 0x7

    .line 447
    invoke-virtual {v0, v1}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 448
    .line 449
    .line 450
    move-result-object v4

    .line 451
    invoke-virtual {v0, v2}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 452
    .line 453
    .line 454
    move-result-object v1

    .line 455
    move-object v5, v1

    .line 456
    check-cast v5, Landroid/graphics/drawable/StateListDrawable;

    .line 457
    .line 458
    const/4 v1, 0x5

    .line 459
    invoke-virtual {v0, v1}, Landroid/content/res/TypedArray;->getDrawable(I)Landroid/graphics/drawable/Drawable;

    .line 460
    .line 461
    .line 462
    move-result-object v6

    .line 463
    if-eqz v3, :cond_9

    .line 464
    .line 465
    if-eqz v4, :cond_9

    .line 466
    .line 467
    if-eqz v5, :cond_9

    .line 468
    .line 469
    if-eqz v6, :cond_9

    .line 470
    .line 471
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 472
    .line 473
    .line 474
    move-result-object v1

    .line 475
    invoke-virtual {v1}, Landroid/content/Context;->getResources()Landroid/content/res/Resources;

    .line 476
    .line 477
    .line 478
    move-result-object v1

    .line 479
    new-instance v2, Landroidx/recyclerview/widget/q;

    .line 480
    .line 481
    const v7, 0x7f030007

    .line 482
    .line 483
    .line 484
    invoke-virtual {v1, v7}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 485
    .line 486
    .line 487
    move-result v7

    .line 488
    const v8, 0x7f030009

    .line 489
    .line 490
    .line 491
    invoke-virtual {v1, v8}, Landroid/content/res/Resources;->getDimensionPixelSize(I)I

    .line 492
    .line 493
    .line 494
    move-result v8

    .line 495
    const v9, 0x7f030008

    .line 496
    .line 497
    .line 498
    invoke-virtual {v1, v9}, Landroid/content/res/Resources;->getDimensionPixelOffset(I)I

    .line 499
    .line 500
    .line 501
    move-result v9

    .line 502
    const/16 v16, 0x4

    .line 503
    .line 504
    const/16 v17, 0x2

    .line 505
    .line 506
    move-object v1, v2

    .line 507
    move-object/from16 v2, p0

    .line 508
    .line 509
    invoke-direct/range {v1 .. v9}, Landroidx/recyclerview/widget/q;-><init>(Landroidx/recyclerview/widget/RecyclerView;Landroid/graphics/drawable/StateListDrawable;Landroid/graphics/drawable/Drawable;Landroid/graphics/drawable/StateListDrawable;Landroid/graphics/drawable/Drawable;III)V

    .line 510
    .line 511
    .line 512
    goto :goto_6

    .line 513
    :cond_9
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 514
    .line 515
    new-instance v1, Ljava/lang/StringBuilder;

    .line 516
    .line 517
    const-string v2, "Trying to set fast scroller without both required drawables."

    .line 518
    .line 519
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 520
    .line 521
    .line 522
    invoke-static {v10, v1}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 523
    .line 524
    .line 525
    move-result-object v1

    .line 526
    invoke-direct {v0, v1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 527
    .line 528
    .line 529
    throw v0

    .line 530
    :cond_a
    const/16 v16, 0x4

    .line 531
    .line 532
    const/16 v17, 0x2

    .line 533
    .line 534
    :goto_6
    const/4 v1, 0x4

    .line 535
    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    .line 536
    .line 537
    .line 538
    const-string v2, ": Could not instantiate the LayoutManager: "

    .line 539
    .line 540
    if-eqz v15, :cond_e

    .line 541
    .line 542
    invoke-virtual {v15}, Ljava/lang/String;->trim()Ljava/lang/String;

    .line 543
    .line 544
    .line 545
    move-result-object v0

    .line 546
    invoke-virtual {v0}, Ljava/lang/String;->isEmpty()Z

    .line 547
    .line 548
    .line 549
    move-result v3

    .line 550
    if-nez v3, :cond_e

    .line 551
    .line 552
    invoke-virtual {v0, v13}, Ljava/lang/String;->charAt(I)C

    .line 553
    .line 554
    .line 555
    move-result v3

    .line 556
    const/16 v4, 0x2e

    .line 557
    .line 558
    if-ne v3, v4, :cond_b

    .line 559
    .line 560
    new-instance v3, Ljava/lang/StringBuilder;

    .line 561
    .line 562
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 563
    .line 564
    .line 565
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getPackageName()Ljava/lang/String;

    .line 566
    .line 567
    .line 568
    move-result-object v4

    .line 569
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 570
    .line 571
    .line 572
    goto :goto_8

    .line 573
    :cond_b
    const-string v3, "."

    .line 574
    .line 575
    invoke-virtual {v0, v3}, Ljava/lang/String;->contains(Ljava/lang/CharSequence;)Z

    .line 576
    .line 577
    .line 578
    move-result v3

    .line 579
    if-eqz v3, :cond_c

    .line 580
    .line 581
    :goto_7
    move-object v3, v0

    .line 582
    goto :goto_9

    .line 583
    :cond_c
    new-instance v3, Ljava/lang/StringBuilder;

    .line 584
    .line 585
    invoke-direct {v3}, Ljava/lang/StringBuilder;-><init>()V

    .line 586
    .line 587
    .line 588
    const-class v5, Landroidx/recyclerview/widget/RecyclerView;

    .line 589
    .line 590
    invoke-virtual {v5}, Ljava/lang/Class;->getPackage()Ljava/lang/Package;

    .line 591
    .line 592
    .line 593
    move-result-object v5

    .line 594
    invoke-virtual {v5}, Ljava/lang/Package;->getName()Ljava/lang/String;

    .line 595
    .line 596
    .line 597
    move-result-object v5

    .line 598
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 599
    .line 600
    .line 601
    invoke-virtual {v3, v4}, Ljava/lang/StringBuilder;->append(C)Ljava/lang/StringBuilder;

    .line 602
    .line 603
    .line 604
    :goto_8
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 605
    .line 606
    .line 607
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 608
    .line 609
    .line 610
    move-result-object v0

    .line 611
    goto :goto_7

    .line 612
    :goto_9
    :try_start_0
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->isInEditMode()Z

    .line 613
    .line 614
    .line 615
    move-result v0

    .line 616
    if-eqz v0, :cond_d

    .line 617
    .line 618
    invoke-virtual/range {p0 .. p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 619
    .line 620
    .line 621
    move-result-object v0

    .line 622
    invoke-virtual {v0}, Ljava/lang/Class;->getClassLoader()Ljava/lang/ClassLoader;

    .line 623
    .line 624
    .line 625
    move-result-object v0

    .line 626
    goto :goto_a

    .line 627
    :cond_d
    invoke-virtual/range {p1 .. p1}, Landroid/content/Context;->getClassLoader()Ljava/lang/ClassLoader;

    .line 628
    .line 629
    .line 630
    move-result-object v0

    .line 631
    :goto_a
    invoke-static {v3, v13, v0}, Ljava/lang/Class;->forName(Ljava/lang/String;ZLjava/lang/ClassLoader;)Ljava/lang/Class;

    .line 632
    .line 633
    .line 634
    move-result-object v0

    .line 635
    const-class v4, Landroidx/recyclerview/widget/t0;

    .line 636
    .line 637
    invoke-virtual {v0, v4}, Ljava/lang/Class;->asSubclass(Ljava/lang/Class;)Ljava/lang/Class;

    .line 638
    .line 639
    .line 640
    move-result-object v4
    :try_end_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_0 .. :try_end_0} :catch_6
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_0 .. :try_end_0} :catch_5
    .catch Ljava/lang/InstantiationException; {:try_start_0 .. :try_end_0} :catch_4
    .catch Ljava/lang/IllegalAccessException; {:try_start_0 .. :try_end_0} :catch_3
    .catch Ljava/lang/ClassCastException; {:try_start_0 .. :try_end_0} :catch_2

    .line 641
    :try_start_1
    sget-object v0, Landroidx/recyclerview/widget/RecyclerView;->F0:[Ljava/lang/Class;

    .line 642
    .line 643
    invoke-virtual {v4, v0}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 644
    .line 645
    .line 646
    move-result-object v0

    .line 647
    new-array v1, v1, [Ljava/lang/Object;

    .line 648
    .line 649
    aput-object v11, v1, v13

    .line 650
    .line 651
    aput-object v12, v1, v14

    .line 652
    .line 653
    const v5, 0x7f010015

    .line 654
    .line 655
    .line 656
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 657
    .line 658
    .line 659
    move-result-object v5

    .line 660
    aput-object v5, v1, v17

    .line 661
    .line 662
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 663
    .line 664
    .line 665
    move-result-object v5

    .line 666
    const/4 v6, 0x3

    .line 667
    aput-object v5, v1, v6
    :try_end_1
    .catch Ljava/lang/NoSuchMethodException; {:try_start_1 .. :try_end_1} :catch_0
    .catch Ljava/lang/ClassNotFoundException; {:try_start_1 .. :try_end_1} :catch_6
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_1 .. :try_end_1} :catch_5
    .catch Ljava/lang/InstantiationException; {:try_start_1 .. :try_end_1} :catch_4
    .catch Ljava/lang/IllegalAccessException; {:try_start_1 .. :try_end_1} :catch_3
    .catch Ljava/lang/ClassCastException; {:try_start_1 .. :try_end_1} :catch_2

    .line 668
    .line 669
    move-object v15, v1

    .line 670
    goto :goto_b

    .line 671
    :catch_0
    move-exception v0

    .line 672
    move-object v1, v0

    .line 673
    :try_start_2
    new-array v0, v13, [Ljava/lang/Class;

    .line 674
    .line 675
    invoke-virtual {v4, v0}, Ljava/lang/Class;->getConstructor([Ljava/lang/Class;)Ljava/lang/reflect/Constructor;

    .line 676
    .line 677
    .line 678
    move-result-object v0
    :try_end_2
    .catch Ljava/lang/NoSuchMethodException; {:try_start_2 .. :try_end_2} :catch_1
    .catch Ljava/lang/ClassNotFoundException; {:try_start_2 .. :try_end_2} :catch_6
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_2 .. :try_end_2} :catch_5
    .catch Ljava/lang/InstantiationException; {:try_start_2 .. :try_end_2} :catch_4
    .catch Ljava/lang/IllegalAccessException; {:try_start_2 .. :try_end_2} :catch_3
    .catch Ljava/lang/ClassCastException; {:try_start_2 .. :try_end_2} :catch_2

    .line 679
    const/4 v15, 0x0

    .line 680
    :goto_b
    :try_start_3
    invoke-virtual {v0, v14}, Ljava/lang/reflect/AccessibleObject;->setAccessible(Z)V

    .line 681
    .line 682
    .line 683
    invoke-virtual {v0, v15}, Ljava/lang/reflect/Constructor;->newInstance([Ljava/lang/Object;)Ljava/lang/Object;

    .line 684
    .line 685
    .line 686
    move-result-object v0

    .line 687
    check-cast v0, Landroidx/recyclerview/widget/t0;

    .line 688
    .line 689
    invoke-virtual {v10, v0}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutManager(Landroidx/recyclerview/widget/t0;)V

    .line 690
    .line 691
    .line 692
    goto/16 :goto_c

    .line 693
    .line 694
    :catch_1
    move-exception v0

    .line 695
    invoke-virtual {v0, v1}, Ljava/lang/Throwable;->initCause(Ljava/lang/Throwable;)Ljava/lang/Throwable;

    .line 696
    .line 697
    .line 698
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 699
    .line 700
    new-instance v4, Ljava/lang/StringBuilder;

    .line 701
    .line 702
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 703
    .line 704
    .line 705
    invoke-interface/range {p2 .. p2}, Landroid/util/AttributeSet;->getPositionDescription()Ljava/lang/String;

    .line 706
    .line 707
    .line 708
    move-result-object v5

    .line 709
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 710
    .line 711
    .line 712
    const-string v5, ": Error creating LayoutManager "

    .line 713
    .line 714
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 715
    .line 716
    .line 717
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 718
    .line 719
    .line 720
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 721
    .line 722
    .line 723
    move-result-object v4

    .line 724
    invoke-direct {v1, v4, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 725
    .line 726
    .line 727
    throw v1
    :try_end_3
    .catch Ljava/lang/ClassNotFoundException; {:try_start_3 .. :try_end_3} :catch_6
    .catch Ljava/lang/reflect/InvocationTargetException; {:try_start_3 .. :try_end_3} :catch_5
    .catch Ljava/lang/InstantiationException; {:try_start_3 .. :try_end_3} :catch_4
    .catch Ljava/lang/IllegalAccessException; {:try_start_3 .. :try_end_3} :catch_3
    .catch Ljava/lang/ClassCastException; {:try_start_3 .. :try_end_3} :catch_2

    .line 728
    :catch_2
    move-exception v0

    .line 729
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 730
    .line 731
    new-instance v2, Ljava/lang/StringBuilder;

    .line 732
    .line 733
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 734
    .line 735
    .line 736
    invoke-interface/range {p2 .. p2}, Landroid/util/AttributeSet;->getPositionDescription()Ljava/lang/String;

    .line 737
    .line 738
    .line 739
    move-result-object v4

    .line 740
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 741
    .line 742
    .line 743
    const-string v4, ": Class is not a LayoutManager "

    .line 744
    .line 745
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 746
    .line 747
    .line 748
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 749
    .line 750
    .line 751
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 752
    .line 753
    .line 754
    move-result-object v2

    .line 755
    invoke-direct {v1, v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 756
    .line 757
    .line 758
    throw v1

    .line 759
    :catch_3
    move-exception v0

    .line 760
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 761
    .line 762
    new-instance v2, Ljava/lang/StringBuilder;

    .line 763
    .line 764
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 765
    .line 766
    .line 767
    invoke-interface/range {p2 .. p2}, Landroid/util/AttributeSet;->getPositionDescription()Ljava/lang/String;

    .line 768
    .line 769
    .line 770
    move-result-object v4

    .line 771
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 772
    .line 773
    .line 774
    const-string v4, ": Cannot access non-public constructor "

    .line 775
    .line 776
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 777
    .line 778
    .line 779
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 780
    .line 781
    .line 782
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 783
    .line 784
    .line 785
    move-result-object v2

    .line 786
    invoke-direct {v1, v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 787
    .line 788
    .line 789
    throw v1

    .line 790
    :catch_4
    move-exception v0

    .line 791
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 792
    .line 793
    new-instance v4, Ljava/lang/StringBuilder;

    .line 794
    .line 795
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 796
    .line 797
    .line 798
    invoke-interface/range {p2 .. p2}, Landroid/util/AttributeSet;->getPositionDescription()Ljava/lang/String;

    .line 799
    .line 800
    .line 801
    move-result-object v5

    .line 802
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 803
    .line 804
    .line 805
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 806
    .line 807
    .line 808
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 809
    .line 810
    .line 811
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 812
    .line 813
    .line 814
    move-result-object v2

    .line 815
    invoke-direct {v1, v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 816
    .line 817
    .line 818
    throw v1

    .line 819
    :catch_5
    move-exception v0

    .line 820
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 821
    .line 822
    new-instance v4, Ljava/lang/StringBuilder;

    .line 823
    .line 824
    invoke-direct {v4}, Ljava/lang/StringBuilder;-><init>()V

    .line 825
    .line 826
    .line 827
    invoke-interface/range {p2 .. p2}, Landroid/util/AttributeSet;->getPositionDescription()Ljava/lang/String;

    .line 828
    .line 829
    .line 830
    move-result-object v5

    .line 831
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 832
    .line 833
    .line 834
    invoke-virtual {v4, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 835
    .line 836
    .line 837
    invoke-virtual {v4, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 838
    .line 839
    .line 840
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 841
    .line 842
    .line 843
    move-result-object v2

    .line 844
    invoke-direct {v1, v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 845
    .line 846
    .line 847
    throw v1

    .line 848
    :catch_6
    move-exception v0

    .line 849
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 850
    .line 851
    new-instance v2, Ljava/lang/StringBuilder;

    .line 852
    .line 853
    invoke-direct {v2}, Ljava/lang/StringBuilder;-><init>()V

    .line 854
    .line 855
    .line 856
    invoke-interface/range {p2 .. p2}, Landroid/util/AttributeSet;->getPositionDescription()Ljava/lang/String;

    .line 857
    .line 858
    .line 859
    move-result-object v4

    .line 860
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 861
    .line 862
    .line 863
    const-string v4, ": Unable to find LayoutManager "

    .line 864
    .line 865
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 866
    .line 867
    .line 868
    invoke-virtual {v2, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 869
    .line 870
    .line 871
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 872
    .line 873
    .line 874
    move-result-object v2

    .line 875
    invoke-direct {v1, v2, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;Ljava/lang/Throwable;)V

    .line 876
    .line 877
    .line 878
    throw v1

    .line 879
    :cond_e
    :goto_c
    sget-object v3, Landroidx/recyclerview/widget/RecyclerView;->A0:[I

    .line 880
    .line 881
    const v0, 0x7f010015

    .line 882
    .line 883
    .line 884
    invoke-virtual {v11, v12, v3, v0, v13}, Landroid/content/Context;->obtainStyledAttributes(Landroid/util/AttributeSet;[III)Landroid/content/res/TypedArray;

    .line 885
    .line 886
    .line 887
    move-result-object v0

    .line 888
    const v6, 0x7f010015

    .line 889
    .line 890
    .line 891
    const/4 v7, 0x0

    .line 892
    sget v1, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 893
    .line 894
    const/16 v2, 0x1d

    .line 895
    .line 896
    if-lt v1, v2, :cond_f

    .line 897
    .line 898
    move-object/from16 v1, p0

    .line 899
    .line 900
    move-object/from16 v2, p1

    .line 901
    .line 902
    move-object/from16 v4, p2

    .line 903
    .line 904
    move-object v5, v0

    .line 905
    invoke-static/range {v1 .. v7}, Lg/s;->d(Landroid/view/View;Landroid/content/Context;[ILandroid/util/AttributeSet;Landroid/content/res/TypedArray;II)V

    .line 906
    .line 907
    .line 908
    :cond_f
    invoke-virtual {v0, v13, v14}, Landroid/content/res/TypedArray;->getBoolean(IZ)Z

    .line 909
    .line 910
    .line 911
    move-result v1

    .line 912
    invoke-virtual {v0}, Landroid/content/res/TypedArray;->recycle()V

    .line 913
    .line 914
    .line 915
    invoke-virtual {v10, v1}, Landroidx/recyclerview/widget/RecyclerView;->setNestedScrollingEnabled(Z)V

    .line 916
    .line 917
    .line 918
    const v0, 0x7f050044

    .line 919
    .line 920
    .line 921
    sget-object v1, Ljava/lang/Boolean;->TRUE:Ljava/lang/Boolean;

    .line 922
    .line 923
    invoke-virtual {v10, v0, v1}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 924
    .line 925
    .line 926
    return-void
.end method

.method public static D(Landroid/view/View;)Landroidx/recyclerview/widget/RecyclerView;
    .locals 4

    .line 1
    instance-of v0, p0, Landroid/view/ViewGroup;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return-object v1

    :cond_0
    instance-of v0, p0, Landroidx/recyclerview/widget/RecyclerView;

    if-eqz v0, :cond_1

    check-cast p0, Landroidx/recyclerview/widget/RecyclerView;

    return-object p0

    :cond_1
    check-cast p0, Landroid/view/ViewGroup;

    invoke-virtual {p0}, Landroid/view/ViewGroup;->getChildCount()I

    move-result v0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_3

    invoke-virtual {p0, v2}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    move-result-object v3

    invoke-static {v3}, Landroidx/recyclerview/widget/RecyclerView;->D(Landroid/view/View;)Landroidx/recyclerview/widget/RecyclerView;

    move-result-object v3

    if-eqz v3, :cond_2

    return-object v3

    :cond_2
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_3
    return-object v1
.end method

.method public static I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;
    .locals 0

    .line 1
    if-nez p0, :cond_0

    const/4 p0, 0x0

    return-object p0

    :cond_0
    invoke-virtual {p0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object p0

    check-cast p0, Landroidx/recyclerview/widget/u0;

    iget-object p0, p0, Landroidx/recyclerview/widget/u0;->a:Landroidx/recyclerview/widget/i1;

    return-object p0
.end method

.method public static synthetic a(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1, p2, p3}, Landroid/view/ViewGroup;->attachViewToParent(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public static synthetic b(Landroidx/recyclerview/widget/RecyclerView;I)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->detachViewFromParent(I)V

    return-void
.end method

.method public static synthetic c(Landroidx/recyclerview/widget/RecyclerView;)Z
    .locals 0

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->awakenScrollBars()Z

    move-result p0

    return p0
.end method

.method public static synthetic d(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1, p2, p3}, Landroid/view/ViewGroup;->attachViewToParent(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    return-void
.end method

.method public static synthetic e(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/View;)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->detachViewFromParent(Landroid/view/View;)V

    return-void
.end method

.method public static synthetic f(Landroidx/recyclerview/widget/RecyclerView;II)V
    .locals 0

    .line 1
    invoke-virtual {p0, p1, p2}, Landroid/view/View;->setMeasuredDimension(II)V

    return-void
.end method

.method private getScrollingChildHelper()Lg/f;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->o0:Lg/f;

    if-nez v0, :cond_0

    new-instance v0, Lg/f;

    invoke-direct {v0, p0}, Lg/f;-><init>(Landroid/view/View;)V

    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->o0:Lg/f;

    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->o0:Lg/f;

    return-object v0
.end method

.method public static i(Landroidx/recyclerview/widget/i1;)V
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/i1;->mNestedRecyclerView:Ljava/lang/ref/WeakReference;

    if-eqz v0, :cond_3

    invoke-virtual {v0}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    move-result-object v0

    :goto_0
    check-cast v0, Landroid/view/View;

    :goto_1
    const/4 v1, 0x0

    if-eqz v0, :cond_2

    iget-object v2, p0, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    if-ne v0, v2, :cond_0

    return-void

    :cond_0
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    instance-of v2, v0, Landroid/view/View;

    if-eqz v2, :cond_1

    goto :goto_0

    :cond_1
    move-object v0, v1

    goto :goto_1

    :cond_2
    iput-object v1, p0, Landroidx/recyclerview/widget/i1;->mNestedRecyclerView:Ljava/lang/ref/WeakReference;

    :cond_3
    return-void
.end method

.method public static l(ILandroid/widget/EdgeEffect;Landroid/widget/EdgeEffect;I)I
    .locals 4

    .line 1
    const/high16 v0, 0x3f000000    # 0.5f

    const/4 v1, 0x0

    const/high16 v2, 0x40800000    # 4.0f

    if-lez p0, :cond_1

    if-eqz p1, :cond_1

    invoke-static {p1}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    move-result v3

    cmpl-float v3, v3, v1

    if-eqz v3, :cond_1

    neg-int p2, p0

    int-to-float p2, p2

    mul-float p2, p2, v2

    int-to-float v1, p3

    div-float/2addr p2, v1

    neg-int p3, p3

    int-to-float p3, p3

    div-float/2addr p3, v2

    invoke-static {p1, p2, v0}, Lb0/d;->A(Landroid/widget/EdgeEffect;FF)F

    move-result p2

    mul-float p2, p2, p3

    invoke-static {p2}, Ljava/lang/Math;->round(F)I

    move-result p2

    if-eq p2, p0, :cond_0

    invoke-virtual {p1}, Landroid/widget/EdgeEffect;->finish()V

    :cond_0
    sub-int/2addr p0, p2

    return p0

    :cond_1
    if-gez p0, :cond_3

    if-eqz p2, :cond_3

    invoke-static {p2}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    move-result p1

    cmpl-float p1, p1, v1

    if-eqz p1, :cond_3

    int-to-float p1, p0

    mul-float p1, p1, v2

    int-to-float p3, p3

    div-float/2addr p1, p3

    div-float/2addr p3, v2

    invoke-static {p2, p1, v0}, Lb0/d;->A(Landroid/widget/EdgeEffect;FF)F

    move-result p1

    mul-float p1, p1, p3

    invoke-static {p1}, Ljava/lang/Math;->round(F)I

    move-result p1

    if-eq p1, p0, :cond_2

    invoke-virtual {p2}, Landroid/widget/EdgeEffect;->finish()V

    :cond_2
    sub-int/2addr p0, p1

    :cond_3
    return p0
.end method

.method public static setDebugAssertionsEnabled(Z)V
    .locals 0

    sput-boolean p0, Landroidx/recyclerview/widget/RecyclerView;->y0:Z

    return-void
.end method

.method public static setVerboseLoggingEnabled(Z)V
    .locals 0

    sput-boolean p0, Landroidx/recyclerview/widget/RecyclerView;->z0:Z

    return-void
.end method


# virtual methods
.method public final A(Landroid/view/View;)Landroid/view/View;
    .locals 2

    .line 1
    :goto_0
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    if-eqz v0, :cond_0

    if-eq v0, p0, :cond_0

    instance-of v1, v0, Landroid/view/View;

    if-eqz v1, :cond_0

    move-object p1, v0

    check-cast p1, Landroid/view/View;

    goto :goto_0

    :cond_0
    if-ne v0, p0, :cond_1

    goto :goto_1

    :cond_1
    const/4 p1, 0x0

    :goto_1
    return-object p1
.end method

.method public final B(Landroid/view/MotionEvent;)Z
    .locals 12

    .line 1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->q:Ljava/util/ArrayList;

    .line 6
    .line 7
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 8
    .line 9
    .line 10
    move-result v2

    .line 11
    const/4 v3, 0x0

    .line 12
    const/4 v4, 0x0

    .line 13
    :goto_0
    if-ge v4, v2, :cond_6

    .line 14
    .line 15
    invoke-virtual {v1, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 16
    .line 17
    .line 18
    move-result-object v5

    .line 19
    check-cast v5, Landroidx/recyclerview/widget/w0;

    .line 20
    .line 21
    move-object v6, v5

    .line 22
    check-cast v6, Landroidx/recyclerview/widget/q;

    .line 23
    .line 24
    iget v7, v6, Landroidx/recyclerview/widget/q;->v:I

    .line 25
    .line 26
    const/4 v8, 0x1

    .line 27
    const/4 v9, 0x2

    .line 28
    if-ne v7, v8, :cond_3

    .line 29
    .line 30
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 31
    .line 32
    .line 33
    move-result v7

    .line 34
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 35
    .line 36
    .line 37
    move-result v10

    .line 38
    invoke-virtual {v6, v7, v10}, Landroidx/recyclerview/widget/q;->b(FF)Z

    .line 39
    .line 40
    .line 41
    move-result v7

    .line 42
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 43
    .line 44
    .line 45
    move-result v10

    .line 46
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 47
    .line 48
    .line 49
    move-result v11

    .line 50
    invoke-virtual {v6, v10, v11}, Landroidx/recyclerview/widget/q;->a(FF)Z

    .line 51
    .line 52
    .line 53
    move-result v10

    .line 54
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getAction()I

    .line 55
    .line 56
    .line 57
    move-result v11

    .line 58
    if-nez v11, :cond_4

    .line 59
    .line 60
    if-nez v7, :cond_0

    .line 61
    .line 62
    if-eqz v10, :cond_4

    .line 63
    .line 64
    :cond_0
    if-eqz v10, :cond_1

    .line 65
    .line 66
    iput v8, v6, Landroidx/recyclerview/widget/q;->w:I

    .line 67
    .line 68
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 69
    .line 70
    .line 71
    move-result v7

    .line 72
    float-to-int v7, v7

    .line 73
    int-to-float v7, v7

    .line 74
    iput v7, v6, Landroidx/recyclerview/widget/q;->p:F

    .line 75
    .line 76
    goto :goto_1

    .line 77
    :cond_1
    if-eqz v7, :cond_2

    .line 78
    .line 79
    iput v9, v6, Landroidx/recyclerview/widget/q;->w:I

    .line 80
    .line 81
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 82
    .line 83
    .line 84
    move-result v7

    .line 85
    float-to-int v7, v7

    .line 86
    int-to-float v7, v7

    .line 87
    iput v7, v6, Landroidx/recyclerview/widget/q;->m:F

    .line 88
    .line 89
    :cond_2
    :goto_1
    invoke-virtual {v6, v9}, Landroidx/recyclerview/widget/q;->d(I)V

    .line 90
    .line 91
    .line 92
    goto :goto_2

    .line 93
    :cond_3
    if-ne v7, v9, :cond_4

    .line 94
    .line 95
    :goto_2
    const/4 v6, 0x1

    .line 96
    goto :goto_3

    .line 97
    :cond_4
    const/4 v6, 0x0

    .line 98
    :goto_3
    if-eqz v6, :cond_5

    .line 99
    .line 100
    const/4 v6, 0x3

    .line 101
    if-eq v0, v6, :cond_5

    .line 102
    .line 103
    iput-object v5, p0, Landroidx/recyclerview/widget/RecyclerView;->r:Landroidx/recyclerview/widget/w0;

    .line 104
    .line 105
    return v8

    .line 106
    :cond_5
    add-int/lit8 v4, v4, 0x1

    .line 107
    .line 108
    goto :goto_0

    .line 109
    :cond_6
    return v3
.end method

.method public final C([I)V
    .locals 8

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/e;->e()I

    move-result v0

    const/4 v1, 0x1

    const/4 v2, 0x0

    if-nez v0, :cond_0

    const/4 v0, -0x1

    aput v0, p1, v2

    aput v0, p1, v1

    return-void

    :cond_0
    const v3, 0x7fffffff

    const/high16 v4, -0x80000000

    const/4 v5, 0x0

    :goto_0
    if-ge v5, v0, :cond_4

    iget-object v6, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    invoke-virtual {v6, v5}, Landroidx/recyclerview/widget/e;->d(I)Landroid/view/View;

    move-result-object v6

    invoke-static {v6}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    move-result-object v6

    invoke-virtual {v6}, Landroidx/recyclerview/widget/i1;->shouldIgnore()Z

    move-result v7

    if-eqz v7, :cond_1

    goto :goto_1

    :cond_1
    invoke-virtual {v6}, Landroidx/recyclerview/widget/i1;->getLayoutPosition()I

    move-result v6

    if-ge v6, v3, :cond_2

    move v3, v6

    :cond_2
    if-le v6, v4, :cond_3

    move v4, v6

    :cond_3
    :goto_1
    add-int/lit8 v5, v5, 0x1

    goto :goto_0

    :cond_4
    aput v3, p1, v2

    aput v4, p1, v1

    return-void
.end method

.method public final E(I)Landroidx/recyclerview/widget/i1;
    .locals 5

    .line 1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->C:Z

    const/4 v1, 0x0

    if-eqz v0, :cond_0

    return-object v1

    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/e;->h()I

    move-result v0

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v0, :cond_3

    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    invoke-virtual {v3, v2}, Landroidx/recyclerview/widget/e;->g(I)Landroid/view/View;

    move-result-object v3

    invoke-static {v3}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    move-result-object v3

    if-eqz v3, :cond_2

    invoke-virtual {v3}, Landroidx/recyclerview/widget/i1;->isRemoved()Z

    move-result v4

    if-nez v4, :cond_2

    invoke-virtual {p0, v3}, Landroidx/recyclerview/widget/RecyclerView;->F(Landroidx/recyclerview/widget/i1;)I

    move-result v4

    if-ne v4, p1, :cond_2

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    iget-object v4, v3, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    invoke-virtual {v1, v4}, Landroidx/recyclerview/widget/e;->j(Landroid/view/View;)Z

    move-result v1

    if-eqz v1, :cond_1

    move-object v1, v3

    goto :goto_1

    :cond_1
    return-object v3

    :cond_2
    :goto_1
    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_3
    return-object v1
.end method

.method public final F(Landroidx/recyclerview/widget/i1;)I
    .locals 7

    .line 1
    const/16 v0, 0x20c

    .line 2
    .line 3
    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/i1;->hasAnyOfTheFlags(I)Z

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, -0x1

    .line 8
    if-nez v0, :cond_9

    .line 9
    .line 10
    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->isBound()Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    if-nez v0, :cond_0

    .line 15
    .line 16
    goto :goto_2

    .line 17
    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->e:Landroidx/recyclerview/widget/b;

    .line 18
    .line 19
    iget p1, p1, Landroidx/recyclerview/widget/i1;->mPosition:I

    .line 20
    .line 21
    iget-object v0, v0, Landroidx/recyclerview/widget/b;->b:Ljava/util/ArrayList;

    .line 22
    .line 23
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 24
    .line 25
    .line 26
    move-result v2

    .line 27
    const/4 v3, 0x0

    .line 28
    :goto_0
    if-ge v3, v2, :cond_8

    .line 29
    .line 30
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 31
    .line 32
    .line 33
    move-result-object v4

    .line 34
    check-cast v4, Landroidx/recyclerview/widget/a;

    .line 35
    .line 36
    iget v5, v4, Landroidx/recyclerview/widget/a;->a:I

    .line 37
    .line 38
    const/4 v6, 0x1

    .line 39
    if-eq v5, v6, :cond_6

    .line 40
    .line 41
    const/4 v6, 0x2

    .line 42
    if-eq v5, v6, :cond_4

    .line 43
    .line 44
    const/16 v6, 0x8

    .line 45
    .line 46
    if-eq v5, v6, :cond_1

    .line 47
    .line 48
    goto :goto_1

    .line 49
    :cond_1
    iget v5, v4, Landroidx/recyclerview/widget/a;->b:I

    .line 50
    .line 51
    if-ne v5, p1, :cond_2

    .line 52
    .line 53
    iget p1, v4, Landroidx/recyclerview/widget/a;->d:I

    .line 54
    .line 55
    goto :goto_1

    .line 56
    :cond_2
    if-ge v5, p1, :cond_3

    .line 57
    .line 58
    add-int/lit8 p1, p1, -0x1

    .line 59
    .line 60
    :cond_3
    iget v4, v4, Landroidx/recyclerview/widget/a;->d:I

    .line 61
    .line 62
    if-gt v4, p1, :cond_7

    .line 63
    .line 64
    add-int/lit8 p1, p1, 0x1

    .line 65
    .line 66
    goto :goto_1

    .line 67
    :cond_4
    iget v5, v4, Landroidx/recyclerview/widget/a;->b:I

    .line 68
    .line 69
    if-gt v5, p1, :cond_7

    .line 70
    .line 71
    iget v4, v4, Landroidx/recyclerview/widget/a;->d:I

    .line 72
    .line 73
    add-int/2addr v5, v4

    .line 74
    if-le v5, p1, :cond_5

    .line 75
    .line 76
    goto :goto_2

    .line 77
    :cond_5
    sub-int/2addr p1, v4

    .line 78
    goto :goto_1

    .line 79
    :cond_6
    iget v5, v4, Landroidx/recyclerview/widget/a;->b:I

    .line 80
    .line 81
    if-gt v5, p1, :cond_7

    .line 82
    .line 83
    iget v4, v4, Landroidx/recyclerview/widget/a;->d:I

    .line 84
    .line 85
    add-int/2addr p1, v4

    .line 86
    :cond_7
    :goto_1
    add-int/lit8 v3, v3, 0x1

    .line 87
    .line 88
    goto :goto_0

    .line 89
    :cond_8
    move v1, p1

    .line 90
    :cond_9
    :goto_2
    return v1
.end method

.method public final G(Landroidx/recyclerview/widget/i1;)J
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/i0;->hasStableIds()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->getItemId()J

    move-result-wide v0

    goto :goto_0

    :cond_0
    iget p1, p1, Landroidx/recyclerview/widget/i1;->mPosition:I

    int-to-long v0, p1

    :goto_0
    return-wide v0
.end method

.method public final H(Landroid/view/View;)Landroidx/recyclerview/widget/i1;
    .locals 3

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    move-result-object v0

    if-eqz v0, :cond_1

    if-ne v0, p0, :cond_0

    goto :goto_0

    :cond_0
    new-instance v0, Ljava/lang/IllegalArgumentException;

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "View "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string p1, " is not a direct child of "

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1, p0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw v0

    :cond_1
    :goto_0
    invoke-static {p1}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    move-result-object p1

    return-object p1
.end method

.method public final J(Landroid/view/View;)Landroid/graphics/Rect;
    .locals 9

    .line 1
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    check-cast v0, Landroidx/recyclerview/widget/u0;

    .line 6
    .line 7
    iget-boolean v1, v0, Landroidx/recyclerview/widget/u0;->c:Z

    .line 8
    .line 9
    iget-object v2, v0, Landroidx/recyclerview/widget/u0;->b:Landroid/graphics/Rect;

    .line 10
    .line 11
    if-nez v1, :cond_0

    .line 12
    .line 13
    return-object v2

    .line 14
    :cond_0
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    .line 15
    .line 16
    iget-boolean v1, v1, Landroidx/recyclerview/widget/e1;->f:Z

    .line 17
    .line 18
    if-eqz v1, :cond_2

    .line 19
    .line 20
    invoke-virtual {v0}, Landroidx/recyclerview/widget/u0;->b()Z

    .line 21
    .line 22
    .line 23
    move-result v1

    .line 24
    if-nez v1, :cond_1

    .line 25
    .line 26
    iget-object v1, v0, Landroidx/recyclerview/widget/u0;->a:Landroidx/recyclerview/widget/i1;

    .line 27
    .line 28
    invoke-virtual {v1}, Landroidx/recyclerview/widget/i1;->isInvalid()Z

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    if-eqz v1, :cond_2

    .line 33
    .line 34
    :cond_1
    return-object v2

    .line 35
    :cond_2
    const/4 v1, 0x0

    .line 36
    invoke-virtual {v2, v1, v1, v1, v1}, Landroid/graphics/Rect;->set(IIII)V

    .line 37
    .line 38
    .line 39
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->p:Ljava/util/ArrayList;

    .line 40
    .line 41
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 42
    .line 43
    .line 44
    move-result v4

    .line 45
    const/4 v5, 0x0

    .line 46
    :goto_0
    if-ge v5, v4, :cond_3

    .line 47
    .line 48
    iget-object v6, p0, Landroidx/recyclerview/widget/RecyclerView;->j:Landroid/graphics/Rect;

    .line 49
    .line 50
    invoke-virtual {v6, v1, v1, v1, v1}, Landroid/graphics/Rect;->set(IIII)V

    .line 51
    .line 52
    .line 53
    invoke-virtual {v3, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 54
    .line 55
    .line 56
    move-result-object v7

    .line 57
    check-cast v7, Landroidx/recyclerview/widget/q0;

    .line 58
    .line 59
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 60
    .line 61
    .line 62
    invoke-virtual {p1}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 63
    .line 64
    .line 65
    move-result-object v7

    .line 66
    check-cast v7, Landroidx/recyclerview/widget/u0;

    .line 67
    .line 68
    invoke-virtual {v7}, Landroidx/recyclerview/widget/u0;->a()I

    .line 69
    .line 70
    .line 71
    invoke-virtual {v6, v1, v1, v1, v1}, Landroid/graphics/Rect;->set(IIII)V

    .line 72
    .line 73
    .line 74
    iget v7, v2, Landroid/graphics/Rect;->left:I

    .line 75
    .line 76
    iget v8, v6, Landroid/graphics/Rect;->left:I

    .line 77
    .line 78
    add-int/2addr v7, v8

    .line 79
    iput v7, v2, Landroid/graphics/Rect;->left:I

    .line 80
    .line 81
    iget v7, v2, Landroid/graphics/Rect;->top:I

    .line 82
    .line 83
    iget v8, v6, Landroid/graphics/Rect;->top:I

    .line 84
    .line 85
    add-int/2addr v7, v8

    .line 86
    iput v7, v2, Landroid/graphics/Rect;->top:I

    .line 87
    .line 88
    iget v7, v2, Landroid/graphics/Rect;->right:I

    .line 89
    .line 90
    iget v8, v6, Landroid/graphics/Rect;->right:I

    .line 91
    .line 92
    add-int/2addr v7, v8

    .line 93
    iput v7, v2, Landroid/graphics/Rect;->right:I

    .line 94
    .line 95
    iget v7, v2, Landroid/graphics/Rect;->bottom:I

    .line 96
    .line 97
    iget v6, v6, Landroid/graphics/Rect;->bottom:I

    .line 98
    .line 99
    add-int/2addr v7, v6

    .line 100
    iput v7, v2, Landroid/graphics/Rect;->bottom:I

    .line 101
    .line 102
    add-int/lit8 v5, v5, 0x1

    .line 103
    .line 104
    goto :goto_0

    .line 105
    :cond_3
    iput-boolean v1, v0, Landroidx/recyclerview/widget/u0;->c:Z

    .line 106
    .line 107
    return-object v2
.end method

.method public final K()Z
    .locals 1

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView;->E:I

    if-lez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    return v0
.end method

.method public final L()V
    .locals 5

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroidx/recyclerview/widget/e;->h()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x0

    .line 8
    const/4 v2, 0x0

    .line 9
    :goto_0
    const/4 v3, 0x1

    .line 10
    if-ge v2, v0, :cond_0

    .line 11
    .line 12
    iget-object v4, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 13
    .line 14
    invoke-virtual {v4, v2}, Landroidx/recyclerview/widget/e;->g(I)Landroid/view/View;

    .line 15
    .line 16
    .line 17
    move-result-object v4

    .line 18
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 19
    .line 20
    .line 21
    move-result-object v4

    .line 22
    check-cast v4, Landroidx/recyclerview/widget/u0;

    .line 23
    .line 24
    iput-boolean v3, v4, Landroidx/recyclerview/widget/u0;->c:Z

    .line 25
    .line 26
    add-int/lit8 v2, v2, 0x1

    .line 27
    .line 28
    goto :goto_0

    .line 29
    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 30
    .line 31
    iget-object v0, v0, Landroidx/recyclerview/widget/a1;->c:Ljava/util/ArrayList;

    .line 32
    .line 33
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 34
    .line 35
    .line 36
    move-result v2

    .line 37
    :goto_1
    if-ge v1, v2, :cond_2

    .line 38
    .line 39
    invoke-virtual {v0, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 40
    .line 41
    .line 42
    move-result-object v4

    .line 43
    check-cast v4, Landroidx/recyclerview/widget/i1;

    .line 44
    .line 45
    iget-object v4, v4, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 46
    .line 47
    invoke-virtual {v4}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 48
    .line 49
    .line 50
    move-result-object v4

    .line 51
    check-cast v4, Landroidx/recyclerview/widget/u0;

    .line 52
    .line 53
    if-eqz v4, :cond_1

    .line 54
    .line 55
    iput-boolean v3, v4, Landroidx/recyclerview/widget/u0;->c:Z

    .line 56
    .line 57
    :cond_1
    add-int/lit8 v1, v1, 0x1

    .line 58
    .line 59
    goto :goto_1

    .line 60
    :cond_2
    return-void
.end method

.method public final M(IIZ)V
    .locals 10

    .line 1
    add-int v0, p1, p2

    .line 2
    .line 3
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 4
    .line 5
    invoke-virtual {v1}, Landroidx/recyclerview/widget/e;->h()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    const/4 v2, 0x0

    .line 10
    :goto_0
    const-string v3, " now at position "

    .line 11
    .line 12
    const-string v4, "RecyclerView"

    .line 13
    .line 14
    const-string v5, " holder "

    .line 15
    .line 16
    if-ge v2, v1, :cond_4

    .line 17
    .line 18
    iget-object v6, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 19
    .line 20
    invoke-virtual {v6, v2}, Landroidx/recyclerview/widget/e;->g(I)Landroid/view/View;

    .line 21
    .line 22
    .line 23
    move-result-object v6

    .line 24
    invoke-static {v6}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 25
    .line 26
    .line 27
    move-result-object v6

    .line 28
    if-eqz v6, :cond_3

    .line 29
    .line 30
    invoke-virtual {v6}, Landroidx/recyclerview/widget/i1;->shouldIgnore()Z

    .line 31
    .line 32
    .line 33
    move-result v7

    .line 34
    if-nez v7, :cond_3

    .line 35
    .line 36
    iget v7, v6, Landroidx/recyclerview/widget/i1;->mPosition:I

    .line 37
    .line 38
    const-string v8, "offsetPositionRecordsForRemove attached child "

    .line 39
    .line 40
    if-lt v7, v0, :cond_1

    .line 41
    .line 42
    sget-boolean v7, Landroidx/recyclerview/widget/RecyclerView;->z0:Z

    .line 43
    .line 44
    if-eqz v7, :cond_0

    .line 45
    .line 46
    new-instance v7, Ljava/lang/StringBuilder;

    .line 47
    .line 48
    invoke-direct {v7, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 49
    .line 50
    .line 51
    invoke-virtual {v7, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 52
    .line 53
    .line 54
    invoke-virtual {v7, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 55
    .line 56
    .line 57
    invoke-virtual {v7, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 58
    .line 59
    .line 60
    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 61
    .line 62
    .line 63
    iget v3, v6, Landroidx/recyclerview/widget/i1;->mPosition:I

    .line 64
    .line 65
    sub-int/2addr v3, p2

    .line 66
    invoke-virtual {v7, v3}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 67
    .line 68
    .line 69
    invoke-virtual {v7}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 70
    .line 71
    .line 72
    move-result-object v3

    .line 73
    invoke-static {v4, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 74
    .line 75
    .line 76
    :cond_0
    neg-int v3, p2

    .line 77
    invoke-virtual {v6, v3, p3}, Landroidx/recyclerview/widget/i1;->offsetPosition(IZ)V

    .line 78
    .line 79
    .line 80
    goto :goto_1

    .line 81
    :cond_1
    if-lt v7, p1, :cond_3

    .line 82
    .line 83
    sget-boolean v3, Landroidx/recyclerview/widget/RecyclerView;->z0:Z

    .line 84
    .line 85
    if-eqz v3, :cond_2

    .line 86
    .line 87
    new-instance v3, Ljava/lang/StringBuilder;

    .line 88
    .line 89
    invoke-direct {v3, v8}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 90
    .line 91
    .line 92
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 93
    .line 94
    .line 95
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 96
    .line 97
    .line 98
    invoke-virtual {v3, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 99
    .line 100
    .line 101
    const-string v5, " now REMOVED"

    .line 102
    .line 103
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 104
    .line 105
    .line 106
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 107
    .line 108
    .line 109
    move-result-object v3

    .line 110
    invoke-static {v4, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 111
    .line 112
    .line 113
    :cond_2
    add-int/lit8 v3, p1, -0x1

    .line 114
    .line 115
    neg-int v4, p2

    .line 116
    invoke-virtual {v6, v3, v4, p3}, Landroidx/recyclerview/widget/i1;->flagRemovedAndOffsetPosition(IIZ)V

    .line 117
    .line 118
    .line 119
    :goto_1
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    .line 120
    .line 121
    const/4 v4, 0x1

    .line 122
    iput-boolean v4, v3, Landroidx/recyclerview/widget/e1;->e:Z

    .line 123
    .line 124
    :cond_3
    add-int/lit8 v2, v2, 0x1

    .line 125
    .line 126
    goto :goto_0

    .line 127
    :cond_4
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 128
    .line 129
    iget-object v2, v1, Landroidx/recyclerview/widget/a1;->c:Ljava/util/ArrayList;

    .line 130
    .line 131
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 132
    .line 133
    .line 134
    move-result v6

    .line 135
    :cond_5
    :goto_2
    add-int/lit8 v6, v6, -0x1

    .line 136
    .line 137
    if-ltz v6, :cond_8

    .line 138
    .line 139
    invoke-virtual {v2, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 140
    .line 141
    .line 142
    move-result-object v7

    .line 143
    check-cast v7, Landroidx/recyclerview/widget/i1;

    .line 144
    .line 145
    if-eqz v7, :cond_5

    .line 146
    .line 147
    iget v8, v7, Landroidx/recyclerview/widget/i1;->mPosition:I

    .line 148
    .line 149
    if-lt v8, v0, :cond_7

    .line 150
    .line 151
    sget-boolean v8, Landroidx/recyclerview/widget/RecyclerView;->z0:Z

    .line 152
    .line 153
    if-eqz v8, :cond_6

    .line 154
    .line 155
    new-instance v8, Ljava/lang/StringBuilder;

    .line 156
    .line 157
    const-string v9, "offsetPositionRecordsForRemove cached "

    .line 158
    .line 159
    invoke-direct {v8, v9}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 160
    .line 161
    .line 162
    invoke-virtual {v8, v6}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 163
    .line 164
    .line 165
    invoke-virtual {v8, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 166
    .line 167
    .line 168
    invoke-virtual {v8, v7}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 169
    .line 170
    .line 171
    invoke-virtual {v8, v3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 172
    .line 173
    .line 174
    iget v9, v7, Landroidx/recyclerview/widget/i1;->mPosition:I

    .line 175
    .line 176
    sub-int/2addr v9, p2

    .line 177
    invoke-virtual {v8, v9}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 178
    .line 179
    .line 180
    invoke-virtual {v8}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 181
    .line 182
    .line 183
    move-result-object v8

    .line 184
    invoke-static {v4, v8}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 185
    .line 186
    .line 187
    :cond_6
    neg-int v8, p2

    .line 188
    invoke-virtual {v7, v8, p3}, Landroidx/recyclerview/widget/i1;->offsetPosition(IZ)V

    .line 189
    .line 190
    .line 191
    goto :goto_2

    .line 192
    :cond_7
    if-lt v8, p1, :cond_5

    .line 193
    .line 194
    const/16 v8, 0x8

    .line 195
    .line 196
    invoke-virtual {v7, v8}, Landroidx/recyclerview/widget/i1;->addFlags(I)V

    .line 197
    .line 198
    .line 199
    invoke-virtual {v1, v6}, Landroidx/recyclerview/widget/a1;->g(I)V

    .line 200
    .line 201
    .line 202
    goto :goto_2

    .line 203
    :cond_8
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->requestLayout()V

    .line 204
    .line 205
    .line 206
    return-void
.end method

.method public final N()V
    .locals 1

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView;->E:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView;->E:I

    return-void
.end method

.method public final O(Z)V
    .locals 6

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView;->E:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    sub-int/2addr v0, v1

    .line 5
    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView;->E:I

    .line 6
    .line 7
    if-ge v0, v1, :cond_7

    .line 8
    .line 9
    sget-boolean v2, Landroidx/recyclerview/widget/RecyclerView;->y0:Z

    .line 10
    .line 11
    if-eqz v2, :cond_1

    .line 12
    .line 13
    if-ltz v0, :cond_0

    .line 14
    .line 15
    goto :goto_0

    .line 16
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 17
    .line 18
    new-instance v0, Ljava/lang/StringBuilder;

    .line 19
    .line 20
    const-string v1, "layout or scroll counter cannot go below zero.Some calls are not matching"

    .line 21
    .line 22
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    invoke-static {p0, v0}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 26
    .line 27
    .line 28
    move-result-object v0

    .line 29
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 30
    .line 31
    .line 32
    throw p1

    .line 33
    :cond_1
    :goto_0
    const/4 v0, 0x0

    .line 34
    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView;->E:I

    .line 35
    .line 36
    if-eqz p1, :cond_7

    .line 37
    .line 38
    iget p1, p0, Landroidx/recyclerview/widget/RecyclerView;->z:I

    .line 39
    .line 40
    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView;->z:I

    .line 41
    .line 42
    if-eqz p1, :cond_3

    .line 43
    .line 44
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->B:Landroid/view/accessibility/AccessibilityManager;

    .line 45
    .line 46
    if-eqz v0, :cond_2

    .line 47
    .line 48
    invoke-virtual {v0}, Landroid/view/accessibility/AccessibilityManager;->isEnabled()Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-eqz v0, :cond_2

    .line 53
    .line 54
    goto :goto_1

    .line 55
    :cond_2
    const/4 v1, 0x0

    .line 56
    :goto_1
    if-eqz v1, :cond_3

    .line 57
    .line 58
    invoke-static {}, Landroid/view/accessibility/AccessibilityEvent;->obtain()Landroid/view/accessibility/AccessibilityEvent;

    .line 59
    .line 60
    .line 61
    move-result-object v0

    .line 62
    const/16 v1, 0x800

    .line 63
    .line 64
    invoke-virtual {v0, v1}, Landroid/view/accessibility/AccessibilityEvent;->setEventType(I)V

    .line 65
    .line 66
    .line 67
    invoke-static {v0, p1}, Lh/b;->b(Landroid/view/accessibility/AccessibilityEvent;I)V

    .line 68
    .line 69
    .line 70
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView;->sendAccessibilityEventUnchecked(Landroid/view/accessibility/AccessibilityEvent;)V

    .line 71
    .line 72
    .line 73
    :cond_3
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->s0:Ljava/util/ArrayList;

    .line 74
    .line 75
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 76
    .line 77
    .line 78
    move-result v0

    .line 79
    const/4 v1, -0x1

    .line 80
    add-int/2addr v0, v1

    .line 81
    :goto_2
    if-ltz v0, :cond_6

    .line 82
    .line 83
    invoke-virtual {p1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object v2

    .line 87
    check-cast v2, Landroidx/recyclerview/widget/i1;

    .line 88
    .line 89
    iget-object v3, v2, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 90
    .line 91
    invoke-virtual {v3}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 92
    .line 93
    .line 94
    move-result-object v3

    .line 95
    if-ne v3, p0, :cond_5

    .line 96
    .line 97
    invoke-virtual {v2}, Landroidx/recyclerview/widget/i1;->shouldIgnore()Z

    .line 98
    .line 99
    .line 100
    move-result v3

    .line 101
    if-eqz v3, :cond_4

    .line 102
    .line 103
    goto :goto_3

    .line 104
    :cond_4
    iget v3, v2, Landroidx/recyclerview/widget/i1;->mPendingAccessibilityState:I

    .line 105
    .line 106
    if-eq v3, v1, :cond_5

    .line 107
    .line 108
    iget-object v4, v2, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 109
    .line 110
    sget-object v5, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 111
    .line 112
    invoke-static {v4, v3}, Lg/j;->s(Landroid/view/View;I)V

    .line 113
    .line 114
    .line 115
    iput v1, v2, Landroidx/recyclerview/widget/i1;->mPendingAccessibilityState:I

    .line 116
    .line 117
    :cond_5
    :goto_3
    add-int/lit8 v0, v0, -0x1

    .line 118
    .line 119
    goto :goto_2

    .line 120
    :cond_6
    invoke-virtual {p1}, Ljava/util/ArrayList;->clear()V

    .line 121
    .line 122
    .line 123
    :cond_7
    return-void
.end method

.method public final P(Landroid/view/MotionEvent;)V
    .locals 3

    .line 1
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    move-result v0

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v1

    iget v2, p0, Landroidx/recyclerview/widget/RecyclerView;->N:I

    if-ne v1, v2, :cond_1

    if-nez v0, :cond_0

    const/4 v0, 0x1

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getPointerId(I)I

    move-result v1

    iput v1, p0, Landroidx/recyclerview/widget/RecyclerView;->N:I

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getX(I)F

    move-result v1

    const/high16 v2, 0x3f000000    # 0.5f

    add-float/2addr v1, v2

    float-to-int v1, v1

    iput v1, p0, Landroidx/recyclerview/widget/RecyclerView;->R:I

    iput v1, p0, Landroidx/recyclerview/widget/RecyclerView;->P:I

    invoke-virtual {p1, v0}, Landroid/view/MotionEvent;->getY(I)F

    move-result p1

    add-float/2addr p1, v2

    float-to-int p1, p1

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView;->S:I

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView;->Q:I

    :cond_1
    return-void
.end method

.method public final Q()V
    .locals 1

    .line 1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->l0:Z

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->s:Z

    .line 6
    .line 7
    if-eqz v0, :cond_0

    .line 8
    .line 9
    sget-object v0, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 10
    .line 11
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->t0:Landroidx/recyclerview/widget/f0;

    .line 12
    .line 13
    invoke-static {p0, v0}, Lg/j;->m(Landroid/view/View;Ljava/lang/Runnable;)V

    .line 14
    .line 15
    .line 16
    const/4 v0, 0x1

    .line 17
    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->l0:Z

    .line 18
    .line 19
    :cond_0
    return-void
.end method

.method public final R()V
    .locals 5

    .line 1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->C:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->e:Landroidx/recyclerview/widget/b;

    .line 7
    .line 8
    iget-object v2, v0, Landroidx/recyclerview/widget/b;->b:Ljava/util/ArrayList;

    .line 9
    .line 10
    invoke-virtual {v0, v2}, Landroidx/recyclerview/widget/b;->l(Ljava/util/ArrayList;)V

    .line 11
    .line 12
    .line 13
    iget-object v2, v0, Landroidx/recyclerview/widget/b;->c:Ljava/util/ArrayList;

    .line 14
    .line 15
    invoke-virtual {v0, v2}, Landroidx/recyclerview/widget/b;->l(Ljava/util/ArrayList;)V

    .line 16
    .line 17
    .line 18
    iput v1, v0, Landroidx/recyclerview/widget/b;->f:I

    .line 19
    .line 20
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->D:Z

    .line 21
    .line 22
    if-eqz v0, :cond_0

    .line 23
    .line 24
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 25
    .line 26
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->T()V

    .line 27
    .line 28
    .line 29
    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 30
    .line 31
    const/4 v2, 0x1

    .line 32
    if-eqz v0, :cond_1

    .line 33
    .line 34
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 35
    .line 36
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->t0()Z

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-eqz v0, :cond_1

    .line 41
    .line 42
    const/4 v0, 0x1

    .line 43
    goto :goto_0

    .line 44
    :cond_1
    const/4 v0, 0x0

    .line 45
    :goto_0
    if-eqz v0, :cond_2

    .line 46
    .line 47
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->e:Landroidx/recyclerview/widget/b;

    .line 48
    .line 49
    invoke-virtual {v0}, Landroidx/recyclerview/widget/b;->j()V

    .line 50
    .line 51
    .line 52
    goto :goto_1

    .line 53
    :cond_2
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->e:Landroidx/recyclerview/widget/b;

    .line 54
    .line 55
    invoke-virtual {v0}, Landroidx/recyclerview/widget/b;->c()V

    .line 56
    .line 57
    .line 58
    :goto_1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->i0:Z

    .line 59
    .line 60
    if-nez v0, :cond_4

    .line 61
    .line 62
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->j0:Z

    .line 63
    .line 64
    if-eqz v0, :cond_3

    .line 65
    .line 66
    goto :goto_2

    .line 67
    :cond_3
    const/4 v0, 0x0

    .line 68
    goto :goto_3

    .line 69
    :cond_4
    :goto_2
    const/4 v0, 0x1

    .line 70
    :goto_3
    iget-boolean v3, p0, Landroidx/recyclerview/widget/RecyclerView;->u:Z

    .line 71
    .line 72
    if-eqz v3, :cond_7

    .line 73
    .line 74
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 75
    .line 76
    if-eqz v3, :cond_7

    .line 77
    .line 78
    iget-boolean v3, p0, Landroidx/recyclerview/widget/RecyclerView;->C:Z

    .line 79
    .line 80
    if-nez v3, :cond_5

    .line 81
    .line 82
    if-nez v0, :cond_5

    .line 83
    .line 84
    iget-object v4, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 85
    .line 86
    iget-boolean v4, v4, Landroidx/recyclerview/widget/t0;->e:Z

    .line 87
    .line 88
    if-eqz v4, :cond_7

    .line 89
    .line 90
    :cond_5
    if-eqz v3, :cond_6

    .line 91
    .line 92
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 93
    .line 94
    invoke-virtual {v3}, Landroidx/recyclerview/widget/i0;->hasStableIds()Z

    .line 95
    .line 96
    .line 97
    move-result v3

    .line 98
    if-eqz v3, :cond_7

    .line 99
    .line 100
    :cond_6
    const/4 v3, 0x1

    .line 101
    goto :goto_4

    .line 102
    :cond_7
    const/4 v3, 0x0

    .line 103
    :goto_4
    iget-object v4, p0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    .line 104
    .line 105
    iput-boolean v3, v4, Landroidx/recyclerview/widget/e1;->i:Z

    .line 106
    .line 107
    if-eqz v3, :cond_9

    .line 108
    .line 109
    if-eqz v0, :cond_9

    .line 110
    .line 111
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->C:Z

    .line 112
    .line 113
    if-nez v0, :cond_9

    .line 114
    .line 115
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 116
    .line 117
    if-eqz v0, :cond_8

    .line 118
    .line 119
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 120
    .line 121
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->t0()Z

    .line 122
    .line 123
    .line 124
    move-result v0

    .line 125
    if-eqz v0, :cond_8

    .line 126
    .line 127
    const/4 v0, 0x1

    .line 128
    goto :goto_5

    .line 129
    :cond_8
    const/4 v0, 0x0

    .line 130
    :goto_5
    if-eqz v0, :cond_9

    .line 131
    .line 132
    const/4 v1, 0x1

    .line 133
    :cond_9
    iput-boolean v1, v4, Landroidx/recyclerview/widget/e1;->j:Z

    .line 134
    .line 135
    return-void
.end method

.method public final S(Z)V
    .locals 6

    .line 1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->D:Z

    .line 2
    .line 3
    or-int/2addr p1, v0

    .line 4
    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView;->D:Z

    .line 5
    .line 6
    const/4 p1, 0x1

    .line 7
    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView;->C:Z

    .line 8
    .line 9
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 10
    .line 11
    invoke-virtual {p1}, Landroidx/recyclerview/widget/e;->h()I

    .line 12
    .line 13
    .line 14
    move-result p1

    .line 15
    const/4 v0, 0x0

    .line 16
    const/4 v1, 0x0

    .line 17
    :goto_0
    const/4 v2, 0x6

    .line 18
    if-ge v1, p1, :cond_1

    .line 19
    .line 20
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 21
    .line 22
    invoke-virtual {v3, v1}, Landroidx/recyclerview/widget/e;->g(I)Landroid/view/View;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    invoke-static {v3}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 27
    .line 28
    .line 29
    move-result-object v3

    .line 30
    if-eqz v3, :cond_0

    .line 31
    .line 32
    invoke-virtual {v3}, Landroidx/recyclerview/widget/i1;->shouldIgnore()Z

    .line 33
    .line 34
    .line 35
    move-result v4

    .line 36
    if-nez v4, :cond_0

    .line 37
    .line 38
    invoke-virtual {v3, v2}, Landroidx/recyclerview/widget/i1;->addFlags(I)V

    .line 39
    .line 40
    .line 41
    :cond_0
    add-int/lit8 v1, v1, 0x1

    .line 42
    .line 43
    goto :goto_0

    .line 44
    :cond_1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->L()V

    .line 45
    .line 46
    .line 47
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 48
    .line 49
    iget-object v1, p1, Landroidx/recyclerview/widget/a1;->c:Ljava/util/ArrayList;

    .line 50
    .line 51
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 52
    .line 53
    .line 54
    move-result v3

    .line 55
    :goto_1
    if-ge v0, v3, :cond_3

    .line 56
    .line 57
    invoke-virtual {v1, v0}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 58
    .line 59
    .line 60
    move-result-object v4

    .line 61
    check-cast v4, Landroidx/recyclerview/widget/i1;

    .line 62
    .line 63
    if-eqz v4, :cond_2

    .line 64
    .line 65
    invoke-virtual {v4, v2}, Landroidx/recyclerview/widget/i1;->addFlags(I)V

    .line 66
    .line 67
    .line 68
    const/4 v5, 0x0

    .line 69
    invoke-virtual {v4, v5}, Landroidx/recyclerview/widget/i1;->addChangePayload(Ljava/lang/Object;)V

    .line 70
    .line 71
    .line 72
    :cond_2
    add-int/lit8 v0, v0, 0x1

    .line 73
    .line 74
    goto :goto_1

    .line 75
    :cond_3
    iget-object v0, p1, Landroidx/recyclerview/widget/a1;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 76
    .line 77
    iget-object v0, v0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 78
    .line 79
    if-eqz v0, :cond_4

    .line 80
    .line 81
    invoke-virtual {v0}, Landroidx/recyclerview/widget/i0;->hasStableIds()Z

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    if-nez v0, :cond_5

    .line 86
    .line 87
    :cond_4
    invoke-virtual {p1}, Landroidx/recyclerview/widget/a1;->f()V

    .line 88
    .line 89
    .line 90
    :cond_5
    return-void
.end method

.method public final T(Landroidx/recyclerview/widget/i1;Landroidx/recyclerview/widget/n0;)V
    .locals 4

    .line 1
    const/4 v0, 0x0

    const/16 v1, 0x2000

    invoke-virtual {p1, v0, v1}, Landroidx/recyclerview/widget/i1;->setFlags(II)V

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    iget-boolean v0, v0, Landroidx/recyclerview/widget/e1;->g:Z

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->g:Landroidx/recyclerview/widget/t1;

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->isUpdated()Z

    move-result v0

    if-eqz v0, :cond_0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->isRemoved()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->shouldIgnore()Z

    move-result v0

    if-nez v0, :cond_0

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView;->G(Landroidx/recyclerview/widget/i1;)J

    move-result-wide v2

    invoke-virtual {v1, v2, v3, p1}, Landroidx/recyclerview/widget/t1;->b(JLandroidx/recyclerview/widget/i1;)V

    :cond_0
    invoke-virtual {v1, p1, p2}, Landroidx/recyclerview/widget/t1;->d(Landroidx/recyclerview/widget/i1;Landroidx/recyclerview/widget/n0;)V

    return-void
.end method

.method public final U(FI)I
    .locals 3

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v0

    int-to-float v0, v0

    div-float/2addr p1, v0

    int-to-float p2, p2

    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v0

    int-to-float v0, v0

    div-float/2addr p2, v0

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    invoke-static {v0}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    move-result v0

    cmpl-float v0, v0, v1

    if-eqz v0, :cond_2

    const/4 v0, -0x1

    invoke-virtual {p0, v0}, Landroid/view/View;->canScrollHorizontally(I)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    :goto_0
    invoke-virtual {p1}, Landroid/widget/EdgeEffect;->onRelease()V

    goto :goto_2

    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    neg-float p2, p2

    const/high16 v2, 0x3f800000    # 1.0f

    sub-float/2addr v2, p1

    invoke-static {v0, p2, v2}, Lb0/d;->A(Landroid/widget/EdgeEffect;FF)F

    move-result p1

    neg-float p1, p1

    iget-object p2, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    invoke-static {p2}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    move-result p2

    cmpl-float p2, p2, v1

    if-nez p2, :cond_1

    iget-object p2, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    invoke-virtual {p2}, Landroid/widget/EdgeEffect;->onRelease()V

    :cond_1
    :goto_1
    move v1, p1

    :goto_2
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    goto :goto_3

    :cond_2
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    if-eqz v0, :cond_4

    invoke-static {v0}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    move-result v0

    cmpl-float v0, v0, v1

    if-eqz v0, :cond_4

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/view/View;->canScrollHorizontally(I)Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    goto :goto_0

    :cond_3
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    invoke-static {v0, p2, p1}, Lb0/d;->A(Landroid/widget/EdgeEffect;FF)F

    move-result p1

    iget-object p2, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    invoke-static {p2}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    move-result p2

    cmpl-float p2, p2, v1

    if-nez p2, :cond_1

    iget-object p2, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    invoke-virtual {p2}, Landroid/widget/EdgeEffect;->onRelease()V

    goto :goto_1

    :cond_4
    :goto_3
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result p1

    int-to-float p1, p1

    mul-float v1, v1, p1

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result p1

    return p1
.end method

.method public final V(FI)I
    .locals 3

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    move-result v0

    int-to-float v0, v0

    div-float/2addr p1, v0

    int-to-float p2, p2

    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result v0

    int-to-float v0, v0

    div-float/2addr p2, v0

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    const/4 v1, 0x0

    if-eqz v0, :cond_2

    invoke-static {v0}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    move-result v0

    cmpl-float v0, v0, v1

    if-eqz v0, :cond_2

    const/4 v0, -0x1

    invoke-virtual {p0, v0}, Landroid/view/View;->canScrollVertically(I)Z

    move-result v0

    if-eqz v0, :cond_0

    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    :goto_0
    invoke-virtual {p1}, Landroid/widget/EdgeEffect;->onRelease()V

    goto :goto_2

    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    neg-float p2, p2

    invoke-static {v0, p2, p1}, Lb0/d;->A(Landroid/widget/EdgeEffect;FF)F

    move-result p1

    neg-float p1, p1

    iget-object p2, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    invoke-static {p2}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    move-result p2

    cmpl-float p2, p2, v1

    if-nez p2, :cond_1

    iget-object p2, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    invoke-virtual {p2}, Landroid/widget/EdgeEffect;->onRelease()V

    :cond_1
    :goto_1
    move v1, p1

    :goto_2
    invoke-virtual {p0}, Landroid/view/View;->invalidate()V

    goto :goto_3

    :cond_2
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    if-eqz v0, :cond_4

    invoke-static {v0}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    move-result v0

    cmpl-float v0, v0, v1

    if-eqz v0, :cond_4

    const/4 v0, 0x1

    invoke-virtual {p0, v0}, Landroid/view/View;->canScrollVertically(I)Z

    move-result v0

    if-eqz v0, :cond_3

    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    goto :goto_0

    :cond_3
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    const/high16 v2, 0x3f800000    # 1.0f

    sub-float/2addr v2, p1

    invoke-static {v0, p2, v2}, Lb0/d;->A(Landroid/widget/EdgeEffect;FF)F

    move-result p1

    iget-object p2, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    invoke-static {p2}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    move-result p2

    cmpl-float p2, p2, v1

    if-nez p2, :cond_1

    iget-object p2, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    invoke-virtual {p2}, Landroid/widget/EdgeEffect;->onRelease()V

    goto :goto_1

    :cond_4
    :goto_3
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    move-result p1

    int-to-float p1, p1

    mul-float v1, v1, p1

    invoke-static {v1}, Ljava/lang/Math;->round(F)I

    move-result p1

    return p1
.end method

.method public final W(Landroid/view/View;Landroid/view/View;)V
    .locals 11

    .line 1
    if-eqz p2, :cond_0

    move-object v0, p2

    goto :goto_0

    :cond_0
    move-object v0, p1

    :goto_0
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    move-result v1

    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    move-result v2

    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->j:Landroid/graphics/Rect;

    const/4 v4, 0x0

    invoke-virtual {v3, v4, v4, v1, v2}, Landroid/graphics/Rect;->set(IIII)V

    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    move-result-object v0

    instance-of v1, v0, Landroidx/recyclerview/widget/u0;

    if-eqz v1, :cond_1

    check-cast v0, Landroidx/recyclerview/widget/u0;

    iget-boolean v1, v0, Landroidx/recyclerview/widget/u0;->c:Z

    if-nez v1, :cond_1

    iget v1, v3, Landroid/graphics/Rect;->left:I

    iget-object v0, v0, Landroidx/recyclerview/widget/u0;->b:Landroid/graphics/Rect;

    iget v2, v0, Landroid/graphics/Rect;->left:I

    sub-int/2addr v1, v2

    iput v1, v3, Landroid/graphics/Rect;->left:I

    iget v1, v3, Landroid/graphics/Rect;->right:I

    iget v2, v0, Landroid/graphics/Rect;->right:I

    add-int/2addr v1, v2

    iput v1, v3, Landroid/graphics/Rect;->right:I

    iget v1, v3, Landroid/graphics/Rect;->top:I

    iget v2, v0, Landroid/graphics/Rect;->top:I

    sub-int/2addr v1, v2

    iput v1, v3, Landroid/graphics/Rect;->top:I

    iget v1, v3, Landroid/graphics/Rect;->bottom:I

    iget v0, v0, Landroid/graphics/Rect;->bottom:I

    add-int/2addr v1, v0

    iput v1, v3, Landroid/graphics/Rect;->bottom:I

    :cond_1
    if-eqz p2, :cond_2

    invoke-virtual {p0, p2, v3}, Landroid/view/ViewGroup;->offsetDescendantRectToMyCoords(Landroid/view/View;Landroid/graphics/Rect;)V

    invoke-virtual {p0, p1, v3}, Landroid/view/ViewGroup;->offsetRectIntoDescendantCoords(Landroid/view/View;Landroid/graphics/Rect;)V

    :cond_2
    iget-object v5, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    iget-object v8, p0, Landroidx/recyclerview/widget/RecyclerView;->j:Landroid/graphics/Rect;

    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->u:Z

    const/4 v1, 0x1

    xor-int/lit8 v9, v0, 0x1

    if-nez p2, :cond_3

    const/4 v10, 0x1

    goto :goto_1

    :cond_3
    const/4 v10, 0x0

    :goto_1
    move-object v6, p0

    move-object v7, p1

    invoke-virtual/range {v5 .. v10}, Landroidx/recyclerview/widget/t0;->g0(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/View;Landroid/graphics/Rect;ZZ)Z

    return-void
.end method

.method public final X()V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->O:Landroid/view/VelocityTracker;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/view/VelocityTracker;->clear()V

    .line 6
    .line 7
    .line 8
    :cond_0
    const/4 v0, 0x0

    .line 9
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView;->f0(I)V

    .line 10
    .line 11
    .line 12
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 13
    .line 14
    if-eqz v1, :cond_1

    .line 15
    .line 16
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->onRelease()V

    .line 17
    .line 18
    .line 19
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 20
    .line 21
    invoke-virtual {v0}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    :cond_1
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 26
    .line 27
    if-eqz v1, :cond_2

    .line 28
    .line 29
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->onRelease()V

    .line 30
    .line 31
    .line 32
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 33
    .line 34
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 35
    .line 36
    .line 37
    move-result v1

    .line 38
    or-int/2addr v0, v1

    .line 39
    :cond_2
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 40
    .line 41
    if-eqz v1, :cond_3

    .line 42
    .line 43
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->onRelease()V

    .line 44
    .line 45
    .line 46
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 47
    .line 48
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 49
    .line 50
    .line 51
    move-result v1

    .line 52
    or-int/2addr v0, v1

    .line 53
    :cond_3
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 54
    .line 55
    if-eqz v1, :cond_4

    .line 56
    .line 57
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->onRelease()V

    .line 58
    .line 59
    .line 60
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 61
    .line 62
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 63
    .line 64
    .line 65
    move-result v1

    .line 66
    or-int/2addr v0, v1

    .line 67
    :cond_4
    if-eqz v0, :cond_5

    .line 68
    .line 69
    sget-object v0, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 70
    .line 71
    invoke-static {p0}, Lg/j;->k(Landroid/view/View;)V

    .line 72
    .line 73
    .line 74
    :cond_5
    return-void
.end method

.method public final Y(IILandroid/view/MotionEvent;I)Z
    .locals 18

    .line 1
    move-object/from16 v8, p0

    .line 2
    .line 3
    move/from16 v9, p1

    .line 4
    .line 5
    move/from16 v10, p2

    .line 6
    .line 7
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView;->m()V

    .line 8
    .line 9
    .line 10
    iget-object v0, v8, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 11
    .line 12
    iget-object v11, v8, Landroidx/recyclerview/widget/RecyclerView;->r0:[I

    .line 13
    .line 14
    const/4 v12, 0x1

    .line 15
    const/4 v13, 0x0

    .line 16
    if-eqz v0, :cond_0

    .line 17
    .line 18
    aput v13, v11, v13

    .line 19
    .line 20
    aput v13, v11, v12

    .line 21
    .line 22
    invoke-virtual {v8, v9, v10, v11}, Landroidx/recyclerview/widget/RecyclerView;->Z(II[I)V

    .line 23
    .line 24
    .line 25
    aget v0, v11, v13

    .line 26
    .line 27
    aget v1, v11, v12

    .line 28
    .line 29
    sub-int v2, v9, v0

    .line 30
    .line 31
    sub-int v3, v10, v1

    .line 32
    .line 33
    move v14, v0

    .line 34
    move v15, v1

    .line 35
    move/from16 v16, v2

    .line 36
    .line 37
    move/from16 v17, v3

    .line 38
    .line 39
    goto :goto_0

    .line 40
    :cond_0
    const/4 v14, 0x0

    .line 41
    const/4 v15, 0x0

    .line 42
    const/16 v16, 0x0

    .line 43
    .line 44
    const/16 v17, 0x0

    .line 45
    .line 46
    :goto_0
    iget-object v0, v8, Landroidx/recyclerview/widget/RecyclerView;->p:Ljava/util/ArrayList;

    .line 47
    .line 48
    invoke-virtual {v0}, Ljava/util/ArrayList;->isEmpty()Z

    .line 49
    .line 50
    .line 51
    move-result v0

    .line 52
    if-nez v0, :cond_1

    .line 53
    .line 54
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    .line 55
    .line 56
    .line 57
    :cond_1
    iget-object v7, v8, Landroidx/recyclerview/widget/RecyclerView;->r0:[I

    .line 58
    .line 59
    aput v13, v7, v13

    .line 60
    .line 61
    aput v13, v7, v12

    .line 62
    .line 63
    iget-object v5, v8, Landroidx/recyclerview/widget/RecyclerView;->p0:[I

    .line 64
    .line 65
    move-object/from16 v0, p0

    .line 66
    .line 67
    move v1, v14

    .line 68
    move v2, v15

    .line 69
    move/from16 v3, v16

    .line 70
    .line 71
    move/from16 v4, v17

    .line 72
    .line 73
    move/from16 v6, p4

    .line 74
    .line 75
    invoke-virtual/range {v0 .. v7}, Landroidx/recyclerview/widget/RecyclerView;->s(IIII[II[I)V

    .line 76
    .line 77
    .line 78
    aget v0, v11, v13

    .line 79
    .line 80
    sub-int v1, v16, v0

    .line 81
    .line 82
    aget v2, v11, v12

    .line 83
    .line 84
    sub-int v3, v17, v2

    .line 85
    .line 86
    if-nez v0, :cond_3

    .line 87
    .line 88
    if-eqz v2, :cond_2

    .line 89
    .line 90
    goto :goto_1

    .line 91
    :cond_2
    const/4 v0, 0x0

    .line 92
    goto :goto_2

    .line 93
    :cond_3
    :goto_1
    const/4 v0, 0x1

    .line 94
    :goto_2
    iget v2, v8, Landroidx/recyclerview/widget/RecyclerView;->R:I

    .line 95
    .line 96
    iget-object v4, v8, Landroidx/recyclerview/widget/RecyclerView;->p0:[I

    .line 97
    .line 98
    aget v5, v4, v13

    .line 99
    .line 100
    sub-int/2addr v2, v5

    .line 101
    iput v2, v8, Landroidx/recyclerview/widget/RecyclerView;->R:I

    .line 102
    .line 103
    iget v2, v8, Landroidx/recyclerview/widget/RecyclerView;->S:I

    .line 104
    .line 105
    aget v4, v4, v12

    .line 106
    .line 107
    sub-int/2addr v2, v4

    .line 108
    iput v2, v8, Landroidx/recyclerview/widget/RecyclerView;->S:I

    .line 109
    .line 110
    iget-object v2, v8, Landroidx/recyclerview/widget/RecyclerView;->q0:[I

    .line 111
    .line 112
    aget v6, v2, v13

    .line 113
    .line 114
    add-int/2addr v6, v5

    .line 115
    aput v6, v2, v13

    .line 116
    .line 117
    aget v5, v2, v12

    .line 118
    .line 119
    add-int/2addr v5, v4

    .line 120
    aput v5, v2, v12

    .line 121
    .line 122
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getOverScrollMode()I

    .line 123
    .line 124
    .line 125
    move-result v2

    .line 126
    const/4 v4, 0x2

    .line 127
    if-eq v2, v4, :cond_b

    .line 128
    .line 129
    if-eqz p3, :cond_a

    .line 130
    .line 131
    invoke-virtual/range {p3 .. p3}, Landroid/view/MotionEvent;->getSource()I

    .line 132
    .line 133
    .line 134
    move-result v2

    .line 135
    const/16 v4, 0x2002

    .line 136
    .line 137
    and-int/2addr v2, v4

    .line 138
    if-ne v2, v4, :cond_4

    .line 139
    .line 140
    const/4 v2, 0x1

    .line 141
    goto :goto_3

    .line 142
    :cond_4
    const/4 v2, 0x0

    .line 143
    :goto_3
    if-nez v2, :cond_a

    .line 144
    .line 145
    invoke-virtual/range {p3 .. p3}, Landroid/view/MotionEvent;->getX()F

    .line 146
    .line 147
    .line 148
    move-result v2

    .line 149
    int-to-float v1, v1

    .line 150
    invoke-virtual/range {p3 .. p3}, Landroid/view/MotionEvent;->getY()F

    .line 151
    .line 152
    .line 153
    move-result v4

    .line 154
    int-to-float v3, v3

    .line 155
    const/high16 v5, 0x3f800000    # 1.0f

    .line 156
    .line 157
    const/4 v6, 0x0

    .line 158
    cmpg-float v7, v1, v6

    .line 159
    .line 160
    if-gez v7, :cond_5

    .line 161
    .line 162
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView;->v()V

    .line 163
    .line 164
    .line 165
    iget-object v7, v8, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 166
    .line 167
    neg-float v11, v1

    .line 168
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 169
    .line 170
    .line 171
    move-result v12

    .line 172
    int-to-float v12, v12

    .line 173
    div-float/2addr v11, v12

    .line 174
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 175
    .line 176
    .line 177
    move-result v12

    .line 178
    int-to-float v12, v12

    .line 179
    div-float/2addr v4, v12

    .line 180
    sub-float v4, v5, v4

    .line 181
    .line 182
    goto :goto_4

    .line 183
    :cond_5
    cmpl-float v7, v1, v6

    .line 184
    .line 185
    if-lez v7, :cond_6

    .line 186
    .line 187
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView;->w()V

    .line 188
    .line 189
    .line 190
    iget-object v7, v8, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 191
    .line 192
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 193
    .line 194
    .line 195
    move-result v11

    .line 196
    int-to-float v11, v11

    .line 197
    div-float v11, v1, v11

    .line 198
    .line 199
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 200
    .line 201
    .line 202
    move-result v12

    .line 203
    int-to-float v12, v12

    .line 204
    div-float/2addr v4, v12

    .line 205
    :goto_4
    invoke-static {v7, v11, v4}, Lb0/d;->A(Landroid/widget/EdgeEffect;FF)F

    .line 206
    .line 207
    .line 208
    const/4 v4, 0x1

    .line 209
    goto :goto_5

    .line 210
    :cond_6
    const/4 v4, 0x0

    .line 211
    :goto_5
    cmpg-float v7, v3, v6

    .line 212
    .line 213
    if-gez v7, :cond_7

    .line 214
    .line 215
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView;->x()V

    .line 216
    .line 217
    .line 218
    iget-object v4, v8, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 219
    .line 220
    neg-float v5, v3

    .line 221
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 222
    .line 223
    .line 224
    move-result v7

    .line 225
    int-to-float v7, v7

    .line 226
    div-float/2addr v5, v7

    .line 227
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 228
    .line 229
    .line 230
    move-result v7

    .line 231
    int-to-float v7, v7

    .line 232
    div-float/2addr v2, v7

    .line 233
    invoke-static {v4, v5, v2}, Lb0/d;->A(Landroid/widget/EdgeEffect;FF)F

    .line 234
    .line 235
    .line 236
    goto :goto_6

    .line 237
    :cond_7
    cmpl-float v7, v3, v6

    .line 238
    .line 239
    if-lez v7, :cond_8

    .line 240
    .line 241
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView;->u()V

    .line 242
    .line 243
    .line 244
    iget-object v4, v8, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 245
    .line 246
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 247
    .line 248
    .line 249
    move-result v7

    .line 250
    int-to-float v7, v7

    .line 251
    div-float v7, v3, v7

    .line 252
    .line 253
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 254
    .line 255
    .line 256
    move-result v11

    .line 257
    int-to-float v11, v11

    .line 258
    div-float/2addr v2, v11

    .line 259
    sub-float/2addr v5, v2

    .line 260
    invoke-static {v4, v7, v5}, Lb0/d;->A(Landroid/widget/EdgeEffect;FF)F

    .line 261
    .line 262
    .line 263
    :goto_6
    const/4 v4, 0x1

    .line 264
    :cond_8
    if-nez v4, :cond_9

    .line 265
    .line 266
    cmpl-float v1, v1, v6

    .line 267
    .line 268
    if-nez v1, :cond_9

    .line 269
    .line 270
    cmpl-float v1, v3, v6

    .line 271
    .line 272
    if-eqz v1, :cond_a

    .line 273
    .line 274
    :cond_9
    sget-object v1, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 275
    .line 276
    invoke-static/range {p0 .. p0}, Lg/j;->k(Landroid/view/View;)V

    .line 277
    .line 278
    .line 279
    :cond_a
    invoke-virtual/range {p0 .. p2}, Landroidx/recyclerview/widget/RecyclerView;->k(II)V

    .line 280
    .line 281
    .line 282
    :cond_b
    if-nez v14, :cond_c

    .line 283
    .line 284
    if-eqz v15, :cond_d

    .line 285
    .line 286
    :cond_c
    invoke-virtual {v8, v14, v15}, Landroidx/recyclerview/widget/RecyclerView;->t(II)V

    .line 287
    .line 288
    .line 289
    :cond_d
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->awakenScrollBars()Z

    .line 290
    .line 291
    .line 292
    move-result v1

    .line 293
    if-nez v1, :cond_e

    .line 294
    .line 295
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->invalidate()V

    .line 296
    .line 297
    .line 298
    :cond_e
    if-nez v0, :cond_10

    .line 299
    .line 300
    if-nez v14, :cond_10

    .line 301
    .line 302
    if-eqz v15, :cond_f

    .line 303
    .line 304
    goto :goto_7

    .line 305
    :cond_f
    const/4 v12, 0x0

    .line 306
    goto :goto_8

    .line 307
    :cond_10
    :goto_7
    const/4 v12, 0x1

    .line 308
    :goto_8
    return v12
.end method

.method public final Z(II[I)V
    .locals 8

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->d0()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->N()V

    .line 5
    .line 6
    .line 7
    sget v0, Le/b;->a:I

    .line 8
    .line 9
    const-string v0, "RV Scroll"

    .line 10
    .line 11
    invoke-static {v0}, Le/a;->a(Ljava/lang/String;)V

    .line 12
    .line 13
    .line 14
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    .line 15
    .line 16
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView;->z(Landroidx/recyclerview/widget/e1;)V

    .line 17
    .line 18
    .line 19
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 20
    .line 21
    const/4 v2, 0x0

    .line 22
    if-eqz p1, :cond_0

    .line 23
    .line 24
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 25
    .line 26
    invoke-virtual {v3, p1, v1, v0}, Landroidx/recyclerview/widget/t0;->i0(ILandroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;)I

    .line 27
    .line 28
    .line 29
    move-result p1

    .line 30
    goto :goto_0

    .line 31
    :cond_0
    const/4 p1, 0x0

    .line 32
    :goto_0
    if-eqz p2, :cond_1

    .line 33
    .line 34
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 35
    .line 36
    invoke-virtual {v3, p2, v1, v0}, Landroidx/recyclerview/widget/t0;->k0(ILandroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;)I

    .line 37
    .line 38
    .line 39
    move-result p2

    .line 40
    goto :goto_1

    .line 41
    :cond_1
    const/4 p2, 0x0

    .line 42
    :goto_1
    invoke-static {}, Le/a;->b()V

    .line 43
    .line 44
    .line 45
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 46
    .line 47
    invoke-virtual {v0}, Landroidx/recyclerview/widget/e;->e()I

    .line 48
    .line 49
    .line 50
    move-result v0

    .line 51
    const/4 v1, 0x0

    .line 52
    :goto_2
    if-ge v1, v0, :cond_4

    .line 53
    .line 54
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 55
    .line 56
    invoke-virtual {v3, v1}, Landroidx/recyclerview/widget/e;->d(I)Landroid/view/View;

    .line 57
    .line 58
    .line 59
    move-result-object v3

    .line 60
    invoke-virtual {p0, v3}, Landroidx/recyclerview/widget/RecyclerView;->H(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 61
    .line 62
    .line 63
    move-result-object v4

    .line 64
    if-eqz v4, :cond_3

    .line 65
    .line 66
    iget-object v4, v4, Landroidx/recyclerview/widget/i1;->mShadowingHolder:Landroidx/recyclerview/widget/i1;

    .line 67
    .line 68
    if-eqz v4, :cond_3

    .line 69
    .line 70
    iget-object v4, v4, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 71
    .line 72
    invoke-virtual {v3}, Landroid/view/View;->getLeft()I

    .line 73
    .line 74
    .line 75
    move-result v5

    .line 76
    invoke-virtual {v3}, Landroid/view/View;->getTop()I

    .line 77
    .line 78
    .line 79
    move-result v3

    .line 80
    invoke-virtual {v4}, Landroid/view/View;->getLeft()I

    .line 81
    .line 82
    .line 83
    move-result v6

    .line 84
    if-ne v5, v6, :cond_2

    .line 85
    .line 86
    invoke-virtual {v4}, Landroid/view/View;->getTop()I

    .line 87
    .line 88
    .line 89
    move-result v6

    .line 90
    if-eq v3, v6, :cond_3

    .line 91
    .line 92
    :cond_2
    invoke-virtual {v4}, Landroid/view/View;->getWidth()I

    .line 93
    .line 94
    .line 95
    move-result v6

    .line 96
    add-int/2addr v6, v5

    .line 97
    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    .line 98
    .line 99
    .line 100
    move-result v7

    .line 101
    add-int/2addr v7, v3

    .line 102
    invoke-virtual {v4, v5, v3, v6, v7}, Landroid/view/View;->layout(IIII)V

    .line 103
    .line 104
    .line 105
    :cond_3
    add-int/lit8 v1, v1, 0x1

    .line 106
    .line 107
    goto :goto_2

    .line 108
    :cond_4
    const/4 v0, 0x1

    .line 109
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView;->O(Z)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/RecyclerView;->e0(Z)V

    .line 113
    .line 114
    .line 115
    if-eqz p3, :cond_5

    .line 116
    .line 117
    aput p1, p3, v2

    .line 118
    .line 119
    aput p2, p3, v0

    .line 120
    .line 121
    :cond_5
    return-void
.end method

.method public final a0(I)V
    .locals 2

    .line 1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->x:Z

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    const/4 v0, 0x0

    .line 7
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView;->setScrollState(I)V

    .line 8
    .line 9
    .line 10
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->c0:Landroidx/recyclerview/widget/h1;

    .line 11
    .line 12
    iget-object v1, v0, Landroidx/recyclerview/widget/h1;->g:Landroidx/recyclerview/widget/RecyclerView;

    .line 13
    .line 14
    invoke-virtual {v1, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 15
    .line 16
    .line 17
    iget-object v0, v0, Landroidx/recyclerview/widget/h1;->c:Landroid/widget/OverScroller;

    .line 18
    .line 19
    invoke-virtual {v0}, Landroid/widget/OverScroller;->abortAnimation()V

    .line 20
    .line 21
    .line 22
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 23
    .line 24
    if-nez v0, :cond_1

    .line 25
    .line 26
    const-string p1, "RecyclerView"

    .line 27
    .line 28
    const-string v0, "Cannot scroll to position a LayoutManager set. Call setLayoutManager with a non-null argument."

    .line 29
    .line 30
    invoke-static {p1, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 31
    .line 32
    .line 33
    return-void

    .line 34
    :cond_1
    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/t0;->j0(I)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {p0}, Landroid/view/View;->awakenScrollBars()Z

    .line 38
    .line 39
    .line 40
    return-void
.end method

.method public final addFocusables(Ljava/util/ArrayList;II)V
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :cond_0
    invoke-super {p0, p1, p2, p3}, Landroid/view/ViewGroup;->addFocusables(Ljava/util/ArrayList;II)V

    return-void
.end method

.method public final b0(Landroid/widget/EdgeEffect;II)Z
    .locals 7

    .line 1
    const/4 v0, 0x1

    .line 2
    if-lez p2, :cond_0

    .line 3
    .line 4
    return v0

    .line 5
    :cond_0
    invoke-static {p1}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    .line 6
    .line 7
    .line 8
    move-result p1

    .line 9
    int-to-float p3, p3

    .line 10
    mul-float p1, p1, p3

    .line 11
    .line 12
    neg-int p2, p2

    .line 13
    invoke-static {p2}, Ljava/lang/Math;->abs(I)I

    .line 14
    .line 15
    .line 16
    move-result p2

    .line 17
    int-to-float p2, p2

    .line 18
    const p3, 0x3eb33333    # 0.35f

    .line 19
    .line 20
    .line 21
    mul-float p2, p2, p3

    .line 22
    .line 23
    iget p3, p0, Landroidx/recyclerview/widget/RecyclerView;->a:F

    .line 24
    .line 25
    const v1, 0x3c75c28f    # 0.015f

    .line 26
    .line 27
    .line 28
    mul-float p3, p3, v1

    .line 29
    .line 30
    div-float/2addr p2, p3

    .line 31
    float-to-double v1, p2

    .line 32
    invoke-static {v1, v2}, Ljava/lang/Math;->log(D)D

    .line 33
    .line 34
    .line 35
    move-result-wide v1

    .line 36
    sget p2, Landroidx/recyclerview/widget/RecyclerView;->B0:F

    .line 37
    .line 38
    float-to-double v3, p2

    .line 39
    const-wide/high16 v5, 0x3ff0000000000000L    # 1.0

    .line 40
    .line 41
    sub-double v5, v3, v5

    .line 42
    .line 43
    float-to-double p2, p3

    .line 44
    div-double/2addr v3, v5

    .line 45
    mul-double v3, v3, v1

    .line 46
    .line 47
    invoke-static {v3, v4}, Ljava/lang/Math;->exp(D)D

    .line 48
    .line 49
    .line 50
    move-result-wide v1

    .line 51
    mul-double v1, v1, p2

    .line 52
    .line 53
    double-to-float p2, v1

    .line 54
    cmpg-float p1, p2, p1

    .line 55
    .line 56
    if-gez p1, :cond_1

    .line 57
    .line 58
    goto :goto_0

    .line 59
    :cond_1
    const/4 v0, 0x0

    .line 60
    :goto_0
    return v0
.end method

.method public final c0(IIZ)V
    .locals 8

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    const-string p1, "RecyclerView"

    .line 6
    .line 7
    const-string p2, "Cannot smooth scroll without a LayoutManager set. Call setLayoutManager with a non-null argument."

    .line 8
    .line 9
    invoke-static {p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 10
    .line 11
    .line 12
    return-void

    .line 13
    :cond_0
    iget-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView;->x:Z

    .line 14
    .line 15
    if-eqz v1, :cond_1

    .line 16
    .line 17
    return-void

    .line 18
    :cond_1
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->c()Z

    .line 19
    .line 20
    .line 21
    move-result v0

    .line 22
    const/4 v1, 0x0

    .line 23
    if-nez v0, :cond_2

    .line 24
    .line 25
    const/4 v5, 0x0

    .line 26
    goto :goto_0

    .line 27
    :cond_2
    move v5, p1

    .line 28
    :goto_0
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 29
    .line 30
    invoke-virtual {p1}, Landroidx/recyclerview/widget/t0;->d()Z

    .line 31
    .line 32
    .line 33
    move-result p1

    .line 34
    if-nez p1, :cond_3

    .line 35
    .line 36
    const/4 v6, 0x0

    .line 37
    goto :goto_1

    .line 38
    :cond_3
    move v6, p2

    .line 39
    :goto_1
    if-nez v5, :cond_4

    .line 40
    .line 41
    if-eqz v6, :cond_e

    .line 42
    .line 43
    :cond_4
    const/4 p1, 0x1

    .line 44
    if-eqz p3, :cond_7

    .line 45
    .line 46
    if-eqz v5, :cond_5

    .line 47
    .line 48
    const/4 p2, 0x1

    .line 49
    goto :goto_2

    .line 50
    :cond_5
    const/4 p2, 0x0

    .line 51
    :goto_2
    if-eqz v6, :cond_6

    .line 52
    .line 53
    or-int/lit8 p2, p2, 0x2

    .line 54
    .line 55
    :cond_6
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView;->getScrollingChildHelper()Lg/f;

    .line 56
    .line 57
    .line 58
    move-result-object p3

    .line 59
    invoke-virtual {p3, p2, p1}, Lg/f;->d(II)Z

    .line 60
    .line 61
    .line 62
    :cond_7
    iget-object p2, p0, Landroidx/recyclerview/widget/RecyclerView;->c0:Landroidx/recyclerview/widget/h1;

    .line 63
    .line 64
    iget-object p3, p2, Landroidx/recyclerview/widget/h1;->g:Landroidx/recyclerview/widget/RecyclerView;

    .line 65
    .line 66
    invoke-static {v5}, Ljava/lang/Math;->abs(I)I

    .line 67
    .line 68
    .line 69
    move-result v0

    .line 70
    invoke-static {v6}, Ljava/lang/Math;->abs(I)I

    .line 71
    .line 72
    .line 73
    move-result v2

    .line 74
    if-le v0, v2, :cond_8

    .line 75
    .line 76
    const/4 v3, 0x1

    .line 77
    goto :goto_3

    .line 78
    :cond_8
    const/4 v3, 0x0

    .line 79
    :goto_3
    if-eqz v3, :cond_9

    .line 80
    .line 81
    invoke-virtual {p3}, Landroid/view/View;->getWidth()I

    .line 82
    .line 83
    .line 84
    move-result v4

    .line 85
    goto :goto_4

    .line 86
    :cond_9
    invoke-virtual {p3}, Landroid/view/View;->getHeight()I

    .line 87
    .line 88
    .line 89
    move-result v4

    .line 90
    :goto_4
    if-eqz v3, :cond_a

    .line 91
    .line 92
    goto :goto_5

    .line 93
    :cond_a
    move v0, v2

    .line 94
    :goto_5
    int-to-float v0, v0

    .line 95
    int-to-float v2, v4

    .line 96
    div-float/2addr v0, v2

    .line 97
    const/high16 v2, 0x3f800000    # 1.0f

    .line 98
    .line 99
    add-float/2addr v0, v2

    .line 100
    const/high16 v2, 0x43960000    # 300.0f

    .line 101
    .line 102
    mul-float v0, v0, v2

    .line 103
    .line 104
    float-to-int v0, v0

    .line 105
    const/16 v2, 0x7d0

    .line 106
    .line 107
    invoke-static {v0, v2}, Ljava/lang/Math;->min(II)I

    .line 108
    .line 109
    .line 110
    move-result v7

    .line 111
    iget-object v0, p2, Landroidx/recyclerview/widget/h1;->d:Landroid/view/animation/Interpolator;

    .line 112
    .line 113
    sget-object v2, Landroidx/recyclerview/widget/RecyclerView;->G0:Landroidx/recyclerview/widget/g0;

    .line 114
    .line 115
    if-eq v0, v2, :cond_b

    .line 116
    .line 117
    iput-object v2, p2, Landroidx/recyclerview/widget/h1;->d:Landroid/view/animation/Interpolator;

    .line 118
    .line 119
    new-instance v0, Landroid/widget/OverScroller;

    .line 120
    .line 121
    invoke-virtual {p3}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 122
    .line 123
    .line 124
    move-result-object v3

    .line 125
    invoke-direct {v0, v3, v2}, Landroid/widget/OverScroller;-><init>(Landroid/content/Context;Landroid/view/animation/Interpolator;)V

    .line 126
    .line 127
    .line 128
    iput-object v0, p2, Landroidx/recyclerview/widget/h1;->c:Landroid/widget/OverScroller;

    .line 129
    .line 130
    :cond_b
    iput v1, p2, Landroidx/recyclerview/widget/h1;->b:I

    .line 131
    .line 132
    iput v1, p2, Landroidx/recyclerview/widget/h1;->a:I

    .line 133
    .line 134
    const/4 v0, 0x2

    .line 135
    invoke-virtual {p3, v0}, Landroidx/recyclerview/widget/RecyclerView;->setScrollState(I)V

    .line 136
    .line 137
    .line 138
    iget-object v2, p2, Landroidx/recyclerview/widget/h1;->c:Landroid/widget/OverScroller;

    .line 139
    .line 140
    const/4 v3, 0x0

    .line 141
    const/4 v4, 0x0

    .line 142
    invoke-virtual/range {v2 .. v7}, Landroid/widget/OverScroller;->startScroll(IIIII)V

    .line 143
    .line 144
    .line 145
    sget p3, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 146
    .line 147
    const/16 v0, 0x17

    .line 148
    .line 149
    if-ge p3, v0, :cond_c

    .line 150
    .line 151
    iget-object p3, p2, Landroidx/recyclerview/widget/h1;->c:Landroid/widget/OverScroller;

    .line 152
    .line 153
    invoke-virtual {p3}, Landroid/widget/OverScroller;->computeScrollOffset()Z

    .line 154
    .line 155
    .line 156
    :cond_c
    iget-boolean p3, p2, Landroidx/recyclerview/widget/h1;->e:Z

    .line 157
    .line 158
    if-eqz p3, :cond_d

    .line 159
    .line 160
    iput-boolean p1, p2, Landroidx/recyclerview/widget/h1;->f:Z

    .line 161
    .line 162
    goto :goto_6

    .line 163
    :cond_d
    iget-object p1, p2, Landroidx/recyclerview/widget/h1;->g:Landroidx/recyclerview/widget/RecyclerView;

    .line 164
    .line 165
    invoke-virtual {p1, p2}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 166
    .line 167
    .line 168
    sget-object p3, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 169
    .line 170
    invoke-static {p1, p2}, Lg/j;->m(Landroid/view/View;Ljava/lang/Runnable;)V

    .line 171
    .line 172
    .line 173
    :cond_e
    :goto_6
    return-void
.end method

.method public final checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z
    .locals 1

    instance-of v0, p1, Landroidx/recyclerview/widget/u0;

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    check-cast p1, Landroidx/recyclerview/widget/u0;

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/t0;->e(Landroidx/recyclerview/widget/u0;)Z

    move-result p1

    if-eqz p1, :cond_0

    const/4 p1, 0x1

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return p1
.end method

.method public final computeHorizontalScrollExtent()I
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->c()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/t0;->i(Landroidx/recyclerview/widget/e1;)I

    move-result v1

    :cond_1
    return v1
.end method

.method public final computeHorizontalScrollOffset()I
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->c()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/t0;->j(Landroidx/recyclerview/widget/e1;)I

    move-result v1

    :cond_1
    return v1
.end method

.method public final computeHorizontalScrollRange()I
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->c()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/t0;->k(Landroidx/recyclerview/widget/e1;)I

    move-result v1

    :cond_1
    return v1
.end method

.method public final computeVerticalScrollExtent()I
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->d()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/t0;->l(Landroidx/recyclerview/widget/e1;)I

    move-result v1

    :cond_1
    return v1
.end method

.method public final computeVerticalScrollOffset()I
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->d()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/t0;->m(Landroidx/recyclerview/widget/e1;)I

    move-result v1

    :cond_1
    return v1
.end method

.method public final computeVerticalScrollRange()I
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    const/4 v1, 0x0

    if-nez v0, :cond_0

    return v1

    :cond_0
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->d()Z

    move-result v0

    if-eqz v0, :cond_1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/t0;->n(Landroidx/recyclerview/widget/e1;)I

    move-result v1

    :cond_1
    return v1
.end method

.method public final d0()V
    .locals 2

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView;->v:I

    const/4 v1, 0x1

    add-int/2addr v0, v1

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView;->v:I

    if-ne v0, v1, :cond_0

    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->x:Z

    if-nez v0, :cond_0

    const/4 v0, 0x0

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->w:Z

    :cond_0
    return-void
.end method

.method public final dispatchNestedFling(FFZ)Z
    .locals 3

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView;->getScrollingChildHelper()Lg/f;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-boolean v1, v0, Lg/f;->d:Z

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-eqz v1, :cond_0

    .line 9
    .line 10
    invoke-virtual {v0, v2}, Lg/f;->c(I)Landroid/view/ViewParent;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    if-eqz v1, :cond_0

    .line 15
    .line 16
    iget-object v0, v0, Lg/f;->c:Landroid/view/View;

    .line 17
    .line 18
    :try_start_0
    invoke-static {v1, v0, p1, p2, p3}, Lg/b0;->a(Landroid/view/ViewParent;Landroid/view/View;FFZ)Z

    .line 19
    .line 20
    .line 21
    move-result v2
    :try_end_0
    .catch Ljava/lang/AbstractMethodError; {:try_start_0 .. :try_end_0} :catch_0

    .line 22
    goto :goto_0

    .line 23
    :catch_0
    move-exception p1

    .line 24
    new-instance p2, Ljava/lang/StringBuilder;

    .line 25
    .line 26
    const-string p3, "ViewParent "

    .line 27
    .line 28
    invoke-direct {p2, p3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    const-string p3, " does not implement interface method onNestedFling"

    .line 35
    .line 36
    invoke-virtual {p2, p3}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 37
    .line 38
    .line 39
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object p2

    .line 43
    const-string p3, "ViewParentCompat"

    .line 44
    .line 45
    invoke-static {p3, p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 46
    .line 47
    .line 48
    :cond_0
    :goto_0
    return v2
.end method

.method public final dispatchNestedPreFling(FF)Z
    .locals 3

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView;->getScrollingChildHelper()Lg/f;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-boolean v1, v0, Lg/f;->d:Z

    .line 6
    .line 7
    const/4 v2, 0x0

    .line 8
    if-eqz v1, :cond_0

    .line 9
    .line 10
    invoke-virtual {v0, v2}, Lg/f;->c(I)Landroid/view/ViewParent;

    .line 11
    .line 12
    .line 13
    move-result-object v1

    .line 14
    if-eqz v1, :cond_0

    .line 15
    .line 16
    iget-object v0, v0, Lg/f;->c:Landroid/view/View;

    .line 17
    .line 18
    :try_start_0
    invoke-static {v1, v0, p1, p2}, Lg/b0;->b(Landroid/view/ViewParent;Landroid/view/View;FF)Z

    .line 19
    .line 20
    .line 21
    move-result v2
    :try_end_0
    .catch Ljava/lang/AbstractMethodError; {:try_start_0 .. :try_end_0} :catch_0

    .line 22
    goto :goto_0

    .line 23
    :catch_0
    move-exception p1

    .line 24
    new-instance p2, Ljava/lang/StringBuilder;

    .line 25
    .line 26
    const-string v0, "ViewParent "

    .line 27
    .line 28
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    invoke-virtual {p2, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 32
    .line 33
    .line 34
    const-string v0, " does not implement interface method onNestedPreFling"

    .line 35
    .line 36
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 37
    .line 38
    .line 39
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 40
    .line 41
    .line 42
    move-result-object p2

    .line 43
    const-string v0, "ViewParentCompat"

    .line 44
    .line 45
    invoke-static {v0, p2, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 46
    .line 47
    .line 48
    :cond_0
    :goto_0
    return v2
.end method

.method public final dispatchNestedPreScroll(II[I[I)Z
    .locals 6

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView;->getScrollingChildHelper()Lg/f;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v5, 0x0

    .line 6
    move v1, p1

    .line 7
    move v2, p2

    .line 8
    move-object v3, p3

    .line 9
    move-object v4, p4

    .line 10
    invoke-virtual/range {v0 .. v5}, Lg/f;->a(II[I[II)Z

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    return p1
.end method

.method public final dispatchNestedScroll(IIII[I)Z
    .locals 8

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView;->getScrollingChildHelper()Lg/f;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v6, 0x0

    .line 6
    const/4 v7, 0x0

    .line 7
    move v1, p1

    .line 8
    move v2, p2

    .line 9
    move v3, p3

    .line 10
    move v4, p4

    .line 11
    move-object v5, p5

    .line 12
    invoke-virtual/range {v0 .. v7}, Lg/f;->b(IIII[II[I)Z

    .line 13
    .line 14
    .line 15
    move-result p1

    .line 16
    return p1
.end method

.method public final dispatchPopulateAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)Z
    .locals 0

    invoke-virtual {p0, p1}, Landroid/view/View;->onPopulateAccessibilityEvent(Landroid/view/accessibility/AccessibilityEvent;)V

    const/4 p1, 0x1

    return p1
.end method

.method public final dispatchRestoreInstanceState(Landroid/util/SparseArray;)V
    .locals 0

    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->dispatchThawSelfOnly(Landroid/util/SparseArray;)V

    return-void
.end method

.method public final dispatchSaveInstanceState(Landroid/util/SparseArray;)V
    .locals 0

    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->dispatchFreezeSelfOnly(Landroid/util/SparseArray;)V

    return-void
.end method

.method public final draw(Landroid/graphics/Canvas;)V
    .locals 14

    .line 1
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->draw(Landroid/graphics/Canvas;)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->p:Ljava/util/ArrayList;

    .line 5
    .line 6
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 7
    .line 8
    .line 9
    move-result v1

    .line 10
    const/4 v2, 0x0

    .line 11
    const/4 v3, 0x0

    .line 12
    :goto_0
    const/4 v4, 0x1

    .line 13
    const/4 v5, 0x0

    .line 14
    if-ge v3, v1, :cond_6

    .line 15
    .line 16
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 17
    .line 18
    .line 19
    move-result-object v6

    .line 20
    check-cast v6, Landroidx/recyclerview/widget/q0;

    .line 21
    .line 22
    check-cast v6, Landroidx/recyclerview/widget/q;

    .line 23
    .line 24
    iget v7, v6, Landroidx/recyclerview/widget/q;->q:I

    .line 25
    .line 26
    iget-object v8, v6, Landroidx/recyclerview/widget/q;->s:Landroidx/recyclerview/widget/RecyclerView;

    .line 27
    .line 28
    invoke-virtual {v8}, Landroid/view/View;->getWidth()I

    .line 29
    .line 30
    .line 31
    move-result v8

    .line 32
    if-ne v7, v8, :cond_4

    .line 33
    .line 34
    iget v7, v6, Landroidx/recyclerview/widget/q;->r:I

    .line 35
    .line 36
    iget-object v8, v6, Landroidx/recyclerview/widget/q;->s:Landroidx/recyclerview/widget/RecyclerView;

    .line 37
    .line 38
    invoke-virtual {v8}, Landroid/view/View;->getHeight()I

    .line 39
    .line 40
    .line 41
    move-result v8

    .line 42
    if-eq v7, v8, :cond_0

    .line 43
    .line 44
    goto/16 :goto_3

    .line 45
    .line 46
    :cond_0
    iget v7, v6, Landroidx/recyclerview/widget/q;->A:I

    .line 47
    .line 48
    if-eqz v7, :cond_5

    .line 49
    .line 50
    iget-boolean v7, v6, Landroidx/recyclerview/widget/q;->t:Z

    .line 51
    .line 52
    if-eqz v7, :cond_3

    .line 53
    .line 54
    iget v7, v6, Landroidx/recyclerview/widget/q;->q:I

    .line 55
    .line 56
    iget v8, v6, Landroidx/recyclerview/widget/q;->e:I

    .line 57
    .line 58
    sub-int/2addr v7, v8

    .line 59
    iget v9, v6, Landroidx/recyclerview/widget/q;->l:I

    .line 60
    .line 61
    iget v10, v6, Landroidx/recyclerview/widget/q;->k:I

    .line 62
    .line 63
    div-int/lit8 v11, v10, 0x2

    .line 64
    .line 65
    sub-int/2addr v9, v11

    .line 66
    iget-object v11, v6, Landroidx/recyclerview/widget/q;->c:Landroid/graphics/drawable/StateListDrawable;

    .line 67
    .line 68
    invoke-virtual {v11, v2, v2, v8, v10}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 69
    .line 70
    .line 71
    iget v10, v6, Landroidx/recyclerview/widget/q;->r:I

    .line 72
    .line 73
    iget-object v12, v6, Landroidx/recyclerview/widget/q;->d:Landroid/graphics/drawable/Drawable;

    .line 74
    .line 75
    iget v13, v6, Landroidx/recyclerview/widget/q;->f:I

    .line 76
    .line 77
    invoke-virtual {v12, v2, v2, v13, v10}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 78
    .line 79
    .line 80
    iget-object v10, v6, Landroidx/recyclerview/widget/q;->s:Landroidx/recyclerview/widget/RecyclerView;

    .line 81
    .line 82
    sget-object v13, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 83
    .line 84
    invoke-static {v10}, Lg/k;->d(Landroid/view/View;)I

    .line 85
    .line 86
    .line 87
    move-result v10

    .line 88
    if-ne v10, v4, :cond_1

    .line 89
    .line 90
    goto :goto_1

    .line 91
    :cond_1
    const/4 v4, 0x0

    .line 92
    :goto_1
    if-eqz v4, :cond_2

    .line 93
    .line 94
    invoke-virtual {v12, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 95
    .line 96
    .line 97
    int-to-float v4, v8

    .line 98
    int-to-float v7, v9

    .line 99
    invoke-virtual {p1, v4, v7}, Landroid/graphics/Canvas;->translate(FF)V

    .line 100
    .line 101
    .line 102
    const/high16 v4, -0x40800000    # -1.0f

    .line 103
    .line 104
    const/high16 v7, 0x3f800000    # 1.0f

    .line 105
    .line 106
    invoke-virtual {p1, v4, v7}, Landroid/graphics/Canvas;->scale(FF)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v11, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 110
    .line 111
    .line 112
    invoke-virtual {p1, v4, v7}, Landroid/graphics/Canvas;->scale(FF)V

    .line 113
    .line 114
    .line 115
    neg-int v4, v8

    .line 116
    goto :goto_2

    .line 117
    :cond_2
    int-to-float v4, v7

    .line 118
    invoke-virtual {p1, v4, v5}, Landroid/graphics/Canvas;->translate(FF)V

    .line 119
    .line 120
    .line 121
    invoke-virtual {v12, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 122
    .line 123
    .line 124
    int-to-float v4, v9

    .line 125
    invoke-virtual {p1, v5, v4}, Landroid/graphics/Canvas;->translate(FF)V

    .line 126
    .line 127
    .line 128
    invoke-virtual {v11, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 129
    .line 130
    .line 131
    neg-int v4, v7

    .line 132
    :goto_2
    int-to-float v4, v4

    .line 133
    neg-int v7, v9

    .line 134
    int-to-float v7, v7

    .line 135
    invoke-virtual {p1, v4, v7}, Landroid/graphics/Canvas;->translate(FF)V

    .line 136
    .line 137
    .line 138
    :cond_3
    iget-boolean v4, v6, Landroidx/recyclerview/widget/q;->u:Z

    .line 139
    .line 140
    if-eqz v4, :cond_5

    .line 141
    .line 142
    iget v4, v6, Landroidx/recyclerview/widget/q;->r:I

    .line 143
    .line 144
    iget v7, v6, Landroidx/recyclerview/widget/q;->i:I

    .line 145
    .line 146
    sub-int/2addr v4, v7

    .line 147
    iget v8, v6, Landroidx/recyclerview/widget/q;->o:I

    .line 148
    .line 149
    iget v9, v6, Landroidx/recyclerview/widget/q;->n:I

    .line 150
    .line 151
    div-int/lit8 v10, v9, 0x2

    .line 152
    .line 153
    sub-int/2addr v8, v10

    .line 154
    iget-object v10, v6, Landroidx/recyclerview/widget/q;->g:Landroid/graphics/drawable/StateListDrawable;

    .line 155
    .line 156
    invoke-virtual {v10, v2, v2, v9, v7}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 157
    .line 158
    .line 159
    iget v7, v6, Landroidx/recyclerview/widget/q;->q:I

    .line 160
    .line 161
    iget-object v9, v6, Landroidx/recyclerview/widget/q;->h:Landroid/graphics/drawable/Drawable;

    .line 162
    .line 163
    iget v6, v6, Landroidx/recyclerview/widget/q;->j:I

    .line 164
    .line 165
    invoke-virtual {v9, v2, v2, v7, v6}, Landroid/graphics/drawable/Drawable;->setBounds(IIII)V

    .line 166
    .line 167
    .line 168
    int-to-float v6, v4

    .line 169
    invoke-virtual {p1, v5, v6}, Landroid/graphics/Canvas;->translate(FF)V

    .line 170
    .line 171
    .line 172
    invoke-virtual {v9, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 173
    .line 174
    .line 175
    int-to-float v6, v8

    .line 176
    invoke-virtual {p1, v6, v5}, Landroid/graphics/Canvas;->translate(FF)V

    .line 177
    .line 178
    .line 179
    invoke-virtual {v10, p1}, Landroid/graphics/drawable/Drawable;->draw(Landroid/graphics/Canvas;)V

    .line 180
    .line 181
    .line 182
    neg-int v5, v8

    .line 183
    int-to-float v5, v5

    .line 184
    neg-int v4, v4

    .line 185
    int-to-float v4, v4

    .line 186
    invoke-virtual {p1, v5, v4}, Landroid/graphics/Canvas;->translate(FF)V

    .line 187
    .line 188
    .line 189
    goto :goto_4

    .line 190
    :cond_4
    :goto_3
    iget-object v4, v6, Landroidx/recyclerview/widget/q;->s:Landroidx/recyclerview/widget/RecyclerView;

    .line 191
    .line 192
    invoke-virtual {v4}, Landroid/view/View;->getWidth()I

    .line 193
    .line 194
    .line 195
    move-result v4

    .line 196
    iput v4, v6, Landroidx/recyclerview/widget/q;->q:I

    .line 197
    .line 198
    iget-object v4, v6, Landroidx/recyclerview/widget/q;->s:Landroidx/recyclerview/widget/RecyclerView;

    .line 199
    .line 200
    invoke-virtual {v4}, Landroid/view/View;->getHeight()I

    .line 201
    .line 202
    .line 203
    move-result v4

    .line 204
    iput v4, v6, Landroidx/recyclerview/widget/q;->r:I

    .line 205
    .line 206
    invoke-virtual {v6, v2}, Landroidx/recyclerview/widget/q;->d(I)V

    .line 207
    .line 208
    .line 209
    :cond_5
    :goto_4
    add-int/lit8 v3, v3, 0x1

    .line 210
    .line 211
    goto/16 :goto_0

    .line 212
    .line 213
    :cond_6
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 214
    .line 215
    if-eqz v1, :cond_9

    .line 216
    .line 217
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 218
    .line 219
    .line 220
    move-result v1

    .line 221
    if-nez v1, :cond_9

    .line 222
    .line 223
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 224
    .line 225
    .line 226
    move-result v1

    .line 227
    iget-boolean v3, p0, Landroidx/recyclerview/widget/RecyclerView;->h:Z

    .line 228
    .line 229
    if-eqz v3, :cond_7

    .line 230
    .line 231
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 232
    .line 233
    .line 234
    move-result v3

    .line 235
    goto :goto_5

    .line 236
    :cond_7
    const/4 v3, 0x0

    .line 237
    :goto_5
    const/high16 v6, 0x43870000    # 270.0f

    .line 238
    .line 239
    invoke-virtual {p1, v6}, Landroid/graphics/Canvas;->rotate(F)V

    .line 240
    .line 241
    .line 242
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 243
    .line 244
    .line 245
    move-result v6

    .line 246
    neg-int v6, v6

    .line 247
    add-int/2addr v6, v3

    .line 248
    int-to-float v3, v6

    .line 249
    invoke-virtual {p1, v3, v5}, Landroid/graphics/Canvas;->translate(FF)V

    .line 250
    .line 251
    .line 252
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 253
    .line 254
    if-eqz v3, :cond_8

    .line 255
    .line 256
    invoke-virtual {v3, p1}, Landroid/widget/EdgeEffect;->draw(Landroid/graphics/Canvas;)Z

    .line 257
    .line 258
    .line 259
    move-result v3

    .line 260
    if-eqz v3, :cond_8

    .line 261
    .line 262
    const/4 v3, 0x1

    .line 263
    goto :goto_6

    .line 264
    :cond_8
    const/4 v3, 0x0

    .line 265
    :goto_6
    invoke-virtual {p1, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 266
    .line 267
    .line 268
    goto :goto_7

    .line 269
    :cond_9
    const/4 v3, 0x0

    .line 270
    :goto_7
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 271
    .line 272
    if-eqz v1, :cond_c

    .line 273
    .line 274
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 275
    .line 276
    .line 277
    move-result v1

    .line 278
    if-nez v1, :cond_c

    .line 279
    .line 280
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 281
    .line 282
    .line 283
    move-result v1

    .line 284
    iget-boolean v5, p0, Landroidx/recyclerview/widget/RecyclerView;->h:Z

    .line 285
    .line 286
    if-eqz v5, :cond_a

    .line 287
    .line 288
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 289
    .line 290
    .line 291
    move-result v5

    .line 292
    int-to-float v5, v5

    .line 293
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 294
    .line 295
    .line 296
    move-result v6

    .line 297
    int-to-float v6, v6

    .line 298
    invoke-virtual {p1, v5, v6}, Landroid/graphics/Canvas;->translate(FF)V

    .line 299
    .line 300
    .line 301
    :cond_a
    iget-object v5, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 302
    .line 303
    if-eqz v5, :cond_b

    .line 304
    .line 305
    invoke-virtual {v5, p1}, Landroid/widget/EdgeEffect;->draw(Landroid/graphics/Canvas;)Z

    .line 306
    .line 307
    .line 308
    move-result v5

    .line 309
    if-eqz v5, :cond_b

    .line 310
    .line 311
    const/4 v5, 0x1

    .line 312
    goto :goto_8

    .line 313
    :cond_b
    const/4 v5, 0x0

    .line 314
    :goto_8
    or-int/2addr v3, v5

    .line 315
    invoke-virtual {p1, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 316
    .line 317
    .line 318
    :cond_c
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 319
    .line 320
    if-eqz v1, :cond_f

    .line 321
    .line 322
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 323
    .line 324
    .line 325
    move-result v1

    .line 326
    if-nez v1, :cond_f

    .line 327
    .line 328
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 329
    .line 330
    .line 331
    move-result v1

    .line 332
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 333
    .line 334
    .line 335
    move-result v5

    .line 336
    iget-boolean v6, p0, Landroidx/recyclerview/widget/RecyclerView;->h:Z

    .line 337
    .line 338
    if-eqz v6, :cond_d

    .line 339
    .line 340
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 341
    .line 342
    .line 343
    move-result v6

    .line 344
    goto :goto_9

    .line 345
    :cond_d
    const/4 v6, 0x0

    .line 346
    :goto_9
    const/high16 v7, 0x42b40000    # 90.0f

    .line 347
    .line 348
    invoke-virtual {p1, v7}, Landroid/graphics/Canvas;->rotate(F)V

    .line 349
    .line 350
    .line 351
    int-to-float v6, v6

    .line 352
    neg-int v5, v5

    .line 353
    int-to-float v5, v5

    .line 354
    invoke-virtual {p1, v6, v5}, Landroid/graphics/Canvas;->translate(FF)V

    .line 355
    .line 356
    .line 357
    iget-object v5, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 358
    .line 359
    if-eqz v5, :cond_e

    .line 360
    .line 361
    invoke-virtual {v5, p1}, Landroid/widget/EdgeEffect;->draw(Landroid/graphics/Canvas;)Z

    .line 362
    .line 363
    .line 364
    move-result v5

    .line 365
    if-eqz v5, :cond_e

    .line 366
    .line 367
    const/4 v5, 0x1

    .line 368
    goto :goto_a

    .line 369
    :cond_e
    const/4 v5, 0x0

    .line 370
    :goto_a
    or-int/2addr v3, v5

    .line 371
    invoke-virtual {p1, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 372
    .line 373
    .line 374
    :cond_f
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 375
    .line 376
    if-eqz v1, :cond_12

    .line 377
    .line 378
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 379
    .line 380
    .line 381
    move-result v1

    .line 382
    if-nez v1, :cond_12

    .line 383
    .line 384
    invoke-virtual {p1}, Landroid/graphics/Canvas;->save()I

    .line 385
    .line 386
    .line 387
    move-result v1

    .line 388
    const/high16 v5, 0x43340000    # 180.0f

    .line 389
    .line 390
    invoke-virtual {p1, v5}, Landroid/graphics/Canvas;->rotate(F)V

    .line 391
    .line 392
    .line 393
    iget-boolean v5, p0, Landroidx/recyclerview/widget/RecyclerView;->h:Z

    .line 394
    .line 395
    if-eqz v5, :cond_10

    .line 396
    .line 397
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 398
    .line 399
    .line 400
    move-result v5

    .line 401
    neg-int v5, v5

    .line 402
    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 403
    .line 404
    .line 405
    move-result v6

    .line 406
    add-int/2addr v6, v5

    .line 407
    int-to-float v5, v6

    .line 408
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 409
    .line 410
    .line 411
    move-result v6

    .line 412
    neg-int v6, v6

    .line 413
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 414
    .line 415
    .line 416
    move-result v7

    .line 417
    add-int/2addr v7, v6

    .line 418
    int-to-float v6, v7

    .line 419
    goto :goto_b

    .line 420
    :cond_10
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 421
    .line 422
    .line 423
    move-result v5

    .line 424
    neg-int v5, v5

    .line 425
    int-to-float v5, v5

    .line 426
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 427
    .line 428
    .line 429
    move-result v6

    .line 430
    neg-int v6, v6

    .line 431
    int-to-float v6, v6

    .line 432
    :goto_b
    invoke-virtual {p1, v5, v6}, Landroid/graphics/Canvas;->translate(FF)V

    .line 433
    .line 434
    .line 435
    iget-object v5, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 436
    .line 437
    if-eqz v5, :cond_11

    .line 438
    .line 439
    invoke-virtual {v5, p1}, Landroid/widget/EdgeEffect;->draw(Landroid/graphics/Canvas;)Z

    .line 440
    .line 441
    .line 442
    move-result v5

    .line 443
    if-eqz v5, :cond_11

    .line 444
    .line 445
    const/4 v2, 0x1

    .line 446
    :cond_11
    or-int/2addr v3, v2

    .line 447
    invoke-virtual {p1, v1}, Landroid/graphics/Canvas;->restoreToCount(I)V

    .line 448
    .line 449
    .line 450
    :cond_12
    if-nez v3, :cond_13

    .line 451
    .line 452
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 453
    .line 454
    if-eqz p1, :cond_13

    .line 455
    .line 456
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 457
    .line 458
    .line 459
    move-result p1

    .line 460
    if-lez p1, :cond_13

    .line 461
    .line 462
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 463
    .line 464
    invoke-virtual {p1}, Landroidx/recyclerview/widget/o0;->f()Z

    .line 465
    .line 466
    .line 467
    move-result p1

    .line 468
    if-eqz p1, :cond_13

    .line 469
    .line 470
    goto :goto_c

    .line 471
    :cond_13
    move v4, v3

    .line 472
    :goto_c
    if-eqz v4, :cond_14

    .line 473
    .line 474
    sget-object p1, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 475
    .line 476
    invoke-static {p0}, Lg/j;->k(Landroid/view/View;)V

    .line 477
    .line 478
    .line 479
    :cond_14
    return-void
.end method

.method public final drawChild(Landroid/graphics/Canvas;Landroid/view/View;J)Z
    .locals 0

    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/ViewGroup;->drawChild(Landroid/graphics/Canvas;Landroid/view/View;J)Z

    move-result p1

    return p1
.end method

.method public final e0(Z)V
    .locals 3

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView;->v:I

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    if-ge v0, v1, :cond_1

    .line 5
    .line 6
    sget-boolean v0, Landroidx/recyclerview/widget/RecyclerView;->y0:Z

    .line 7
    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    iput v1, p0, Landroidx/recyclerview/widget/RecyclerView;->v:I

    .line 11
    .line 12
    goto :goto_0

    .line 13
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 14
    .line 15
    new-instance v0, Ljava/lang/StringBuilder;

    .line 16
    .line 17
    const-string v1, "stopInterceptRequestLayout was called more times than startInterceptRequestLayout."

    .line 18
    .line 19
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    invoke-static {p0, v0}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 23
    .line 24
    .line 25
    move-result-object v0

    .line 26
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 27
    .line 28
    .line 29
    throw p1

    .line 30
    :cond_1
    :goto_0
    const/4 v0, 0x0

    .line 31
    if-nez p1, :cond_2

    .line 32
    .line 33
    iget-boolean v2, p0, Landroidx/recyclerview/widget/RecyclerView;->x:Z

    .line 34
    .line 35
    if-nez v2, :cond_2

    .line 36
    .line 37
    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->w:Z

    .line 38
    .line 39
    :cond_2
    iget v2, p0, Landroidx/recyclerview/widget/RecyclerView;->v:I

    .line 40
    .line 41
    if-ne v2, v1, :cond_4

    .line 42
    .line 43
    if-eqz p1, :cond_3

    .line 44
    .line 45
    iget-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView;->w:Z

    .line 46
    .line 47
    if-eqz p1, :cond_3

    .line 48
    .line 49
    iget-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView;->x:Z

    .line 50
    .line 51
    if-nez p1, :cond_3

    .line 52
    .line 53
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 54
    .line 55
    if-eqz p1, :cond_3

    .line 56
    .line 57
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 58
    .line 59
    if-eqz p1, :cond_3

    .line 60
    .line 61
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->o()V

    .line 62
    .line 63
    .line 64
    :cond_3
    iget-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView;->x:Z

    .line 65
    .line 66
    if-nez p1, :cond_4

    .line 67
    .line 68
    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->w:Z

    .line 69
    .line 70
    :cond_4
    iget p1, p0, Landroidx/recyclerview/widget/RecyclerView;->v:I

    .line 71
    .line 72
    sub-int/2addr p1, v1

    .line 73
    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView;->v:I

    .line 74
    .line 75
    return-void
.end method

.method public final f0(I)V
    .locals 1

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView;->getScrollingChildHelper()Lg/f;

    move-result-object v0

    invoke-virtual {v0, p1}, Lg/f;->e(I)V

    return-void
.end method

.method public final focusSearch(Landroid/view/View;I)Landroid/view/View;
    .locals 13

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 7
    .line 8
    const/4 v1, 0x0

    .line 9
    const/4 v2, 0x1

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 13
    .line 14
    if-eqz v0, :cond_0

    .line 15
    .line 16
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->K()Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-nez v0, :cond_0

    .line 21
    .line 22
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->x:Z

    .line 23
    .line 24
    if-nez v0, :cond_0

    .line 25
    .line 26
    const/4 v0, 0x1

    .line 27
    goto :goto_0

    .line 28
    :cond_0
    const/4 v0, 0x0

    .line 29
    :goto_0
    invoke-static {}, Landroid/view/FocusFinder;->getInstance()Landroid/view/FocusFinder;

    .line 30
    .line 31
    .line 32
    move-result-object v3

    .line 33
    const/16 v4, 0x11

    .line 34
    .line 35
    const/16 v5, 0x21

    .line 36
    .line 37
    iget-object v6, p0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    .line 38
    .line 39
    iget-object v7, p0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 40
    .line 41
    const/4 v8, 0x0

    .line 42
    const/4 v9, 0x2

    .line 43
    if-eqz v0, :cond_b

    .line 44
    .line 45
    if-eq p2, v9, :cond_1

    .line 46
    .line 47
    if-ne p2, v2, :cond_b

    .line 48
    .line 49
    :cond_1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 50
    .line 51
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->d()Z

    .line 52
    .line 53
    .line 54
    move-result v0

    .line 55
    if-eqz v0, :cond_3

    .line 56
    .line 57
    if-ne p2, v9, :cond_2

    .line 58
    .line 59
    const/16 v0, 0x82

    .line 60
    .line 61
    goto :goto_1

    .line 62
    :cond_2
    const/16 v0, 0x21

    .line 63
    .line 64
    :goto_1
    invoke-virtual {v3, p0, p1, v0}, Landroid/view/FocusFinder;->findNextFocus(Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;

    .line 65
    .line 66
    .line 67
    move-result-object v0

    .line 68
    if-nez v0, :cond_3

    .line 69
    .line 70
    const/4 v0, 0x1

    .line 71
    goto :goto_2

    .line 72
    :cond_3
    const/4 v0, 0x0

    .line 73
    :goto_2
    if-nez v0, :cond_8

    .line 74
    .line 75
    iget-object v10, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 76
    .line 77
    invoke-virtual {v10}, Landroidx/recyclerview/widget/t0;->c()Z

    .line 78
    .line 79
    .line 80
    move-result v10

    .line 81
    if-eqz v10, :cond_8

    .line 82
    .line 83
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 84
    .line 85
    iget-object v0, v0, Landroidx/recyclerview/widget/t0;->b:Landroidx/recyclerview/widget/RecyclerView;

    .line 86
    .line 87
    sget-object v10, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 88
    .line 89
    invoke-static {v0}, Lg/k;->d(Landroid/view/View;)I

    .line 90
    .line 91
    .line 92
    move-result v0

    .line 93
    if-ne v0, v2, :cond_4

    .line 94
    .line 95
    const/4 v0, 0x1

    .line 96
    goto :goto_3

    .line 97
    :cond_4
    const/4 v0, 0x0

    .line 98
    :goto_3
    if-ne p2, v9, :cond_5

    .line 99
    .line 100
    const/4 v10, 0x1

    .line 101
    goto :goto_4

    .line 102
    :cond_5
    const/4 v10, 0x0

    .line 103
    :goto_4
    xor-int/2addr v0, v10

    .line 104
    if-eqz v0, :cond_6

    .line 105
    .line 106
    const/16 v0, 0x42

    .line 107
    .line 108
    goto :goto_5

    .line 109
    :cond_6
    const/16 v0, 0x11

    .line 110
    .line 111
    :goto_5
    invoke-virtual {v3, p0, p1, v0}, Landroid/view/FocusFinder;->findNextFocus(Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;

    .line 112
    .line 113
    .line 114
    move-result-object v0

    .line 115
    if-nez v0, :cond_7

    .line 116
    .line 117
    const/4 v0, 0x1

    .line 118
    goto :goto_6

    .line 119
    :cond_7
    const/4 v0, 0x0

    .line 120
    :cond_8
    :goto_6
    if-eqz v0, :cond_a

    .line 121
    .line 122
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->m()V

    .line 123
    .line 124
    .line 125
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView;->A(Landroid/view/View;)Landroid/view/View;

    .line 126
    .line 127
    .line 128
    move-result-object v0

    .line 129
    if-nez v0, :cond_9

    .line 130
    .line 131
    return-object v8

    .line 132
    :cond_9
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->d0()V

    .line 133
    .line 134
    .line 135
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 136
    .line 137
    invoke-virtual {v0, p1, p2, v7, v6}, Landroidx/recyclerview/widget/t0;->N(Landroid/view/View;ILandroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;)Landroid/view/View;

    .line 138
    .line 139
    .line 140
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView;->e0(Z)V

    .line 141
    .line 142
    .line 143
    :cond_a
    invoke-virtual {v3, p0, p1, p2}, Landroid/view/FocusFinder;->findNextFocus(Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;

    .line 144
    .line 145
    .line 146
    move-result-object v0

    .line 147
    goto :goto_7

    .line 148
    :cond_b
    invoke-virtual {v3, p0, p1, p2}, Landroid/view/FocusFinder;->findNextFocus(Landroid/view/ViewGroup;Landroid/view/View;I)Landroid/view/View;

    .line 149
    .line 150
    .line 151
    move-result-object v3

    .line 152
    if-nez v3, :cond_d

    .line 153
    .line 154
    if-eqz v0, :cond_d

    .line 155
    .line 156
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->m()V

    .line 157
    .line 158
    .line 159
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView;->A(Landroid/view/View;)Landroid/view/View;

    .line 160
    .line 161
    .line 162
    move-result-object v0

    .line 163
    if-nez v0, :cond_c

    .line 164
    .line 165
    return-object v8

    .line 166
    :cond_c
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->d0()V

    .line 167
    .line 168
    .line 169
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 170
    .line 171
    invoke-virtual {v0, p1, p2, v7, v6}, Landroidx/recyclerview/widget/t0;->N(Landroid/view/View;ILandroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;)Landroid/view/View;

    .line 172
    .line 173
    .line 174
    move-result-object v0

    .line 175
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView;->e0(Z)V

    .line 176
    .line 177
    .line 178
    goto :goto_7

    .line 179
    :cond_d
    move-object v0, v3

    .line 180
    :goto_7
    if-eqz v0, :cond_f

    .line 181
    .line 182
    invoke-virtual {v0}, Landroid/view/View;->hasFocusable()Z

    .line 183
    .line 184
    .line 185
    move-result v3

    .line 186
    if-nez v3, :cond_f

    .line 187
    .line 188
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getFocusedChild()Landroid/view/View;

    .line 189
    .line 190
    .line 191
    move-result-object v1

    .line 192
    if-nez v1, :cond_e

    .line 193
    .line 194
    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->focusSearch(Landroid/view/View;I)Landroid/view/View;

    .line 195
    .line 196
    .line 197
    move-result-object p1

    .line 198
    return-object p1

    .line 199
    :cond_e
    invoke-virtual {p0, v0, v8}, Landroidx/recyclerview/widget/RecyclerView;->W(Landroid/view/View;Landroid/view/View;)V

    .line 200
    .line 201
    .line 202
    return-object p1

    .line 203
    :cond_f
    if-eqz v0, :cond_24

    .line 204
    .line 205
    if-eq v0, p0, :cond_24

    .line 206
    .line 207
    if-ne v0, p1, :cond_10

    .line 208
    .line 209
    goto/16 :goto_c

    .line 210
    .line 211
    :cond_10
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView;->A(Landroid/view/View;)Landroid/view/View;

    .line 212
    .line 213
    .line 214
    move-result-object v3

    .line 215
    if-nez v3, :cond_11

    .line 216
    .line 217
    goto/16 :goto_d

    .line 218
    .line 219
    :cond_11
    if-nez p1, :cond_12

    .line 220
    .line 221
    goto/16 :goto_b

    .line 222
    .line 223
    :cond_12
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView;->A(Landroid/view/View;)Landroid/view/View;

    .line 224
    .line 225
    .line 226
    move-result-object v3

    .line 227
    if-nez v3, :cond_13

    .line 228
    .line 229
    goto/16 :goto_b

    .line 230
    .line 231
    :cond_13
    invoke-virtual {p1}, Landroid/view/View;->getWidth()I

    .line 232
    .line 233
    .line 234
    move-result v3

    .line 235
    invoke-virtual {p1}, Landroid/view/View;->getHeight()I

    .line 236
    .line 237
    .line 238
    move-result v6

    .line 239
    iget-object v7, p0, Landroidx/recyclerview/widget/RecyclerView;->j:Landroid/graphics/Rect;

    .line 240
    .line 241
    invoke-virtual {v7, v1, v1, v3, v6}, Landroid/graphics/Rect;->set(IIII)V

    .line 242
    .line 243
    .line 244
    invoke-virtual {v0}, Landroid/view/View;->getWidth()I

    .line 245
    .line 246
    .line 247
    move-result v3

    .line 248
    invoke-virtual {v0}, Landroid/view/View;->getHeight()I

    .line 249
    .line 250
    .line 251
    move-result v6

    .line 252
    iget-object v8, p0, Landroidx/recyclerview/widget/RecyclerView;->k:Landroid/graphics/Rect;

    .line 253
    .line 254
    invoke-virtual {v8, v1, v1, v3, v6}, Landroid/graphics/Rect;->set(IIII)V

    .line 255
    .line 256
    .line 257
    invoke-virtual {p0, p1, v7}, Landroid/view/ViewGroup;->offsetDescendantRectToMyCoords(Landroid/view/View;Landroid/graphics/Rect;)V

    .line 258
    .line 259
    .line 260
    invoke-virtual {p0, v0, v8}, Landroid/view/ViewGroup;->offsetDescendantRectToMyCoords(Landroid/view/View;Landroid/graphics/Rect;)V

    .line 261
    .line 262
    .line 263
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 264
    .line 265
    iget-object v1, v1, Landroidx/recyclerview/widget/t0;->b:Landroidx/recyclerview/widget/RecyclerView;

    .line 266
    .line 267
    sget-object v3, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 268
    .line 269
    invoke-static {v1}, Lg/k;->d(Landroid/view/View;)I

    .line 270
    .line 271
    .line 272
    move-result v1

    .line 273
    if-ne v1, v2, :cond_14

    .line 274
    .line 275
    const/4 v1, -0x1

    .line 276
    goto :goto_8

    .line 277
    :cond_14
    const/4 v1, 0x1

    .line 278
    :goto_8
    iget v3, v7, Landroid/graphics/Rect;->left:I

    .line 279
    .line 280
    iget v6, v8, Landroid/graphics/Rect;->left:I

    .line 281
    .line 282
    if-lt v3, v6, :cond_15

    .line 283
    .line 284
    iget v10, v7, Landroid/graphics/Rect;->right:I

    .line 285
    .line 286
    if-gt v10, v6, :cond_16

    .line 287
    .line 288
    :cond_15
    iget v10, v7, Landroid/graphics/Rect;->right:I

    .line 289
    .line 290
    iget v11, v8, Landroid/graphics/Rect;->right:I

    .line 291
    .line 292
    if-ge v10, v11, :cond_16

    .line 293
    .line 294
    const/4 v3, 0x1

    .line 295
    goto :goto_9

    .line 296
    :cond_16
    iget v10, v7, Landroid/graphics/Rect;->right:I

    .line 297
    .line 298
    iget v11, v8, Landroid/graphics/Rect;->right:I

    .line 299
    .line 300
    if-gt v10, v11, :cond_17

    .line 301
    .line 302
    if-lt v3, v11, :cond_18

    .line 303
    .line 304
    :cond_17
    if-le v3, v6, :cond_18

    .line 305
    .line 306
    const/4 v3, -0x1

    .line 307
    goto :goto_9

    .line 308
    :cond_18
    const/4 v3, 0x0

    .line 309
    :goto_9
    iget v6, v7, Landroid/graphics/Rect;->top:I

    .line 310
    .line 311
    iget v10, v8, Landroid/graphics/Rect;->top:I

    .line 312
    .line 313
    if-lt v6, v10, :cond_19

    .line 314
    .line 315
    iget v11, v7, Landroid/graphics/Rect;->bottom:I

    .line 316
    .line 317
    if-gt v11, v10, :cond_1a

    .line 318
    .line 319
    :cond_19
    iget v11, v7, Landroid/graphics/Rect;->bottom:I

    .line 320
    .line 321
    iget v12, v8, Landroid/graphics/Rect;->bottom:I

    .line 322
    .line 323
    if-ge v11, v12, :cond_1a

    .line 324
    .line 325
    const/4 v6, 0x1

    .line 326
    goto :goto_a

    .line 327
    :cond_1a
    iget v7, v7, Landroid/graphics/Rect;->bottom:I

    .line 328
    .line 329
    iget v8, v8, Landroid/graphics/Rect;->bottom:I

    .line 330
    .line 331
    if-gt v7, v8, :cond_1b

    .line 332
    .line 333
    if-lt v6, v8, :cond_1c

    .line 334
    .line 335
    :cond_1b
    if-le v6, v10, :cond_1c

    .line 336
    .line 337
    const/4 v6, -0x1

    .line 338
    goto :goto_a

    .line 339
    :cond_1c
    const/4 v6, 0x0

    .line 340
    :goto_a
    if-eq p2, v2, :cond_22

    .line 341
    .line 342
    if-eq p2, v9, :cond_21

    .line 343
    .line 344
    if-eq p2, v4, :cond_20

    .line 345
    .line 346
    if-eq p2, v5, :cond_1f

    .line 347
    .line 348
    const/16 v1, 0x42

    .line 349
    .line 350
    if-eq p2, v1, :cond_1e

    .line 351
    .line 352
    const/16 v1, 0x82

    .line 353
    .line 354
    if-ne p2, v1, :cond_1d

    .line 355
    .line 356
    if-lez v6, :cond_24

    .line 357
    .line 358
    goto :goto_b

    .line 359
    :cond_1d
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 360
    .line 361
    new-instance v0, Ljava/lang/StringBuilder;

    .line 362
    .line 363
    const-string v1, "Invalid direction: "

    .line 364
    .line 365
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 366
    .line 367
    .line 368
    invoke-virtual {v0, p2}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 369
    .line 370
    .line 371
    invoke-static {p0, v0}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 372
    .line 373
    .line 374
    move-result-object p2

    .line 375
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 376
    .line 377
    .line 378
    throw p1

    .line 379
    :cond_1e
    if-lez v3, :cond_24

    .line 380
    .line 381
    goto :goto_b

    .line 382
    :cond_1f
    if-gez v6, :cond_24

    .line 383
    .line 384
    goto :goto_b

    .line 385
    :cond_20
    if-gez v3, :cond_24

    .line 386
    .line 387
    goto :goto_b

    .line 388
    :cond_21
    if-gtz v6, :cond_23

    .line 389
    .line 390
    if-nez v6, :cond_24

    .line 391
    .line 392
    mul-int v3, v3, v1

    .line 393
    .line 394
    if-lez v3, :cond_24

    .line 395
    .line 396
    goto :goto_b

    .line 397
    :cond_22
    if-ltz v6, :cond_23

    .line 398
    .line 399
    if-nez v6, :cond_24

    .line 400
    .line 401
    mul-int v3, v3, v1

    .line 402
    .line 403
    if-gez v3, :cond_24

    .line 404
    .line 405
    :cond_23
    :goto_b
    const/4 v1, 0x1

    .line 406
    goto :goto_d

    .line 407
    :cond_24
    :goto_c
    const/4 v1, 0x0

    .line 408
    :goto_d
    if-eqz v1, :cond_25

    .line 409
    .line 410
    goto :goto_e

    .line 411
    :cond_25
    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->focusSearch(Landroid/view/View;I)Landroid/view/View;

    .line 412
    .line 413
    .line 414
    move-result-object v0

    .line 415
    :goto_e
    return-object v0
.end method

.method public final g(Landroidx/recyclerview/widget/i1;)V
    .locals 5

    .line 1
    iget-object v0, p1, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    const/4 v2, 0x1

    .line 8
    if-ne v1, p0, :cond_0

    .line 9
    .line 10
    const/4 v1, 0x1

    .line 11
    goto :goto_0

    .line 12
    :cond_0
    const/4 v1, 0x0

    .line 13
    :goto_0
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 14
    .line 15
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView;->H(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 16
    .line 17
    .line 18
    move-result-object v4

    .line 19
    invoke-virtual {v3, v4}, Landroidx/recyclerview/widget/a1;->l(Landroidx/recyclerview/widget/i1;)V

    .line 20
    .line 21
    .line 22
    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->isTmpDetached()Z

    .line 23
    .line 24
    .line 25
    move-result p1

    .line 26
    const/4 v3, -0x1

    .line 27
    if-eqz p1, :cond_1

    .line 28
    .line 29
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 30
    .line 31
    invoke-virtual {v0}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 32
    .line 33
    .line 34
    move-result-object v1

    .line 35
    invoke-virtual {p1, v0, v3, v1, v2}, Landroidx/recyclerview/widget/e;->b(Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;Z)V

    .line 36
    .line 37
    .line 38
    goto :goto_1

    .line 39
    :cond_1
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 40
    .line 41
    if-nez v1, :cond_2

    .line 42
    .line 43
    invoke-virtual {p1, v0, v3, v2}, Landroidx/recyclerview/widget/e;->a(Landroid/view/View;IZ)V

    .line 44
    .line 45
    .line 46
    goto :goto_1

    .line 47
    :cond_2
    iget-object v1, p1, Landroidx/recyclerview/widget/e;->a:Landroidx/recyclerview/widget/p0;

    .line 48
    .line 49
    iget-object v1, v1, Landroidx/recyclerview/widget/p0;->a:Landroidx/recyclerview/widget/RecyclerView;

    .line 50
    .line 51
    invoke-virtual {v1, v0}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    .line 52
    .line 53
    .line 54
    move-result v1

    .line 55
    if-ltz v1, :cond_3

    .line 56
    .line 57
    iget-object v2, p1, Landroidx/recyclerview/widget/e;->b:Landroidx/recyclerview/widget/d;

    .line 58
    .line 59
    invoke-virtual {v2, v1}, Landroidx/recyclerview/widget/d;->h(I)V

    .line 60
    .line 61
    .line 62
    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/e;->i(Landroid/view/View;)V

    .line 63
    .line 64
    .line 65
    :goto_1
    return-void

    .line 66
    :cond_3
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 67
    .line 68
    new-instance v1, Ljava/lang/StringBuilder;

    .line 69
    .line 70
    const-string v2, "view is not a child, cannot hide "

    .line 71
    .line 72
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 73
    .line 74
    .line 75
    invoke-virtual {v1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 76
    .line 77
    .line 78
    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 79
    .line 80
    .line 81
    move-result-object v0

    .line 82
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 83
    .line 84
    .line 85
    throw p1
.end method

.method public final generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->q()Landroidx/recyclerview/widget/u0;

    .line 6
    .line 7
    .line 8
    move-result-object v0

    .line 9
    return-object v0

    .line 10
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 11
    .line 12
    new-instance v1, Ljava/lang/StringBuilder;

    .line 13
    .line 14
    const-string v2, "RecyclerView has no LayoutManager"

    .line 15
    .line 16
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 17
    .line 18
    .line 19
    invoke-static {p0, v1}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 20
    .line 21
    .line 22
    move-result-object v1

    .line 23
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 24
    .line 25
    .line 26
    throw v0
.end method

.method public final generateLayoutParams(Landroid/util/AttributeSet;)Landroid/view/ViewGroup$LayoutParams;
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    if-eqz v0, :cond_0

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v0, v1, p1}, Landroidx/recyclerview/widget/t0;->r(Landroid/content/Context;Landroid/util/AttributeSet;)Landroidx/recyclerview/widget/u0;

    move-result-object p1

    return-object p1

    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "RecyclerView has no LayoutManager"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1
    invoke-static {p0, v0}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    .line 2
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public final generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;
    .locals 2

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    if-eqz v0, :cond_0

    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/t0;->s(Landroid/view/ViewGroup$LayoutParams;)Landroidx/recyclerview/widget/u0;

    move-result-object p1

    return-object p1

    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, "RecyclerView has no LayoutManager"

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 9
    invoke-static {p0, v0}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    move-result-object v0

    .line 10
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public getAccessibilityClassName()Ljava/lang/CharSequence;
    .locals 1

    const-string v0, "androidx.recyclerview.widget.RecyclerView"

    return-object v0
.end method

.method public getAdapter()Landroidx/recyclerview/widget/i0;
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    return-object v0
.end method

.method public getBaseline()I
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    if-eqz v0, :cond_0

    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    const/4 v0, -0x1

    return v0

    :cond_0
    invoke-super {p0}, Landroid/view/ViewGroup;->getBaseline()I

    move-result v0

    return v0
.end method

.method public final getChildDrawingOrder(II)I
    .locals 0

    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->getChildDrawingOrder(II)I

    move-result p1

    return p1
.end method

.method public getClipToPadding()Z
    .locals 1

    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->h:Z

    return v0
.end method

.method public getCompatAccessibilityDelegate()Landroidx/recyclerview/widget/k1;
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->m0:Landroidx/recyclerview/widget/k1;

    return-object v0
.end method

.method public getEdgeEffectFactory()Landroidx/recyclerview/widget/m0;
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->G:Landroidx/recyclerview/widget/m0;

    return-object v0
.end method

.method public getItemAnimator()Landroidx/recyclerview/widget/o0;
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    return-object v0
.end method

.method public getItemDecorationCount()I
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->p:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v0

    return v0
.end method

.method public getLayoutManager()Landroidx/recyclerview/widget/t0;
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    return-object v0
.end method

.method public getMaxFlingVelocity()I
    .locals 1

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView;->V:I

    return v0
.end method

.method public getMinFlingVelocity()I
    .locals 1

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView;->U:I

    return v0
.end method

.method public getNanoTime()J
    .locals 2

    sget-boolean v0, Landroidx/recyclerview/widget/RecyclerView;->E0:Z

    if-eqz v0, :cond_0

    invoke-static {}, Ljava/lang/System;->nanoTime()J

    move-result-wide v0

    return-wide v0

    :cond_0
    const-wide/16 v0, 0x0

    return-wide v0
.end method

.method public getOnFlingListener()Landroidx/recyclerview/widget/v0;
    .locals 1

    const/4 v0, 0x0

    return-object v0
.end method

.method public getPreserveFocusAfterLayout()Z
    .locals 1

    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->b0:Z

    return v0
.end method

.method public getRecycledViewPool()Landroidx/recyclerview/widget/z0;
    .locals 1

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    invoke-virtual {v0}, Landroidx/recyclerview/widget/a1;->c()Landroidx/recyclerview/widget/z0;

    move-result-object v0

    return-object v0
.end method

.method public getScrollState()I
    .locals 1

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView;->M:I

    return v0
.end method

.method public final h(Ljava/lang/String;)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->K()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    if-eqz v0, :cond_1

    .line 6
    .line 7
    if-nez p1, :cond_0

    .line 8
    .line 9
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 10
    .line 11
    new-instance v0, Ljava/lang/StringBuilder;

    .line 12
    .line 13
    const-string v1, "Cannot call this method while RecyclerView is computing a layout or scrolling"

    .line 14
    .line 15
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 16
    .line 17
    .line 18
    invoke-static {p0, v0}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 19
    .line 20
    .line 21
    move-result-object v0

    .line 22
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 23
    .line 24
    .line 25
    throw p1

    .line 26
    :cond_0
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 27
    .line 28
    invoke-direct {v0, p1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 29
    .line 30
    .line 31
    throw v0

    .line 32
    :cond_1
    iget p1, p0, Landroidx/recyclerview/widget/RecyclerView;->F:I

    .line 33
    .line 34
    if-lez p1, :cond_2

    .line 35
    .line 36
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 37
    .line 38
    new-instance v0, Ljava/lang/StringBuilder;

    .line 39
    .line 40
    const-string v1, ""

    .line 41
    .line 42
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 43
    .line 44
    .line 45
    invoke-static {p0, v0}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 46
    .line 47
    .line 48
    move-result-object v0

    .line 49
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 50
    .line 51
    .line 52
    const-string v0, "RecyclerView"

    .line 53
    .line 54
    const-string v1, "Cannot call this method in a scroll callback. Scroll callbacks mightbe run during a measure & layout pass where you cannot change theRecyclerView data. Any method call that might change the structureof the RecyclerView or the adapter contents should be postponed tothe next frame."

    .line 55
    .line 56
    invoke-static {v0, v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 57
    .line 58
    .line 59
    :cond_2
    return-void
.end method

.method public final hasNestedScrollingParent()Z
    .locals 2

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView;->getScrollingChildHelper()Lg/f;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-virtual {v0, v1}, Lg/f;->c(I)Landroid/view/ViewParent;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    if-eqz v0, :cond_0

    .line 11
    .line 12
    const/4 v1, 0x1

    .line 13
    :cond_0
    return v1
.end method

.method public final isAttachedToWindow()Z
    .locals 1

    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->s:Z

    return v0
.end method

.method public final isLayoutSuppressed()Z
    .locals 1

    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->x:Z

    return v0
.end method

.method public final isNestedScrollingEnabled()Z
    .locals 1

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView;->getScrollingChildHelper()Lg/f;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-boolean v0, v0, Lg/f;->d:Z

    .line 6
    .line 7
    return v0
.end method

.method public final j()V
    .locals 6

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 2
    .line 3
    invoke-virtual {v0}, Landroidx/recyclerview/widget/e;->h()I

    .line 4
    .line 5
    .line 6
    move-result v0

    .line 7
    const/4 v1, 0x0

    .line 8
    const/4 v2, 0x0

    .line 9
    :goto_0
    if-ge v2, v0, :cond_1

    .line 10
    .line 11
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 12
    .line 13
    invoke-virtual {v3, v2}, Landroidx/recyclerview/widget/e;->g(I)Landroid/view/View;

    .line 14
    .line 15
    .line 16
    move-result-object v3

    .line 17
    invoke-static {v3}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 18
    .line 19
    .line 20
    move-result-object v3

    .line 21
    invoke-virtual {v3}, Landroidx/recyclerview/widget/i1;->shouldIgnore()Z

    .line 22
    .line 23
    .line 24
    move-result v4

    .line 25
    if-nez v4, :cond_0

    .line 26
    .line 27
    invoke-virtual {v3}, Landroidx/recyclerview/widget/i1;->clearOldPosition()V

    .line 28
    .line 29
    .line 30
    :cond_0
    add-int/lit8 v2, v2, 0x1

    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 34
    .line 35
    iget-object v2, v0, Landroidx/recyclerview/widget/a1;->c:Ljava/util/ArrayList;

    .line 36
    .line 37
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 38
    .line 39
    .line 40
    move-result v3

    .line 41
    const/4 v4, 0x0

    .line 42
    :goto_1
    if-ge v4, v3, :cond_2

    .line 43
    .line 44
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v5

    .line 48
    check-cast v5, Landroidx/recyclerview/widget/i1;

    .line 49
    .line 50
    invoke-virtual {v5}, Landroidx/recyclerview/widget/i1;->clearOldPosition()V

    .line 51
    .line 52
    .line 53
    add-int/lit8 v4, v4, 0x1

    .line 54
    .line 55
    goto :goto_1

    .line 56
    :cond_2
    iget-object v2, v0, Landroidx/recyclerview/widget/a1;->a:Ljava/util/ArrayList;

    .line 57
    .line 58
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 59
    .line 60
    .line 61
    move-result v3

    .line 62
    const/4 v4, 0x0

    .line 63
    :goto_2
    if-ge v4, v3, :cond_3

    .line 64
    .line 65
    invoke-virtual {v2, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 66
    .line 67
    .line 68
    move-result-object v5

    .line 69
    check-cast v5, Landroidx/recyclerview/widget/i1;

    .line 70
    .line 71
    invoke-virtual {v5}, Landroidx/recyclerview/widget/i1;->clearOldPosition()V

    .line 72
    .line 73
    .line 74
    add-int/lit8 v4, v4, 0x1

    .line 75
    .line 76
    goto :goto_2

    .line 77
    :cond_3
    iget-object v2, v0, Landroidx/recyclerview/widget/a1;->b:Ljava/util/ArrayList;

    .line 78
    .line 79
    if-eqz v2, :cond_4

    .line 80
    .line 81
    invoke-virtual {v2}, Ljava/util/ArrayList;->size()I

    .line 82
    .line 83
    .line 84
    move-result v2

    .line 85
    :goto_3
    if-ge v1, v2, :cond_4

    .line 86
    .line 87
    iget-object v3, v0, Landroidx/recyclerview/widget/a1;->b:Ljava/util/ArrayList;

    .line 88
    .line 89
    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 90
    .line 91
    .line 92
    move-result-object v3

    .line 93
    check-cast v3, Landroidx/recyclerview/widget/i1;

    .line 94
    .line 95
    invoke-virtual {v3}, Landroidx/recyclerview/widget/i1;->clearOldPosition()V

    .line 96
    .line 97
    .line 98
    add-int/lit8 v1, v1, 0x1

    .line 99
    .line 100
    goto :goto_3

    .line 101
    :cond_4
    return-void
.end method

.method public final k(II)V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 6
    .line 7
    .line 8
    move-result v0

    .line 9
    if-nez v0, :cond_0

    .line 10
    .line 11
    if-lez p1, :cond_0

    .line 12
    .line 13
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 14
    .line 15
    invoke-virtual {v0}, Landroid/widget/EdgeEffect;->onRelease()V

    .line 16
    .line 17
    .line 18
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 19
    .line 20
    invoke-virtual {v0}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    goto :goto_0

    .line 25
    :cond_0
    const/4 v0, 0x0

    .line 26
    :goto_0
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 27
    .line 28
    if-eqz v1, :cond_1

    .line 29
    .line 30
    invoke-virtual {v1}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 31
    .line 32
    .line 33
    move-result v1

    .line 34
    if-nez v1, :cond_1

    .line 35
    .line 36
    if-gez p1, :cond_1

    .line 37
    .line 38
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 39
    .line 40
    invoke-virtual {p1}, Landroid/widget/EdgeEffect;->onRelease()V

    .line 41
    .line 42
    .line 43
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 44
    .line 45
    invoke-virtual {p1}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 46
    .line 47
    .line 48
    move-result p1

    .line 49
    or-int/2addr v0, p1

    .line 50
    :cond_1
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 51
    .line 52
    if-eqz p1, :cond_2

    .line 53
    .line 54
    invoke-virtual {p1}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 55
    .line 56
    .line 57
    move-result p1

    .line 58
    if-nez p1, :cond_2

    .line 59
    .line 60
    if-lez p2, :cond_2

    .line 61
    .line 62
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 63
    .line 64
    invoke-virtual {p1}, Landroid/widget/EdgeEffect;->onRelease()V

    .line 65
    .line 66
    .line 67
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 68
    .line 69
    invoke-virtual {p1}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 70
    .line 71
    .line 72
    move-result p1

    .line 73
    or-int/2addr v0, p1

    .line 74
    :cond_2
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 75
    .line 76
    if-eqz p1, :cond_3

    .line 77
    .line 78
    invoke-virtual {p1}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 79
    .line 80
    .line 81
    move-result p1

    .line 82
    if-nez p1, :cond_3

    .line 83
    .line 84
    if-gez p2, :cond_3

    .line 85
    .line 86
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 87
    .line 88
    invoke-virtual {p1}, Landroid/widget/EdgeEffect;->onRelease()V

    .line 89
    .line 90
    .line 91
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 92
    .line 93
    invoke-virtual {p1}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 94
    .line 95
    .line 96
    move-result p1

    .line 97
    or-int/2addr v0, p1

    .line 98
    :cond_3
    if-eqz v0, :cond_4

    .line 99
    .line 100
    sget-object p1, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 101
    .line 102
    invoke-static {p0}, Lg/j;->k(Landroid/view/View;)V

    .line 103
    .line 104
    .line 105
    :cond_4
    return-void
.end method

.method public final m()V
    .locals 6

    .line 1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->u:Z

    .line 2
    .line 3
    const-string v1, "RV FullInvalidate"

    .line 4
    .line 5
    if-eqz v0, :cond_b

    .line 6
    .line 7
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->C:Z

    .line 8
    .line 9
    if-eqz v0, :cond_0

    .line 10
    .line 11
    goto/16 :goto_7

    .line 12
    .line 13
    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->e:Landroidx/recyclerview/widget/b;

    .line 14
    .line 15
    invoke-virtual {v0}, Landroidx/recyclerview/widget/b;->g()Z

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    if-nez v0, :cond_1

    .line 20
    .line 21
    return-void

    .line 22
    :cond_1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->e:Landroidx/recyclerview/widget/b;

    .line 23
    .line 24
    iget v2, v0, Landroidx/recyclerview/widget/b;->f:I

    .line 25
    .line 26
    const/4 v3, 0x4

    .line 27
    and-int/2addr v3, v2

    .line 28
    const/4 v4, 0x0

    .line 29
    const/4 v5, 0x1

    .line 30
    if-eqz v3, :cond_2

    .line 31
    .line 32
    const/4 v3, 0x1

    .line 33
    goto :goto_0

    .line 34
    :cond_2
    const/4 v3, 0x0

    .line 35
    :goto_0
    if-eqz v3, :cond_9

    .line 36
    .line 37
    const/16 v3, 0xb

    .line 38
    .line 39
    and-int/2addr v2, v3

    .line 40
    if-eqz v2, :cond_3

    .line 41
    .line 42
    const/4 v2, 0x1

    .line 43
    goto :goto_1

    .line 44
    :cond_3
    const/4 v2, 0x0

    .line 45
    :goto_1
    if-nez v2, :cond_9

    .line 46
    .line 47
    sget v0, Le/b;->a:I

    .line 48
    .line 49
    const-string v0, "RV PartialInvalidate"

    .line 50
    .line 51
    invoke-static {v0}, Le/a;->a(Ljava/lang/String;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->d0()V

    .line 55
    .line 56
    .line 57
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->N()V

    .line 58
    .line 59
    .line 60
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->e:Landroidx/recyclerview/widget/b;

    .line 61
    .line 62
    invoke-virtual {v0}, Landroidx/recyclerview/widget/b;->j()V

    .line 63
    .line 64
    .line 65
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->w:Z

    .line 66
    .line 67
    if-nez v0, :cond_8

    .line 68
    .line 69
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 70
    .line 71
    invoke-virtual {v0}, Landroidx/recyclerview/widget/e;->e()I

    .line 72
    .line 73
    .line 74
    move-result v0

    .line 75
    const/4 v1, 0x0

    .line 76
    :goto_2
    if-ge v1, v0, :cond_6

    .line 77
    .line 78
    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 79
    .line 80
    invoke-virtual {v2, v1}, Landroidx/recyclerview/widget/e;->d(I)Landroid/view/View;

    .line 81
    .line 82
    .line 83
    move-result-object v2

    .line 84
    invoke-static {v2}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 85
    .line 86
    .line 87
    move-result-object v2

    .line 88
    if-eqz v2, :cond_5

    .line 89
    .line 90
    invoke-virtual {v2}, Landroidx/recyclerview/widget/i1;->shouldIgnore()Z

    .line 91
    .line 92
    .line 93
    move-result v3

    .line 94
    if-eqz v3, :cond_4

    .line 95
    .line 96
    goto :goto_3

    .line 97
    :cond_4
    invoke-virtual {v2}, Landroidx/recyclerview/widget/i1;->isUpdated()Z

    .line 98
    .line 99
    .line 100
    move-result v2

    .line 101
    if-eqz v2, :cond_5

    .line 102
    .line 103
    const/4 v4, 0x1

    .line 104
    goto :goto_4

    .line 105
    :cond_5
    :goto_3
    add-int/lit8 v1, v1, 0x1

    .line 106
    .line 107
    goto :goto_2

    .line 108
    :cond_6
    :goto_4
    if-eqz v4, :cond_7

    .line 109
    .line 110
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->o()V

    .line 111
    .line 112
    .line 113
    goto :goto_5

    .line 114
    :cond_7
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->e:Landroidx/recyclerview/widget/b;

    .line 115
    .line 116
    invoke-virtual {v0}, Landroidx/recyclerview/widget/b;->b()V

    .line 117
    .line 118
    .line 119
    :cond_8
    :goto_5
    invoke-virtual {p0, v5}, Landroidx/recyclerview/widget/RecyclerView;->e0(Z)V

    .line 120
    .line 121
    .line 122
    invoke-virtual {p0, v5}, Landroidx/recyclerview/widget/RecyclerView;->O(Z)V

    .line 123
    .line 124
    .line 125
    goto :goto_6

    .line 126
    :cond_9
    invoke-virtual {v0}, Landroidx/recyclerview/widget/b;->g()Z

    .line 127
    .line 128
    .line 129
    move-result v0

    .line 130
    if-eqz v0, :cond_a

    .line 131
    .line 132
    sget v0, Le/b;->a:I

    .line 133
    .line 134
    invoke-static {v1}, Le/a;->a(Ljava/lang/String;)V

    .line 135
    .line 136
    .line 137
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->o()V

    .line 138
    .line 139
    .line 140
    :goto_6
    invoke-static {}, Le/a;->b()V

    .line 141
    .line 142
    .line 143
    :cond_a
    return-void

    .line 144
    :cond_b
    :goto_7
    sget v0, Le/b;->a:I

    .line 145
    .line 146
    invoke-static {v1}, Le/a;->a(Ljava/lang/String;)V

    .line 147
    .line 148
    .line 149
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->o()V

    .line 150
    .line 151
    .line 152
    invoke-static {}, Le/a;->b()V

    .line 153
    .line 154
    .line 155
    return-void
.end method

.method public final n(II)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 6
    .line 7
    .line 8
    move-result v1

    .line 9
    add-int/2addr v1, v0

    .line 10
    sget-object v0, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 11
    .line 12
    invoke-static {p0}, Lg/j;->e(Landroid/view/View;)I

    .line 13
    .line 14
    .line 15
    move-result v0

    .line 16
    invoke-static {p1, v1, v0}, Landroidx/recyclerview/widget/t0;->f(III)I

    .line 17
    .line 18
    .line 19
    move-result p1

    .line 20
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 25
    .line 26
    .line 27
    move-result v1

    .line 28
    add-int/2addr v1, v0

    .line 29
    invoke-static {p0}, Lg/j;->d(Landroid/view/View;)I

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    invoke-static {p2, v1, v0}, Landroidx/recyclerview/widget/t0;->f(III)I

    .line 34
    .line 35
    .line 36
    move-result p2

    .line 37
    invoke-virtual {p0, p1, p2}, Landroid/view/View;->setMeasuredDimension(II)V

    .line 38
    .line 39
    .line 40
    return-void
.end method

.method public final o()V
    .locals 18

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 4
    .line 5
    const-string v2, "RecyclerView"

    .line 6
    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    const-string v1, "No adapter attached; skipping layout"

    .line 10
    .line 11
    invoke-static {v2, v1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    .line 12
    .line 13
    .line 14
    return-void

    .line 15
    :cond_0
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 16
    .line 17
    if-nez v1, :cond_1

    .line 18
    .line 19
    const-string v1, "No layout manager attached; skipping layout"

    .line 20
    .line 21
    invoke-static {v2, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 22
    .line 23
    .line 24
    return-void

    .line 25
    :cond_1
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    .line 26
    .line 27
    const/4 v3, 0x0

    .line 28
    iput-boolean v3, v1, Landroidx/recyclerview/widget/e1;->h:Z

    .line 29
    .line 30
    iget-boolean v4, v0, Landroidx/recyclerview/widget/RecyclerView;->u0:Z

    .line 31
    .line 32
    const/4 v5, 0x1

    .line 33
    if-eqz v4, :cond_3

    .line 34
    .line 35
    iget v4, v0, Landroidx/recyclerview/widget/RecyclerView;->v0:I

    .line 36
    .line 37
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 38
    .line 39
    .line 40
    move-result v6

    .line 41
    if-ne v4, v6, :cond_2

    .line 42
    .line 43
    iget v4, v0, Landroidx/recyclerview/widget/RecyclerView;->w0:I

    .line 44
    .line 45
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 46
    .line 47
    .line 48
    move-result v6

    .line 49
    if-eq v4, v6, :cond_3

    .line 50
    .line 51
    :cond_2
    const/4 v4, 0x1

    .line 52
    goto :goto_0

    .line 53
    :cond_3
    const/4 v4, 0x0

    .line 54
    :goto_0
    iput v3, v0, Landroidx/recyclerview/widget/RecyclerView;->v0:I

    .line 55
    .line 56
    iput v3, v0, Landroidx/recyclerview/widget/RecyclerView;->w0:I

    .line 57
    .line 58
    iput-boolean v3, v0, Landroidx/recyclerview/widget/RecyclerView;->u0:Z

    .line 59
    .line 60
    iget v6, v1, Landroidx/recyclerview/widget/e1;->c:I

    .line 61
    .line 62
    if-ne v6, v5, :cond_4

    .line 63
    .line 64
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView;->p()V

    .line 65
    .line 66
    .line 67
    goto :goto_2

    .line 68
    :cond_4
    iget-object v6, v0, Landroidx/recyclerview/widget/RecyclerView;->e:Landroidx/recyclerview/widget/b;

    .line 69
    .line 70
    iget-object v7, v6, Landroidx/recyclerview/widget/b;->c:Ljava/util/ArrayList;

    .line 71
    .line 72
    invoke-virtual {v7}, Ljava/util/ArrayList;->isEmpty()Z

    .line 73
    .line 74
    .line 75
    move-result v7

    .line 76
    if-nez v7, :cond_5

    .line 77
    .line 78
    iget-object v6, v6, Landroidx/recyclerview/widget/b;->b:Ljava/util/ArrayList;

    .line 79
    .line 80
    invoke-virtual {v6}, Ljava/util/ArrayList;->isEmpty()Z

    .line 81
    .line 82
    .line 83
    move-result v6

    .line 84
    if-nez v6, :cond_5

    .line 85
    .line 86
    const/4 v6, 0x1

    .line 87
    goto :goto_1

    .line 88
    :cond_5
    const/4 v6, 0x0

    .line 89
    :goto_1
    if-nez v6, :cond_7

    .line 90
    .line 91
    if-nez v4, :cond_7

    .line 92
    .line 93
    iget-object v4, v0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 94
    .line 95
    iget v4, v4, Landroidx/recyclerview/widget/t0;->m:I

    .line 96
    .line 97
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 98
    .line 99
    .line 100
    move-result v6

    .line 101
    if-ne v4, v6, :cond_7

    .line 102
    .line 103
    iget-object v4, v0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 104
    .line 105
    iget v4, v4, Landroidx/recyclerview/widget/t0;->n:I

    .line 106
    .line 107
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 108
    .line 109
    .line 110
    move-result v6

    .line 111
    if-eq v4, v6, :cond_6

    .line 112
    .line 113
    goto :goto_2

    .line 114
    :cond_6
    iget-object v4, v0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 115
    .line 116
    invoke-virtual {v4, v0}, Landroidx/recyclerview/widget/t0;->l0(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 117
    .line 118
    .line 119
    goto :goto_3

    .line 120
    :cond_7
    :goto_2
    iget-object v4, v0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 121
    .line 122
    invoke-virtual {v4, v0}, Landroidx/recyclerview/widget/t0;->l0(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 123
    .line 124
    .line 125
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView;->q()V

    .line 126
    .line 127
    .line 128
    :goto_3
    const/4 v4, 0x4

    .line 129
    invoke-virtual {v1, v4}, Landroidx/recyclerview/widget/e1;->a(I)V

    .line 130
    .line 131
    .line 132
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView;->d0()V

    .line 133
    .line 134
    .line 135
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView;->N()V

    .line 136
    .line 137
    .line 138
    iput v5, v1, Landroidx/recyclerview/widget/e1;->c:I

    .line 139
    .line 140
    iget-boolean v6, v1, Landroidx/recyclerview/widget/e1;->i:Z

    .line 141
    .line 142
    iget-object v7, v0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 143
    .line 144
    iget-object v8, v0, Landroidx/recyclerview/widget/RecyclerView;->g:Landroidx/recyclerview/widget/t1;

    .line 145
    .line 146
    if-eqz v6, :cond_29

    .line 147
    .line 148
    iget-object v6, v0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 149
    .line 150
    invoke-virtual {v6}, Landroidx/recyclerview/widget/e;->e()I

    .line 151
    .line 152
    .line 153
    move-result v6

    .line 154
    sub-int/2addr v6, v5

    .line 155
    :goto_4
    if-ltz v6, :cond_18

    .line 156
    .line 157
    iget-object v9, v0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 158
    .line 159
    invoke-virtual {v9, v6}, Landroidx/recyclerview/widget/e;->d(I)Landroid/view/View;

    .line 160
    .line 161
    .line 162
    move-result-object v9

    .line 163
    invoke-static {v9}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 164
    .line 165
    .line 166
    move-result-object v9

    .line 167
    invoke-virtual {v9}, Landroidx/recyclerview/widget/i1;->shouldIgnore()Z

    .line 168
    .line 169
    .line 170
    move-result v10

    .line 171
    if-eqz v10, :cond_8

    .line 172
    .line 173
    goto/16 :goto_a

    .line 174
    .line 175
    :cond_8
    invoke-virtual {v0, v9}, Landroidx/recyclerview/widget/RecyclerView;->G(Landroidx/recyclerview/widget/i1;)J

    .line 176
    .line 177
    .line 178
    move-result-wide v10

    .line 179
    iget-object v12, v0, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 180
    .line 181
    invoke-virtual {v12}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 182
    .line 183
    .line 184
    new-instance v12, Landroidx/recyclerview/widget/n0;

    .line 185
    .line 186
    invoke-direct {v12}, Landroidx/recyclerview/widget/n0;-><init>()V

    .line 187
    .line 188
    .line 189
    invoke-virtual {v12, v9}, Landroidx/recyclerview/widget/n0;->a(Landroidx/recyclerview/widget/i1;)V

    .line 190
    .line 191
    .line 192
    iget-object v13, v8, Landroidx/recyclerview/widget/t1;->c:Ljava/lang/Object;

    .line 193
    .line 194
    check-cast v13, La/c;

    .line 195
    .line 196
    iget-object v14, v13, La/c;->b:[J

    .line 197
    .line 198
    iget v15, v13, La/c;->d:I

    .line 199
    .line 200
    invoke-static {v14, v15, v10, v11}, Lb0/d;->d([JIJ)I

    .line 201
    .line 202
    .line 203
    move-result v14

    .line 204
    if-ltz v14, :cond_9

    .line 205
    .line 206
    iget-object v13, v13, La/c;->c:[Ljava/lang/Object;

    .line 207
    .line 208
    aget-object v13, v13, v14

    .line 209
    .line 210
    sget-object v14, La/c;->e:Ljava/lang/Object;

    .line 211
    .line 212
    if-ne v13, v14, :cond_a

    .line 213
    .line 214
    :cond_9
    const/4 v13, 0x0

    .line 215
    :cond_a
    check-cast v13, Landroidx/recyclerview/widget/i1;

    .line 216
    .line 217
    if-eqz v13, :cond_16

    .line 218
    .line 219
    invoke-virtual {v13}, Landroidx/recyclerview/widget/i1;->shouldIgnore()Z

    .line 220
    .line 221
    .line 222
    move-result v14

    .line 223
    if-nez v14, :cond_16

    .line 224
    .line 225
    iget-object v14, v8, Landroidx/recyclerview/widget/t1;->b:Ljava/lang/Object;

    .line 226
    .line 227
    check-cast v14, La/h;

    .line 228
    .line 229
    invoke-virtual {v14, v13}, La/h;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 230
    .line 231
    .line 232
    move-result-object v14

    .line 233
    check-cast v14, Landroidx/recyclerview/widget/s1;

    .line 234
    .line 235
    if-eqz v14, :cond_b

    .line 236
    .line 237
    iget v14, v14, Landroidx/recyclerview/widget/s1;->a:I

    .line 238
    .line 239
    and-int/2addr v14, v5

    .line 240
    if-eqz v14, :cond_b

    .line 241
    .line 242
    const/4 v14, 0x1

    .line 243
    goto :goto_5

    .line 244
    :cond_b
    const/4 v14, 0x0

    .line 245
    :goto_5
    iget-object v15, v8, Landroidx/recyclerview/widget/t1;->b:Ljava/lang/Object;

    .line 246
    .line 247
    check-cast v15, La/h;

    .line 248
    .line 249
    invoke-virtual {v15, v9}, La/h;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 250
    .line 251
    .line 252
    move-result-object v15

    .line 253
    check-cast v15, Landroidx/recyclerview/widget/s1;

    .line 254
    .line 255
    if-eqz v15, :cond_c

    .line 256
    .line 257
    iget v15, v15, Landroidx/recyclerview/widget/s1;->a:I

    .line 258
    .line 259
    and-int/2addr v5, v15

    .line 260
    if-eqz v5, :cond_c

    .line 261
    .line 262
    const/4 v5, 0x1

    .line 263
    goto :goto_6

    .line 264
    :cond_c
    const/4 v5, 0x0

    .line 265
    :goto_6
    if-eqz v14, :cond_d

    .line 266
    .line 267
    if-ne v13, v9, :cond_d

    .line 268
    .line 269
    goto/16 :goto_9

    .line 270
    .line 271
    :cond_d
    invoke-virtual {v8, v13, v4}, Landroidx/recyclerview/widget/t1;->l(Landroidx/recyclerview/widget/i1;I)Landroidx/recyclerview/widget/n0;

    .line 272
    .line 273
    .line 274
    move-result-object v15

    .line 275
    invoke-virtual {v8, v9, v12}, Landroidx/recyclerview/widget/t1;->c(Landroidx/recyclerview/widget/i1;Landroidx/recyclerview/widget/n0;)V

    .line 276
    .line 277
    .line 278
    const/16 v12, 0x8

    .line 279
    .line 280
    invoke-virtual {v8, v9, v12}, Landroidx/recyclerview/widget/t1;->l(Landroidx/recyclerview/widget/i1;I)Landroidx/recyclerview/widget/n0;

    .line 281
    .line 282
    .line 283
    move-result-object v12

    .line 284
    if-nez v15, :cond_12

    .line 285
    .line 286
    iget-object v5, v0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 287
    .line 288
    invoke-virtual {v5}, Landroidx/recyclerview/widget/e;->e()I

    .line 289
    .line 290
    .line 291
    move-result v5

    .line 292
    const/4 v12, 0x0

    .line 293
    :goto_7
    if-ge v12, v5, :cond_11

    .line 294
    .line 295
    iget-object v14, v0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 296
    .line 297
    invoke-virtual {v14, v12}, Landroidx/recyclerview/widget/e;->d(I)Landroid/view/View;

    .line 298
    .line 299
    .line 300
    move-result-object v14

    .line 301
    invoke-static {v14}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 302
    .line 303
    .line 304
    move-result-object v14

    .line 305
    if-ne v14, v9, :cond_e

    .line 306
    .line 307
    goto :goto_8

    .line 308
    :cond_e
    invoke-virtual {v0, v14}, Landroidx/recyclerview/widget/RecyclerView;->G(Landroidx/recyclerview/widget/i1;)J

    .line 309
    .line 310
    .line 311
    move-result-wide v15

    .line 312
    cmp-long v17, v15, v10

    .line 313
    .line 314
    if-nez v17, :cond_10

    .line 315
    .line 316
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 317
    .line 318
    const-string v2, " \n View Holder 2:"

    .line 319
    .line 320
    if-eqz v1, :cond_f

    .line 321
    .line 322
    invoke-virtual {v1}, Landroidx/recyclerview/widget/i0;->hasStableIds()Z

    .line 323
    .line 324
    .line 325
    move-result v1

    .line 326
    if-eqz v1, :cond_f

    .line 327
    .line 328
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 329
    .line 330
    new-instance v3, Ljava/lang/StringBuilder;

    .line 331
    .line 332
    const-string v4, "Two different ViewHolders have the same stable ID. Stable IDs in your adapter MUST BE unique and SHOULD NOT change.\n ViewHolder 1:"

    .line 333
    .line 334
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 335
    .line 336
    .line 337
    invoke-virtual {v3, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 338
    .line 339
    .line 340
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 341
    .line 342
    .line 343
    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 344
    .line 345
    .line 346
    invoke-static {v0, v3}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 347
    .line 348
    .line 349
    move-result-object v2

    .line 350
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 351
    .line 352
    .line 353
    throw v1

    .line 354
    :cond_f
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 355
    .line 356
    new-instance v3, Ljava/lang/StringBuilder;

    .line 357
    .line 358
    const-string v4, "Two different ViewHolders have the same change ID. This might happen due to inconsistent Adapter update events or if the LayoutManager lays out the same View multiple times.\n ViewHolder 1:"

    .line 359
    .line 360
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 361
    .line 362
    .line 363
    invoke-virtual {v3, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 364
    .line 365
    .line 366
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 367
    .line 368
    .line 369
    invoke-virtual {v3, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 370
    .line 371
    .line 372
    invoke-static {v0, v3}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 373
    .line 374
    .line 375
    move-result-object v2

    .line 376
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 377
    .line 378
    .line 379
    throw v1

    .line 380
    :cond_10
    :goto_8
    add-int/lit8 v12, v12, 0x1

    .line 381
    .line 382
    goto :goto_7

    .line 383
    :cond_11
    new-instance v5, Ljava/lang/StringBuilder;

    .line 384
    .line 385
    const-string v10, "Problem while matching changed view holders with the newones. The pre-layout information for the change holder "

    .line 386
    .line 387
    invoke-direct {v5, v10}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 388
    .line 389
    .line 390
    invoke-virtual {v5, v13}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 391
    .line 392
    .line 393
    const-string v10, " cannot be found but it is necessary for "

    .line 394
    .line 395
    invoke-virtual {v5, v10}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 396
    .line 397
    .line 398
    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 399
    .line 400
    .line 401
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView;->y()Ljava/lang/String;

    .line 402
    .line 403
    .line 404
    move-result-object v9

    .line 405
    invoke-virtual {v5, v9}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 406
    .line 407
    .line 408
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 409
    .line 410
    .line 411
    move-result-object v5

    .line 412
    invoke-static {v2, v5}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 413
    .line 414
    .line 415
    goto :goto_a

    .line 416
    :cond_12
    invoke-virtual {v13, v3}, Landroidx/recyclerview/widget/i1;->setIsRecyclable(Z)V

    .line 417
    .line 418
    .line 419
    if-eqz v14, :cond_13

    .line 420
    .line 421
    invoke-virtual {v0, v13}, Landroidx/recyclerview/widget/RecyclerView;->g(Landroidx/recyclerview/widget/i1;)V

    .line 422
    .line 423
    .line 424
    :cond_13
    if-eq v13, v9, :cond_15

    .line 425
    .line 426
    if-eqz v5, :cond_14

    .line 427
    .line 428
    invoke-virtual {v0, v9}, Landroidx/recyclerview/widget/RecyclerView;->g(Landroidx/recyclerview/widget/i1;)V

    .line 429
    .line 430
    .line 431
    :cond_14
    iput-object v9, v13, Landroidx/recyclerview/widget/i1;->mShadowedHolder:Landroidx/recyclerview/widget/i1;

    .line 432
    .line 433
    invoke-virtual {v0, v13}, Landroidx/recyclerview/widget/RecyclerView;->g(Landroidx/recyclerview/widget/i1;)V

    .line 434
    .line 435
    .line 436
    invoke-virtual {v7, v13}, Landroidx/recyclerview/widget/a1;->l(Landroidx/recyclerview/widget/i1;)V

    .line 437
    .line 438
    .line 439
    invoke-virtual {v9, v3}, Landroidx/recyclerview/widget/i1;->setIsRecyclable(Z)V

    .line 440
    .line 441
    .line 442
    iput-object v13, v9, Landroidx/recyclerview/widget/i1;->mShadowingHolder:Landroidx/recyclerview/widget/i1;

    .line 443
    .line 444
    :cond_15
    iget-object v5, v0, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 445
    .line 446
    invoke-virtual {v5, v13, v9, v15, v12}, Landroidx/recyclerview/widget/o0;->a(Landroidx/recyclerview/widget/i1;Landroidx/recyclerview/widget/i1;Landroidx/recyclerview/widget/n0;Landroidx/recyclerview/widget/n0;)Z

    .line 447
    .line 448
    .line 449
    move-result v5

    .line 450
    if-eqz v5, :cond_17

    .line 451
    .line 452
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView;->Q()V

    .line 453
    .line 454
    .line 455
    goto :goto_a

    .line 456
    :cond_16
    :goto_9
    invoke-virtual {v8, v9, v12}, Landroidx/recyclerview/widget/t1;->c(Landroidx/recyclerview/widget/i1;Landroidx/recyclerview/widget/n0;)V

    .line 457
    .line 458
    .line 459
    :cond_17
    :goto_a
    add-int/lit8 v6, v6, -0x1

    .line 460
    .line 461
    const/4 v5, 0x1

    .line 462
    goto/16 :goto_4

    .line 463
    .line 464
    :cond_18
    iget-object v2, v8, Landroidx/recyclerview/widget/t1;->b:Ljava/lang/Object;

    .line 465
    .line 466
    check-cast v2, La/h;

    .line 467
    .line 468
    iget v2, v2, La/h;->c:I

    .line 469
    .line 470
    add-int/lit8 v2, v2, -0x1

    .line 471
    .line 472
    :goto_b
    if-ltz v2, :cond_29

    .line 473
    .line 474
    iget-object v4, v8, Landroidx/recyclerview/widget/t1;->b:Ljava/lang/Object;

    .line 475
    .line 476
    move-object v5, v4

    .line 477
    check-cast v5, La/h;

    .line 478
    .line 479
    iget-object v5, v5, La/h;->b:[Ljava/lang/Object;

    .line 480
    .line 481
    shl-int/lit8 v6, v2, 0x1

    .line 482
    .line 483
    aget-object v5, v5, v6

    .line 484
    .line 485
    move-object v10, v5

    .line 486
    check-cast v10, Landroidx/recyclerview/widget/i1;

    .line 487
    .line 488
    check-cast v4, La/h;

    .line 489
    .line 490
    invoke-virtual {v4, v2}, La/h;->h(I)Ljava/lang/Object;

    .line 491
    .line 492
    .line 493
    move-result-object v4

    .line 494
    check-cast v4, Landroidx/recyclerview/widget/s1;

    .line 495
    .line 496
    iget v5, v4, Landroidx/recyclerview/widget/s1;->a:I

    .line 497
    .line 498
    and-int/lit8 v6, v5, 0x3

    .line 499
    .line 500
    const/4 v9, 0x3

    .line 501
    iget-object v11, v0, Landroidx/recyclerview/widget/RecyclerView;->x0:Landroidx/recyclerview/widget/p0;

    .line 502
    .line 503
    if-ne v6, v9, :cond_19

    .line 504
    .line 505
    goto :goto_c

    .line 506
    :cond_19
    and-int/lit8 v6, v5, 0x1

    .line 507
    .line 508
    if-eqz v6, :cond_1b

    .line 509
    .line 510
    iget-object v5, v4, Landroidx/recyclerview/widget/s1;->b:Landroidx/recyclerview/widget/n0;

    .line 511
    .line 512
    if-nez v5, :cond_1a

    .line 513
    .line 514
    :goto_c
    iget-object v3, v11, Landroidx/recyclerview/widget/p0;->a:Landroidx/recyclerview/widget/RecyclerView;

    .line 515
    .line 516
    iget-object v5, v3, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 517
    .line 518
    iget-object v6, v10, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 519
    .line 520
    iget-object v3, v3, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 521
    .line 522
    invoke-virtual {v5, v6, v3}, Landroidx/recyclerview/widget/t0;->e0(Landroid/view/View;Landroidx/recyclerview/widget/a1;)V

    .line 523
    .line 524
    .line 525
    goto/16 :goto_16

    .line 526
    .line 527
    :cond_1a
    iget-object v6, v4, Landroidx/recyclerview/widget/s1;->c:Landroidx/recyclerview/widget/n0;

    .line 528
    .line 529
    goto :goto_10

    .line 530
    :cond_1b
    and-int/lit8 v6, v5, 0xe

    .line 531
    .line 532
    const/16 v9, 0xe

    .line 533
    .line 534
    if-ne v6, v9, :cond_1c

    .line 535
    .line 536
    goto/16 :goto_14

    .line 537
    .line 538
    :cond_1c
    and-int/lit8 v6, v5, 0xc

    .line 539
    .line 540
    const/16 v9, 0xc

    .line 541
    .line 542
    if-ne v6, v9, :cond_20

    .line 543
    .line 544
    iget-object v5, v4, Landroidx/recyclerview/widget/s1;->b:Landroidx/recyclerview/widget/n0;

    .line 545
    .line 546
    iget-object v6, v4, Landroidx/recyclerview/widget/s1;->c:Landroidx/recyclerview/widget/n0;

    .line 547
    .line 548
    invoke-virtual {v11}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 549
    .line 550
    .line 551
    invoke-virtual {v10, v3}, Landroidx/recyclerview/widget/i1;->setIsRecyclable(Z)V

    .line 552
    .line 553
    .line 554
    iget-object v3, v11, Landroidx/recyclerview/widget/p0;->a:Landroidx/recyclerview/widget/RecyclerView;

    .line 555
    .line 556
    iget-boolean v9, v3, Landroidx/recyclerview/widget/RecyclerView;->C:Z

    .line 557
    .line 558
    if-eqz v9, :cond_1d

    .line 559
    .line 560
    iget-object v9, v3, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 561
    .line 562
    invoke-virtual {v9, v10, v10, v5, v6}, Landroidx/recyclerview/widget/o0;->a(Landroidx/recyclerview/widget/i1;Landroidx/recyclerview/widget/i1;Landroidx/recyclerview/widget/n0;Landroidx/recyclerview/widget/n0;)Z

    .line 563
    .line 564
    .line 565
    move-result v5

    .line 566
    if-eqz v5, :cond_28

    .line 567
    .line 568
    goto :goto_f

    .line 569
    :cond_1d
    iget-object v9, v3, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 570
    .line 571
    check-cast v9, Landroidx/recyclerview/widget/l;

    .line 572
    .line 573
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 574
    .line 575
    .line 576
    iget v11, v5, Landroidx/recyclerview/widget/n0;->a:I

    .line 577
    .line 578
    iget v13, v6, Landroidx/recyclerview/widget/n0;->a:I

    .line 579
    .line 580
    if-ne v11, v13, :cond_1f

    .line 581
    .line 582
    iget v12, v5, Landroidx/recyclerview/widget/n0;->b:I

    .line 583
    .line 584
    iget v14, v6, Landroidx/recyclerview/widget/n0;->b:I

    .line 585
    .line 586
    if-eq v12, v14, :cond_1e

    .line 587
    .line 588
    goto :goto_d

    .line 589
    :cond_1e
    invoke-virtual {v9, v10}, Landroidx/recyclerview/widget/o0;->c(Landroidx/recyclerview/widget/i1;)V

    .line 590
    .line 591
    .line 592
    const/4 v5, 0x0

    .line 593
    goto :goto_e

    .line 594
    :cond_1f
    :goto_d
    iget v12, v5, Landroidx/recyclerview/widget/n0;->b:I

    .line 595
    .line 596
    iget v14, v6, Landroidx/recyclerview/widget/n0;->b:I

    .line 597
    .line 598
    invoke-virtual/range {v9 .. v14}, Landroidx/recyclerview/widget/l;->g(Landroidx/recyclerview/widget/i1;IIII)Z

    .line 599
    .line 600
    .line 601
    move-result v5

    .line 602
    :goto_e
    if-eqz v5, :cond_28

    .line 603
    .line 604
    :goto_f
    invoke-virtual {v3}, Landroidx/recyclerview/widget/RecyclerView;->Q()V

    .line 605
    .line 606
    .line 607
    goto/16 :goto_16

    .line 608
    .line 609
    :cond_20
    and-int/lit8 v6, v5, 0x4

    .line 610
    .line 611
    if-eqz v6, :cond_25

    .line 612
    .line 613
    iget-object v5, v4, Landroidx/recyclerview/widget/s1;->b:Landroidx/recyclerview/widget/n0;

    .line 614
    .line 615
    const/4 v6, 0x0

    .line 616
    :goto_10
    iget-object v15, v11, Landroidx/recyclerview/widget/p0;->a:Landroidx/recyclerview/widget/RecyclerView;

    .line 617
    .line 618
    iget-object v9, v15, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 619
    .line 620
    invoke-virtual {v9, v10}, Landroidx/recyclerview/widget/a1;->l(Landroidx/recyclerview/widget/i1;)V

    .line 621
    .line 622
    .line 623
    invoke-virtual {v15, v10}, Landroidx/recyclerview/widget/RecyclerView;->g(Landroidx/recyclerview/widget/i1;)V

    .line 624
    .line 625
    .line 626
    invoke-virtual {v10, v3}, Landroidx/recyclerview/widget/i1;->setIsRecyclable(Z)V

    .line 627
    .line 628
    .line 629
    iget-object v3, v15, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 630
    .line 631
    move-object v9, v3

    .line 632
    check-cast v9, Landroidx/recyclerview/widget/l;

    .line 633
    .line 634
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 635
    .line 636
    .line 637
    iget v11, v5, Landroidx/recyclerview/widget/n0;->a:I

    .line 638
    .line 639
    iget v12, v5, Landroidx/recyclerview/widget/n0;->b:I

    .line 640
    .line 641
    iget-object v3, v10, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 642
    .line 643
    if-nez v6, :cond_21

    .line 644
    .line 645
    invoke-virtual {v3}, Landroid/view/View;->getLeft()I

    .line 646
    .line 647
    .line 648
    move-result v5

    .line 649
    goto :goto_11

    .line 650
    :cond_21
    iget v5, v6, Landroidx/recyclerview/widget/n0;->a:I

    .line 651
    .line 652
    :goto_11
    move v13, v5

    .line 653
    if-nez v6, :cond_22

    .line 654
    .line 655
    invoke-virtual {v3}, Landroid/view/View;->getTop()I

    .line 656
    .line 657
    .line 658
    move-result v5

    .line 659
    goto :goto_12

    .line 660
    :cond_22
    iget v5, v6, Landroidx/recyclerview/widget/n0;->b:I

    .line 661
    .line 662
    :goto_12
    move v14, v5

    .line 663
    invoke-virtual {v10}, Landroidx/recyclerview/widget/i1;->isRemoved()Z

    .line 664
    .line 665
    .line 666
    move-result v5

    .line 667
    if-nez v5, :cond_24

    .line 668
    .line 669
    if-ne v11, v13, :cond_23

    .line 670
    .line 671
    if-eq v12, v14, :cond_24

    .line 672
    .line 673
    :cond_23
    invoke-virtual {v3}, Landroid/view/View;->getWidth()I

    .line 674
    .line 675
    .line 676
    move-result v5

    .line 677
    add-int/2addr v5, v13

    .line 678
    invoke-virtual {v3}, Landroid/view/View;->getHeight()I

    .line 679
    .line 680
    .line 681
    move-result v6

    .line 682
    add-int/2addr v6, v14

    .line 683
    invoke-virtual {v3, v13, v14, v5, v6}, Landroid/view/View;->layout(IIII)V

    .line 684
    .line 685
    .line 686
    invoke-virtual/range {v9 .. v14}, Landroidx/recyclerview/widget/l;->g(Landroidx/recyclerview/widget/i1;IIII)Z

    .line 687
    .line 688
    .line 689
    move-result v3

    .line 690
    goto :goto_13

    .line 691
    :cond_24
    invoke-virtual {v9, v10}, Landroidx/recyclerview/widget/l;->l(Landroidx/recyclerview/widget/i1;)V

    .line 692
    .line 693
    .line 694
    iget-object v3, v9, Landroidx/recyclerview/widget/l;->h:Ljava/util/ArrayList;

    .line 695
    .line 696
    invoke-virtual {v3, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 697
    .line 698
    .line 699
    const/4 v3, 0x1

    .line 700
    :goto_13
    if-eqz v3, :cond_28

    .line 701
    .line 702
    invoke-virtual {v15}, Landroidx/recyclerview/widget/RecyclerView;->Q()V

    .line 703
    .line 704
    .line 705
    goto :goto_16

    .line 706
    :cond_25
    and-int/lit8 v3, v5, 0x8

    .line 707
    .line 708
    if-eqz v3, :cond_28

    .line 709
    .line 710
    :goto_14
    iget-object v3, v4, Landroidx/recyclerview/widget/s1;->b:Landroidx/recyclerview/widget/n0;

    .line 711
    .line 712
    iget-object v5, v4, Landroidx/recyclerview/widget/s1;->c:Landroidx/recyclerview/widget/n0;

    .line 713
    .line 714
    iget-object v6, v11, Landroidx/recyclerview/widget/p0;->a:Landroidx/recyclerview/widget/RecyclerView;

    .line 715
    .line 716
    invoke-virtual {v6}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 717
    .line 718
    .line 719
    const/4 v9, 0x0

    .line 720
    invoke-virtual {v10, v9}, Landroidx/recyclerview/widget/i1;->setIsRecyclable(Z)V

    .line 721
    .line 722
    .line 723
    iget-object v9, v6, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 724
    .line 725
    check-cast v9, Landroidx/recyclerview/widget/l;

    .line 726
    .line 727
    if-eqz v3, :cond_27

    .line 728
    .line 729
    invoke-virtual {v9}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 730
    .line 731
    .line 732
    iget v11, v3, Landroidx/recyclerview/widget/n0;->a:I

    .line 733
    .line 734
    iget v13, v5, Landroidx/recyclerview/widget/n0;->a:I

    .line 735
    .line 736
    if-ne v11, v13, :cond_26

    .line 737
    .line 738
    iget v12, v3, Landroidx/recyclerview/widget/n0;->b:I

    .line 739
    .line 740
    iget v14, v5, Landroidx/recyclerview/widget/n0;->b:I

    .line 741
    .line 742
    if-eq v12, v14, :cond_27

    .line 743
    .line 744
    :cond_26
    iget v12, v3, Landroidx/recyclerview/widget/n0;->b:I

    .line 745
    .line 746
    iget v14, v5, Landroidx/recyclerview/widget/n0;->b:I

    .line 747
    .line 748
    invoke-virtual/range {v9 .. v14}, Landroidx/recyclerview/widget/l;->g(Landroidx/recyclerview/widget/i1;IIII)Z

    .line 749
    .line 750
    .line 751
    move-result v3

    .line 752
    goto :goto_15

    .line 753
    :cond_27
    invoke-virtual {v9, v10}, Landroidx/recyclerview/widget/l;->l(Landroidx/recyclerview/widget/i1;)V

    .line 754
    .line 755
    .line 756
    iget-object v3, v10, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 757
    .line 758
    const/4 v5, 0x0

    .line 759
    invoke-virtual {v3, v5}, Landroid/view/View;->setAlpha(F)V

    .line 760
    .line 761
    .line 762
    iget-object v3, v9, Landroidx/recyclerview/widget/l;->i:Ljava/util/ArrayList;

    .line 763
    .line 764
    invoke-virtual {v3, v10}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 765
    .line 766
    .line 767
    const/4 v3, 0x1

    .line 768
    :goto_15
    if-eqz v3, :cond_28

    .line 769
    .line 770
    invoke-virtual {v6}, Landroidx/recyclerview/widget/RecyclerView;->Q()V

    .line 771
    .line 772
    .line 773
    :cond_28
    :goto_16
    const/4 v3, 0x0

    .line 774
    iput v3, v4, Landroidx/recyclerview/widget/s1;->a:I

    .line 775
    .line 776
    const/4 v3, 0x0

    .line 777
    iput-object v3, v4, Landroidx/recyclerview/widget/s1;->b:Landroidx/recyclerview/widget/n0;

    .line 778
    .line 779
    iput-object v3, v4, Landroidx/recyclerview/widget/s1;->c:Landroidx/recyclerview/widget/n0;

    .line 780
    .line 781
    sget-object v3, Landroidx/recyclerview/widget/s1;->d:Lf/b;

    .line 782
    .line 783
    invoke-virtual {v3, v4}, Lf/b;->b(Ljava/lang/Object;)V

    .line 784
    .line 785
    .line 786
    add-int/lit8 v2, v2, -0x1

    .line 787
    .line 788
    const/4 v3, 0x0

    .line 789
    goto/16 :goto_b

    .line 790
    .line 791
    :cond_29
    const/4 v2, 0x0

    .line 792
    iget-object v3, v0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 793
    .line 794
    invoke-virtual {v3, v7}, Landroidx/recyclerview/widget/t0;->d0(Landroidx/recyclerview/widget/a1;)V

    .line 795
    .line 796
    .line 797
    iget v3, v1, Landroidx/recyclerview/widget/e1;->d:I

    .line 798
    .line 799
    iput v3, v1, Landroidx/recyclerview/widget/e1;->a:I

    .line 800
    .line 801
    const/4 v3, 0x0

    .line 802
    iput-boolean v3, v0, Landroidx/recyclerview/widget/RecyclerView;->C:Z

    .line 803
    .line 804
    iput-boolean v3, v0, Landroidx/recyclerview/widget/RecyclerView;->D:Z

    .line 805
    .line 806
    iput-boolean v3, v1, Landroidx/recyclerview/widget/e1;->i:Z

    .line 807
    .line 808
    iput-boolean v3, v1, Landroidx/recyclerview/widget/e1;->j:Z

    .line 809
    .line 810
    iget-object v4, v0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 811
    .line 812
    iput-boolean v3, v4, Landroidx/recyclerview/widget/t0;->e:Z

    .line 813
    .line 814
    iget-object v4, v7, Landroidx/recyclerview/widget/a1;->b:Ljava/util/ArrayList;

    .line 815
    .line 816
    if-eqz v4, :cond_2a

    .line 817
    .line 818
    invoke-virtual {v4}, Ljava/util/ArrayList;->clear()V

    .line 819
    .line 820
    .line 821
    :cond_2a
    iget-object v4, v0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 822
    .line 823
    iget-boolean v5, v4, Landroidx/recyclerview/widget/t0;->j:Z

    .line 824
    .line 825
    if-eqz v5, :cond_2b

    .line 826
    .line 827
    iput v3, v4, Landroidx/recyclerview/widget/t0;->i:I

    .line 828
    .line 829
    iput-boolean v3, v4, Landroidx/recyclerview/widget/t0;->j:Z

    .line 830
    .line 831
    invoke-virtual {v7}, Landroidx/recyclerview/widget/a1;->m()V

    .line 832
    .line 833
    .line 834
    :cond_2b
    iget-object v4, v0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 835
    .line 836
    invoke-virtual {v4, v1}, Landroidx/recyclerview/widget/t0;->Y(Landroidx/recyclerview/widget/e1;)V

    .line 837
    .line 838
    .line 839
    const/4 v4, 0x1

    .line 840
    invoke-virtual {v0, v4}, Landroidx/recyclerview/widget/RecyclerView;->O(Z)V

    .line 841
    .line 842
    .line 843
    invoke-virtual {v0, v3}, Landroidx/recyclerview/widget/RecyclerView;->e0(Z)V

    .line 844
    .line 845
    .line 846
    invoke-virtual {v8}, Landroidx/recyclerview/widget/t1;->e()V

    .line 847
    .line 848
    .line 849
    iget-object v5, v0, Landroidx/recyclerview/widget/RecyclerView;->n0:[I

    .line 850
    .line 851
    aget v6, v5, v3

    .line 852
    .line 853
    aget v7, v5, v4

    .line 854
    .line 855
    invoke-virtual {v0, v5}, Landroidx/recyclerview/widget/RecyclerView;->C([I)V

    .line 856
    .line 857
    .line 858
    aget v8, v5, v3

    .line 859
    .line 860
    if-ne v8, v6, :cond_2d

    .line 861
    .line 862
    aget v4, v5, v4

    .line 863
    .line 864
    if-eq v4, v7, :cond_2c

    .line 865
    .line 866
    goto :goto_17

    .line 867
    :cond_2c
    const/4 v4, 0x0

    .line 868
    goto :goto_18

    .line 869
    :cond_2d
    :goto_17
    const/4 v4, 0x1

    .line 870
    :goto_18
    if-eqz v4, :cond_2e

    .line 871
    .line 872
    invoke-virtual {v0, v3, v3}, Landroidx/recyclerview/widget/RecyclerView;->t(II)V

    .line 873
    .line 874
    .line 875
    :cond_2e
    iget-boolean v3, v0, Landroidx/recyclerview/widget/RecyclerView;->b0:Z

    .line 876
    .line 877
    const-wide/16 v4, -0x1

    .line 878
    .line 879
    if-eqz v3, :cond_41

    .line 880
    .line 881
    iget-object v3, v0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 882
    .line 883
    if-eqz v3, :cond_41

    .line 884
    .line 885
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->hasFocus()Z

    .line 886
    .line 887
    .line 888
    move-result v3

    .line 889
    if-eqz v3, :cond_41

    .line 890
    .line 891
    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getDescendantFocusability()I

    .line 892
    .line 893
    .line 894
    move-result v3

    .line 895
    const/high16 v6, 0x60000

    .line 896
    .line 897
    if-eq v3, v6, :cond_41

    .line 898
    .line 899
    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getDescendantFocusability()I

    .line 900
    .line 901
    .line 902
    move-result v3

    .line 903
    const/high16 v6, 0x20000

    .line 904
    .line 905
    if-ne v3, v6, :cond_2f

    .line 906
    .line 907
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->isFocused()Z

    .line 908
    .line 909
    .line 910
    move-result v3

    .line 911
    if-eqz v3, :cond_2f

    .line 912
    .line 913
    goto/16 :goto_21

    .line 914
    .line 915
    :cond_2f
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->isFocused()Z

    .line 916
    .line 917
    .line 918
    move-result v3

    .line 919
    if-nez v3, :cond_30

    .line 920
    .line 921
    invoke-virtual/range {p0 .. p0}, Landroid/view/ViewGroup;->getFocusedChild()Landroid/view/View;

    .line 922
    .line 923
    .line 924
    move-result-object v3

    .line 925
    iget-object v6, v0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 926
    .line 927
    invoke-virtual {v6, v3}, Landroidx/recyclerview/widget/e;->j(Landroid/view/View;)Z

    .line 928
    .line 929
    .line 930
    move-result v3

    .line 931
    if-nez v3, :cond_30

    .line 932
    .line 933
    goto/16 :goto_21

    .line 934
    .line 935
    :cond_30
    iget-wide v6, v1, Landroidx/recyclerview/widget/e1;->l:J

    .line 936
    .line 937
    cmp-long v3, v6, v4

    .line 938
    .line 939
    if-eqz v3, :cond_35

    .line 940
    .line 941
    iget-object v3, v0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 942
    .line 943
    invoke-virtual {v3}, Landroidx/recyclerview/widget/i0;->hasStableIds()Z

    .line 944
    .line 945
    .line 946
    move-result v3

    .line 947
    if-eqz v3, :cond_35

    .line 948
    .line 949
    iget-wide v6, v1, Landroidx/recyclerview/widget/e1;->l:J

    .line 950
    .line 951
    iget-object v3, v0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 952
    .line 953
    if-eqz v3, :cond_33

    .line 954
    .line 955
    invoke-virtual {v3}, Landroidx/recyclerview/widget/i0;->hasStableIds()Z

    .line 956
    .line 957
    .line 958
    move-result v3

    .line 959
    if-nez v3, :cond_31

    .line 960
    .line 961
    goto :goto_1a

    .line 962
    :cond_31
    iget-object v3, v0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 963
    .line 964
    invoke-virtual {v3}, Landroidx/recyclerview/widget/e;->h()I

    .line 965
    .line 966
    .line 967
    move-result v3

    .line 968
    const/4 v8, 0x0

    .line 969
    move-object v9, v2

    .line 970
    :goto_19
    if-ge v8, v3, :cond_34

    .line 971
    .line 972
    iget-object v10, v0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 973
    .line 974
    invoke-virtual {v10, v8}, Landroidx/recyclerview/widget/e;->g(I)Landroid/view/View;

    .line 975
    .line 976
    .line 977
    move-result-object v10

    .line 978
    invoke-static {v10}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 979
    .line 980
    .line 981
    move-result-object v10

    .line 982
    if-eqz v10, :cond_32

    .line 983
    .line 984
    invoke-virtual {v10}, Landroidx/recyclerview/widget/i1;->isRemoved()Z

    .line 985
    .line 986
    .line 987
    move-result v11

    .line 988
    if-nez v11, :cond_32

    .line 989
    .line 990
    invoke-virtual {v10}, Landroidx/recyclerview/widget/i1;->getItemId()J

    .line 991
    .line 992
    .line 993
    move-result-wide v11

    .line 994
    cmp-long v13, v11, v6

    .line 995
    .line 996
    if-nez v13, :cond_32

    .line 997
    .line 998
    iget-object v9, v0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 999
    .line 1000
    iget-object v11, v10, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 1001
    .line 1002
    invoke-virtual {v9, v11}, Landroidx/recyclerview/widget/e;->j(Landroid/view/View;)Z

    .line 1003
    .line 1004
    .line 1005
    move-result v9

    .line 1006
    if-eqz v9, :cond_36

    .line 1007
    .line 1008
    move-object v9, v10

    .line 1009
    :cond_32
    add-int/lit8 v8, v8, 0x1

    .line 1010
    .line 1011
    goto :goto_19

    .line 1012
    :cond_33
    :goto_1a
    move-object v9, v2

    .line 1013
    :cond_34
    move-object v10, v9

    .line 1014
    goto :goto_1b

    .line 1015
    :cond_35
    move-object v10, v2

    .line 1016
    :cond_36
    :goto_1b
    if-eqz v10, :cond_38

    .line 1017
    .line 1018
    iget-object v3, v0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 1019
    .line 1020
    iget-object v6, v10, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 1021
    .line 1022
    invoke-virtual {v3, v6}, Landroidx/recyclerview/widget/e;->j(Landroid/view/View;)Z

    .line 1023
    .line 1024
    .line 1025
    move-result v3

    .line 1026
    if-nez v3, :cond_38

    .line 1027
    .line 1028
    iget-object v3, v10, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 1029
    .line 1030
    invoke-virtual {v3}, Landroid/view/View;->hasFocusable()Z

    .line 1031
    .line 1032
    .line 1033
    move-result v3

    .line 1034
    if-nez v3, :cond_37

    .line 1035
    .line 1036
    goto :goto_1c

    .line 1037
    :cond_37
    iget-object v2, v10, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 1038
    .line 1039
    goto :goto_20

    .line 1040
    :cond_38
    :goto_1c
    iget-object v3, v0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 1041
    .line 1042
    invoke-virtual {v3}, Landroidx/recyclerview/widget/e;->e()I

    .line 1043
    .line 1044
    .line 1045
    move-result v3

    .line 1046
    if-lez v3, :cond_3f

    .line 1047
    .line 1048
    iget v3, v1, Landroidx/recyclerview/widget/e1;->k:I

    .line 1049
    .line 1050
    const/4 v6, -0x1

    .line 1051
    if-eq v3, v6, :cond_39

    .line 1052
    .line 1053
    goto :goto_1d

    .line 1054
    :cond_39
    const/4 v3, 0x0

    .line 1055
    :goto_1d
    invoke-virtual {v1}, Landroidx/recyclerview/widget/e1;->b()I

    .line 1056
    .line 1057
    .line 1058
    move-result v6

    .line 1059
    move v7, v3

    .line 1060
    :goto_1e
    if-ge v7, v6, :cond_3c

    .line 1061
    .line 1062
    invoke-virtual {v0, v7}, Landroidx/recyclerview/widget/RecyclerView;->E(I)Landroidx/recyclerview/widget/i1;

    .line 1063
    .line 1064
    .line 1065
    move-result-object v8

    .line 1066
    if-nez v8, :cond_3a

    .line 1067
    .line 1068
    goto :goto_1f

    .line 1069
    :cond_3a
    iget-object v9, v8, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 1070
    .line 1071
    invoke-virtual {v9}, Landroid/view/View;->hasFocusable()Z

    .line 1072
    .line 1073
    .line 1074
    move-result v9

    .line 1075
    if-eqz v9, :cond_3b

    .line 1076
    .line 1077
    iget-object v2, v8, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 1078
    .line 1079
    goto :goto_20

    .line 1080
    :cond_3b
    add-int/lit8 v7, v7, 0x1

    .line 1081
    .line 1082
    goto :goto_1e

    .line 1083
    :cond_3c
    :goto_1f
    invoke-static {v6, v3}, Ljava/lang/Math;->min(II)I

    .line 1084
    .line 1085
    .line 1086
    move-result v3

    .line 1087
    :cond_3d
    add-int/lit8 v3, v3, -0x1

    .line 1088
    .line 1089
    if-ltz v3, :cond_3f

    .line 1090
    .line 1091
    invoke-virtual {v0, v3}, Landroidx/recyclerview/widget/RecyclerView;->E(I)Landroidx/recyclerview/widget/i1;

    .line 1092
    .line 1093
    .line 1094
    move-result-object v6

    .line 1095
    if-nez v6, :cond_3e

    .line 1096
    .line 1097
    goto :goto_20

    .line 1098
    :cond_3e
    iget-object v7, v6, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 1099
    .line 1100
    invoke-virtual {v7}, Landroid/view/View;->hasFocusable()Z

    .line 1101
    .line 1102
    .line 1103
    move-result v7

    .line 1104
    if-eqz v7, :cond_3d

    .line 1105
    .line 1106
    iget-object v2, v6, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 1107
    .line 1108
    :cond_3f
    :goto_20
    if-eqz v2, :cond_41

    .line 1109
    .line 1110
    iget v3, v1, Landroidx/recyclerview/widget/e1;->m:I

    .line 1111
    .line 1112
    int-to-long v6, v3

    .line 1113
    cmp-long v8, v6, v4

    .line 1114
    .line 1115
    if-eqz v8, :cond_40

    .line 1116
    .line 1117
    invoke-virtual {v2, v3}, Landroid/view/View;->findViewById(I)Landroid/view/View;

    .line 1118
    .line 1119
    .line 1120
    move-result-object v3

    .line 1121
    if-eqz v3, :cond_40

    .line 1122
    .line 1123
    invoke-virtual {v3}, Landroid/view/View;->isFocusable()Z

    .line 1124
    .line 1125
    .line 1126
    move-result v6

    .line 1127
    if-eqz v6, :cond_40

    .line 1128
    .line 1129
    move-object v2, v3

    .line 1130
    :cond_40
    invoke-virtual {v2}, Landroid/view/View;->requestFocus()Z

    .line 1131
    .line 1132
    .line 1133
    :cond_41
    :goto_21
    iput-wide v4, v1, Landroidx/recyclerview/widget/e1;->l:J

    .line 1134
    .line 1135
    const/4 v2, -0x1

    .line 1136
    iput v2, v1, Landroidx/recyclerview/widget/e1;->k:I

    .line 1137
    .line 1138
    iput v2, v1, Landroidx/recyclerview/widget/e1;->m:I

    .line 1139
    .line 1140
    return-void
.end method

.method public final onAttachedToWindow()V
    .locals 5

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->onAttachedToWindow()V

    .line 2
    .line 3
    .line 4
    const/4 v0, 0x0

    .line 5
    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView;->E:I

    .line 6
    .line 7
    const/4 v1, 0x1

    .line 8
    iput-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView;->s:Z

    .line 9
    .line 10
    iget-boolean v2, p0, Landroidx/recyclerview/widget/RecyclerView;->u:Z

    .line 11
    .line 12
    if-eqz v2, :cond_0

    .line 13
    .line 14
    invoke-virtual {p0}, Landroid/view/View;->isLayoutRequested()Z

    .line 15
    .line 16
    .line 17
    move-result v2

    .line 18
    if-nez v2, :cond_0

    .line 19
    .line 20
    const/4 v2, 0x1

    .line 21
    goto :goto_0

    .line 22
    :cond_0
    const/4 v2, 0x0

    .line 23
    :goto_0
    iput-boolean v2, p0, Landroidx/recyclerview/widget/RecyclerView;->u:Z

    .line 24
    .line 25
    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 26
    .line 27
    invoke-virtual {v2}, Landroidx/recyclerview/widget/a1;->d()V

    .line 28
    .line 29
    .line 30
    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 31
    .line 32
    if-eqz v2, :cond_1

    .line 33
    .line 34
    iput-boolean v1, v2, Landroidx/recyclerview/widget/t0;->f:Z

    .line 35
    .line 36
    :cond_1
    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->l0:Z

    .line 37
    .line 38
    sget-boolean v0, Landroidx/recyclerview/widget/RecyclerView;->E0:Z

    .line 39
    .line 40
    if-eqz v0, :cond_6

    .line 41
    .line 42
    sget-object v0, Landroidx/recyclerview/widget/u;->e:Ljava/lang/ThreadLocal;

    .line 43
    .line 44
    invoke-virtual {v0}, Ljava/lang/ThreadLocal;->get()Ljava/lang/Object;

    .line 45
    .line 46
    .line 47
    move-result-object v1

    .line 48
    check-cast v1, Landroidx/recyclerview/widget/u;

    .line 49
    .line 50
    iput-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->d0:Landroidx/recyclerview/widget/u;

    .line 51
    .line 52
    if-nez v1, :cond_3

    .line 53
    .line 54
    new-instance v1, Landroidx/recyclerview/widget/u;

    .line 55
    .line 56
    invoke-direct {v1}, Landroidx/recyclerview/widget/u;-><init>()V

    .line 57
    .line 58
    .line 59
    iput-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->d0:Landroidx/recyclerview/widget/u;

    .line 60
    .line 61
    sget-object v1, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 62
    .line 63
    invoke-static {p0}, Lg/k;->b(Landroid/view/View;)Landroid/view/Display;

    .line 64
    .line 65
    .line 66
    move-result-object v1

    .line 67
    invoke-virtual {p0}, Landroid/view/View;->isInEditMode()Z

    .line 68
    .line 69
    .line 70
    move-result v2

    .line 71
    if-nez v2, :cond_2

    .line 72
    .line 73
    if-eqz v1, :cond_2

    .line 74
    .line 75
    invoke-virtual {v1}, Landroid/view/Display;->getRefreshRate()F

    .line 76
    .line 77
    .line 78
    move-result v1

    .line 79
    const/high16 v2, 0x41f00000    # 30.0f

    .line 80
    .line 81
    cmpl-float v2, v1, v2

    .line 82
    .line 83
    if-ltz v2, :cond_2

    .line 84
    .line 85
    goto :goto_1

    .line 86
    :cond_2
    const/high16 v1, 0x42700000    # 60.0f

    .line 87
    .line 88
    :goto_1
    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView;->d0:Landroidx/recyclerview/widget/u;

    .line 89
    .line 90
    const v3, 0x4e6e6b28    # 1.0E9f

    .line 91
    .line 92
    .line 93
    div-float/2addr v3, v1

    .line 94
    float-to-long v3, v3

    .line 95
    iput-wide v3, v2, Landroidx/recyclerview/widget/u;->c:J

    .line 96
    .line 97
    invoke-virtual {v0, v2}, Ljava/lang/ThreadLocal;->set(Ljava/lang/Object;)V

    .line 98
    .line 99
    .line 100
    :cond_3
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->d0:Landroidx/recyclerview/widget/u;

    .line 101
    .line 102
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 103
    .line 104
    .line 105
    sget-boolean v1, Landroidx/recyclerview/widget/RecyclerView;->y0:Z

    .line 106
    .line 107
    iget-object v0, v0, Landroidx/recyclerview/widget/u;->a:Ljava/util/ArrayList;

    .line 108
    .line 109
    if-eqz v1, :cond_5

    .line 110
    .line 111
    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 112
    .line 113
    .line 114
    move-result v1

    .line 115
    if-nez v1, :cond_4

    .line 116
    .line 117
    goto :goto_2

    .line 118
    :cond_4
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 119
    .line 120
    const-string v1, "RecyclerView already present in worker list!"

    .line 121
    .line 122
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 123
    .line 124
    .line 125
    throw v0

    .line 126
    :cond_5
    :goto_2
    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 127
    .line 128
    .line 129
    :cond_6
    return-void
.end method

.method public final onDetachedFromWindow()V
    .locals 5

    .line 1
    invoke-super {p0}, Landroid/view/ViewGroup;->onDetachedFromWindow()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 5
    .line 6
    if-eqz v0, :cond_0

    .line 7
    .line 8
    invoke-virtual {v0}, Landroidx/recyclerview/widget/o0;->e()V

    .line 9
    .line 10
    .line 11
    :cond_0
    const/4 v0, 0x0

    .line 12
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView;->setScrollState(I)V

    .line 13
    .line 14
    .line 15
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->c0:Landroidx/recyclerview/widget/h1;

    .line 16
    .line 17
    iget-object v2, v1, Landroidx/recyclerview/widget/h1;->g:Landroidx/recyclerview/widget/RecyclerView;

    .line 18
    .line 19
    invoke-virtual {v2, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 20
    .line 21
    .line 22
    iget-object v1, v1, Landroidx/recyclerview/widget/h1;->c:Landroid/widget/OverScroller;

    .line 23
    .line 24
    invoke-virtual {v1}, Landroid/widget/OverScroller;->abortAnimation()V

    .line 25
    .line 26
    .line 27
    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->s:Z

    .line 28
    .line 29
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 30
    .line 31
    if-eqz v1, :cond_1

    .line 32
    .line 33
    iput-boolean v0, v1, Landroidx/recyclerview/widget/t0;->f:Z

    .line 34
    .line 35
    invoke-virtual {v1, p0}, Landroidx/recyclerview/widget/t0;->M(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 36
    .line 37
    .line 38
    :cond_1
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->s0:Ljava/util/ArrayList;

    .line 39
    .line 40
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 41
    .line 42
    .line 43
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->t0:Landroidx/recyclerview/widget/f0;

    .line 44
    .line 45
    invoke-virtual {p0, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 46
    .line 47
    .line 48
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->g:Landroidx/recyclerview/widget/t1;

    .line 49
    .line 50
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 51
    .line 52
    .line 53
    :goto_0
    sget-object v1, Landroidx/recyclerview/widget/s1;->d:Lf/b;

    .line 54
    .line 55
    invoke-virtual {v1}, Lf/b;->a()Ljava/lang/Object;

    .line 56
    .line 57
    .line 58
    move-result-object v1

    .line 59
    if-eqz v1, :cond_2

    .line 60
    .line 61
    goto :goto_0

    .line 62
    :cond_2
    const/4 v1, 0x0

    .line 63
    :goto_1
    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 64
    .line 65
    iget-object v3, v2, Landroidx/recyclerview/widget/a1;->c:Ljava/util/ArrayList;

    .line 66
    .line 67
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 68
    .line 69
    .line 70
    move-result v4

    .line 71
    if-ge v1, v4, :cond_3

    .line 72
    .line 73
    invoke-virtual {v3, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 74
    .line 75
    .line 76
    move-result-object v2

    .line 77
    check-cast v2, Landroidx/recyclerview/widget/i1;

    .line 78
    .line 79
    iget-object v2, v2, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 80
    .line 81
    invoke-static {v2}, Lb0/d;->g(Landroid/view/View;)V

    .line 82
    .line 83
    .line 84
    add-int/lit8 v1, v1, 0x1

    .line 85
    .line 86
    goto :goto_1

    .line 87
    :cond_3
    iget-object v1, v2, Landroidx/recyclerview/widget/a1;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 88
    .line 89
    iget-object v1, v1, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 90
    .line 91
    invoke-virtual {v2, v1, v0}, Landroidx/recyclerview/widget/a1;->e(Landroidx/recyclerview/widget/i0;Z)V

    .line 92
    .line 93
    .line 94
    new-instance v1, Lg/z;

    .line 95
    .line 96
    invoke-direct {v1, v0, p0}, Lg/z;-><init>(ILjava/lang/Object;)V

    .line 97
    .line 98
    .line 99
    :goto_2
    invoke-virtual {v1}, Lg/z;->hasNext()Z

    .line 100
    .line 101
    .line 102
    move-result v0

    .line 103
    const/4 v2, 0x0

    .line 104
    if-eqz v0, :cond_6

    .line 105
    .line 106
    invoke-virtual {v1}, Lg/z;->next()Ljava/lang/Object;

    .line 107
    .line 108
    .line 109
    move-result-object v0

    .line 110
    check-cast v0, Landroid/view/View;

    .line 111
    .line 112
    const v3, 0x7f050054

    .line 113
    .line 114
    .line 115
    invoke-virtual {v0, v3}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 116
    .line 117
    .line 118
    move-result-object v4

    .line 119
    check-cast v4, Lj/a;

    .line 120
    .line 121
    if-nez v4, :cond_4

    .line 122
    .line 123
    new-instance v4, Lj/a;

    .line 124
    .line 125
    invoke-direct {v4}, Lj/a;-><init>()V

    .line 126
    .line 127
    .line 128
    invoke-virtual {v0, v3, v4}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 129
    .line 130
    .line 131
    :cond_4
    iget-object v0, v4, Lj/a;->a:Ljava/util/ArrayList;

    .line 132
    .line 133
    invoke-static {v0}, Lb0/d;->x(Ljava/util/List;)I

    .line 134
    .line 135
    .line 136
    move-result v3

    .line 137
    const/4 v4, -0x1

    .line 138
    if-lt v4, v3, :cond_5

    .line 139
    .line 140
    goto :goto_2

    .line 141
    :cond_5
    invoke-virtual {v0, v3}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 142
    .line 143
    .line 144
    move-result-object v0

    .line 145
    invoke-static {v0}, Landroidx/recyclerview/widget/c;->c(Ljava/lang/Object;)V

    .line 146
    .line 147
    .line 148
    throw v2

    .line 149
    :cond_6
    sget-boolean v0, Landroidx/recyclerview/widget/RecyclerView;->E0:Z

    .line 150
    .line 151
    if-eqz v0, :cond_9

    .line 152
    .line 153
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->d0:Landroidx/recyclerview/widget/u;

    .line 154
    .line 155
    if-eqz v0, :cond_9

    .line 156
    .line 157
    iget-object v0, v0, Landroidx/recyclerview/widget/u;->a:Ljava/util/ArrayList;

    .line 158
    .line 159
    invoke-virtual {v0, p0}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    .line 160
    .line 161
    .line 162
    move-result v0

    .line 163
    sget-boolean v1, Landroidx/recyclerview/widget/RecyclerView;->y0:Z

    .line 164
    .line 165
    if-eqz v1, :cond_8

    .line 166
    .line 167
    if-eqz v0, :cond_7

    .line 168
    .line 169
    goto :goto_3

    .line 170
    :cond_7
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 171
    .line 172
    const-string v1, "RecyclerView removal failed!"

    .line 173
    .line 174
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 175
    .line 176
    .line 177
    throw v0

    .line 178
    :cond_8
    :goto_3
    iput-object v2, p0, Landroidx/recyclerview/widget/RecyclerView;->d0:Landroidx/recyclerview/widget/u;

    .line 179
    .line 180
    :cond_9
    return-void
.end method

.method public final onDraw(Landroid/graphics/Canvas;)V
    .locals 3

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onDraw(Landroid/graphics/Canvas;)V

    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->p:Ljava/util/ArrayList;

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result v0

    const/4 v1, 0x0

    :goto_0
    if-ge v1, v0, :cond_0

    invoke-virtual {p1, v1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/recyclerview/widget/q0;

    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    add-int/lit8 v1, v1, 0x1

    goto :goto_0

    :cond_0
    return-void
.end method

.method public final onGenericMotionEvent(Landroid/view/MotionEvent;)Z
    .locals 15

    .line 1
    move-object v6, p0

    .line 2
    move-object/from16 v7, p1

    .line 3
    .line 4
    iget-object v0, v6, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 5
    .line 6
    const/4 v8, 0x0

    .line 7
    if-nez v0, :cond_0

    .line 8
    .line 9
    return v8

    .line 10
    :cond_0
    iget-boolean v0, v6, Landroidx/recyclerview/widget/RecyclerView;->x:Z

    .line 11
    .line 12
    if-eqz v0, :cond_1

    .line 13
    .line 14
    return v8

    .line 15
    :cond_1
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getAction()I

    .line 16
    .line 17
    .line 18
    move-result v0

    .line 19
    const/16 v1, 0x8

    .line 20
    .line 21
    if-ne v0, v1, :cond_12

    .line 22
    .line 23
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getSource()I

    .line 24
    .line 25
    .line 26
    move-result v0

    .line 27
    and-int/lit8 v0, v0, 0x2

    .line 28
    .line 29
    const/4 v1, 0x0

    .line 30
    if-eqz v0, :cond_3

    .line 31
    .line 32
    iget-object v0, v6, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 33
    .line 34
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->d()Z

    .line 35
    .line 36
    .line 37
    move-result v0

    .line 38
    if-eqz v0, :cond_2

    .line 39
    .line 40
    const/16 v0, 0x9

    .line 41
    .line 42
    invoke-virtual {v7, v0}, Landroid/view/MotionEvent;->getAxisValue(I)F

    .line 43
    .line 44
    .line 45
    move-result v0

    .line 46
    neg-float v0, v0

    .line 47
    goto :goto_0

    .line 48
    :cond_2
    const/4 v0, 0x0

    .line 49
    :goto_0
    iget-object v2, v6, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 50
    .line 51
    invoke-virtual {v2}, Landroidx/recyclerview/widget/t0;->c()Z

    .line 52
    .line 53
    .line 54
    move-result v2

    .line 55
    if-eqz v2, :cond_6

    .line 56
    .line 57
    const/16 v2, 0xa

    .line 58
    .line 59
    invoke-virtual {v7, v2}, Landroid/view/MotionEvent;->getAxisValue(I)F

    .line 60
    .line 61
    .line 62
    move-result v2

    .line 63
    goto :goto_2

    .line 64
    :cond_3
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getSource()I

    .line 65
    .line 66
    .line 67
    move-result v0

    .line 68
    const/high16 v2, 0x400000

    .line 69
    .line 70
    and-int/2addr v0, v2

    .line 71
    if-eqz v0, :cond_5

    .line 72
    .line 73
    const/16 v0, 0x1a

    .line 74
    .line 75
    invoke-virtual {v7, v0}, Landroid/view/MotionEvent;->getAxisValue(I)F

    .line 76
    .line 77
    .line 78
    move-result v2

    .line 79
    iget-object v0, v6, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 80
    .line 81
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->d()Z

    .line 82
    .line 83
    .line 84
    move-result v0

    .line 85
    if-eqz v0, :cond_4

    .line 86
    .line 87
    neg-float v0, v2

    .line 88
    goto :goto_1

    .line 89
    :cond_4
    iget-object v0, v6, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 90
    .line 91
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->c()Z

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    if-eqz v0, :cond_5

    .line 96
    .line 97
    const/4 v0, 0x0

    .line 98
    goto :goto_2

    .line 99
    :cond_5
    const/4 v0, 0x0

    .line 100
    :cond_6
    :goto_1
    const/4 v2, 0x0

    .line 101
    :goto_2
    cmpl-float v3, v0, v1

    .line 102
    .line 103
    if-nez v3, :cond_7

    .line 104
    .line 105
    cmpl-float v1, v2, v1

    .line 106
    .line 107
    if-eqz v1, :cond_12

    .line 108
    .line 109
    :cond_7
    iget v1, v6, Landroidx/recyclerview/widget/RecyclerView;->W:F

    .line 110
    .line 111
    mul-float v2, v2, v1

    .line 112
    .line 113
    float-to-int v1, v2

    .line 114
    iget v2, v6, Landroidx/recyclerview/widget/RecyclerView;->a0:F

    .line 115
    .line 116
    mul-float v0, v0, v2

    .line 117
    .line 118
    float-to-int v0, v0

    .line 119
    iget-object v2, v6, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 120
    .line 121
    if-nez v2, :cond_8

    .line 122
    .line 123
    const-string v0, "RecyclerView"

    .line 124
    .line 125
    const-string v1, "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument."

    .line 126
    .line 127
    invoke-static {v0, v1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 128
    .line 129
    .line 130
    goto/16 :goto_8

    .line 131
    .line 132
    :cond_8
    iget-boolean v3, v6, Landroidx/recyclerview/widget/RecyclerView;->x:Z

    .line 133
    .line 134
    if-eqz v3, :cond_9

    .line 135
    .line 136
    goto/16 :goto_8

    .line 137
    .line 138
    :cond_9
    iget-object v9, v6, Landroidx/recyclerview/widget/RecyclerView;->r0:[I

    .line 139
    .line 140
    aput v8, v9, v8

    .line 141
    .line 142
    const/4 v10, 0x1

    .line 143
    aput v8, v9, v10

    .line 144
    .line 145
    invoke-virtual {v2}, Landroidx/recyclerview/widget/t0;->c()Z

    .line 146
    .line 147
    .line 148
    move-result v11

    .line 149
    iget-object v2, v6, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 150
    .line 151
    invoke-virtual {v2}, Landroidx/recyclerview/widget/t0;->d()Z

    .line 152
    .line 153
    .line 154
    move-result v12

    .line 155
    if-eqz v12, :cond_a

    .line 156
    .line 157
    or-int/lit8 v2, v11, 0x2

    .line 158
    .line 159
    goto :goto_3

    .line 160
    :cond_a
    move v2, v11

    .line 161
    :goto_3
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    .line 162
    .line 163
    .line 164
    move-result v3

    .line 165
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    .line 166
    .line 167
    .line 168
    move-result v4

    .line 169
    invoke-virtual {p0, v3, v1}, Landroidx/recyclerview/widget/RecyclerView;->U(FI)I

    .line 170
    .line 171
    .line 172
    move-result v3

    .line 173
    sub-int v13, v1, v3

    .line 174
    .line 175
    invoke-virtual {p0, v4, v0}, Landroidx/recyclerview/widget/RecyclerView;->V(FI)I

    .line 176
    .line 177
    .line 178
    move-result v1

    .line 179
    sub-int v14, v0, v1

    .line 180
    .line 181
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView;->getScrollingChildHelper()Lg/f;

    .line 182
    .line 183
    .line 184
    move-result-object v0

    .line 185
    invoke-virtual {v0, v2, v10}, Lg/f;->d(II)Z

    .line 186
    .line 187
    .line 188
    if-eqz v11, :cond_b

    .line 189
    .line 190
    move v1, v13

    .line 191
    goto :goto_4

    .line 192
    :cond_b
    const/4 v1, 0x0

    .line 193
    :goto_4
    if-eqz v12, :cond_c

    .line 194
    .line 195
    move v2, v14

    .line 196
    goto :goto_5

    .line 197
    :cond_c
    const/4 v2, 0x0

    .line 198
    :goto_5
    iget-object v3, v6, Landroidx/recyclerview/widget/RecyclerView;->r0:[I

    .line 199
    .line 200
    iget-object v4, v6, Landroidx/recyclerview/widget/RecyclerView;->p0:[I

    .line 201
    .line 202
    const/4 v5, 0x1

    .line 203
    move-object v0, p0

    .line 204
    invoke-virtual/range {v0 .. v5}, Landroidx/recyclerview/widget/RecyclerView;->r(II[I[II)Z

    .line 205
    .line 206
    .line 207
    move-result v0

    .line 208
    if-eqz v0, :cond_d

    .line 209
    .line 210
    aget v0, v9, v8

    .line 211
    .line 212
    sub-int/2addr v13, v0

    .line 213
    aget v0, v9, v10

    .line 214
    .line 215
    sub-int/2addr v14, v0

    .line 216
    :cond_d
    if-eqz v11, :cond_e

    .line 217
    .line 218
    move v0, v13

    .line 219
    goto :goto_6

    .line 220
    :cond_e
    const/4 v0, 0x0

    .line 221
    :goto_6
    if-eqz v12, :cond_f

    .line 222
    .line 223
    move v1, v14

    .line 224
    goto :goto_7

    .line 225
    :cond_f
    const/4 v1, 0x0

    .line 226
    :goto_7
    invoke-virtual {p0, v0, v1, v7, v10}, Landroidx/recyclerview/widget/RecyclerView;->Y(IILandroid/view/MotionEvent;I)Z

    .line 227
    .line 228
    .line 229
    iget-object v0, v6, Landroidx/recyclerview/widget/RecyclerView;->d0:Landroidx/recyclerview/widget/u;

    .line 230
    .line 231
    if-eqz v0, :cond_11

    .line 232
    .line 233
    if-nez v13, :cond_10

    .line 234
    .line 235
    if-eqz v14, :cond_11

    .line 236
    .line 237
    :cond_10
    invoke-virtual {v0, p0, v13, v14}, Landroidx/recyclerview/widget/u;->a(Landroidx/recyclerview/widget/RecyclerView;II)V

    .line 238
    .line 239
    .line 240
    :cond_11
    invoke-virtual {p0, v10}, Landroidx/recyclerview/widget/RecyclerView;->f0(I)V

    .line 241
    .line 242
    .line 243
    :cond_12
    :goto_8
    return v8
.end method

.method public final onInterceptTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 11

    .line 1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->x:Z

    .line 2
    .line 3
    const/4 v1, 0x0

    .line 4
    if-eqz v0, :cond_0

    .line 5
    .line 6
    return v1

    .line 7
    :cond_0
    const/4 v0, 0x0

    .line 8
    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->r:Landroidx/recyclerview/widget/w0;

    .line 9
    .line 10
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView;->B(Landroid/view/MotionEvent;)Z

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    const/4 v2, 0x1

    .line 15
    if-eqz v0, :cond_1

    .line 16
    .line 17
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->X()V

    .line 18
    .line 19
    .line 20
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setScrollState(I)V

    .line 21
    .line 22
    .line 23
    return v2

    .line 24
    :cond_1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 25
    .line 26
    if-nez v0, :cond_2

    .line 27
    .line 28
    return v1

    .line 29
    :cond_2
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->c()Z

    .line 30
    .line 31
    .line 32
    move-result v0

    .line 33
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 34
    .line 35
    invoke-virtual {v3}, Landroidx/recyclerview/widget/t0;->d()Z

    .line 36
    .line 37
    .line 38
    move-result v3

    .line 39
    iget-object v4, p0, Landroidx/recyclerview/widget/RecyclerView;->O:Landroid/view/VelocityTracker;

    .line 40
    .line 41
    if-nez v4, :cond_3

    .line 42
    .line 43
    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    .line 44
    .line 45
    .line 46
    move-result-object v4

    .line 47
    iput-object v4, p0, Landroidx/recyclerview/widget/RecyclerView;->O:Landroid/view/VelocityTracker;

    .line 48
    .line 49
    :cond_3
    iget-object v4, p0, Landroidx/recyclerview/widget/RecyclerView;->O:Landroid/view/VelocityTracker;

    .line 50
    .line 51
    invoke-virtual {v4, p1}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 52
    .line 53
    .line 54
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 55
    .line 56
    .line 57
    move-result v4

    .line 58
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getActionIndex()I

    .line 59
    .line 60
    .line 61
    move-result v5

    .line 62
    const/4 v6, 0x2

    .line 63
    const/high16 v7, 0x3f000000    # 0.5f

    .line 64
    .line 65
    if-eqz v4, :cond_c

    .line 66
    .line 67
    if-eq v4, v2, :cond_b

    .line 68
    .line 69
    if-eq v4, v6, :cond_7

    .line 70
    .line 71
    const/4 v0, 0x3

    .line 72
    if-eq v4, v0, :cond_6

    .line 73
    .line 74
    const/4 v0, 0x5

    .line 75
    if-eq v4, v0, :cond_5

    .line 76
    .line 77
    const/4 v0, 0x6

    .line 78
    if-eq v4, v0, :cond_4

    .line 79
    .line 80
    goto/16 :goto_2

    .line 81
    .line 82
    :cond_4
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView;->P(Landroid/view/MotionEvent;)V

    .line 83
    .line 84
    .line 85
    goto/16 :goto_2

    .line 86
    .line 87
    :cond_5
    invoke-virtual {p1, v5}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 88
    .line 89
    .line 90
    move-result v0

    .line 91
    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView;->N:I

    .line 92
    .line 93
    invoke-virtual {p1, v5}, Landroid/view/MotionEvent;->getX(I)F

    .line 94
    .line 95
    .line 96
    move-result v0

    .line 97
    add-float/2addr v0, v7

    .line 98
    float-to-int v0, v0

    .line 99
    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView;->R:I

    .line 100
    .line 101
    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView;->P:I

    .line 102
    .line 103
    invoke-virtual {p1, v5}, Landroid/view/MotionEvent;->getY(I)F

    .line 104
    .line 105
    .line 106
    move-result p1

    .line 107
    add-float/2addr p1, v7

    .line 108
    float-to-int p1, p1

    .line 109
    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView;->S:I

    .line 110
    .line 111
    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView;->Q:I

    .line 112
    .line 113
    goto/16 :goto_2

    .line 114
    .line 115
    :cond_6
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->X()V

    .line 116
    .line 117
    .line 118
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setScrollState(I)V

    .line 119
    .line 120
    .line 121
    goto/16 :goto_2

    .line 122
    .line 123
    :cond_7
    iget v4, p0, Landroidx/recyclerview/widget/RecyclerView;->N:I

    .line 124
    .line 125
    invoke-virtual {p1, v4}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 126
    .line 127
    .line 128
    move-result v4

    .line 129
    if-gez v4, :cond_8

    .line 130
    .line 131
    new-instance p1, Ljava/lang/StringBuilder;

    .line 132
    .line 133
    const-string v0, "Error processing scroll; pointer index for id "

    .line 134
    .line 135
    invoke-direct {p1, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 136
    .line 137
    .line 138
    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView;->N:I

    .line 139
    .line 140
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 141
    .line 142
    .line 143
    const-string v0, " not found. Did any MotionEvents get skipped?"

    .line 144
    .line 145
    invoke-virtual {p1, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 146
    .line 147
    .line 148
    invoke-virtual {p1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 149
    .line 150
    .line 151
    move-result-object p1

    .line 152
    const-string v0, "RecyclerView"

    .line 153
    .line 154
    invoke-static {v0, p1}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 155
    .line 156
    .line 157
    return v1

    .line 158
    :cond_8
    invoke-virtual {p1, v4}, Landroid/view/MotionEvent;->getX(I)F

    .line 159
    .line 160
    .line 161
    move-result v5

    .line 162
    add-float/2addr v5, v7

    .line 163
    float-to-int v5, v5

    .line 164
    invoke-virtual {p1, v4}, Landroid/view/MotionEvent;->getY(I)F

    .line 165
    .line 166
    .line 167
    move-result p1

    .line 168
    add-float/2addr p1, v7

    .line 169
    float-to-int p1, p1

    .line 170
    iget v4, p0, Landroidx/recyclerview/widget/RecyclerView;->M:I

    .line 171
    .line 172
    if-eq v4, v2, :cond_15

    .line 173
    .line 174
    iget v4, p0, Landroidx/recyclerview/widget/RecyclerView;->P:I

    .line 175
    .line 176
    sub-int v4, v5, v4

    .line 177
    .line 178
    iget v6, p0, Landroidx/recyclerview/widget/RecyclerView;->Q:I

    .line 179
    .line 180
    sub-int v6, p1, v6

    .line 181
    .line 182
    if-eqz v0, :cond_9

    .line 183
    .line 184
    invoke-static {v4}, Ljava/lang/Math;->abs(I)I

    .line 185
    .line 186
    .line 187
    move-result v0

    .line 188
    iget v4, p0, Landroidx/recyclerview/widget/RecyclerView;->T:I

    .line 189
    .line 190
    if-le v0, v4, :cond_9

    .line 191
    .line 192
    iput v5, p0, Landroidx/recyclerview/widget/RecyclerView;->R:I

    .line 193
    .line 194
    const/4 v0, 0x1

    .line 195
    goto :goto_0

    .line 196
    :cond_9
    const/4 v0, 0x0

    .line 197
    :goto_0
    if-eqz v3, :cond_a

    .line 198
    .line 199
    invoke-static {v6}, Ljava/lang/Math;->abs(I)I

    .line 200
    .line 201
    .line 202
    move-result v3

    .line 203
    iget v4, p0, Landroidx/recyclerview/widget/RecyclerView;->T:I

    .line 204
    .line 205
    if-le v3, v4, :cond_a

    .line 206
    .line 207
    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView;->S:I

    .line 208
    .line 209
    const/4 v0, 0x1

    .line 210
    :cond_a
    if-eqz v0, :cond_15

    .line 211
    .line 212
    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/RecyclerView;->setScrollState(I)V

    .line 213
    .line 214
    .line 215
    goto/16 :goto_2

    .line 216
    .line 217
    :cond_b
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->O:Landroid/view/VelocityTracker;

    .line 218
    .line 219
    invoke-virtual {p1}, Landroid/view/VelocityTracker;->clear()V

    .line 220
    .line 221
    .line 222
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView;->f0(I)V

    .line 223
    .line 224
    .line 225
    goto/16 :goto_2

    .line 226
    .line 227
    :cond_c
    iget-boolean v4, p0, Landroidx/recyclerview/widget/RecyclerView;->y:Z

    .line 228
    .line 229
    if-eqz v4, :cond_d

    .line 230
    .line 231
    iput-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView;->y:Z

    .line 232
    .line 233
    :cond_d
    invoke-virtual {p1, v1}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 234
    .line 235
    .line 236
    move-result v4

    .line 237
    iput v4, p0, Landroidx/recyclerview/widget/RecyclerView;->N:I

    .line 238
    .line 239
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 240
    .line 241
    .line 242
    move-result v4

    .line 243
    add-float/2addr v4, v7

    .line 244
    float-to-int v4, v4

    .line 245
    iput v4, p0, Landroidx/recyclerview/widget/RecyclerView;->R:I

    .line 246
    .line 247
    iput v4, p0, Landroidx/recyclerview/widget/RecyclerView;->P:I

    .line 248
    .line 249
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 250
    .line 251
    .line 252
    move-result v4

    .line 253
    add-float/2addr v4, v7

    .line 254
    float-to-int v4, v4

    .line 255
    iput v4, p0, Landroidx/recyclerview/widget/RecyclerView;->S:I

    .line 256
    .line 257
    iput v4, p0, Landroidx/recyclerview/widget/RecyclerView;->Q:I

    .line 258
    .line 259
    iget-object v4, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 260
    .line 261
    const/high16 v5, 0x3f800000    # 1.0f

    .line 262
    .line 263
    const/4 v7, -0x1

    .line 264
    const/4 v8, 0x0

    .line 265
    if-eqz v4, :cond_e

    .line 266
    .line 267
    invoke-static {v4}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    .line 268
    .line 269
    .line 270
    move-result v4

    .line 271
    cmpl-float v4, v4, v8

    .line 272
    .line 273
    if-eqz v4, :cond_e

    .line 274
    .line 275
    invoke-virtual {p0, v7}, Landroid/view/View;->canScrollHorizontally(I)Z

    .line 276
    .line 277
    .line 278
    move-result v4

    .line 279
    if-nez v4, :cond_e

    .line 280
    .line 281
    iget-object v4, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 282
    .line 283
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 284
    .line 285
    .line 286
    move-result v9

    .line 287
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 288
    .line 289
    .line 290
    move-result v10

    .line 291
    int-to-float v10, v10

    .line 292
    div-float/2addr v9, v10

    .line 293
    sub-float v9, v5, v9

    .line 294
    .line 295
    invoke-static {v4, v8, v9}, Lb0/d;->A(Landroid/widget/EdgeEffect;FF)F

    .line 296
    .line 297
    .line 298
    const/4 v4, 0x1

    .line 299
    goto :goto_1

    .line 300
    :cond_e
    const/4 v4, 0x0

    .line 301
    :goto_1
    iget-object v9, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 302
    .line 303
    if-eqz v9, :cond_f

    .line 304
    .line 305
    invoke-static {v9}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    .line 306
    .line 307
    .line 308
    move-result v9

    .line 309
    cmpl-float v9, v9, v8

    .line 310
    .line 311
    if-eqz v9, :cond_f

    .line 312
    .line 313
    invoke-virtual {p0, v2}, Landroid/view/View;->canScrollHorizontally(I)Z

    .line 314
    .line 315
    .line 316
    move-result v9

    .line 317
    if-nez v9, :cond_f

    .line 318
    .line 319
    iget-object v4, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 320
    .line 321
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getY()F

    .line 322
    .line 323
    .line 324
    move-result v9

    .line 325
    invoke-virtual {p0}, Landroid/view/View;->getHeight()I

    .line 326
    .line 327
    .line 328
    move-result v10

    .line 329
    int-to-float v10, v10

    .line 330
    div-float/2addr v9, v10

    .line 331
    invoke-static {v4, v8, v9}, Lb0/d;->A(Landroid/widget/EdgeEffect;FF)F

    .line 332
    .line 333
    .line 334
    const/4 v4, 0x1

    .line 335
    :cond_f
    iget-object v9, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 336
    .line 337
    if-eqz v9, :cond_10

    .line 338
    .line 339
    invoke-static {v9}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    .line 340
    .line 341
    .line 342
    move-result v9

    .line 343
    cmpl-float v9, v9, v8

    .line 344
    .line 345
    if-eqz v9, :cond_10

    .line 346
    .line 347
    invoke-virtual {p0, v7}, Landroid/view/View;->canScrollVertically(I)Z

    .line 348
    .line 349
    .line 350
    move-result v7

    .line 351
    if-nez v7, :cond_10

    .line 352
    .line 353
    iget-object v4, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 354
    .line 355
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 356
    .line 357
    .line 358
    move-result v7

    .line 359
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 360
    .line 361
    .line 362
    move-result v9

    .line 363
    int-to-float v9, v9

    .line 364
    div-float/2addr v7, v9

    .line 365
    invoke-static {v4, v8, v7}, Lb0/d;->A(Landroid/widget/EdgeEffect;FF)F

    .line 366
    .line 367
    .line 368
    const/4 v4, 0x1

    .line 369
    :cond_10
    iget-object v7, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 370
    .line 371
    if-eqz v7, :cond_11

    .line 372
    .line 373
    invoke-static {v7}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    .line 374
    .line 375
    .line 376
    move-result v7

    .line 377
    cmpl-float v7, v7, v8

    .line 378
    .line 379
    if-eqz v7, :cond_11

    .line 380
    .line 381
    invoke-virtual {p0, v2}, Landroid/view/View;->canScrollVertically(I)Z

    .line 382
    .line 383
    .line 384
    move-result v7

    .line 385
    if-nez v7, :cond_11

    .line 386
    .line 387
    iget-object v4, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 388
    .line 389
    invoke-virtual {p1}, Landroid/view/MotionEvent;->getX()F

    .line 390
    .line 391
    .line 392
    move-result p1

    .line 393
    invoke-virtual {p0}, Landroid/view/View;->getWidth()I

    .line 394
    .line 395
    .line 396
    move-result v7

    .line 397
    int-to-float v7, v7

    .line 398
    div-float/2addr p1, v7

    .line 399
    sub-float/2addr v5, p1

    .line 400
    invoke-static {v4, v8, v5}, Lb0/d;->A(Landroid/widget/EdgeEffect;FF)F

    .line 401
    .line 402
    .line 403
    const/4 v4, 0x1

    .line 404
    :cond_11
    if-nez v4, :cond_12

    .line 405
    .line 406
    iget p1, p0, Landroidx/recyclerview/widget/RecyclerView;->M:I

    .line 407
    .line 408
    if-ne p1, v6, :cond_13

    .line 409
    .line 410
    :cond_12
    invoke-virtual {p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 411
    .line 412
    .line 413
    move-result-object p1

    .line 414
    invoke-interface {p1, v2}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 415
    .line 416
    .line 417
    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/RecyclerView;->setScrollState(I)V

    .line 418
    .line 419
    .line 420
    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/RecyclerView;->f0(I)V

    .line 421
    .line 422
    .line 423
    :cond_13
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->q0:[I

    .line 424
    .line 425
    aput v1, p1, v2

    .line 426
    .line 427
    aput v1, p1, v1

    .line 428
    .line 429
    if-eqz v3, :cond_14

    .line 430
    .line 431
    or-int/lit8 v0, v0, 0x2

    .line 432
    .line 433
    :cond_14
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView;->getScrollingChildHelper()Lg/f;

    .line 434
    .line 435
    .line 436
    move-result-object p1

    .line 437
    invoke-virtual {p1, v0, v1}, Lg/f;->d(II)Z

    .line 438
    .line 439
    .line 440
    :cond_15
    :goto_2
    iget p1, p0, Landroidx/recyclerview/widget/RecyclerView;->M:I

    .line 441
    .line 442
    if-ne p1, v2, :cond_16

    .line 443
    .line 444
    const/4 v1, 0x1

    .line 445
    :cond_16
    return v1
.end method

.method public final onLayout(ZIIII)V
    .locals 0

    .line 1
    sget p1, Le/b;->a:I

    .line 2
    .line 3
    const-string p1, "RV OnLayout"

    .line 4
    .line 5
    invoke-static {p1}, Le/a;->a(Ljava/lang/String;)V

    .line 6
    .line 7
    .line 8
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->o()V

    .line 9
    .line 10
    .line 11
    invoke-static {}, Le/a;->b()V

    .line 12
    .line 13
    .line 14
    const/4 p1, 0x1

    .line 15
    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView;->u:Z

    .line 16
    .line 17
    return-void
.end method

.method public final onMeasure(II)V
    .locals 6

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView;->n(II)V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_0
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->G()Z

    .line 10
    .line 11
    .line 12
    move-result v0

    .line 13
    const/4 v1, 0x1

    .line 14
    const/4 v2, 0x0

    .line 15
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    .line 16
    .line 17
    if-eqz v0, :cond_6

    .line 18
    .line 19
    invoke-static {p1}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 20
    .line 21
    .line 22
    move-result v0

    .line 23
    invoke-static {p2}, Landroid/view/View$MeasureSpec;->getMode(I)I

    .line 24
    .line 25
    .line 26
    move-result v4

    .line 27
    iget-object v5, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 28
    .line 29
    iget-object v5, v5, Landroidx/recyclerview/widget/t0;->b:Landroidx/recyclerview/widget/RecyclerView;

    .line 30
    .line 31
    invoke-virtual {v5, p1, p2}, Landroidx/recyclerview/widget/RecyclerView;->n(II)V

    .line 32
    .line 33
    .line 34
    const/high16 v5, 0x40000000    # 2.0f

    .line 35
    .line 36
    if-ne v0, v5, :cond_1

    .line 37
    .line 38
    if-ne v4, v5, :cond_1

    .line 39
    .line 40
    const/4 v2, 0x1

    .line 41
    :cond_1
    iput-boolean v2, p0, Landroidx/recyclerview/widget/RecyclerView;->u0:Z

    .line 42
    .line 43
    if-nez v2, :cond_5

    .line 44
    .line 45
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 46
    .line 47
    if-nez v0, :cond_2

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_2
    iget v0, v3, Landroidx/recyclerview/widget/e1;->c:I

    .line 51
    .line 52
    if-ne v0, v1, :cond_3

    .line 53
    .line 54
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->p()V

    .line 55
    .line 56
    .line 57
    :cond_3
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 58
    .line 59
    invoke-virtual {v0, p1, p2}, Landroidx/recyclerview/widget/t0;->m0(II)V

    .line 60
    .line 61
    .line 62
    iput-boolean v1, v3, Landroidx/recyclerview/widget/e1;->h:Z

    .line 63
    .line 64
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->q()V

    .line 65
    .line 66
    .line 67
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 68
    .line 69
    invoke-virtual {v0, p1, p2}, Landroidx/recyclerview/widget/t0;->o0(II)V

    .line 70
    .line 71
    .line 72
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 73
    .line 74
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->r0()Z

    .line 75
    .line 76
    .line 77
    move-result v0

    .line 78
    if-eqz v0, :cond_4

    .line 79
    .line 80
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 81
    .line 82
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 83
    .line 84
    .line 85
    move-result v2

    .line 86
    invoke-static {v2, v5}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 87
    .line 88
    .line 89
    move-result v2

    .line 90
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 91
    .line 92
    .line 93
    move-result v4

    .line 94
    invoke-static {v4, v5}, Landroid/view/View$MeasureSpec;->makeMeasureSpec(II)I

    .line 95
    .line 96
    .line 97
    move-result v4

    .line 98
    invoke-virtual {v0, v2, v4}, Landroidx/recyclerview/widget/t0;->m0(II)V

    .line 99
    .line 100
    .line 101
    iput-boolean v1, v3, Landroidx/recyclerview/widget/e1;->h:Z

    .line 102
    .line 103
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->q()V

    .line 104
    .line 105
    .line 106
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 107
    .line 108
    invoke-virtual {v0, p1, p2}, Landroidx/recyclerview/widget/t0;->o0(II)V

    .line 109
    .line 110
    .line 111
    :cond_4
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 112
    .line 113
    .line 114
    move-result p1

    .line 115
    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView;->v0:I

    .line 116
    .line 117
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 118
    .line 119
    .line 120
    move-result p1

    .line 121
    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView;->w0:I

    .line 122
    .line 123
    goto :goto_4

    .line 124
    :cond_5
    :goto_0
    return-void

    .line 125
    :cond_6
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->t:Z

    .line 126
    .line 127
    if-eqz v0, :cond_7

    .line 128
    .line 129
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 130
    .line 131
    iget-object v0, v0, Landroidx/recyclerview/widget/t0;->b:Landroidx/recyclerview/widget/RecyclerView;

    .line 132
    .line 133
    invoke-virtual {v0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView;->n(II)V

    .line 134
    .line 135
    .line 136
    return-void

    .line 137
    :cond_7
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->A:Z

    .line 138
    .line 139
    if-eqz v0, :cond_9

    .line 140
    .line 141
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->d0()V

    .line 142
    .line 143
    .line 144
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->N()V

    .line 145
    .line 146
    .line 147
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->R()V

    .line 148
    .line 149
    .line 150
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView;->O(Z)V

    .line 151
    .line 152
    .line 153
    iget-boolean v0, v3, Landroidx/recyclerview/widget/e1;->j:Z

    .line 154
    .line 155
    if-eqz v0, :cond_8

    .line 156
    .line 157
    iput-boolean v1, v3, Landroidx/recyclerview/widget/e1;->f:Z

    .line 158
    .line 159
    goto :goto_1

    .line 160
    :cond_8
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->e:Landroidx/recyclerview/widget/b;

    .line 161
    .line 162
    invoke-virtual {v0}, Landroidx/recyclerview/widget/b;->c()V

    .line 163
    .line 164
    .line 165
    iput-boolean v2, v3, Landroidx/recyclerview/widget/e1;->f:Z

    .line 166
    .line 167
    :goto_1
    iput-boolean v2, p0, Landroidx/recyclerview/widget/RecyclerView;->A:Z

    .line 168
    .line 169
    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/RecyclerView;->e0(Z)V

    .line 170
    .line 171
    .line 172
    goto :goto_2

    .line 173
    :cond_9
    iget-boolean v0, v3, Landroidx/recyclerview/widget/e1;->j:Z

    .line 174
    .line 175
    if-eqz v0, :cond_a

    .line 176
    .line 177
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 178
    .line 179
    .line 180
    move-result p1

    .line 181
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 182
    .line 183
    .line 184
    move-result p2

    .line 185
    invoke-virtual {p0, p1, p2}, Landroid/view/View;->setMeasuredDimension(II)V

    .line 186
    .line 187
    .line 188
    return-void

    .line 189
    :cond_a
    :goto_2
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 190
    .line 191
    if-eqz v0, :cond_b

    .line 192
    .line 193
    invoke-virtual {v0}, Landroidx/recyclerview/widget/i0;->getItemCount()I

    .line 194
    .line 195
    .line 196
    move-result v0

    .line 197
    iput v0, v3, Landroidx/recyclerview/widget/e1;->d:I

    .line 198
    .line 199
    goto :goto_3

    .line 200
    :cond_b
    iput v2, v3, Landroidx/recyclerview/widget/e1;->d:I

    .line 201
    .line 202
    :goto_3
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->d0()V

    .line 203
    .line 204
    .line 205
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 206
    .line 207
    iget-object v0, v0, Landroidx/recyclerview/widget/t0;->b:Landroidx/recyclerview/widget/RecyclerView;

    .line 208
    .line 209
    invoke-virtual {v0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView;->n(II)V

    .line 210
    .line 211
    .line 212
    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/RecyclerView;->e0(Z)V

    .line 213
    .line 214
    .line 215
    iput-boolean v2, v3, Landroidx/recyclerview/widget/e1;->f:Z

    .line 216
    .line 217
    :goto_4
    return-void
.end method

.method public final onRequestFocusInDescendants(ILandroid/graphics/Rect;)Z
    .locals 1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->K()Z

    move-result v0

    if-eqz v0, :cond_0

    const/4 p1, 0x0

    return p1

    :cond_0
    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->onRequestFocusInDescendants(ILandroid/graphics/Rect;)Z

    move-result p1

    return p1
.end method

.method public final onRestoreInstanceState(Landroid/os/Parcelable;)V
    .locals 1

    .line 1
    instance-of v0, p1, Landroidx/recyclerview/widget/d1;

    .line 2
    .line 3
    if-nez v0, :cond_0

    .line 4
    .line 5
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 6
    .line 7
    .line 8
    return-void

    .line 9
    :cond_0
    check-cast p1, Landroidx/recyclerview/widget/d1;

    .line 10
    .line 11
    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->d:Landroidx/recyclerview/widget/d1;

    .line 12
    .line 13
    iget-object p1, p1, Lk/c;->a:Landroid/os/Parcelable;

    .line 14
    .line 15
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->onRestoreInstanceState(Landroid/os/Parcelable;)V

    .line 16
    .line 17
    .line 18
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->requestLayout()V

    .line 19
    .line 20
    .line 21
    return-void
.end method

.method public final onSaveInstanceState()Landroid/os/Parcelable;
    .locals 2

    .line 1
    new-instance v0, Landroidx/recyclerview/widget/d1;

    .line 2
    .line 3
    invoke-super {p0}, Landroid/view/ViewGroup;->onSaveInstanceState()Landroid/os/Parcelable;

    .line 4
    .line 5
    .line 6
    move-result-object v1

    .line 7
    invoke-direct {v0, v1}, Landroidx/recyclerview/widget/d1;-><init>(Landroid/os/Parcelable;)V

    .line 8
    .line 9
    .line 10
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->d:Landroidx/recyclerview/widget/d1;

    .line 11
    .line 12
    if-eqz v1, :cond_0

    .line 13
    .line 14
    iget-object v1, v1, Landroidx/recyclerview/widget/d1;->c:Landroid/os/Parcelable;

    .line 15
    .line 16
    iput-object v1, v0, Landroidx/recyclerview/widget/d1;->c:Landroid/os/Parcelable;

    .line 17
    .line 18
    goto :goto_1

    .line 19
    :cond_0
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 20
    .line 21
    if-eqz v1, :cond_1

    .line 22
    .line 23
    invoke-virtual {v1}, Landroidx/recyclerview/widget/t0;->a0()Landroid/os/Parcelable;

    .line 24
    .line 25
    .line 26
    move-result-object v1

    .line 27
    goto :goto_0

    .line 28
    :cond_1
    const/4 v1, 0x0

    .line 29
    :goto_0
    iput-object v1, v0, Landroidx/recyclerview/widget/d1;->c:Landroid/os/Parcelable;

    .line 30
    .line 31
    :goto_1
    return-object v0
.end method

.method public final onSizeChanged(IIII)V
    .locals 0

    .line 1
    invoke-super {p0, p1, p2, p3, p4}, Landroid/view/ViewGroup;->onSizeChanged(IIII)V

    .line 2
    .line 3
    .line 4
    if-ne p1, p3, :cond_0

    .line 5
    .line 6
    if-eq p2, p4, :cond_1

    .line 7
    .line 8
    :cond_0
    const/4 p1, 0x0

    .line 9
    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 10
    .line 11
    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 12
    .line 13
    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 14
    .line 15
    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 16
    .line 17
    :cond_1
    return-void
.end method

.method public final onTouchEvent(Landroid/view/MotionEvent;)Z
    .locals 20

    .line 1
    move-object/from16 v6, p0

    .line 2
    .line 3
    move-object/from16 v7, p1

    .line 4
    .line 5
    iget-boolean v0, v6, Landroidx/recyclerview/widget/RecyclerView;->x:Z

    .line 6
    .line 7
    const/4 v8, 0x0

    .line 8
    if-nez v0, :cond_49

    .line 9
    .line 10
    iget-boolean v0, v6, Landroidx/recyclerview/widget/RecyclerView;->y:Z

    .line 11
    .line 12
    if-eqz v0, :cond_0

    .line 13
    .line 14
    goto/16 :goto_19

    .line 15
    .line 16
    :cond_0
    iget-object v0, v6, Landroidx/recyclerview/widget/RecyclerView;->r:Landroidx/recyclerview/widget/w0;

    .line 17
    .line 18
    const/4 v1, 0x2

    .line 19
    const/4 v2, 0x0

    .line 20
    const/4 v9, 0x1

    .line 21
    const/4 v3, 0x3

    .line 22
    if-nez v0, :cond_2

    .line 23
    .line 24
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getAction()I

    .line 25
    .line 26
    .line 27
    move-result v0

    .line 28
    if-nez v0, :cond_1

    .line 29
    .line 30
    const/4 v0, 0x0

    .line 31
    goto/16 :goto_5

    .line 32
    .line 33
    :cond_1
    invoke-virtual/range {p0 .. p1}, Landroidx/recyclerview/widget/RecyclerView;->B(Landroid/view/MotionEvent;)Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    goto/16 :goto_5

    .line 38
    .line 39
    :cond_2
    check-cast v0, Landroidx/recyclerview/widget/q;

    .line 40
    .line 41
    iget v4, v0, Landroidx/recyclerview/widget/q;->v:I

    .line 42
    .line 43
    if-nez v4, :cond_3

    .line 44
    .line 45
    goto/16 :goto_4

    .line 46
    .line 47
    :cond_3
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getAction()I

    .line 48
    .line 49
    .line 50
    move-result v4

    .line 51
    if-nez v4, :cond_7

    .line 52
    .line 53
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    .line 54
    .line 55
    .line 56
    move-result v4

    .line 57
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    .line 58
    .line 59
    .line 60
    move-result v5

    .line 61
    invoke-virtual {v0, v4, v5}, Landroidx/recyclerview/widget/q;->b(FF)Z

    .line 62
    .line 63
    .line 64
    move-result v4

    .line 65
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    .line 66
    .line 67
    .line 68
    move-result v5

    .line 69
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    .line 70
    .line 71
    .line 72
    move-result v10

    .line 73
    invoke-virtual {v0, v5, v10}, Landroidx/recyclerview/widget/q;->a(FF)Z

    .line 74
    .line 75
    .line 76
    move-result v5

    .line 77
    if-nez v4, :cond_4

    .line 78
    .line 79
    if-eqz v5, :cond_12

    .line 80
    .line 81
    :cond_4
    if-eqz v5, :cond_5

    .line 82
    .line 83
    iput v9, v0, Landroidx/recyclerview/widget/q;->w:I

    .line 84
    .line 85
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    .line 86
    .line 87
    .line 88
    move-result v4

    .line 89
    float-to-int v4, v4

    .line 90
    int-to-float v4, v4

    .line 91
    iput v4, v0, Landroidx/recyclerview/widget/q;->p:F

    .line 92
    .line 93
    goto :goto_0

    .line 94
    :cond_5
    if-eqz v4, :cond_6

    .line 95
    .line 96
    iput v1, v0, Landroidx/recyclerview/widget/q;->w:I

    .line 97
    .line 98
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    .line 99
    .line 100
    .line 101
    move-result v4

    .line 102
    float-to-int v4, v4

    .line 103
    int-to-float v4, v4

    .line 104
    iput v4, v0, Landroidx/recyclerview/widget/q;->m:F

    .line 105
    .line 106
    :cond_6
    :goto_0
    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/q;->d(I)V

    .line 107
    .line 108
    .line 109
    goto/16 :goto_4

    .line 110
    .line 111
    :cond_7
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getAction()I

    .line 112
    .line 113
    .line 114
    move-result v4

    .line 115
    if-ne v4, v9, :cond_8

    .line 116
    .line 117
    iget v4, v0, Landroidx/recyclerview/widget/q;->v:I

    .line 118
    .line 119
    if-ne v4, v1, :cond_8

    .line 120
    .line 121
    iput v2, v0, Landroidx/recyclerview/widget/q;->m:F

    .line 122
    .line 123
    iput v2, v0, Landroidx/recyclerview/widget/q;->p:F

    .line 124
    .line 125
    invoke-virtual {v0, v9}, Landroidx/recyclerview/widget/q;->d(I)V

    .line 126
    .line 127
    .line 128
    iput v8, v0, Landroidx/recyclerview/widget/q;->w:I

    .line 129
    .line 130
    goto/16 :goto_4

    .line 131
    .line 132
    :cond_8
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getAction()I

    .line 133
    .line 134
    .line 135
    move-result v4

    .line 136
    if-ne v4, v1, :cond_12

    .line 137
    .line 138
    iget v4, v0, Landroidx/recyclerview/widget/q;->v:I

    .line 139
    .line 140
    if-ne v4, v1, :cond_12

    .line 141
    .line 142
    invoke-virtual {v0}, Landroidx/recyclerview/widget/q;->e()V

    .line 143
    .line 144
    .line 145
    iget v4, v0, Landroidx/recyclerview/widget/q;->w:I

    .line 146
    .line 147
    const/high16 v5, 0x40000000    # 2.0f

    .line 148
    .line 149
    iget v10, v0, Landroidx/recyclerview/widget/q;->b:I

    .line 150
    .line 151
    if-ne v4, v9, :cond_d

    .line 152
    .line 153
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    .line 154
    .line 155
    .line 156
    move-result v4

    .line 157
    iget-object v11, v0, Landroidx/recyclerview/widget/q;->y:[I

    .line 158
    .line 159
    aput v10, v11, v8

    .line 160
    .line 161
    iget v12, v0, Landroidx/recyclerview/widget/q;->q:I

    .line 162
    .line 163
    sub-int/2addr v12, v10

    .line 164
    aput v12, v11, v9

    .line 165
    .line 166
    int-to-float v13, v10

    .line 167
    int-to-float v12, v12

    .line 168
    invoke-static {v12, v4}, Ljava/lang/Math;->min(FF)F

    .line 169
    .line 170
    .line 171
    move-result v4

    .line 172
    invoke-static {v13, v4}, Ljava/lang/Math;->max(FF)F

    .line 173
    .line 174
    .line 175
    move-result v4

    .line 176
    iget v12, v0, Landroidx/recyclerview/widget/q;->o:I

    .line 177
    .line 178
    int-to-float v12, v12

    .line 179
    sub-float/2addr v12, v4

    .line 180
    invoke-static {v12}, Ljava/lang/Math;->abs(F)F

    .line 181
    .line 182
    .line 183
    move-result v12

    .line 184
    cmpg-float v12, v12, v5

    .line 185
    .line 186
    if-gez v12, :cond_9

    .line 187
    .line 188
    goto :goto_2

    .line 189
    :cond_9
    iget v12, v0, Landroidx/recyclerview/widget/q;->p:F

    .line 190
    .line 191
    iget-object v13, v0, Landroidx/recyclerview/widget/q;->s:Landroidx/recyclerview/widget/RecyclerView;

    .line 192
    .line 193
    invoke-virtual {v13}, Landroidx/recyclerview/widget/RecyclerView;->computeHorizontalScrollRange()I

    .line 194
    .line 195
    .line 196
    move-result v13

    .line 197
    iget-object v14, v0, Landroidx/recyclerview/widget/q;->s:Landroidx/recyclerview/widget/RecyclerView;

    .line 198
    .line 199
    invoke-virtual {v14}, Landroidx/recyclerview/widget/RecyclerView;->computeHorizontalScrollOffset()I

    .line 200
    .line 201
    .line 202
    move-result v14

    .line 203
    iget v15, v0, Landroidx/recyclerview/widget/q;->q:I

    .line 204
    .line 205
    aget v16, v11, v9

    .line 206
    .line 207
    aget v11, v11, v8

    .line 208
    .line 209
    sub-int v11, v16, v11

    .line 210
    .line 211
    if-nez v11, :cond_b

    .line 212
    .line 213
    :cond_a
    const/4 v11, 0x0

    .line 214
    goto :goto_1

    .line 215
    :cond_b
    sub-float v12, v4, v12

    .line 216
    .line 217
    int-to-float v11, v11

    .line 218
    div-float/2addr v12, v11

    .line 219
    sub-int/2addr v13, v15

    .line 220
    int-to-float v11, v13

    .line 221
    mul-float v12, v12, v11

    .line 222
    .line 223
    float-to-int v11, v12

    .line 224
    add-int/2addr v14, v11

    .line 225
    if-ge v14, v13, :cond_a

    .line 226
    .line 227
    if-ltz v14, :cond_a

    .line 228
    .line 229
    :goto_1
    if-eqz v11, :cond_c

    .line 230
    .line 231
    iget-object v12, v0, Landroidx/recyclerview/widget/q;->s:Landroidx/recyclerview/widget/RecyclerView;

    .line 232
    .line 233
    invoke-virtual {v12, v11, v8}, Landroidx/recyclerview/widget/RecyclerView;->scrollBy(II)V

    .line 234
    .line 235
    .line 236
    :cond_c
    iput v4, v0, Landroidx/recyclerview/widget/q;->p:F

    .line 237
    .line 238
    :cond_d
    :goto_2
    iget v4, v0, Landroidx/recyclerview/widget/q;->w:I

    .line 239
    .line 240
    if-ne v4, v1, :cond_12

    .line 241
    .line 242
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    .line 243
    .line 244
    .line 245
    move-result v4

    .line 246
    iget-object v11, v0, Landroidx/recyclerview/widget/q;->x:[I

    .line 247
    .line 248
    aput v10, v11, v8

    .line 249
    .line 250
    iget v12, v0, Landroidx/recyclerview/widget/q;->r:I

    .line 251
    .line 252
    sub-int/2addr v12, v10

    .line 253
    aput v12, v11, v9

    .line 254
    .line 255
    int-to-float v10, v10

    .line 256
    int-to-float v12, v12

    .line 257
    invoke-static {v12, v4}, Ljava/lang/Math;->min(FF)F

    .line 258
    .line 259
    .line 260
    move-result v4

    .line 261
    invoke-static {v10, v4}, Ljava/lang/Math;->max(FF)F

    .line 262
    .line 263
    .line 264
    move-result v4

    .line 265
    iget v10, v0, Landroidx/recyclerview/widget/q;->l:I

    .line 266
    .line 267
    int-to-float v10, v10

    .line 268
    sub-float/2addr v10, v4

    .line 269
    invoke-static {v10}, Ljava/lang/Math;->abs(F)F

    .line 270
    .line 271
    .line 272
    move-result v10

    .line 273
    cmpg-float v5, v10, v5

    .line 274
    .line 275
    if-gez v5, :cond_e

    .line 276
    .line 277
    goto :goto_4

    .line 278
    :cond_e
    iget v5, v0, Landroidx/recyclerview/widget/q;->m:F

    .line 279
    .line 280
    iget-object v10, v0, Landroidx/recyclerview/widget/q;->s:Landroidx/recyclerview/widget/RecyclerView;

    .line 281
    .line 282
    invoke-virtual {v10}, Landroidx/recyclerview/widget/RecyclerView;->computeVerticalScrollRange()I

    .line 283
    .line 284
    .line 285
    move-result v10

    .line 286
    iget-object v12, v0, Landroidx/recyclerview/widget/q;->s:Landroidx/recyclerview/widget/RecyclerView;

    .line 287
    .line 288
    invoke-virtual {v12}, Landroidx/recyclerview/widget/RecyclerView;->computeVerticalScrollOffset()I

    .line 289
    .line 290
    .line 291
    move-result v12

    .line 292
    iget v13, v0, Landroidx/recyclerview/widget/q;->r:I

    .line 293
    .line 294
    aget v14, v11, v9

    .line 295
    .line 296
    aget v11, v11, v8

    .line 297
    .line 298
    sub-int/2addr v14, v11

    .line 299
    if-nez v14, :cond_10

    .line 300
    .line 301
    :cond_f
    const/4 v5, 0x0

    .line 302
    goto :goto_3

    .line 303
    :cond_10
    sub-float v5, v4, v5

    .line 304
    .line 305
    int-to-float v11, v14

    .line 306
    div-float/2addr v5, v11

    .line 307
    sub-int/2addr v10, v13

    .line 308
    int-to-float v11, v10

    .line 309
    mul-float v5, v5, v11

    .line 310
    .line 311
    float-to-int v5, v5

    .line 312
    add-int/2addr v12, v5

    .line 313
    if-ge v12, v10, :cond_f

    .line 314
    .line 315
    if-ltz v12, :cond_f

    .line 316
    .line 317
    :goto_3
    if-eqz v5, :cond_11

    .line 318
    .line 319
    iget-object v10, v0, Landroidx/recyclerview/widget/q;->s:Landroidx/recyclerview/widget/RecyclerView;

    .line 320
    .line 321
    invoke-virtual {v10, v8, v5}, Landroidx/recyclerview/widget/RecyclerView;->scrollBy(II)V

    .line 322
    .line 323
    .line 324
    :cond_11
    iput v4, v0, Landroidx/recyclerview/widget/q;->m:F

    .line 325
    .line 326
    :cond_12
    :goto_4
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getAction()I

    .line 327
    .line 328
    .line 329
    move-result v0

    .line 330
    if-eq v0, v3, :cond_13

    .line 331
    .line 332
    if-ne v0, v9, :cond_14

    .line 333
    .line 334
    :cond_13
    const/4 v0, 0x0

    .line 335
    iput-object v0, v6, Landroidx/recyclerview/widget/RecyclerView;->r:Landroidx/recyclerview/widget/w0;

    .line 336
    .line 337
    :cond_14
    const/4 v0, 0x1

    .line 338
    :goto_5
    if-eqz v0, :cond_15

    .line 339
    .line 340
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView;->X()V

    .line 341
    .line 342
    .line 343
    invoke-virtual {v6, v8}, Landroidx/recyclerview/widget/RecyclerView;->setScrollState(I)V

    .line 344
    .line 345
    .line 346
    return v9

    .line 347
    :cond_15
    iget-object v0, v6, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 348
    .line 349
    if-nez v0, :cond_16

    .line 350
    .line 351
    return v8

    .line 352
    :cond_16
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->c()Z

    .line 353
    .line 354
    .line 355
    move-result v10

    .line 356
    iget-object v0, v6, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 357
    .line 358
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->d()Z

    .line 359
    .line 360
    .line 361
    move-result v11

    .line 362
    iget-object v0, v6, Landroidx/recyclerview/widget/RecyclerView;->O:Landroid/view/VelocityTracker;

    .line 363
    .line 364
    if-nez v0, :cond_17

    .line 365
    .line 366
    invoke-static {}, Landroid/view/VelocityTracker;->obtain()Landroid/view/VelocityTracker;

    .line 367
    .line 368
    .line 369
    move-result-object v0

    .line 370
    iput-object v0, v6, Landroidx/recyclerview/widget/RecyclerView;->O:Landroid/view/VelocityTracker;

    .line 371
    .line 372
    :cond_17
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionMasked()I

    .line 373
    .line 374
    .line 375
    move-result v0

    .line 376
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getActionIndex()I

    .line 377
    .line 378
    .line 379
    move-result v4

    .line 380
    iget-object v12, v6, Landroidx/recyclerview/widget/RecyclerView;->q0:[I

    .line 381
    .line 382
    if-nez v0, :cond_18

    .line 383
    .line 384
    aput v8, v12, v9

    .line 385
    .line 386
    aput v8, v12, v8

    .line 387
    .line 388
    :cond_18
    invoke-static/range {p1 .. p1}, Landroid/view/MotionEvent;->obtain(Landroid/view/MotionEvent;)Landroid/view/MotionEvent;

    .line 389
    .line 390
    .line 391
    move-result-object v13

    .line 392
    aget v5, v12, v8

    .line 393
    .line 394
    int-to-float v5, v5

    .line 395
    aget v14, v12, v9

    .line 396
    .line 397
    int-to-float v14, v14

    .line 398
    invoke-virtual {v13, v5, v14}, Landroid/view/MotionEvent;->offsetLocation(FF)V

    .line 399
    .line 400
    .line 401
    const/high16 v5, 0x3f000000    # 0.5f

    .line 402
    .line 403
    if-eqz v0, :cond_45

    .line 404
    .line 405
    const-string v14, "RecyclerView"

    .line 406
    .line 407
    if-eq v0, v9, :cond_2a

    .line 408
    .line 409
    if-eq v0, v1, :cond_1c

    .line 410
    .line 411
    if-eq v0, v3, :cond_1b

    .line 412
    .line 413
    const/4 v1, 0x5

    .line 414
    if-eq v0, v1, :cond_1a

    .line 415
    .line 416
    const/4 v1, 0x6

    .line 417
    if-eq v0, v1, :cond_19

    .line 418
    .line 419
    goto/16 :goto_18

    .line 420
    .line 421
    :cond_19
    invoke-virtual/range {p0 .. p1}, Landroidx/recyclerview/widget/RecyclerView;->P(Landroid/view/MotionEvent;)V

    .line 422
    .line 423
    .line 424
    goto/16 :goto_18

    .line 425
    .line 426
    :cond_1a
    invoke-virtual {v7, v4}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 427
    .line 428
    .line 429
    move-result v0

    .line 430
    iput v0, v6, Landroidx/recyclerview/widget/RecyclerView;->N:I

    .line 431
    .line 432
    invoke-virtual {v7, v4}, Landroid/view/MotionEvent;->getX(I)F

    .line 433
    .line 434
    .line 435
    move-result v0

    .line 436
    add-float/2addr v0, v5

    .line 437
    float-to-int v0, v0

    .line 438
    iput v0, v6, Landroidx/recyclerview/widget/RecyclerView;->R:I

    .line 439
    .line 440
    iput v0, v6, Landroidx/recyclerview/widget/RecyclerView;->P:I

    .line 441
    .line 442
    invoke-virtual {v7, v4}, Landroid/view/MotionEvent;->getY(I)F

    .line 443
    .line 444
    .line 445
    move-result v0

    .line 446
    add-float/2addr v0, v5

    .line 447
    float-to-int v0, v0

    .line 448
    iput v0, v6, Landroidx/recyclerview/widget/RecyclerView;->S:I

    .line 449
    .line 450
    iput v0, v6, Landroidx/recyclerview/widget/RecyclerView;->Q:I

    .line 451
    .line 452
    goto/16 :goto_18

    .line 453
    .line 454
    :cond_1b
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView;->X()V

    .line 455
    .line 456
    .line 457
    invoke-virtual {v6, v8}, Landroidx/recyclerview/widget/RecyclerView;->setScrollState(I)V

    .line 458
    .line 459
    .line 460
    goto/16 :goto_18

    .line 461
    .line 462
    :cond_1c
    iget v0, v6, Landroidx/recyclerview/widget/RecyclerView;->N:I

    .line 463
    .line 464
    invoke-virtual {v7, v0}, Landroid/view/MotionEvent;->findPointerIndex(I)I

    .line 465
    .line 466
    .line 467
    move-result v0

    .line 468
    if-gez v0, :cond_1d

    .line 469
    .line 470
    new-instance v0, Ljava/lang/StringBuilder;

    .line 471
    .line 472
    const-string v1, "Error processing scroll; pointer index for id "

    .line 473
    .line 474
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 475
    .line 476
    .line 477
    iget v1, v6, Landroidx/recyclerview/widget/RecyclerView;->N:I

    .line 478
    .line 479
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 480
    .line 481
    .line 482
    const-string v1, " not found. Did any MotionEvents get skipped?"

    .line 483
    .line 484
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 485
    .line 486
    .line 487
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 488
    .line 489
    .line 490
    move-result-object v0

    .line 491
    invoke-static {v14, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 492
    .line 493
    .line 494
    return v8

    .line 495
    :cond_1d
    invoke-virtual {v7, v0}, Landroid/view/MotionEvent;->getX(I)F

    .line 496
    .line 497
    .line 498
    move-result v1

    .line 499
    add-float/2addr v1, v5

    .line 500
    float-to-int v14, v1

    .line 501
    invoke-virtual {v7, v0}, Landroid/view/MotionEvent;->getY(I)F

    .line 502
    .line 503
    .line 504
    move-result v0

    .line 505
    add-float/2addr v0, v5

    .line 506
    float-to-int v15, v0

    .line 507
    iget v0, v6, Landroidx/recyclerview/widget/RecyclerView;->R:I

    .line 508
    .line 509
    sub-int/2addr v0, v14

    .line 510
    iget v1, v6, Landroidx/recyclerview/widget/RecyclerView;->S:I

    .line 511
    .line 512
    sub-int/2addr v1, v15

    .line 513
    iget v2, v6, Landroidx/recyclerview/widget/RecyclerView;->M:I

    .line 514
    .line 515
    if-eq v2, v9, :cond_22

    .line 516
    .line 517
    if-eqz v10, :cond_1f

    .line 518
    .line 519
    iget v2, v6, Landroidx/recyclerview/widget/RecyclerView;->T:I

    .line 520
    .line 521
    if-lez v0, :cond_1e

    .line 522
    .line 523
    sub-int/2addr v0, v2

    .line 524
    invoke-static {v8, v0}, Ljava/lang/Math;->max(II)I

    .line 525
    .line 526
    .line 527
    move-result v0

    .line 528
    goto :goto_6

    .line 529
    :cond_1e
    add-int/2addr v0, v2

    .line 530
    invoke-static {v8, v0}, Ljava/lang/Math;->min(II)I

    .line 531
    .line 532
    .line 533
    move-result v0

    .line 534
    :goto_6
    if-eqz v0, :cond_1f

    .line 535
    .line 536
    const/4 v2, 0x1

    .line 537
    goto :goto_7

    .line 538
    :cond_1f
    const/4 v2, 0x0

    .line 539
    :goto_7
    if-eqz v11, :cond_21

    .line 540
    .line 541
    iget v3, v6, Landroidx/recyclerview/widget/RecyclerView;->T:I

    .line 542
    .line 543
    if-lez v1, :cond_20

    .line 544
    .line 545
    sub-int/2addr v1, v3

    .line 546
    invoke-static {v8, v1}, Ljava/lang/Math;->max(II)I

    .line 547
    .line 548
    .line 549
    move-result v1

    .line 550
    goto :goto_8

    .line 551
    :cond_20
    add-int/2addr v1, v3

    .line 552
    invoke-static {v8, v1}, Ljava/lang/Math;->min(II)I

    .line 553
    .line 554
    .line 555
    move-result v1

    .line 556
    :goto_8
    if-eqz v1, :cond_21

    .line 557
    .line 558
    const/4 v2, 0x1

    .line 559
    :cond_21
    if-eqz v2, :cond_22

    .line 560
    .line 561
    invoke-virtual {v6, v9}, Landroidx/recyclerview/widget/RecyclerView;->setScrollState(I)V

    .line 562
    .line 563
    .line 564
    :cond_22
    iget v2, v6, Landroidx/recyclerview/widget/RecyclerView;->M:I

    .line 565
    .line 566
    if-ne v2, v9, :cond_47

    .line 567
    .line 568
    iget-object v5, v6, Landroidx/recyclerview/widget/RecyclerView;->r0:[I

    .line 569
    .line 570
    aput v8, v5, v8

    .line 571
    .line 572
    aput v8, v5, v9

    .line 573
    .line 574
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    .line 575
    .line 576
    .line 577
    move-result v2

    .line 578
    invoke-virtual {v6, v2, v0}, Landroidx/recyclerview/widget/RecyclerView;->U(FI)I

    .line 579
    .line 580
    .line 581
    move-result v2

    .line 582
    sub-int v16, v0, v2

    .line 583
    .line 584
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    .line 585
    .line 586
    .line 587
    move-result v0

    .line 588
    invoke-virtual {v6, v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->V(FI)I

    .line 589
    .line 590
    .line 591
    move-result v0

    .line 592
    sub-int v17, v1, v0

    .line 593
    .line 594
    if-eqz v10, :cond_23

    .line 595
    .line 596
    move/from16 v1, v16

    .line 597
    .line 598
    goto :goto_9

    .line 599
    :cond_23
    const/4 v1, 0x0

    .line 600
    :goto_9
    if-eqz v11, :cond_24

    .line 601
    .line 602
    move/from16 v2, v17

    .line 603
    .line 604
    goto :goto_a

    .line 605
    :cond_24
    const/4 v2, 0x0

    .line 606
    :goto_a
    iget-object v3, v6, Landroidx/recyclerview/widget/RecyclerView;->r0:[I

    .line 607
    .line 608
    iget-object v4, v6, Landroidx/recyclerview/widget/RecyclerView;->p0:[I

    .line 609
    .line 610
    const/16 v18, 0x0

    .line 611
    .line 612
    move-object/from16 v0, p0

    .line 613
    .line 614
    move-object/from16 v19, v5

    .line 615
    .line 616
    move/from16 v5, v18

    .line 617
    .line 618
    invoke-virtual/range {v0 .. v5}, Landroidx/recyclerview/widget/RecyclerView;->r(II[I[II)Z

    .line 619
    .line 620
    .line 621
    move-result v0

    .line 622
    iget-object v1, v6, Landroidx/recyclerview/widget/RecyclerView;->p0:[I

    .line 623
    .line 624
    if-eqz v0, :cond_25

    .line 625
    .line 626
    aget v0, v19, v8

    .line 627
    .line 628
    sub-int v16, v16, v0

    .line 629
    .line 630
    aget v0, v19, v9

    .line 631
    .line 632
    sub-int v17, v17, v0

    .line 633
    .line 634
    aget v0, v12, v8

    .line 635
    .line 636
    aget v2, v1, v8

    .line 637
    .line 638
    add-int/2addr v0, v2

    .line 639
    aput v0, v12, v8

    .line 640
    .line 641
    aget v0, v12, v9

    .line 642
    .line 643
    aget v2, v1, v9

    .line 644
    .line 645
    add-int/2addr v0, v2

    .line 646
    aput v0, v12, v9

    .line 647
    .line 648
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 649
    .line 650
    .line 651
    move-result-object v0

    .line 652
    invoke-interface {v0, v9}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 653
    .line 654
    .line 655
    :cond_25
    move/from16 v0, v16

    .line 656
    .line 657
    move/from16 v2, v17

    .line 658
    .line 659
    aget v3, v1, v8

    .line 660
    .line 661
    sub-int/2addr v14, v3

    .line 662
    iput v14, v6, Landroidx/recyclerview/widget/RecyclerView;->R:I

    .line 663
    .line 664
    aget v1, v1, v9

    .line 665
    .line 666
    sub-int/2addr v15, v1

    .line 667
    iput v15, v6, Landroidx/recyclerview/widget/RecyclerView;->S:I

    .line 668
    .line 669
    if-eqz v10, :cond_26

    .line 670
    .line 671
    move v1, v0

    .line 672
    goto :goto_b

    .line 673
    :cond_26
    const/4 v1, 0x0

    .line 674
    :goto_b
    if-eqz v11, :cond_27

    .line 675
    .line 676
    move v3, v2

    .line 677
    goto :goto_c

    .line 678
    :cond_27
    const/4 v3, 0x0

    .line 679
    :goto_c
    invoke-virtual {v6, v1, v3, v7, v8}, Landroidx/recyclerview/widget/RecyclerView;->Y(IILandroid/view/MotionEvent;I)Z

    .line 680
    .line 681
    .line 682
    move-result v1

    .line 683
    if-eqz v1, :cond_28

    .line 684
    .line 685
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 686
    .line 687
    .line 688
    move-result-object v1

    .line 689
    invoke-interface {v1, v9}, Landroid/view/ViewParent;->requestDisallowInterceptTouchEvent(Z)V

    .line 690
    .line 691
    .line 692
    :cond_28
    iget-object v1, v6, Landroidx/recyclerview/widget/RecyclerView;->d0:Landroidx/recyclerview/widget/u;

    .line 693
    .line 694
    if-eqz v1, :cond_47

    .line 695
    .line 696
    if-nez v0, :cond_29

    .line 697
    .line 698
    if-eqz v2, :cond_47

    .line 699
    .line 700
    :cond_29
    invoke-virtual {v1, v6, v0, v2}, Landroidx/recyclerview/widget/u;->a(Landroidx/recyclerview/widget/RecyclerView;II)V

    .line 701
    .line 702
    .line 703
    goto/16 :goto_18

    .line 704
    .line 705
    :cond_2a
    iget-object v0, v6, Landroidx/recyclerview/widget/RecyclerView;->O:Landroid/view/VelocityTracker;

    .line 706
    .line 707
    invoke-virtual {v0, v13}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 708
    .line 709
    .line 710
    iget-object v0, v6, Landroidx/recyclerview/widget/RecyclerView;->O:Landroid/view/VelocityTracker;

    .line 711
    .line 712
    iget v1, v6, Landroidx/recyclerview/widget/RecyclerView;->V:I

    .line 713
    .line 714
    int-to-float v3, v1

    .line 715
    const/16 v4, 0x3e8

    .line 716
    .line 717
    invoke-virtual {v0, v4, v3}, Landroid/view/VelocityTracker;->computeCurrentVelocity(IF)V

    .line 718
    .line 719
    .line 720
    if-eqz v10, :cond_2b

    .line 721
    .line 722
    iget-object v0, v6, Landroidx/recyclerview/widget/RecyclerView;->O:Landroid/view/VelocityTracker;

    .line 723
    .line 724
    iget v3, v6, Landroidx/recyclerview/widget/RecyclerView;->N:I

    .line 725
    .line 726
    invoke-virtual {v0, v3}, Landroid/view/VelocityTracker;->getXVelocity(I)F

    .line 727
    .line 728
    .line 729
    move-result v0

    .line 730
    neg-float v0, v0

    .line 731
    goto :goto_d

    .line 732
    :cond_2b
    const/4 v0, 0x0

    .line 733
    :goto_d
    if-eqz v11, :cond_2c

    .line 734
    .line 735
    iget-object v3, v6, Landroidx/recyclerview/widget/RecyclerView;->O:Landroid/view/VelocityTracker;

    .line 736
    .line 737
    iget v4, v6, Landroidx/recyclerview/widget/RecyclerView;->N:I

    .line 738
    .line 739
    invoke-virtual {v3, v4}, Landroid/view/VelocityTracker;->getYVelocity(I)F

    .line 740
    .line 741
    .line 742
    move-result v3

    .line 743
    neg-float v3, v3

    .line 744
    goto :goto_e

    .line 745
    :cond_2c
    const/4 v3, 0x0

    .line 746
    :goto_e
    cmpl-float v4, v0, v2

    .line 747
    .line 748
    if-nez v4, :cond_2d

    .line 749
    .line 750
    cmpl-float v4, v3, v2

    .line 751
    .line 752
    if-eqz v4, :cond_43

    .line 753
    .line 754
    :cond_2d
    float-to-int v0, v0

    .line 755
    float-to-int v3, v3

    .line 756
    iget-object v4, v6, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 757
    .line 758
    if-nez v4, :cond_2e

    .line 759
    .line 760
    const-string v0, "Cannot fling without a LayoutManager set. Call setLayoutManager with a non-null argument."

    .line 761
    .line 762
    invoke-static {v14, v0}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    .line 763
    .line 764
    .line 765
    goto/16 :goto_16

    .line 766
    .line 767
    :cond_2e
    iget-boolean v5, v6, Landroidx/recyclerview/widget/RecyclerView;->x:Z

    .line 768
    .line 769
    if-eqz v5, :cond_2f

    .line 770
    .line 771
    goto/16 :goto_16

    .line 772
    .line 773
    :cond_2f
    invoke-virtual {v4}, Landroidx/recyclerview/widget/t0;->c()Z

    .line 774
    .line 775
    .line 776
    move-result v4

    .line 777
    iget-object v5, v6, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 778
    .line 779
    invoke-virtual {v5}, Landroidx/recyclerview/widget/t0;->d()Z

    .line 780
    .line 781
    .line 782
    move-result v5

    .line 783
    iget v7, v6, Landroidx/recyclerview/widget/RecyclerView;->U:I

    .line 784
    .line 785
    if-eqz v4, :cond_30

    .line 786
    .line 787
    invoke-static {v0}, Ljava/lang/Math;->abs(I)I

    .line 788
    .line 789
    .line 790
    move-result v10

    .line 791
    if-ge v10, v7, :cond_31

    .line 792
    .line 793
    :cond_30
    const/4 v0, 0x0

    .line 794
    :cond_31
    if-eqz v5, :cond_32

    .line 795
    .line 796
    invoke-static {v3}, Ljava/lang/Math;->abs(I)I

    .line 797
    .line 798
    .line 799
    move-result v10

    .line 800
    if-ge v10, v7, :cond_33

    .line 801
    .line 802
    :cond_32
    const/4 v3, 0x0

    .line 803
    :cond_33
    if-nez v0, :cond_34

    .line 804
    .line 805
    if-nez v3, :cond_34

    .line 806
    .line 807
    goto/16 :goto_16

    .line 808
    .line 809
    :cond_34
    if-eqz v0, :cond_37

    .line 810
    .line 811
    iget-object v7, v6, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 812
    .line 813
    if-eqz v7, :cond_35

    .line 814
    .line 815
    invoke-static {v7}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    .line 816
    .line 817
    .line 818
    move-result v7

    .line 819
    cmpl-float v7, v7, v2

    .line 820
    .line 821
    if-eqz v7, :cond_35

    .line 822
    .line 823
    iget-object v7, v6, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 824
    .line 825
    neg-int v10, v0

    .line 826
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 827
    .line 828
    .line 829
    move-result v11

    .line 830
    invoke-virtual {v6, v7, v10, v11}, Landroidx/recyclerview/widget/RecyclerView;->b0(Landroid/widget/EdgeEffect;II)Z

    .line 831
    .line 832
    .line 833
    move-result v7

    .line 834
    if-eqz v7, :cond_36

    .line 835
    .line 836
    iget-object v0, v6, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 837
    .line 838
    invoke-virtual {v0, v10}, Landroid/widget/EdgeEffect;->onAbsorb(I)V

    .line 839
    .line 840
    .line 841
    goto :goto_f

    .line 842
    :cond_35
    iget-object v7, v6, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 843
    .line 844
    if-eqz v7, :cond_37

    .line 845
    .line 846
    invoke-static {v7}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    .line 847
    .line 848
    .line 849
    move-result v7

    .line 850
    cmpl-float v7, v7, v2

    .line 851
    .line 852
    if-eqz v7, :cond_37

    .line 853
    .line 854
    iget-object v7, v6, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 855
    .line 856
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getWidth()I

    .line 857
    .line 858
    .line 859
    move-result v10

    .line 860
    invoke-virtual {v6, v7, v0, v10}, Landroidx/recyclerview/widget/RecyclerView;->b0(Landroid/widget/EdgeEffect;II)Z

    .line 861
    .line 862
    .line 863
    move-result v7

    .line 864
    if-eqz v7, :cond_36

    .line 865
    .line 866
    iget-object v7, v6, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 867
    .line 868
    invoke-virtual {v7, v0}, Landroid/widget/EdgeEffect;->onAbsorb(I)V

    .line 869
    .line 870
    .line 871
    :goto_f
    const/4 v0, 0x0

    .line 872
    :cond_36
    const/4 v7, 0x0

    .line 873
    goto :goto_10

    .line 874
    :cond_37
    move v7, v0

    .line 875
    const/4 v0, 0x0

    .line 876
    :goto_10
    if-eqz v3, :cond_3a

    .line 877
    .line 878
    iget-object v10, v6, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 879
    .line 880
    if-eqz v10, :cond_38

    .line 881
    .line 882
    invoke-static {v10}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    .line 883
    .line 884
    .line 885
    move-result v10

    .line 886
    cmpl-float v10, v10, v2

    .line 887
    .line 888
    if-eqz v10, :cond_38

    .line 889
    .line 890
    iget-object v2, v6, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 891
    .line 892
    neg-int v10, v3

    .line 893
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 894
    .line 895
    .line 896
    move-result v11

    .line 897
    invoke-virtual {v6, v2, v10, v11}, Landroidx/recyclerview/widget/RecyclerView;->b0(Landroid/widget/EdgeEffect;II)Z

    .line 898
    .line 899
    .line 900
    move-result v2

    .line 901
    if-eqz v2, :cond_39

    .line 902
    .line 903
    iget-object v2, v6, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 904
    .line 905
    invoke-virtual {v2, v10}, Landroid/widget/EdgeEffect;->onAbsorb(I)V

    .line 906
    .line 907
    .line 908
    goto :goto_11

    .line 909
    :cond_38
    iget-object v10, v6, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 910
    .line 911
    if-eqz v10, :cond_3a

    .line 912
    .line 913
    invoke-static {v10}, Lb0/d;->w(Landroid/widget/EdgeEffect;)F

    .line 914
    .line 915
    .line 916
    move-result v10

    .line 917
    cmpl-float v2, v10, v2

    .line 918
    .line 919
    if-eqz v2, :cond_3a

    .line 920
    .line 921
    iget-object v2, v6, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 922
    .line 923
    invoke-virtual/range {p0 .. p0}, Landroid/view/View;->getHeight()I

    .line 924
    .line 925
    .line 926
    move-result v10

    .line 927
    invoke-virtual {v6, v2, v3, v10}, Landroidx/recyclerview/widget/RecyclerView;->b0(Landroid/widget/EdgeEffect;II)Z

    .line 928
    .line 929
    .line 930
    move-result v2

    .line 931
    if-eqz v2, :cond_39

    .line 932
    .line 933
    iget-object v2, v6, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 934
    .line 935
    invoke-virtual {v2, v3}, Landroid/widget/EdgeEffect;->onAbsorb(I)V

    .line 936
    .line 937
    .line 938
    :goto_11
    const/4 v3, 0x0

    .line 939
    :cond_39
    const/4 v2, 0x0

    .line 940
    goto :goto_12

    .line 941
    :cond_3a
    move v2, v3

    .line 942
    const/4 v3, 0x0

    .line 943
    :goto_12
    iget-object v10, v6, Landroidx/recyclerview/widget/RecyclerView;->c0:Landroidx/recyclerview/widget/h1;

    .line 944
    .line 945
    if-nez v0, :cond_3b

    .line 946
    .line 947
    if-eqz v3, :cond_3c

    .line 948
    .line 949
    :cond_3b
    neg-int v11, v1

    .line 950
    invoke-static {v0, v1}, Ljava/lang/Math;->min(II)I

    .line 951
    .line 952
    .line 953
    move-result v0

    .line 954
    invoke-static {v11, v0}, Ljava/lang/Math;->max(II)I

    .line 955
    .line 956
    .line 957
    move-result v0

    .line 958
    invoke-static {v3, v1}, Ljava/lang/Math;->min(II)I

    .line 959
    .line 960
    .line 961
    move-result v3

    .line 962
    invoke-static {v11, v3}, Ljava/lang/Math;->max(II)I

    .line 963
    .line 964
    .line 965
    move-result v3

    .line 966
    invoke-virtual {v10, v0, v3}, Landroidx/recyclerview/widget/h1;->a(II)V

    .line 967
    .line 968
    .line 969
    :cond_3c
    if-nez v7, :cond_3d

    .line 970
    .line 971
    if-nez v2, :cond_3d

    .line 972
    .line 973
    if-nez v0, :cond_41

    .line 974
    .line 975
    if-eqz v3, :cond_42

    .line 976
    .line 977
    goto :goto_15

    .line 978
    :cond_3d
    int-to-float v0, v7

    .line 979
    int-to-float v3, v2

    .line 980
    invoke-virtual {v6, v0, v3}, Landroidx/recyclerview/widget/RecyclerView;->dispatchNestedPreFling(FF)Z

    .line 981
    .line 982
    .line 983
    move-result v11

    .line 984
    if-nez v11, :cond_42

    .line 985
    .line 986
    if-nez v4, :cond_3f

    .line 987
    .line 988
    if-eqz v5, :cond_3e

    .line 989
    .line 990
    goto :goto_13

    .line 991
    :cond_3e
    const/4 v11, 0x0

    .line 992
    goto :goto_14

    .line 993
    :cond_3f
    :goto_13
    const/4 v11, 0x1

    .line 994
    :goto_14
    invoke-virtual {v6, v0, v3, v11}, Landroidx/recyclerview/widget/RecyclerView;->dispatchNestedFling(FFZ)Z

    .line 995
    .line 996
    .line 997
    if-eqz v11, :cond_42

    .line 998
    .line 999
    if-eqz v5, :cond_40

    .line 1000
    .line 1001
    or-int/lit8 v4, v4, 0x2

    .line 1002
    .line 1003
    :cond_40
    invoke-direct/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView;->getScrollingChildHelper()Lg/f;

    .line 1004
    .line 1005
    .line 1006
    move-result-object v0

    .line 1007
    invoke-virtual {v0, v4, v9}, Lg/f;->d(II)Z

    .line 1008
    .line 1009
    .line 1010
    neg-int v0, v1

    .line 1011
    invoke-static {v7, v1}, Ljava/lang/Math;->min(II)I

    .line 1012
    .line 1013
    .line 1014
    move-result v3

    .line 1015
    invoke-static {v0, v3}, Ljava/lang/Math;->max(II)I

    .line 1016
    .line 1017
    .line 1018
    move-result v3

    .line 1019
    invoke-static {v2, v1}, Ljava/lang/Math;->min(II)I

    .line 1020
    .line 1021
    .line 1022
    move-result v1

    .line 1023
    invoke-static {v0, v1}, Ljava/lang/Math;->max(II)I

    .line 1024
    .line 1025
    .line 1026
    move-result v0

    .line 1027
    invoke-virtual {v10, v3, v0}, Landroidx/recyclerview/widget/h1;->a(II)V

    .line 1028
    .line 1029
    .line 1030
    :cond_41
    :goto_15
    const/4 v0, 0x1

    .line 1031
    goto :goto_17

    .line 1032
    :cond_42
    :goto_16
    const/4 v0, 0x0

    .line 1033
    :goto_17
    if-nez v0, :cond_44

    .line 1034
    .line 1035
    :cond_43
    invoke-virtual {v6, v8}, Landroidx/recyclerview/widget/RecyclerView;->setScrollState(I)V

    .line 1036
    .line 1037
    .line 1038
    :cond_44
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView;->X()V

    .line 1039
    .line 1040
    .line 1041
    const/4 v8, 0x1

    .line 1042
    goto :goto_18

    .line 1043
    :cond_45
    invoke-virtual {v7, v8}, Landroid/view/MotionEvent;->getPointerId(I)I

    .line 1044
    .line 1045
    .line 1046
    move-result v0

    .line 1047
    iput v0, v6, Landroidx/recyclerview/widget/RecyclerView;->N:I

    .line 1048
    .line 1049
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getX()F

    .line 1050
    .line 1051
    .line 1052
    move-result v0

    .line 1053
    add-float/2addr v0, v5

    .line 1054
    float-to-int v0, v0

    .line 1055
    iput v0, v6, Landroidx/recyclerview/widget/RecyclerView;->R:I

    .line 1056
    .line 1057
    iput v0, v6, Landroidx/recyclerview/widget/RecyclerView;->P:I

    .line 1058
    .line 1059
    invoke-virtual/range {p1 .. p1}, Landroid/view/MotionEvent;->getY()F

    .line 1060
    .line 1061
    .line 1062
    move-result v0

    .line 1063
    add-float/2addr v0, v5

    .line 1064
    float-to-int v0, v0

    .line 1065
    iput v0, v6, Landroidx/recyclerview/widget/RecyclerView;->S:I

    .line 1066
    .line 1067
    iput v0, v6, Landroidx/recyclerview/widget/RecyclerView;->Q:I

    .line 1068
    .line 1069
    if-eqz v11, :cond_46

    .line 1070
    .line 1071
    or-int/lit8 v10, v10, 0x2

    .line 1072
    .line 1073
    :cond_46
    invoke-direct/range {p0 .. p0}, Landroidx/recyclerview/widget/RecyclerView;->getScrollingChildHelper()Lg/f;

    .line 1074
    .line 1075
    .line 1076
    move-result-object v0

    .line 1077
    invoke-virtual {v0, v10, v8}, Lg/f;->d(II)Z

    .line 1078
    .line 1079
    .line 1080
    :cond_47
    :goto_18
    if-nez v8, :cond_48

    .line 1081
    .line 1082
    iget-object v0, v6, Landroidx/recyclerview/widget/RecyclerView;->O:Landroid/view/VelocityTracker;

    .line 1083
    .line 1084
    invoke-virtual {v0, v13}, Landroid/view/VelocityTracker;->addMovement(Landroid/view/MotionEvent;)V

    .line 1085
    .line 1086
    .line 1087
    :cond_48
    invoke-virtual {v13}, Landroid/view/MotionEvent;->recycle()V

    .line 1088
    .line 1089
    .line 1090
    return v9

    .line 1091
    :cond_49
    :goto_19
    return v8
.end method

.method public final p()V
    .locals 10

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    .line 2
    .line 3
    const/4 v1, 0x1

    .line 4
    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/e1;->a(I)V

    .line 5
    .line 6
    .line 7
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView;->z(Landroidx/recyclerview/widget/e1;)V

    .line 8
    .line 9
    .line 10
    const/4 v2, 0x0

    .line 11
    iput-boolean v2, v0, Landroidx/recyclerview/widget/e1;->h:Z

    .line 12
    .line 13
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->d0()V

    .line 14
    .line 15
    .line 16
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->g:Landroidx/recyclerview/widget/t1;

    .line 17
    .line 18
    invoke-virtual {v3}, Landroidx/recyclerview/widget/t1;->e()V

    .line 19
    .line 20
    .line 21
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->N()V

    .line 22
    .line 23
    .line 24
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->R()V

    .line 25
    .line 26
    .line 27
    iget-boolean v4, p0, Landroidx/recyclerview/widget/RecyclerView;->b0:Z

    .line 28
    .line 29
    const/4 v5, 0x0

    .line 30
    if-eqz v4, :cond_0

    .line 31
    .line 32
    invoke-virtual {p0}, Landroid/view/View;->hasFocus()Z

    .line 33
    .line 34
    .line 35
    move-result v4

    .line 36
    if-eqz v4, :cond_0

    .line 37
    .line 38
    iget-object v4, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 39
    .line 40
    if-eqz v4, :cond_0

    .line 41
    .line 42
    invoke-virtual {p0}, Landroid/view/ViewGroup;->getFocusedChild()Landroid/view/View;

    .line 43
    .line 44
    .line 45
    move-result-object v4

    .line 46
    goto :goto_0

    .line 47
    :cond_0
    move-object v4, v5

    .line 48
    :goto_0
    if-nez v4, :cond_1

    .line 49
    .line 50
    goto :goto_1

    .line 51
    :cond_1
    invoke-virtual {p0, v4}, Landroidx/recyclerview/widget/RecyclerView;->A(Landroid/view/View;)Landroid/view/View;

    .line 52
    .line 53
    .line 54
    move-result-object v4

    .line 55
    if-nez v4, :cond_2

    .line 56
    .line 57
    goto :goto_1

    .line 58
    :cond_2
    invoke-virtual {p0, v4}, Landroidx/recyclerview/widget/RecyclerView;->H(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 59
    .line 60
    .line 61
    move-result-object v5

    .line 62
    :goto_1
    const-wide/16 v6, -0x1

    .line 63
    .line 64
    const/4 v4, -0x1

    .line 65
    if-nez v5, :cond_3

    .line 66
    .line 67
    iput-wide v6, v0, Landroidx/recyclerview/widget/e1;->l:J

    .line 68
    .line 69
    iput v4, v0, Landroidx/recyclerview/widget/e1;->k:I

    .line 70
    .line 71
    iput v4, v0, Landroidx/recyclerview/widget/e1;->m:I

    .line 72
    .line 73
    goto :goto_4

    .line 74
    :cond_3
    iget-object v8, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 75
    .line 76
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i0;->hasStableIds()Z

    .line 77
    .line 78
    .line 79
    move-result v8

    .line 80
    if-eqz v8, :cond_4

    .line 81
    .line 82
    invoke-virtual {v5}, Landroidx/recyclerview/widget/i1;->getItemId()J

    .line 83
    .line 84
    .line 85
    move-result-wide v6

    .line 86
    :cond_4
    iput-wide v6, v0, Landroidx/recyclerview/widget/e1;->l:J

    .line 87
    .line 88
    iget-boolean v6, p0, Landroidx/recyclerview/widget/RecyclerView;->C:Z

    .line 89
    .line 90
    if-eqz v6, :cond_5

    .line 91
    .line 92
    const/4 v6, -0x1

    .line 93
    goto :goto_2

    .line 94
    :cond_5
    invoke-virtual {v5}, Landroidx/recyclerview/widget/i1;->isRemoved()Z

    .line 95
    .line 96
    .line 97
    move-result v6

    .line 98
    if-eqz v6, :cond_6

    .line 99
    .line 100
    iget v6, v5, Landroidx/recyclerview/widget/i1;->mOldPosition:I

    .line 101
    .line 102
    goto :goto_2

    .line 103
    :cond_6
    invoke-virtual {v5}, Landroidx/recyclerview/widget/i1;->getAbsoluteAdapterPosition()I

    .line 104
    .line 105
    .line 106
    move-result v6

    .line 107
    :goto_2
    iput v6, v0, Landroidx/recyclerview/widget/e1;->k:I

    .line 108
    .line 109
    iget-object v5, v5, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 110
    .line 111
    :goto_3
    invoke-virtual {v5}, Landroid/view/View;->getId()I

    .line 112
    .line 113
    .line 114
    move-result v6

    .line 115
    :cond_7
    invoke-virtual {v5}, Landroid/view/View;->isFocused()Z

    .line 116
    .line 117
    .line 118
    move-result v7

    .line 119
    if-nez v7, :cond_8

    .line 120
    .line 121
    instance-of v7, v5, Landroid/view/ViewGroup;

    .line 122
    .line 123
    if-eqz v7, :cond_8

    .line 124
    .line 125
    invoke-virtual {v5}, Landroid/view/View;->hasFocus()Z

    .line 126
    .line 127
    .line 128
    move-result v7

    .line 129
    if-eqz v7, :cond_8

    .line 130
    .line 131
    check-cast v5, Landroid/view/ViewGroup;

    .line 132
    .line 133
    invoke-virtual {v5}, Landroid/view/ViewGroup;->getFocusedChild()Landroid/view/View;

    .line 134
    .line 135
    .line 136
    move-result-object v5

    .line 137
    invoke-virtual {v5}, Landroid/view/View;->getId()I

    .line 138
    .line 139
    .line 140
    move-result v7

    .line 141
    if-eq v7, v4, :cond_7

    .line 142
    .line 143
    goto :goto_3

    .line 144
    :cond_8
    iput v6, v0, Landroidx/recyclerview/widget/e1;->m:I

    .line 145
    .line 146
    :goto_4
    iget-boolean v5, v0, Landroidx/recyclerview/widget/e1;->i:Z

    .line 147
    .line 148
    if-eqz v5, :cond_9

    .line 149
    .line 150
    iget-boolean v5, p0, Landroidx/recyclerview/widget/RecyclerView;->j0:Z

    .line 151
    .line 152
    if-eqz v5, :cond_9

    .line 153
    .line 154
    const/4 v5, 0x1

    .line 155
    goto :goto_5

    .line 156
    :cond_9
    const/4 v5, 0x0

    .line 157
    :goto_5
    iput-boolean v5, v0, Landroidx/recyclerview/widget/e1;->g:Z

    .line 158
    .line 159
    iput-boolean v2, p0, Landroidx/recyclerview/widget/RecyclerView;->j0:Z

    .line 160
    .line 161
    iput-boolean v2, p0, Landroidx/recyclerview/widget/RecyclerView;->i0:Z

    .line 162
    .line 163
    iget-boolean v5, v0, Landroidx/recyclerview/widget/e1;->j:Z

    .line 164
    .line 165
    iput-boolean v5, v0, Landroidx/recyclerview/widget/e1;->f:Z

    .line 166
    .line 167
    iget-object v5, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 168
    .line 169
    invoke-virtual {v5}, Landroidx/recyclerview/widget/i0;->getItemCount()I

    .line 170
    .line 171
    .line 172
    move-result v5

    .line 173
    iput v5, v0, Landroidx/recyclerview/widget/e1;->d:I

    .line 174
    .line 175
    iget-object v5, p0, Landroidx/recyclerview/widget/RecyclerView;->n0:[I

    .line 176
    .line 177
    invoke-virtual {p0, v5}, Landroidx/recyclerview/widget/RecyclerView;->C([I)V

    .line 178
    .line 179
    .line 180
    iget-boolean v5, v0, Landroidx/recyclerview/widget/e1;->i:Z

    .line 181
    .line 182
    if-eqz v5, :cond_c

    .line 183
    .line 184
    iget-object v5, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 185
    .line 186
    invoke-virtual {v5}, Landroidx/recyclerview/widget/e;->e()I

    .line 187
    .line 188
    .line 189
    move-result v5

    .line 190
    const/4 v6, 0x0

    .line 191
    :goto_6
    if-ge v6, v5, :cond_c

    .line 192
    .line 193
    iget-object v7, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 194
    .line 195
    invoke-virtual {v7, v6}, Landroidx/recyclerview/widget/e;->d(I)Landroid/view/View;

    .line 196
    .line 197
    .line 198
    move-result-object v7

    .line 199
    invoke-static {v7}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 200
    .line 201
    .line 202
    move-result-object v7

    .line 203
    invoke-virtual {v7}, Landroidx/recyclerview/widget/i1;->shouldIgnore()Z

    .line 204
    .line 205
    .line 206
    move-result v8

    .line 207
    if-nez v8, :cond_b

    .line 208
    .line 209
    invoke-virtual {v7}, Landroidx/recyclerview/widget/i1;->isInvalid()Z

    .line 210
    .line 211
    .line 212
    move-result v8

    .line 213
    if-eqz v8, :cond_a

    .line 214
    .line 215
    iget-object v8, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 216
    .line 217
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i0;->hasStableIds()Z

    .line 218
    .line 219
    .line 220
    move-result v8

    .line 221
    if-nez v8, :cond_a

    .line 222
    .line 223
    goto :goto_7

    .line 224
    :cond_a
    iget-object v8, p0, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 225
    .line 226
    invoke-static {v7}, Landroidx/recyclerview/widget/o0;->b(Landroidx/recyclerview/widget/i1;)V

    .line 227
    .line 228
    .line 229
    invoke-virtual {v7}, Landroidx/recyclerview/widget/i1;->getUnmodifiedPayloads()Ljava/util/List;

    .line 230
    .line 231
    .line 232
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 233
    .line 234
    .line 235
    new-instance v8, Landroidx/recyclerview/widget/n0;

    .line 236
    .line 237
    invoke-direct {v8}, Landroidx/recyclerview/widget/n0;-><init>()V

    .line 238
    .line 239
    .line 240
    invoke-virtual {v8, v7}, Landroidx/recyclerview/widget/n0;->a(Landroidx/recyclerview/widget/i1;)V

    .line 241
    .line 242
    .line 243
    invoke-virtual {v3, v7, v8}, Landroidx/recyclerview/widget/t1;->d(Landroidx/recyclerview/widget/i1;Landroidx/recyclerview/widget/n0;)V

    .line 244
    .line 245
    .line 246
    iget-boolean v8, v0, Landroidx/recyclerview/widget/e1;->g:Z

    .line 247
    .line 248
    if-eqz v8, :cond_b

    .line 249
    .line 250
    invoke-virtual {v7}, Landroidx/recyclerview/widget/i1;->isUpdated()Z

    .line 251
    .line 252
    .line 253
    move-result v8

    .line 254
    if-eqz v8, :cond_b

    .line 255
    .line 256
    invoke-virtual {v7}, Landroidx/recyclerview/widget/i1;->isRemoved()Z

    .line 257
    .line 258
    .line 259
    move-result v8

    .line 260
    if-nez v8, :cond_b

    .line 261
    .line 262
    invoke-virtual {v7}, Landroidx/recyclerview/widget/i1;->shouldIgnore()Z

    .line 263
    .line 264
    .line 265
    move-result v8

    .line 266
    if-nez v8, :cond_b

    .line 267
    .line 268
    invoke-virtual {v7}, Landroidx/recyclerview/widget/i1;->isInvalid()Z

    .line 269
    .line 270
    .line 271
    move-result v8

    .line 272
    if-nez v8, :cond_b

    .line 273
    .line 274
    invoke-virtual {p0, v7}, Landroidx/recyclerview/widget/RecyclerView;->G(Landroidx/recyclerview/widget/i1;)J

    .line 275
    .line 276
    .line 277
    move-result-wide v8

    .line 278
    invoke-virtual {v3, v8, v9, v7}, Landroidx/recyclerview/widget/t1;->b(JLandroidx/recyclerview/widget/i1;)V

    .line 279
    .line 280
    .line 281
    :cond_b
    :goto_7
    add-int/lit8 v6, v6, 0x1

    .line 282
    .line 283
    goto :goto_6

    .line 284
    :cond_c
    iget-boolean v5, v0, Landroidx/recyclerview/widget/e1;->j:Z

    .line 285
    .line 286
    const/4 v6, 0x2

    .line 287
    if-eqz v5, :cond_16

    .line 288
    .line 289
    iget-object v5, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 290
    .line 291
    invoke-virtual {v5}, Landroidx/recyclerview/widget/e;->h()I

    .line 292
    .line 293
    .line 294
    move-result v5

    .line 295
    const/4 v7, 0x0

    .line 296
    :goto_8
    if-ge v7, v5, :cond_10

    .line 297
    .line 298
    iget-object v8, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 299
    .line 300
    invoke-virtual {v8, v7}, Landroidx/recyclerview/widget/e;->g(I)Landroid/view/View;

    .line 301
    .line 302
    .line 303
    move-result-object v8

    .line 304
    invoke-static {v8}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 305
    .line 306
    .line 307
    move-result-object v8

    .line 308
    sget-boolean v9, Landroidx/recyclerview/widget/RecyclerView;->y0:Z

    .line 309
    .line 310
    if-eqz v9, :cond_e

    .line 311
    .line 312
    iget v9, v8, Landroidx/recyclerview/widget/i1;->mPosition:I

    .line 313
    .line 314
    if-ne v9, v4, :cond_e

    .line 315
    .line 316
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->isRemoved()Z

    .line 317
    .line 318
    .line 319
    move-result v9

    .line 320
    if-eqz v9, :cond_d

    .line 321
    .line 322
    goto :goto_9

    .line 323
    :cond_d
    new-instance v0, Ljava/lang/IllegalStateException;

    .line 324
    .line 325
    new-instance v1, Ljava/lang/StringBuilder;

    .line 326
    .line 327
    const-string v2, "view holder cannot have position -1 unless it is removed"

    .line 328
    .line 329
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 330
    .line 331
    .line 332
    invoke-static {p0, v1}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 333
    .line 334
    .line 335
    move-result-object v1

    .line 336
    invoke-direct {v0, v1}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 337
    .line 338
    .line 339
    throw v0

    .line 340
    :cond_e
    :goto_9
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->shouldIgnore()Z

    .line 341
    .line 342
    .line 343
    move-result v9

    .line 344
    if-nez v9, :cond_f

    .line 345
    .line 346
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->saveOldPosition()V

    .line 347
    .line 348
    .line 349
    :cond_f
    add-int/lit8 v7, v7, 0x1

    .line 350
    .line 351
    goto :goto_8

    .line 352
    :cond_10
    iget-boolean v4, v0, Landroidx/recyclerview/widget/e1;->e:Z

    .line 353
    .line 354
    iput-boolean v2, v0, Landroidx/recyclerview/widget/e1;->e:Z

    .line 355
    .line 356
    iget-object v5, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 357
    .line 358
    iget-object v7, p0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 359
    .line 360
    invoke-virtual {v5, v7, v0}, Landroidx/recyclerview/widget/t0;->X(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;)V

    .line 361
    .line 362
    .line 363
    iput-boolean v4, v0, Landroidx/recyclerview/widget/e1;->e:Z

    .line 364
    .line 365
    const/4 v4, 0x0

    .line 366
    :goto_a
    iget-object v5, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 367
    .line 368
    invoke-virtual {v5}, Landroidx/recyclerview/widget/e;->e()I

    .line 369
    .line 370
    .line 371
    move-result v5

    .line 372
    if-ge v4, v5, :cond_16

    .line 373
    .line 374
    iget-object v5, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 375
    .line 376
    invoke-virtual {v5, v4}, Landroidx/recyclerview/widget/e;->d(I)Landroid/view/View;

    .line 377
    .line 378
    .line 379
    move-result-object v5

    .line 380
    invoke-static {v5}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 381
    .line 382
    .line 383
    move-result-object v5

    .line 384
    invoke-virtual {v5}, Landroidx/recyclerview/widget/i1;->shouldIgnore()Z

    .line 385
    .line 386
    .line 387
    move-result v7

    .line 388
    if-eqz v7, :cond_11

    .line 389
    .line 390
    goto :goto_c

    .line 391
    :cond_11
    iget-object v7, v3, Landroidx/recyclerview/widget/t1;->b:Ljava/lang/Object;

    .line 392
    .line 393
    check-cast v7, La/h;

    .line 394
    .line 395
    invoke-virtual {v7, v5}, La/h;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 396
    .line 397
    .line 398
    move-result-object v7

    .line 399
    check-cast v7, Landroidx/recyclerview/widget/s1;

    .line 400
    .line 401
    if-eqz v7, :cond_12

    .line 402
    .line 403
    iget v7, v7, Landroidx/recyclerview/widget/s1;->a:I

    .line 404
    .line 405
    and-int/lit8 v7, v7, 0x4

    .line 406
    .line 407
    if-eqz v7, :cond_12

    .line 408
    .line 409
    const/4 v7, 0x1

    .line 410
    goto :goto_b

    .line 411
    :cond_12
    const/4 v7, 0x0

    .line 412
    :goto_b
    if-nez v7, :cond_15

    .line 413
    .line 414
    invoke-static {v5}, Landroidx/recyclerview/widget/o0;->b(Landroidx/recyclerview/widget/i1;)V

    .line 415
    .line 416
    .line 417
    const/16 v7, 0x2000

    .line 418
    .line 419
    invoke-virtual {v5, v7}, Landroidx/recyclerview/widget/i1;->hasAnyOfTheFlags(I)Z

    .line 420
    .line 421
    .line 422
    move-result v7

    .line 423
    iget-object v8, p0, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 424
    .line 425
    invoke-virtual {v5}, Landroidx/recyclerview/widget/i1;->getUnmodifiedPayloads()Ljava/util/List;

    .line 426
    .line 427
    .line 428
    invoke-virtual {v8}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 429
    .line 430
    .line 431
    new-instance v8, Landroidx/recyclerview/widget/n0;

    .line 432
    .line 433
    invoke-direct {v8}, Landroidx/recyclerview/widget/n0;-><init>()V

    .line 434
    .line 435
    .line 436
    invoke-virtual {v8, v5}, Landroidx/recyclerview/widget/n0;->a(Landroidx/recyclerview/widget/i1;)V

    .line 437
    .line 438
    .line 439
    if-eqz v7, :cond_13

    .line 440
    .line 441
    invoke-virtual {p0, v5, v8}, Landroidx/recyclerview/widget/RecyclerView;->T(Landroidx/recyclerview/widget/i1;Landroidx/recyclerview/widget/n0;)V

    .line 442
    .line 443
    .line 444
    goto :goto_c

    .line 445
    :cond_13
    iget-object v7, v3, Landroidx/recyclerview/widget/t1;->b:Ljava/lang/Object;

    .line 446
    .line 447
    check-cast v7, La/h;

    .line 448
    .line 449
    invoke-virtual {v7, v5}, La/h;->get(Ljava/lang/Object;)Ljava/lang/Object;

    .line 450
    .line 451
    .line 452
    move-result-object v7

    .line 453
    check-cast v7, Landroidx/recyclerview/widget/s1;

    .line 454
    .line 455
    if-nez v7, :cond_14

    .line 456
    .line 457
    invoke-static {}, Landroidx/recyclerview/widget/s1;->a()Landroidx/recyclerview/widget/s1;

    .line 458
    .line 459
    .line 460
    move-result-object v7

    .line 461
    iget-object v9, v3, Landroidx/recyclerview/widget/t1;->b:Ljava/lang/Object;

    .line 462
    .line 463
    check-cast v9, La/h;

    .line 464
    .line 465
    invoke-virtual {v9, v5, v7}, La/h;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 466
    .line 467
    .line 468
    :cond_14
    iget v5, v7, Landroidx/recyclerview/widget/s1;->a:I

    .line 469
    .line 470
    or-int/2addr v5, v6

    .line 471
    iput v5, v7, Landroidx/recyclerview/widget/s1;->a:I

    .line 472
    .line 473
    iput-object v8, v7, Landroidx/recyclerview/widget/s1;->b:Landroidx/recyclerview/widget/n0;

    .line 474
    .line 475
    :cond_15
    :goto_c
    add-int/lit8 v4, v4, 0x1

    .line 476
    .line 477
    goto :goto_a

    .line 478
    :cond_16
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->j()V

    .line 479
    .line 480
    .line 481
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/RecyclerView;->O(Z)V

    .line 482
    .line 483
    .line 484
    invoke-virtual {p0, v2}, Landroidx/recyclerview/widget/RecyclerView;->e0(Z)V

    .line 485
    .line 486
    .line 487
    iput v6, v0, Landroidx/recyclerview/widget/e1;->c:I

    .line 488
    .line 489
    return-void
.end method

.method public final q()V
    .locals 4

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->d0()V

    .line 2
    .line 3
    .line 4
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->N()V

    .line 5
    .line 6
    .line 7
    const/4 v0, 0x6

    .line 8
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    .line 9
    .line 10
    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/e1;->a(I)V

    .line 11
    .line 12
    .line 13
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->e:Landroidx/recyclerview/widget/b;

    .line 14
    .line 15
    invoke-virtual {v0}, Landroidx/recyclerview/widget/b;->c()V

    .line 16
    .line 17
    .line 18
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 19
    .line 20
    invoke-virtual {v0}, Landroidx/recyclerview/widget/i0;->getItemCount()I

    .line 21
    .line 22
    .line 23
    move-result v0

    .line 24
    iput v0, v1, Landroidx/recyclerview/widget/e1;->d:I

    .line 25
    .line 26
    const/4 v0, 0x0

    .line 27
    iput v0, v1, Landroidx/recyclerview/widget/e1;->b:I

    .line 28
    .line 29
    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView;->d:Landroidx/recyclerview/widget/d1;

    .line 30
    .line 31
    if-eqz v2, :cond_1

    .line 32
    .line 33
    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 34
    .line 35
    invoke-virtual {v2}, Landroidx/recyclerview/widget/i0;->canRestoreState()Z

    .line 36
    .line 37
    .line 38
    move-result v2

    .line 39
    if-eqz v2, :cond_1

    .line 40
    .line 41
    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView;->d:Landroidx/recyclerview/widget/d1;

    .line 42
    .line 43
    iget-object v2, v2, Landroidx/recyclerview/widget/d1;->c:Landroid/os/Parcelable;

    .line 44
    .line 45
    if-eqz v2, :cond_0

    .line 46
    .line 47
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 48
    .line 49
    invoke-virtual {v3, v2}, Landroidx/recyclerview/widget/t0;->Z(Landroid/os/Parcelable;)V

    .line 50
    .line 51
    .line 52
    :cond_0
    const/4 v2, 0x0

    .line 53
    iput-object v2, p0, Landroidx/recyclerview/widget/RecyclerView;->d:Landroidx/recyclerview/widget/d1;

    .line 54
    .line 55
    :cond_1
    iput-boolean v0, v1, Landroidx/recyclerview/widget/e1;->f:Z

    .line 56
    .line 57
    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 58
    .line 59
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 60
    .line 61
    invoke-virtual {v2, v3, v1}, Landroidx/recyclerview/widget/t0;->X(Landroidx/recyclerview/widget/a1;Landroidx/recyclerview/widget/e1;)V

    .line 62
    .line 63
    .line 64
    iput-boolean v0, v1, Landroidx/recyclerview/widget/e1;->e:Z

    .line 65
    .line 66
    iget-boolean v2, v1, Landroidx/recyclerview/widget/e1;->i:Z

    .line 67
    .line 68
    const/4 v3, 0x1

    .line 69
    if-eqz v2, :cond_2

    .line 70
    .line 71
    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 72
    .line 73
    if-eqz v2, :cond_2

    .line 74
    .line 75
    const/4 v2, 0x1

    .line 76
    goto :goto_0

    .line 77
    :cond_2
    const/4 v2, 0x0

    .line 78
    :goto_0
    iput-boolean v2, v1, Landroidx/recyclerview/widget/e1;->i:Z

    .line 79
    .line 80
    const/4 v2, 0x4

    .line 81
    iput v2, v1, Landroidx/recyclerview/widget/e1;->c:I

    .line 82
    .line 83
    invoke-virtual {p0, v3}, Landroidx/recyclerview/widget/RecyclerView;->O(Z)V

    .line 84
    .line 85
    .line 86
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView;->e0(Z)V

    .line 87
    .line 88
    .line 89
    return-void
.end method

.method public final r(II[I[II)Z
    .locals 6

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView;->getScrollingChildHelper()Lg/f;

    move-result-object v0

    move v1, p1

    move v2, p2

    move-object v3, p3

    move-object v4, p4

    move v5, p5

    invoke-virtual/range {v0 .. v5}, Lg/f;->a(II[I[II)Z

    move-result p1

    return p1
.end method

.method public final removeDetachedView(Landroid/view/View;Z)V
    .locals 2

    .line 1
    invoke-static {p1}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    if-eqz v0, :cond_2

    .line 6
    .line 7
    invoke-virtual {v0}, Landroidx/recyclerview/widget/i1;->isTmpDetached()Z

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-eqz v1, :cond_0

    .line 12
    .line 13
    invoke-virtual {v0}, Landroidx/recyclerview/widget/i1;->clearTmpDetachFlag()V

    .line 14
    .line 15
    .line 16
    goto :goto_0

    .line 17
    :cond_0
    invoke-virtual {v0}, Landroidx/recyclerview/widget/i1;->shouldIgnore()Z

    .line 18
    .line 19
    .line 20
    move-result v1

    .line 21
    if-eqz v1, :cond_1

    .line 22
    .line 23
    goto :goto_0

    .line 24
    :cond_1
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 25
    .line 26
    new-instance p2, Ljava/lang/StringBuilder;

    .line 27
    .line 28
    const-string v1, "Called removeDetachedView with a view which is not flagged as tmp detached."

    .line 29
    .line 30
    invoke-direct {p2, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 31
    .line 32
    .line 33
    invoke-virtual {p2, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 34
    .line 35
    .line 36
    invoke-static {p0, p2}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 37
    .line 38
    .line 39
    move-result-object p2

    .line 40
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 41
    .line 42
    .line 43
    throw p1

    .line 44
    :cond_2
    sget-boolean v0, Landroidx/recyclerview/widget/RecyclerView;->y0:Z

    .line 45
    .line 46
    if-nez v0, :cond_4

    .line 47
    .line 48
    :goto_0
    invoke-virtual {p1}, Landroid/view/View;->clearAnimation()V

    .line 49
    .line 50
    .line 51
    invoke-static {p1}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 52
    .line 53
    .line 54
    move-result-object v0

    .line 55
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 56
    .line 57
    if-eqz v1, :cond_3

    .line 58
    .line 59
    if-eqz v0, :cond_3

    .line 60
    .line 61
    invoke-virtual {v1, v0}, Landroidx/recyclerview/widget/i0;->onViewDetachedFromWindow(Landroidx/recyclerview/widget/i1;)V

    .line 62
    .line 63
    .line 64
    :cond_3
    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->removeDetachedView(Landroid/view/View;Z)V

    .line 65
    .line 66
    .line 67
    return-void

    .line 68
    :cond_4
    new-instance p2, Ljava/lang/IllegalArgumentException;

    .line 69
    .line 70
    new-instance v0, Ljava/lang/StringBuilder;

    .line 71
    .line 72
    const-string v1, "No ViewHolder found for child: "

    .line 73
    .line 74
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 75
    .line 76
    .line 77
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 78
    .line 79
    .line 80
    invoke-static {p0, v0}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 81
    .line 82
    .line 83
    move-result-object p1

    .line 84
    invoke-direct {p2, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 85
    .line 86
    .line 87
    throw p2
.end method

.method public final requestChildFocus(Landroid/view/View;Landroid/view/View;)V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->K()Z

    .line 7
    .line 8
    .line 9
    move-result v0

    .line 10
    if-nez v0, :cond_0

    .line 11
    .line 12
    if-eqz p2, :cond_0

    .line 13
    .line 14
    invoke-virtual {p0, p1, p2}, Landroidx/recyclerview/widget/RecyclerView;->W(Landroid/view/View;Landroid/view/View;)V

    .line 15
    .line 16
    .line 17
    :cond_0
    invoke-super {p0, p1, p2}, Landroid/view/ViewGroup;->requestChildFocus(Landroid/view/View;Landroid/view/View;)V

    .line 18
    .line 19
    .line 20
    return-void
.end method

.method public final requestChildRectangleOnScreen(Landroid/view/View;Landroid/graphics/Rect;Z)Z
    .locals 6

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 2
    .line 3
    const/4 v5, 0x0

    .line 4
    move-object v1, p0

    .line 5
    move-object v2, p1

    .line 6
    move-object v3, p2

    .line 7
    move v4, p3

    .line 8
    invoke-virtual/range {v0 .. v5}, Landroidx/recyclerview/widget/t0;->g0(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/View;Landroid/graphics/Rect;ZZ)Z

    .line 9
    .line 10
    .line 11
    move-result p1

    .line 12
    return p1
.end method

.method public final requestDisallowInterceptTouchEvent(Z)V
    .locals 4

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->q:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    const/4 v2, 0x0

    :goto_0
    if-ge v2, v1, :cond_0

    invoke-virtual {v0, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v3

    check-cast v3, Landroidx/recyclerview/widget/w0;

    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    add-int/lit8 v2, v2, 0x1

    goto :goto_0

    :cond_0
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->requestDisallowInterceptTouchEvent(Z)V

    return-void
.end method

.method public final requestLayout()V
    .locals 1

    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView;->v:I

    if-nez v0, :cond_0

    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->x:Z

    if-nez v0, :cond_0

    invoke-super {p0}, Landroid/view/ViewGroup;->requestLayout()V

    goto :goto_0

    :cond_0
    const/4 v0, 0x1

    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->w:Z

    :goto_0
    return-void
.end method

.method public final s(IIII[II[I)V
    .locals 8

    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView;->getScrollingChildHelper()Lg/f;

    move-result-object v0

    move v1, p1

    move v2, p2

    move v3, p3

    move v4, p4

    move-object v5, p5

    move v6, p6

    move-object v7, p7

    .line 1
    invoke-virtual/range {v0 .. v7}, Lg/f;->b(IIII[II[I)Z

    return-void
.end method

.method public final scrollBy(II)V
    .locals 3

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    if-nez v0, :cond_0

    const-string p1, "RecyclerView"

    const-string p2, "Cannot scroll without a LayoutManager set. Call setLayoutManager with a non-null argument."

    invoke-static {p1, p2}, Landroid/util/Log;->e(Ljava/lang/String;Ljava/lang/String;)I

    return-void

    :cond_0
    iget-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView;->x:Z

    if-eqz v1, :cond_1

    return-void

    :cond_1
    invoke-virtual {v0}, Landroidx/recyclerview/widget/t0;->c()Z

    move-result v0

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    invoke-virtual {v1}, Landroidx/recyclerview/widget/t0;->d()Z

    move-result v1

    if-nez v0, :cond_2

    if-eqz v1, :cond_5

    :cond_2
    const/4 v2, 0x0

    if-eqz v0, :cond_3

    goto :goto_0

    :cond_3
    const/4 p1, 0x0

    :goto_0
    if-eqz v1, :cond_4

    goto :goto_1

    :cond_4
    const/4 p2, 0x0

    :goto_1
    const/4 v0, 0x0

    invoke-virtual {p0, p1, p2, v0, v2}, Landroidx/recyclerview/widget/RecyclerView;->Y(IILandroid/view/MotionEvent;I)Z

    :cond_5
    return-void
.end method

.method public final scrollTo(II)V
    .locals 0

    const-string p1, "RecyclerView"

    const-string p2, "RecyclerView does not support scrolling to an absolute position. Use scrollToPosition instead"

    invoke-static {p1, p2}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    return-void
.end method

.method public final sendAccessibilityEventUnchecked(Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->K()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    if-eqz v0, :cond_2

    .line 7
    .line 8
    if-eqz p1, :cond_0

    .line 9
    .line 10
    invoke-static {p1}, Lh/b;->a(Landroid/view/accessibility/AccessibilityEvent;)I

    .line 11
    .line 12
    .line 13
    move-result v0

    .line 14
    goto :goto_0

    .line 15
    :cond_0
    const/4 v0, 0x0

    .line 16
    :goto_0
    if-nez v0, :cond_1

    .line 17
    .line 18
    goto :goto_1

    .line 19
    :cond_1
    move v1, v0

    .line 20
    :goto_1
    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView;->z:I

    .line 21
    .line 22
    or-int/2addr v0, v1

    .line 23
    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView;->z:I

    .line 24
    .line 25
    const/4 v1, 0x1

    .line 26
    :cond_2
    if-eqz v1, :cond_3

    .line 27
    .line 28
    return-void

    .line 29
    :cond_3
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->sendAccessibilityEventUnchecked(Landroid/view/accessibility/AccessibilityEvent;)V

    .line 30
    .line 31
    .line 32
    return-void
.end method

.method public setAccessibilityDelegateCompat(Landroidx/recyclerview/widget/k1;)V
    .locals 0

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->m0:Landroidx/recyclerview/widget/k1;

    invoke-static {p0, p1}, Lg/v;->b(Landroid/view/View;Lg/c;)V

    return-void
.end method

.method public setAdapter(Landroidx/recyclerview/widget/i0;)V
    .locals 8

    .line 1
    const/4 v0, 0x0

    .line 2
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView;->setLayoutFrozen(Z)V

    .line 3
    .line 4
    .line 5
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 6
    .line 7
    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView;->b:Landroidx/recyclerview/widget/c1;

    .line 8
    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    invoke-virtual {v1, v2}, Landroidx/recyclerview/widget/i0;->unregisterAdapterDataObserver(Landroidx/recyclerview/widget/k0;)V

    .line 12
    .line 13
    .line 14
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 15
    .line 16
    invoke-virtual {v1, p0}, Landroidx/recyclerview/widget/i0;->onDetachedFromRecyclerView(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 17
    .line 18
    .line 19
    :cond_0
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 20
    .line 21
    if-eqz v1, :cond_1

    .line 22
    .line 23
    invoke-virtual {v1}, Landroidx/recyclerview/widget/o0;->e()V

    .line 24
    .line 25
    .line 26
    :cond_1
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 27
    .line 28
    iget-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 29
    .line 30
    if-eqz v1, :cond_2

    .line 31
    .line 32
    invoke-virtual {v1, v3}, Landroidx/recyclerview/widget/t0;->c0(Landroidx/recyclerview/widget/a1;)V

    .line 33
    .line 34
    .line 35
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 36
    .line 37
    invoke-virtual {v1, v3}, Landroidx/recyclerview/widget/t0;->d0(Landroidx/recyclerview/widget/a1;)V

    .line 38
    .line 39
    .line 40
    :cond_2
    iget-object v1, v3, Landroidx/recyclerview/widget/a1;->a:Ljava/util/ArrayList;

    .line 41
    .line 42
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 43
    .line 44
    .line 45
    invoke-virtual {v3}, Landroidx/recyclerview/widget/a1;->f()V

    .line 46
    .line 47
    .line 48
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->e:Landroidx/recyclerview/widget/b;

    .line 49
    .line 50
    iget-object v4, v1, Landroidx/recyclerview/widget/b;->b:Ljava/util/ArrayList;

    .line 51
    .line 52
    invoke-virtual {v1, v4}, Landroidx/recyclerview/widget/b;->l(Ljava/util/ArrayList;)V

    .line 53
    .line 54
    .line 55
    iget-object v4, v1, Landroidx/recyclerview/widget/b;->c:Ljava/util/ArrayList;

    .line 56
    .line 57
    invoke-virtual {v1, v4}, Landroidx/recyclerview/widget/b;->l(Ljava/util/ArrayList;)V

    .line 58
    .line 59
    .line 60
    iput v0, v1, Landroidx/recyclerview/widget/b;->f:I

    .line 61
    .line 62
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 63
    .line 64
    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 65
    .line 66
    if-eqz p1, :cond_3

    .line 67
    .line 68
    invoke-virtual {p1, v2}, Landroidx/recyclerview/widget/i0;->registerAdapterDataObserver(Landroidx/recyclerview/widget/k0;)V

    .line 69
    .line 70
    .line 71
    invoke-virtual {p1, p0}, Landroidx/recyclerview/widget/i0;->onAttachedToRecyclerView(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 72
    .line 73
    .line 74
    :cond_3
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 75
    .line 76
    if-eqz p1, :cond_4

    .line 77
    .line 78
    invoke-virtual {p1}, Landroidx/recyclerview/widget/t0;->L()V

    .line 79
    .line 80
    .line 81
    :cond_4
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 82
    .line 83
    iget-object v2, v3, Landroidx/recyclerview/widget/a1;->a:Ljava/util/ArrayList;

    .line 84
    .line 85
    invoke-virtual {v2}, Ljava/util/ArrayList;->clear()V

    .line 86
    .line 87
    .line 88
    invoke-virtual {v3}, Landroidx/recyclerview/widget/a1;->f()V

    .line 89
    .line 90
    .line 91
    const/4 v2, 0x1

    .line 92
    invoke-virtual {v3, v1, v2}, Landroidx/recyclerview/widget/a1;->e(Landroidx/recyclerview/widget/i0;Z)V

    .line 93
    .line 94
    .line 95
    invoke-virtual {v3}, Landroidx/recyclerview/widget/a1;->c()Landroidx/recyclerview/widget/z0;

    .line 96
    .line 97
    .line 98
    move-result-object v4

    .line 99
    if-eqz v1, :cond_5

    .line 100
    .line 101
    iget v1, v4, Landroidx/recyclerview/widget/z0;->b:I

    .line 102
    .line 103
    add-int/lit8 v1, v1, -0x1

    .line 104
    .line 105
    iput v1, v4, Landroidx/recyclerview/widget/z0;->b:I

    .line 106
    .line 107
    :cond_5
    iget v1, v4, Landroidx/recyclerview/widget/z0;->b:I

    .line 108
    .line 109
    if-nez v1, :cond_7

    .line 110
    .line 111
    const/4 v1, 0x0

    .line 112
    :goto_0
    iget-object v5, v4, Landroidx/recyclerview/widget/z0;->a:Landroid/util/SparseArray;

    .line 113
    .line 114
    invoke-virtual {v5}, Landroid/util/SparseArray;->size()I

    .line 115
    .line 116
    .line 117
    move-result v6

    .line 118
    if-ge v1, v6, :cond_7

    .line 119
    .line 120
    invoke-virtual {v5, v1}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    move-result-object v5

    .line 124
    check-cast v5, Landroidx/recyclerview/widget/y0;

    .line 125
    .line 126
    iget-object v6, v5, Landroidx/recyclerview/widget/y0;->a:Ljava/util/ArrayList;

    .line 127
    .line 128
    invoke-virtual {v6}, Ljava/util/ArrayList;->iterator()Ljava/util/Iterator;

    .line 129
    .line 130
    .line 131
    move-result-object v6

    .line 132
    :goto_1
    invoke-interface {v6}, Ljava/util/Iterator;->hasNext()Z

    .line 133
    .line 134
    .line 135
    move-result v7

    .line 136
    if-eqz v7, :cond_6

    .line 137
    .line 138
    invoke-interface {v6}, Ljava/util/Iterator;->next()Ljava/lang/Object;

    .line 139
    .line 140
    .line 141
    move-result-object v7

    .line 142
    check-cast v7, Landroidx/recyclerview/widget/i1;

    .line 143
    .line 144
    iget-object v7, v7, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 145
    .line 146
    invoke-static {v7}, Lb0/d;->g(Landroid/view/View;)V

    .line 147
    .line 148
    .line 149
    goto :goto_1

    .line 150
    :cond_6
    iget-object v5, v5, Landroidx/recyclerview/widget/y0;->a:Ljava/util/ArrayList;

    .line 151
    .line 152
    invoke-virtual {v5}, Ljava/util/ArrayList;->clear()V

    .line 153
    .line 154
    .line 155
    add-int/lit8 v1, v1, 0x1

    .line 156
    .line 157
    goto :goto_0

    .line 158
    :cond_7
    if-eqz p1, :cond_8

    .line 159
    .line 160
    iget p1, v4, Landroidx/recyclerview/widget/z0;->b:I

    .line 161
    .line 162
    add-int/2addr p1, v2

    .line 163
    iput p1, v4, Landroidx/recyclerview/widget/z0;->b:I

    .line 164
    .line 165
    :cond_8
    invoke-virtual {v3}, Landroidx/recyclerview/widget/a1;->d()V

    .line 166
    .line 167
    .line 168
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    .line 169
    .line 170
    iput-boolean v2, p1, Landroidx/recyclerview/widget/e1;->e:Z

    .line 171
    .line 172
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView;->S(Z)V

    .line 173
    .line 174
    .line 175
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->requestLayout()V

    .line 176
    .line 177
    .line 178
    return-void
.end method

.method public setChildDrawingOrderCallback(Landroidx/recyclerview/widget/l0;)V
    .locals 0

    if-nez p1, :cond_0

    return-void

    :cond_0
    const/4 p1, 0x0

    invoke-virtual {p0, p1}, Landroid/view/ViewGroup;->setChildrenDrawingOrderEnabled(Z)V

    return-void
.end method

.method public setClipToPadding(Z)V
    .locals 1

    .line 1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->h:Z

    .line 2
    .line 3
    if-eq p1, v0, :cond_0

    .line 4
    .line 5
    const/4 v0, 0x0

    .line 6
    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 7
    .line 8
    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 9
    .line 10
    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 11
    .line 12
    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 13
    .line 14
    :cond_0
    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView;->h:Z

    .line 15
    .line 16
    invoke-super {p0, p1}, Landroid/view/ViewGroup;->setClipToPadding(Z)V

    .line 17
    .line 18
    .line 19
    iget-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView;->u:Z

    .line 20
    .line 21
    if-eqz p1, :cond_1

    .line 22
    .line 23
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->requestLayout()V

    .line 24
    .line 25
    .line 26
    :cond_1
    return-void
.end method

.method public setEdgeEffectFactory(Landroidx/recyclerview/widget/m0;)V
    .locals 0

    .line 1
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 2
    .line 3
    .line 4
    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->G:Landroidx/recyclerview/widget/m0;

    .line 5
    .line 6
    const/4 p1, 0x0

    .line 7
    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 8
    .line 9
    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 10
    .line 11
    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 12
    .line 13
    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 14
    .line 15
    return-void
.end method

.method public setHasFixedSize(Z)V
    .locals 0

    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView;->t:Z

    return-void
.end method

.method public setItemAnimator(Landroidx/recyclerview/widget/o0;)V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    invoke-virtual {v0}, Landroidx/recyclerview/widget/o0;->e()V

    .line 6
    .line 7
    .line 8
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 9
    .line 10
    const/4 v1, 0x0

    .line 11
    iput-object v1, v0, Landroidx/recyclerview/widget/o0;->a:Landroidx/recyclerview/widget/p0;

    .line 12
    .line 13
    :cond_0
    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 14
    .line 15
    if-eqz p1, :cond_1

    .line 16
    .line 17
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->k0:Landroidx/recyclerview/widget/p0;

    .line 18
    .line 19
    iput-object v0, p1, Landroidx/recyclerview/widget/o0;->a:Landroidx/recyclerview/widget/p0;

    .line 20
    .line 21
    :cond_1
    return-void
.end method

.method public setItemViewCacheSize(I)V
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 2
    .line 3
    iput p1, v0, Landroidx/recyclerview/widget/a1;->e:I

    .line 4
    .line 5
    invoke-virtual {v0}, Landroidx/recyclerview/widget/a1;->m()V

    .line 6
    .line 7
    .line 8
    return-void
.end method

.method public setLayoutFrozen(Z)V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView;->suppressLayout(Z)V

    return-void
.end method

.method public setLayoutManager(Landroidx/recyclerview/widget/t0;)V
    .locals 7

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 2
    .line 3
    if-ne p1, v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    const/4 v0, 0x0

    .line 7
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView;->setScrollState(I)V

    .line 8
    .line 9
    .line 10
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->c0:Landroidx/recyclerview/widget/h1;

    .line 11
    .line 12
    iget-object v2, v1, Landroidx/recyclerview/widget/h1;->g:Landroidx/recyclerview/widget/RecyclerView;

    .line 13
    .line 14
    invoke-virtual {v2, v1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 15
    .line 16
    .line 17
    iget-object v1, v1, Landroidx/recyclerview/widget/h1;->c:Landroid/widget/OverScroller;

    .line 18
    .line 19
    invoke-virtual {v1}, Landroid/widget/OverScroller;->abortAnimation()V

    .line 20
    .line 21
    .line 22
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 23
    .line 24
    iget-object v2, p0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 25
    .line 26
    if-eqz v1, :cond_3

    .line 27
    .line 28
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 29
    .line 30
    if-eqz v1, :cond_1

    .line 31
    .line 32
    invoke-virtual {v1}, Landroidx/recyclerview/widget/o0;->e()V

    .line 33
    .line 34
    .line 35
    :cond_1
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 36
    .line 37
    invoke-virtual {v1, v2}, Landroidx/recyclerview/widget/t0;->c0(Landroidx/recyclerview/widget/a1;)V

    .line 38
    .line 39
    .line 40
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 41
    .line 42
    invoke-virtual {v1, v2}, Landroidx/recyclerview/widget/t0;->d0(Landroidx/recyclerview/widget/a1;)V

    .line 43
    .line 44
    .line 45
    iget-object v1, v2, Landroidx/recyclerview/widget/a1;->a:Ljava/util/ArrayList;

    .line 46
    .line 47
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 48
    .line 49
    .line 50
    invoke-virtual {v2}, Landroidx/recyclerview/widget/a1;->f()V

    .line 51
    .line 52
    .line 53
    iget-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView;->s:Z

    .line 54
    .line 55
    if-eqz v1, :cond_2

    .line 56
    .line 57
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 58
    .line 59
    iput-boolean v0, v1, Landroidx/recyclerview/widget/t0;->f:Z

    .line 60
    .line 61
    invoke-virtual {v1, p0}, Landroidx/recyclerview/widget/t0;->M(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 62
    .line 63
    .line 64
    :cond_2
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 65
    .line 66
    const/4 v3, 0x0

    .line 67
    invoke-virtual {v1, v3}, Landroidx/recyclerview/widget/t0;->p0(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 68
    .line 69
    .line 70
    iput-object v3, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 71
    .line 72
    goto :goto_0

    .line 73
    :cond_3
    iget-object v1, v2, Landroidx/recyclerview/widget/a1;->a:Ljava/util/ArrayList;

    .line 74
    .line 75
    invoke-virtual {v1}, Ljava/util/ArrayList;->clear()V

    .line 76
    .line 77
    .line 78
    invoke-virtual {v2}, Landroidx/recyclerview/widget/a1;->f()V

    .line 79
    .line 80
    .line 81
    :goto_0
    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 82
    .line 83
    iget-object v3, v1, Landroidx/recyclerview/widget/e;->b:Landroidx/recyclerview/widget/d;

    .line 84
    .line 85
    invoke-virtual {v3}, Landroidx/recyclerview/widget/d;->g()V

    .line 86
    .line 87
    .line 88
    iget-object v3, v1, Landroidx/recyclerview/widget/e;->c:Ljava/util/ArrayList;

    .line 89
    .line 90
    invoke-virtual {v3}, Ljava/util/ArrayList;->size()I

    .line 91
    .line 92
    .line 93
    move-result v4

    .line 94
    :goto_1
    add-int/lit8 v4, v4, -0x1

    .line 95
    .line 96
    iget-object v5, v1, Landroidx/recyclerview/widget/e;->a:Landroidx/recyclerview/widget/p0;

    .line 97
    .line 98
    if-ltz v4, :cond_5

    .line 99
    .line 100
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 101
    .line 102
    .line 103
    move-result-object v6

    .line 104
    check-cast v6, Landroid/view/View;

    .line 105
    .line 106
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 107
    .line 108
    .line 109
    invoke-static {v6}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 110
    .line 111
    .line 112
    move-result-object v6

    .line 113
    if-eqz v6, :cond_4

    .line 114
    .line 115
    iget-object v5, v5, Landroidx/recyclerview/widget/p0;->a:Landroidx/recyclerview/widget/RecyclerView;

    .line 116
    .line 117
    invoke-virtual {v6, v5}, Landroidx/recyclerview/widget/i1;->onLeftHiddenState(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 118
    .line 119
    .line 120
    :cond_4
    invoke-virtual {v3, v4}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 121
    .line 122
    .line 123
    goto :goto_1

    .line 124
    :cond_5
    invoke-virtual {v5}, Landroidx/recyclerview/widget/p0;->c()I

    .line 125
    .line 126
    .line 127
    move-result v1

    .line 128
    :goto_2
    iget-object v3, v5, Landroidx/recyclerview/widget/p0;->a:Landroidx/recyclerview/widget/RecyclerView;

    .line 129
    .line 130
    if-ge v0, v1, :cond_7

    .line 131
    .line 132
    invoke-virtual {v3, v0}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 133
    .line 134
    .line 135
    move-result-object v4

    .line 136
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 137
    .line 138
    .line 139
    invoke-static {v4}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 140
    .line 141
    .line 142
    move-result-object v6

    .line 143
    iget-object v3, v3, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 144
    .line 145
    if-eqz v3, :cond_6

    .line 146
    .line 147
    if-eqz v6, :cond_6

    .line 148
    .line 149
    invoke-virtual {v3, v6}, Landroidx/recyclerview/widget/i0;->onViewDetachedFromWindow(Landroidx/recyclerview/widget/i1;)V

    .line 150
    .line 151
    .line 152
    :cond_6
    invoke-virtual {v4}, Landroid/view/View;->clearAnimation()V

    .line 153
    .line 154
    .line 155
    add-int/lit8 v0, v0, 0x1

    .line 156
    .line 157
    goto :goto_2

    .line 158
    :cond_7
    invoke-virtual {v3}, Landroid/view/ViewGroup;->removeAllViews()V

    .line 159
    .line 160
    .line 161
    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 162
    .line 163
    if-eqz p1, :cond_9

    .line 164
    .line 165
    iget-object v0, p1, Landroidx/recyclerview/widget/t0;->b:Landroidx/recyclerview/widget/RecyclerView;

    .line 166
    .line 167
    if-nez v0, :cond_8

    .line 168
    .line 169
    invoke-virtual {p1, p0}, Landroidx/recyclerview/widget/t0;->p0(Landroidx/recyclerview/widget/RecyclerView;)V

    .line 170
    .line 171
    .line 172
    iget-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView;->s:Z

    .line 173
    .line 174
    if-eqz p1, :cond_9

    .line 175
    .line 176
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 177
    .line 178
    const/4 v0, 0x1

    .line 179
    iput-boolean v0, p1, Landroidx/recyclerview/widget/t0;->f:Z

    .line 180
    .line 181
    goto :goto_3

    .line 182
    :cond_8
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 183
    .line 184
    new-instance v1, Ljava/lang/StringBuilder;

    .line 185
    .line 186
    const-string v2, "LayoutManager "

    .line 187
    .line 188
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 189
    .line 190
    .line 191
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 192
    .line 193
    .line 194
    const-string v2, " is already attached to a RecyclerView:"

    .line 195
    .line 196
    invoke-virtual {v1, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 197
    .line 198
    .line 199
    iget-object p1, p1, Landroidx/recyclerview/widget/t0;->b:Landroidx/recyclerview/widget/RecyclerView;

    .line 200
    .line 201
    invoke-static {p1, v1}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 202
    .line 203
    .line 204
    move-result-object p1

    .line 205
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 206
    .line 207
    .line 208
    throw v0

    .line 209
    :cond_9
    :goto_3
    invoke-virtual {v2}, Landroidx/recyclerview/widget/a1;->m()V

    .line 210
    .line 211
    .line 212
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->requestLayout()V

    .line 213
    .line 214
    .line 215
    return-void
.end method

.method public setLayoutTransition(Landroid/animation/LayoutTransition;)V
    .locals 1
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    if-nez p1, :cond_0

    const/4 p1, 0x0

    invoke-super {p0, p1}, Landroid/view/ViewGroup;->setLayoutTransition(Landroid/animation/LayoutTransition;)V

    return-void

    :cond_0
    new-instance p1, Ljava/lang/IllegalArgumentException;

    const-string v0, "Providing a LayoutTransition into RecyclerView is not supported. Please use setItemAnimator() instead for animating changes to the items in this RecyclerView"

    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    throw p1
.end method

.method public setNestedScrollingEnabled(Z)V
    .locals 2

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView;->getScrollingChildHelper()Lg/f;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    iget-boolean v1, v0, Lg/f;->d:Z

    .line 6
    .line 7
    if-eqz v1, :cond_0

    .line 8
    .line 9
    sget-object v1, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 10
    .line 11
    iget-object v1, v0, Lg/f;->c:Landroid/view/View;

    .line 12
    .line 13
    invoke-static {v1}, Lg/n;->z(Landroid/view/View;)V

    .line 14
    .line 15
    .line 16
    :cond_0
    iput-boolean p1, v0, Lg/f;->d:Z

    .line 17
    .line 18
    return-void
.end method

.method public setOnFlingListener(Landroidx/recyclerview/widget/v0;)V
    .locals 0

    return-void
.end method

.method public setOnScrollListener(Landroidx/recyclerview/widget/x0;)V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    iput-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->g0:Landroidx/recyclerview/widget/x0;

    return-void
.end method

.method public setPreserveFocusAfterLayout(Z)V
    .locals 0

    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView;->b0:Z

    return-void
.end method

.method public setRecycledViewPool(Landroidx/recyclerview/widget/z0;)V
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 2
    .line 3
    iget-object v1, v0, Landroidx/recyclerview/widget/a1;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 4
    .line 5
    iget-object v2, v1, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 6
    .line 7
    const/4 v3, 0x0

    .line 8
    invoke-virtual {v0, v2, v3}, Landroidx/recyclerview/widget/a1;->e(Landroidx/recyclerview/widget/i0;Z)V

    .line 9
    .line 10
    .line 11
    iget-object v2, v0, Landroidx/recyclerview/widget/a1;->g:Landroidx/recyclerview/widget/z0;

    .line 12
    .line 13
    if-eqz v2, :cond_0

    .line 14
    .line 15
    iget v3, v2, Landroidx/recyclerview/widget/z0;->b:I

    .line 16
    .line 17
    add-int/lit8 v3, v3, -0x1

    .line 18
    .line 19
    iput v3, v2, Landroidx/recyclerview/widget/z0;->b:I

    .line 20
    .line 21
    :cond_0
    iput-object p1, v0, Landroidx/recyclerview/widget/a1;->g:Landroidx/recyclerview/widget/z0;

    .line 22
    .line 23
    if-eqz p1, :cond_1

    .line 24
    .line 25
    invoke-virtual {v1}, Landroidx/recyclerview/widget/RecyclerView;->getAdapter()Landroidx/recyclerview/widget/i0;

    .line 26
    .line 27
    .line 28
    move-result-object p1

    .line 29
    if-eqz p1, :cond_1

    .line 30
    .line 31
    iget-object p1, v0, Landroidx/recyclerview/widget/a1;->g:Landroidx/recyclerview/widget/z0;

    .line 32
    .line 33
    iget v1, p1, Landroidx/recyclerview/widget/z0;->b:I

    .line 34
    .line 35
    add-int/lit8 v1, v1, 0x1

    .line 36
    .line 37
    iput v1, p1, Landroidx/recyclerview/widget/z0;->b:I

    .line 38
    .line 39
    :cond_1
    invoke-virtual {v0}, Landroidx/recyclerview/widget/a1;->d()V

    .line 40
    .line 41
    .line 42
    return-void
.end method

.method public setRecyclerListener(Landroidx/recyclerview/widget/b1;)V
    .locals 0
    .annotation runtime Ljava/lang/Deprecated;
    .end annotation

    return-void
.end method

.method public setScrollState(I)V
    .locals 3

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView;->M:I

    .line 2
    .line 3
    if-ne p1, v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    sget-boolean v0, Landroidx/recyclerview/widget/RecyclerView;->z0:Z

    .line 7
    .line 8
    if-eqz v0, :cond_1

    .line 9
    .line 10
    new-instance v0, Ljava/lang/StringBuilder;

    .line 11
    .line 12
    const-string v1, "setting scroll state to "

    .line 13
    .line 14
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 15
    .line 16
    .line 17
    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 18
    .line 19
    .line 20
    const-string v1, " from "

    .line 21
    .line 22
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 23
    .line 24
    .line 25
    iget v1, p0, Landroidx/recyclerview/widget/RecyclerView;->M:I

    .line 26
    .line 27
    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 28
    .line 29
    .line 30
    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 31
    .line 32
    .line 33
    move-result-object v0

    .line 34
    new-instance v1, Ljava/lang/Exception;

    .line 35
    .line 36
    invoke-direct {v1}, Ljava/lang/Exception;-><init>()V

    .line 37
    .line 38
    .line 39
    const-string v2, "RecyclerView"

    .line 40
    .line 41
    invoke-static {v2, v0, v1}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;Ljava/lang/Throwable;)I

    .line 42
    .line 43
    .line 44
    :cond_1
    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView;->M:I

    .line 45
    .line 46
    const/4 v0, 0x2

    .line 47
    if-eq p1, v0, :cond_2

    .line 48
    .line 49
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->c0:Landroidx/recyclerview/widget/h1;

    .line 50
    .line 51
    iget-object v1, v0, Landroidx/recyclerview/widget/h1;->g:Landroidx/recyclerview/widget/RecyclerView;

    .line 52
    .line 53
    invoke-virtual {v1, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 54
    .line 55
    .line 56
    iget-object v0, v0, Landroidx/recyclerview/widget/h1;->c:Landroid/widget/OverScroller;

    .line 57
    .line 58
    invoke-virtual {v0}, Landroid/widget/OverScroller;->abortAnimation()V

    .line 59
    .line 60
    .line 61
    :cond_2
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 62
    .line 63
    if-eqz v0, :cond_3

    .line 64
    .line 65
    invoke-virtual {v0, p1}, Landroidx/recyclerview/widget/t0;->b0(I)V

    .line 66
    .line 67
    .line 68
    :cond_3
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->h0:Ljava/util/ArrayList;

    .line 69
    .line 70
    if-eqz p1, :cond_4

    .line 71
    .line 72
    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    .line 73
    .line 74
    .line 75
    move-result p1

    .line 76
    :goto_0
    add-int/lit8 p1, p1, -0x1

    .line 77
    .line 78
    if-ltz p1, :cond_4

    .line 79
    .line 80
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->h0:Ljava/util/ArrayList;

    .line 81
    .line 82
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 83
    .line 84
    .line 85
    move-result-object v0

    .line 86
    check-cast v0, Landroidx/recyclerview/widget/x0;

    .line 87
    .line 88
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 89
    .line 90
    .line 91
    goto :goto_0

    .line 92
    :cond_4
    return-void
.end method

.method public setScrollingTouchSlop(I)V
    .locals 3

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v0

    invoke-static {v0}, Landroid/view/ViewConfiguration;->get(Landroid/content/Context;)Landroid/view/ViewConfiguration;

    move-result-object v0

    if-eqz p1, :cond_1

    const/4 v1, 0x1

    if-eq p1, v1, :cond_0

    new-instance v1, Ljava/lang/StringBuilder;

    const-string v2, "setScrollingTouchSlop(): bad argument constant "

    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    const-string p1, "; using default value"

    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {v1}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object p1

    const-string v1, "RecyclerView"

    invoke-static {v1, p1}, Landroid/util/Log;->w(Ljava/lang/String;Ljava/lang/String;)I

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledPagingTouchSlop()I

    move-result p1

    goto :goto_1

    :cond_1
    :goto_0
    invoke-virtual {v0}, Landroid/view/ViewConfiguration;->getScaledTouchSlop()I

    move-result p1

    :goto_1
    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView;->T:I

    return-void
.end method

.method public setViewCacheExtension(Landroidx/recyclerview/widget/g1;)V
    .locals 0

    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    return-void
.end method

.method public final startNestedScroll(I)Z
    .locals 2

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView;->getScrollingChildHelper()Lg/f;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-virtual {v0, p1, v1}, Lg/f;->d(II)Z

    .line 7
    .line 8
    .line 9
    move-result p1

    .line 10
    return p1
.end method

.method public final stopNestedScroll()V
    .locals 2

    .line 1
    invoke-direct {p0}, Landroidx/recyclerview/widget/RecyclerView;->getScrollingChildHelper()Lg/f;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-virtual {v0, v1}, Lg/f;->e(I)V

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public final suppressLayout(Z)V
    .locals 9

    .line 1
    iget-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->x:Z

    .line 2
    .line 3
    if-eq p1, v0, :cond_2

    .line 4
    .line 5
    const-string v0, "Do not suppressLayout in layout or scroll"

    .line 6
    .line 7
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView;->h(Ljava/lang/String;)V

    .line 8
    .line 9
    .line 10
    const/4 v0, 0x0

    .line 11
    if-nez p1, :cond_1

    .line 12
    .line 13
    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->x:Z

    .line 14
    .line 15
    iget-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView;->w:Z

    .line 16
    .line 17
    if-eqz p1, :cond_0

    .line 18
    .line 19
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 20
    .line 21
    if-eqz p1, :cond_0

    .line 22
    .line 23
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 24
    .line 25
    if-eqz p1, :cond_0

    .line 26
    .line 27
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->requestLayout()V

    .line 28
    .line 29
    .line 30
    :cond_0
    iput-boolean v0, p0, Landroidx/recyclerview/widget/RecyclerView;->w:Z

    .line 31
    .line 32
    goto :goto_0

    .line 33
    :cond_1
    invoke-static {}, Landroid/os/SystemClock;->uptimeMillis()J

    .line 34
    .line 35
    .line 36
    move-result-wide v3

    .line 37
    const/4 v5, 0x3

    .line 38
    const/4 v6, 0x0

    .line 39
    const/4 v7, 0x0

    .line 40
    const/4 v8, 0x0

    .line 41
    move-wide v1, v3

    .line 42
    invoke-static/range {v1 .. v8}, Landroid/view/MotionEvent;->obtain(JJIFFI)Landroid/view/MotionEvent;

    .line 43
    .line 44
    .line 45
    move-result-object p1

    .line 46
    invoke-virtual {p0, p1}, Landroidx/recyclerview/widget/RecyclerView;->onTouchEvent(Landroid/view/MotionEvent;)Z

    .line 47
    .line 48
    .line 49
    const/4 p1, 0x1

    .line 50
    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView;->x:Z

    .line 51
    .line 52
    iput-boolean p1, p0, Landroidx/recyclerview/widget/RecyclerView;->y:Z

    .line 53
    .line 54
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/RecyclerView;->setScrollState(I)V

    .line 55
    .line 56
    .line 57
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->c0:Landroidx/recyclerview/widget/h1;

    .line 58
    .line 59
    iget-object v0, p1, Landroidx/recyclerview/widget/h1;->g:Landroidx/recyclerview/widget/RecyclerView;

    .line 60
    .line 61
    invoke-virtual {v0, p1}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 62
    .line 63
    .line 64
    iget-object p1, p1, Landroidx/recyclerview/widget/h1;->c:Landroid/widget/OverScroller;

    .line 65
    .line 66
    invoke-virtual {p1}, Landroid/widget/OverScroller;->abortAnimation()V

    .line 67
    .line 68
    .line 69
    :cond_2
    :goto_0
    return-void
.end method

.method public final t(II)V
    .locals 2

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/RecyclerView;->F:I

    add-int/lit8 v0, v0, 0x1

    iput v0, p0, Landroidx/recyclerview/widget/RecyclerView;->F:I

    invoke-virtual {p0}, Landroid/view/View;->getScrollX()I

    move-result v0

    invoke-virtual {p0}, Landroid/view/View;->getScrollY()I

    move-result v1

    sub-int p1, v0, p1

    sub-int p2, v1, p2

    invoke-virtual {p0, v0, v1, p1, p2}, Landroid/view/View;->onScrollChanged(IIII)V

    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->g0:Landroidx/recyclerview/widget/x0;

    if-eqz p1, :cond_0

    invoke-virtual {p1, p0}, Landroidx/recyclerview/widget/x0;->a(Landroidx/recyclerview/widget/RecyclerView;)V

    :cond_0
    iget-object p1, p0, Landroidx/recyclerview/widget/RecyclerView;->h0:Ljava/util/ArrayList;

    if-eqz p1, :cond_1

    invoke-virtual {p1}, Ljava/util/ArrayList;->size()I

    move-result p1

    :goto_0
    add-int/lit8 p1, p1, -0x1

    if-ltz p1, :cond_1

    iget-object p2, p0, Landroidx/recyclerview/widget/RecyclerView;->h0:Ljava/util/ArrayList;

    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object p2

    check-cast p2, Landroidx/recyclerview/widget/x0;

    invoke-virtual {p2, p0}, Landroidx/recyclerview/widget/x0;->a(Landroidx/recyclerview/widget/RecyclerView;)V

    goto :goto_0

    :cond_1
    iget p1, p0, Landroidx/recyclerview/widget/RecyclerView;->F:I

    add-int/lit8 p1, p1, -0x1

    iput p1, p0, Landroidx/recyclerview/widget/RecyclerView;->F:I

    return-void
.end method

.method public final u()V
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->G:Landroidx/recyclerview/widget/m0;

    .line 7
    .line 8
    check-cast v0, Landroidx/recyclerview/widget/f1;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    new-instance v0, Landroid/widget/EdgeEffect;

    .line 14
    .line 15
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-direct {v0, v1}, Landroid/widget/EdgeEffect;-><init>(Landroid/content/Context;)V

    .line 20
    .line 21
    .line 22
    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 23
    .line 24
    iget-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView;->h:Z

    .line 25
    .line 26
    if-eqz v1, :cond_1

    .line 27
    .line 28
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    sub-int/2addr v1, v2

    .line 37
    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    sub-int/2addr v1, v2

    .line 42
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 47
    .line 48
    .line 49
    move-result v3

    .line 50
    sub-int/2addr v2, v3

    .line 51
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 52
    .line 53
    .line 54
    move-result v3

    .line 55
    sub-int/2addr v2, v3

    .line 56
    goto :goto_0

    .line 57
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 62
    .line 63
    .line 64
    move-result v2

    .line 65
    :goto_0
    invoke-virtual {v0, v1, v2}, Landroid/widget/EdgeEffect;->setSize(II)V

    .line 66
    .line 67
    .line 68
    return-void
.end method

.method public final v()V
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->G:Landroidx/recyclerview/widget/m0;

    .line 7
    .line 8
    check-cast v0, Landroidx/recyclerview/widget/f1;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    new-instance v0, Landroid/widget/EdgeEffect;

    .line 14
    .line 15
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-direct {v0, v1}, Landroid/widget/EdgeEffect;-><init>(Landroid/content/Context;)V

    .line 20
    .line 21
    .line 22
    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 23
    .line 24
    iget-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView;->h:Z

    .line 25
    .line 26
    if-eqz v1, :cond_1

    .line 27
    .line 28
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    sub-int/2addr v1, v2

    .line 37
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    sub-int/2addr v1, v2

    .line 42
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 47
    .line 48
    .line 49
    move-result v3

    .line 50
    sub-int/2addr v2, v3

    .line 51
    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 52
    .line 53
    .line 54
    move-result v3

    .line 55
    sub-int/2addr v2, v3

    .line 56
    goto :goto_0

    .line 57
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 62
    .line 63
    .line 64
    move-result v2

    .line 65
    :goto_0
    invoke-virtual {v0, v1, v2}, Landroid/widget/EdgeEffect;->setSize(II)V

    .line 66
    .line 67
    .line 68
    return-void
.end method

.method public final w()V
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->G:Landroidx/recyclerview/widget/m0;

    .line 7
    .line 8
    check-cast v0, Landroidx/recyclerview/widget/f1;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    new-instance v0, Landroid/widget/EdgeEffect;

    .line 14
    .line 15
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-direct {v0, v1}, Landroid/widget/EdgeEffect;-><init>(Landroid/content/Context;)V

    .line 20
    .line 21
    .line 22
    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 23
    .line 24
    iget-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView;->h:Z

    .line 25
    .line 26
    if-eqz v1, :cond_1

    .line 27
    .line 28
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    sub-int/2addr v1, v2

    .line 37
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    sub-int/2addr v1, v2

    .line 42
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 47
    .line 48
    .line 49
    move-result v3

    .line 50
    sub-int/2addr v2, v3

    .line 51
    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 52
    .line 53
    .line 54
    move-result v3

    .line 55
    sub-int/2addr v2, v3

    .line 56
    goto :goto_0

    .line 57
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 62
    .line 63
    .line 64
    move-result v2

    .line 65
    :goto_0
    invoke-virtual {v0, v1, v2}, Landroid/widget/EdgeEffect;->setSize(II)V

    .line 66
    .line 67
    .line 68
    return-void
.end method

.method public final x()V
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    return-void

    .line 6
    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->G:Landroidx/recyclerview/widget/m0;

    .line 7
    .line 8
    check-cast v0, Landroidx/recyclerview/widget/f1;

    .line 9
    .line 10
    invoke-virtual {v0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 11
    .line 12
    .line 13
    new-instance v0, Landroid/widget/EdgeEffect;

    .line 14
    .line 15
    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 16
    .line 17
    .line 18
    move-result-object v1

    .line 19
    invoke-direct {v0, v1}, Landroid/widget/EdgeEffect;-><init>(Landroid/content/Context;)V

    .line 20
    .line 21
    .line 22
    iput-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 23
    .line 24
    iget-boolean v1, p0, Landroidx/recyclerview/widget/RecyclerView;->h:Z

    .line 25
    .line 26
    if-eqz v1, :cond_1

    .line 27
    .line 28
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 29
    .line 30
    .line 31
    move-result v1

    .line 32
    invoke-virtual {p0}, Landroid/view/View;->getPaddingLeft()I

    .line 33
    .line 34
    .line 35
    move-result v2

    .line 36
    sub-int/2addr v1, v2

    .line 37
    invoke-virtual {p0}, Landroid/view/View;->getPaddingRight()I

    .line 38
    .line 39
    .line 40
    move-result v2

    .line 41
    sub-int/2addr v1, v2

    .line 42
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 43
    .line 44
    .line 45
    move-result v2

    .line 46
    invoke-virtual {p0}, Landroid/view/View;->getPaddingTop()I

    .line 47
    .line 48
    .line 49
    move-result v3

    .line 50
    sub-int/2addr v2, v3

    .line 51
    invoke-virtual {p0}, Landroid/view/View;->getPaddingBottom()I

    .line 52
    .line 53
    .line 54
    move-result v3

    .line 55
    sub-int/2addr v2, v3

    .line 56
    goto :goto_0

    .line 57
    :cond_1
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredWidth()I

    .line 58
    .line 59
    .line 60
    move-result v1

    .line 61
    invoke-virtual {p0}, Landroid/view/View;->getMeasuredHeight()I

    .line 62
    .line 63
    .line 64
    move-result v2

    .line 65
    :goto_0
    invoke-virtual {v0, v1, v2}, Landroid/widget/EdgeEffect;->setSize(II)V

    .line 66
    .line 67
    .line 68
    return-void
.end method

.method public final y()Ljava/lang/String;
    .locals 2

    .line 1
    new-instance v0, Ljava/lang/StringBuilder;

    const-string v1, " "

    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-super {p0}, Landroid/view/ViewGroup;->toString()Ljava/lang/String;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    const-string v1, ", adapter:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", layout:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    iget-object v1, p0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    const-string v1, ", context:"

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    invoke-virtual {p0}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object v1

    invoke-virtual {v0, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    return-object v0
.end method

.method public final z(Landroidx/recyclerview/widget/e1;)V
    .locals 2

    .line 1
    invoke-virtual {p0}, Landroidx/recyclerview/widget/RecyclerView;->getScrollState()I

    move-result v0

    const/4 v1, 0x2

    if-ne v0, v1, :cond_0

    iget-object v0, p0, Landroidx/recyclerview/widget/RecyclerView;->c0:Landroidx/recyclerview/widget/h1;

    iget-object v0, v0, Landroidx/recyclerview/widget/h1;->c:Landroid/widget/OverScroller;

    invoke-virtual {v0}, Landroid/widget/OverScroller;->getFinalX()I

    invoke-virtual {v0}, Landroid/widget/OverScroller;->getCurrX()I

    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    invoke-virtual {v0}, Landroid/widget/OverScroller;->getFinalY()I

    invoke-virtual {v0}, Landroid/widget/OverScroller;->getCurrY()I

    goto :goto_0

    :cond_0
    invoke-virtual {p1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    :goto_0
    return-void
.end method
