.class public final Landroidx/recyclerview/widget/a1;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Ljava/util/ArrayList;

.field public b:Ljava/util/ArrayList;

.field public final c:Ljava/util/ArrayList;

.field public final d:Ljava/util/List;

.field public e:I

.field public f:I

.field public g:Landroidx/recyclerview/widget/z0;

.field public final synthetic h:Landroidx/recyclerview/widget/RecyclerView;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 1

    iput-object p1, p0, Landroidx/recyclerview/widget/a1;->h:Landroidx/recyclerview/widget/RecyclerView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance p1, Ljava/util/ArrayList;

    invoke-direct {p1}, Ljava/util/ArrayList;-><init>()V

    iput-object p1, p0, Landroidx/recyclerview/widget/a1;->a:Ljava/util/ArrayList;

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/recyclerview/widget/a1;->b:Ljava/util/ArrayList;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/a1;->c:Ljava/util/ArrayList;

    invoke-static {p1}, Ljava/util/Collections;->unmodifiableList(Ljava/util/List;)Ljava/util/List;

    move-result-object p1

    iput-object p1, p0, Landroidx/recyclerview/widget/a1;->d:Ljava/util/List;

    const/4 p1, 0x2

    iput p1, p0, Landroidx/recyclerview/widget/a1;->e:I

    iput p1, p0, Landroidx/recyclerview/widget/a1;->f:I

    return-void
.end method


# virtual methods
.method public final a(Landroidx/recyclerview/widget/i1;Z)V
    .locals 5

    .line 1
    invoke-static {p1}, Landroidx/recyclerview/widget/RecyclerView;->i(Landroidx/recyclerview/widget/i1;)V

    .line 2
    .line 3
    .line 4
    iget-object v0, p1, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 5
    .line 6
    iget-object v1, p0, Landroidx/recyclerview/widget/a1;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 7
    .line 8
    iget-object v2, v1, Landroidx/recyclerview/widget/RecyclerView;->m0:Landroidx/recyclerview/widget/k1;

    .line 9
    .line 10
    const/4 v3, 0x0

    .line 11
    if-eqz v2, :cond_1

    .line 12
    .line 13
    iget-object v2, v2, Landroidx/recyclerview/widget/k1;->e:Landroidx/recyclerview/widget/j1;

    .line 14
    .line 15
    instance-of v4, v2, Landroidx/recyclerview/widget/j1;

    .line 16
    .line 17
    if-eqz v4, :cond_0

    .line 18
    .line 19
    iget-object v2, v2, Landroidx/recyclerview/widget/j1;->e:Ljava/util/WeakHashMap;

    .line 20
    .line 21
    invoke-virtual {v2, v0}, Ljava/util/WeakHashMap;->remove(Ljava/lang/Object;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v2

    .line 25
    check-cast v2, Lg/c;

    .line 26
    .line 27
    goto :goto_0

    .line 28
    :cond_0
    move-object v2, v3

    .line 29
    :goto_0
    invoke-static {v0, v2}, Lg/v;->b(Landroid/view/View;Lg/c;)V

    .line 30
    .line 31
    .line 32
    :cond_1
    if-eqz p2, :cond_5

    .line 33
    .line 34
    iget-object p2, v1, Landroidx/recyclerview/widget/RecyclerView;->o:Ljava/util/ArrayList;

    .line 35
    .line 36
    invoke-virtual {p2}, Ljava/util/ArrayList;->size()I

    .line 37
    .line 38
    .line 39
    move-result v0

    .line 40
    if-gtz v0, :cond_4

    .line 41
    .line 42
    iget-object p2, v1, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 43
    .line 44
    if-eqz p2, :cond_2

    .line 45
    .line 46
    invoke-virtual {p2, p1}, Landroidx/recyclerview/widget/i0;->onViewRecycled(Landroidx/recyclerview/widget/i1;)V

    .line 47
    .line 48
    .line 49
    :cond_2
    iget-object p2, v1, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    .line 50
    .line 51
    if-eqz p2, :cond_3

    .line 52
    .line 53
    iget-object p2, v1, Landroidx/recyclerview/widget/RecyclerView;->g:Landroidx/recyclerview/widget/t1;

    .line 54
    .line 55
    invoke-virtual {p2, p1}, Landroidx/recyclerview/widget/t1;->n(Landroidx/recyclerview/widget/i1;)V

    .line 56
    .line 57
    .line 58
    :cond_3
    sget-boolean p2, Landroidx/recyclerview/widget/RecyclerView;->z0:Z

    .line 59
    .line 60
    if-eqz p2, :cond_5

    .line 61
    .line 62
    new-instance p2, Ljava/lang/StringBuilder;

    .line 63
    .line 64
    const-string v0, "dispatchViewRecycled: "

    .line 65
    .line 66
    invoke-direct {p2, v0}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 67
    .line 68
    .line 69
    invoke-virtual {p2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 70
    .line 71
    .line 72
    invoke-virtual {p2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 73
    .line 74
    .line 75
    move-result-object p2

    .line 76
    const-string v0, "RecyclerView"

    .line 77
    .line 78
    invoke-static {v0, p2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 79
    .line 80
    .line 81
    goto :goto_1

    .line 82
    :cond_4
    const/4 p1, 0x0

    .line 83
    invoke-virtual {p2, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 84
    .line 85
    .line 86
    move-result-object p1

    .line 87
    invoke-static {p1}, Landroidx/recyclerview/widget/c;->c(Ljava/lang/Object;)V

    .line 88
    .line 89
    .line 90
    throw v3

    .line 91
    :cond_5
    :goto_1
    iput-object v3, p1, Landroidx/recyclerview/widget/i1;->mBindingAdapter:Landroidx/recyclerview/widget/i0;

    .line 92
    .line 93
    iput-object v3, p1, Landroidx/recyclerview/widget/i1;->mOwnerRecyclerView:Landroidx/recyclerview/widget/RecyclerView;

    .line 94
    .line 95
    invoke-virtual {p0}, Landroidx/recyclerview/widget/a1;->c()Landroidx/recyclerview/widget/z0;

    .line 96
    .line 97
    .line 98
    move-result-object p2

    .line 99
    invoke-virtual {p2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 100
    .line 101
    .line 102
    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->getItemViewType()I

    .line 103
    .line 104
    .line 105
    move-result v0

    .line 106
    invoke-virtual {p2, v0}, Landroidx/recyclerview/widget/z0;->a(I)Landroidx/recyclerview/widget/y0;

    .line 107
    .line 108
    .line 109
    move-result-object v1

    .line 110
    iget-object v1, v1, Landroidx/recyclerview/widget/y0;->a:Ljava/util/ArrayList;

    .line 111
    .line 112
    iget-object p2, p2, Landroidx/recyclerview/widget/z0;->a:Landroid/util/SparseArray;

    .line 113
    .line 114
    invoke-virtual {p2, v0}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 115
    .line 116
    .line 117
    move-result-object p2

    .line 118
    check-cast p2, Landroidx/recyclerview/widget/y0;

    .line 119
    .line 120
    iget p2, p2, Landroidx/recyclerview/widget/y0;->b:I

    .line 121
    .line 122
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 123
    .line 124
    .line 125
    move-result v0

    .line 126
    if-gt p2, v0, :cond_6

    .line 127
    .line 128
    iget-object p1, p1, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 129
    .line 130
    invoke-static {p1}, Lb0/d;->g(Landroid/view/View;)V

    .line 131
    .line 132
    .line 133
    goto :goto_3

    .line 134
    :cond_6
    sget-boolean p2, Landroidx/recyclerview/widget/RecyclerView;->y0:Z

    .line 135
    .line 136
    if-eqz p2, :cond_8

    .line 137
    .line 138
    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 139
    .line 140
    .line 141
    move-result p2

    .line 142
    if-nez p2, :cond_7

    .line 143
    .line 144
    goto :goto_2

    .line 145
    :cond_7
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 146
    .line 147
    const-string p2, "this scrap item already exists"

    .line 148
    .line 149
    invoke-direct {p1, p2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 150
    .line 151
    .line 152
    throw p1

    .line 153
    :cond_8
    :goto_2
    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->resetInternal()V

    .line 154
    .line 155
    .line 156
    invoke-virtual {v1, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 157
    .line 158
    .line 159
    :goto_3
    return-void
.end method

.method public final b(I)I
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/a1;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 2
    .line 3
    if-ltz p1, :cond_1

    .line 4
    .line 5
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    .line 6
    .line 7
    invoke-virtual {v1}, Landroidx/recyclerview/widget/e1;->b()I

    .line 8
    .line 9
    .line 10
    move-result v1

    .line 11
    if-ge p1, v1, :cond_1

    .line 12
    .line 13
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    .line 14
    .line 15
    iget-boolean v1, v1, Landroidx/recyclerview/widget/e1;->f:Z

    .line 16
    .line 17
    if-nez v1, :cond_0

    .line 18
    .line 19
    return p1

    .line 20
    :cond_0
    iget-object v0, v0, Landroidx/recyclerview/widget/RecyclerView;->e:Landroidx/recyclerview/widget/b;

    .line 21
    .line 22
    const/4 v1, 0x0

    .line 23
    invoke-virtual {v0, p1, v1}, Landroidx/recyclerview/widget/b;->f(II)I

    .line 24
    .line 25
    .line 26
    move-result p1

    .line 27
    return p1

    .line 28
    :cond_1
    new-instance v1, Ljava/lang/IndexOutOfBoundsException;

    .line 29
    .line 30
    new-instance v2, Ljava/lang/StringBuilder;

    .line 31
    .line 32
    const-string v3, "invalid position "

    .line 33
    .line 34
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 35
    .line 36
    .line 37
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 38
    .line 39
    .line 40
    const-string p1, ". State item count is "

    .line 41
    .line 42
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 43
    .line 44
    .line 45
    iget-object p1, v0, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    .line 46
    .line 47
    invoke-virtual {p1}, Landroidx/recyclerview/widget/e1;->b()I

    .line 48
    .line 49
    .line 50
    move-result p1

    .line 51
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 52
    .line 53
    .line 54
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->y()Ljava/lang/String;

    .line 55
    .line 56
    .line 57
    move-result-object p1

    .line 58
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 59
    .line 60
    .line 61
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 62
    .line 63
    .line 64
    move-result-object p1

    .line 65
    invoke-direct {v1, p1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 66
    .line 67
    .line 68
    throw v1
.end method

.method public final c()Landroidx/recyclerview/widget/z0;
    .locals 1

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/a1;->g:Landroidx/recyclerview/widget/z0;

    if-nez v0, :cond_0

    new-instance v0, Landroidx/recyclerview/widget/z0;

    invoke-direct {v0}, Landroidx/recyclerview/widget/z0;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/a1;->g:Landroidx/recyclerview/widget/z0;

    invoke-virtual {p0}, Landroidx/recyclerview/widget/a1;->d()V

    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/a1;->g:Landroidx/recyclerview/widget/z0;

    return-object v0
.end method

.method public final d()V
    .locals 2

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/a1;->g:Landroidx/recyclerview/widget/z0;

    .line 2
    .line 3
    if-eqz v0, :cond_0

    .line 4
    .line 5
    iget-object v0, p0, Landroidx/recyclerview/widget/a1;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 6
    .line 7
    iget-object v1, v0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 8
    .line 9
    if-eqz v1, :cond_0

    .line 10
    .line 11
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->isAttachedToWindow()Z

    .line 12
    .line 13
    .line 14
    move-result v1

    .line 15
    if-eqz v1, :cond_0

    .line 16
    .line 17
    iget-object v1, p0, Landroidx/recyclerview/widget/a1;->g:Landroidx/recyclerview/widget/z0;

    .line 18
    .line 19
    iget-object v0, v0, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 20
    .line 21
    iget-object v1, v1, Landroidx/recyclerview/widget/z0;->c:Ljava/util/Set;

    .line 22
    .line 23
    invoke-interface {v1, v0}, Ljava/util/Set;->add(Ljava/lang/Object;)Z

    .line 24
    .line 25
    .line 26
    :cond_0
    return-void
.end method

.method public final e(Landroidx/recyclerview/widget/i0;Z)V
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/a1;->g:Landroidx/recyclerview/widget/z0;

    .line 2
    .line 3
    if-eqz v0, :cond_1

    .line 4
    .line 5
    iget-object v1, v0, Landroidx/recyclerview/widget/z0;->c:Ljava/util/Set;

    .line 6
    .line 7
    invoke-interface {v1, p1}, Ljava/util/Set;->remove(Ljava/lang/Object;)Z

    .line 8
    .line 9
    .line 10
    invoke-interface {v1}, Ljava/util/Set;->size()I

    .line 11
    .line 12
    .line 13
    move-result p1

    .line 14
    if-nez p1, :cond_1

    .line 15
    .line 16
    if-nez p2, :cond_1

    .line 17
    .line 18
    const/4 p1, 0x0

    .line 19
    const/4 p2, 0x0

    .line 20
    :goto_0
    iget-object v1, v0, Landroidx/recyclerview/widget/z0;->a:Landroid/util/SparseArray;

    .line 21
    .line 22
    invoke-virtual {v1}, Landroid/util/SparseArray;->size()I

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    if-ge p2, v2, :cond_1

    .line 27
    .line 28
    invoke-virtual {v1, p2}, Landroid/util/SparseArray;->keyAt(I)I

    .line 29
    .line 30
    .line 31
    move-result v2

    .line 32
    invoke-virtual {v1, v2}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 33
    .line 34
    .line 35
    move-result-object v1

    .line 36
    check-cast v1, Landroidx/recyclerview/widget/y0;

    .line 37
    .line 38
    iget-object v1, v1, Landroidx/recyclerview/widget/y0;->a:Ljava/util/ArrayList;

    .line 39
    .line 40
    const/4 v2, 0x0

    .line 41
    :goto_1
    invoke-virtual {v1}, Ljava/util/ArrayList;->size()I

    .line 42
    .line 43
    .line 44
    move-result v3

    .line 45
    if-ge v2, v3, :cond_0

    .line 46
    .line 47
    invoke-virtual {v1, v2}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 48
    .line 49
    .line 50
    move-result-object v3

    .line 51
    check-cast v3, Landroidx/recyclerview/widget/i1;

    .line 52
    .line 53
    iget-object v3, v3, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 54
    .line 55
    invoke-static {v3}, Lb0/d;->g(Landroid/view/View;)V

    .line 56
    .line 57
    .line 58
    add-int/lit8 v2, v2, 0x1

    .line 59
    .line 60
    goto :goto_1

    .line 61
    :cond_0
    add-int/lit8 p2, p2, 0x1

    .line 62
    .line 63
    goto :goto_0

    .line 64
    :cond_1
    return-void
.end method

.method public final f()V
    .locals 3

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/a1;->c:Ljava/util/ArrayList;

    .line 2
    .line 3
    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    .line 4
    .line 5
    .line 6
    move-result v1

    .line 7
    const/4 v2, -0x1

    .line 8
    add-int/2addr v1, v2

    .line 9
    :goto_0
    if-ltz v1, :cond_0

    .line 10
    .line 11
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/a1;->g(I)V

    .line 12
    .line 13
    .line 14
    add-int/lit8 v1, v1, -0x1

    .line 15
    .line 16
    goto :goto_0

    .line 17
    :cond_0
    invoke-virtual {v0}, Ljava/util/ArrayList;->clear()V

    .line 18
    .line 19
    .line 20
    sget-boolean v0, Landroidx/recyclerview/widget/RecyclerView;->E0:Z

    .line 21
    .line 22
    if-eqz v0, :cond_2

    .line 23
    .line 24
    iget-object v0, p0, Landroidx/recyclerview/widget/a1;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 25
    .line 26
    iget-object v0, v0, Landroidx/recyclerview/widget/RecyclerView;->e0:Landroidx/recyclerview/widget/s;

    .line 27
    .line 28
    iget-object v1, v0, Landroidx/recyclerview/widget/s;->c:[I

    .line 29
    .line 30
    if-eqz v1, :cond_1

    .line 31
    .line 32
    invoke-static {v1, v2}, Ljava/util/Arrays;->fill([II)V

    .line 33
    .line 34
    .line 35
    :cond_1
    const/4 v1, 0x0

    .line 36
    iput v1, v0, Landroidx/recyclerview/widget/s;->d:I

    .line 37
    .line 38
    :cond_2
    return-void
.end method

.method public final g(I)V
    .locals 5

    .line 1
    sget-boolean v0, Landroidx/recyclerview/widget/RecyclerView;->z0:Z

    const-string v1, "RecyclerView"

    if-eqz v0, :cond_0

    new-instance v0, Ljava/lang/StringBuilder;

    const-string v2, "Recycling cached view at index "

    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v0, p1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    invoke-virtual {v0}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v0

    invoke-static {v1, v0}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/a1;->c:Ljava/util/ArrayList;

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    move-result-object v2

    check-cast v2, Landroidx/recyclerview/widget/i1;

    sget-boolean v3, Landroidx/recyclerview/widget/RecyclerView;->z0:Z

    if-eqz v3, :cond_1

    new-instance v3, Ljava/lang/StringBuilder;

    const-string v4, "CachedViewHolder to be recycled: "

    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    move-result-object v3

    invoke-static {v1, v3}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    :cond_1
    const/4 v1, 0x1

    invoke-virtual {p0, v2, v1}, Landroidx/recyclerview/widget/a1;->a(Landroidx/recyclerview/widget/i1;Z)V

    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    return-void
.end method

.method public final h(Landroid/view/View;)V
    .locals 3

    .line 1
    invoke-static {p1}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    move-result-object v0

    invoke-virtual {v0}, Landroidx/recyclerview/widget/i1;->isTmpDetached()Z

    move-result v1

    iget-object v2, p0, Landroidx/recyclerview/widget/a1;->h:Landroidx/recyclerview/widget/RecyclerView;

    if-eqz v1, :cond_0

    const/4 v1, 0x0

    invoke-virtual {v2, p1, v1}, Landroidx/recyclerview/widget/RecyclerView;->removeDetachedView(Landroid/view/View;Z)V

    :cond_0
    invoke-virtual {v0}, Landroidx/recyclerview/widget/i1;->isScrap()Z

    move-result p1

    if-eqz p1, :cond_1

    invoke-virtual {v0}, Landroidx/recyclerview/widget/i1;->unScrap()V

    goto :goto_0

    :cond_1
    invoke-virtual {v0}, Landroidx/recyclerview/widget/i1;->wasReturnedFromScrap()Z

    move-result p1

    if-eqz p1, :cond_2

    invoke-virtual {v0}, Landroidx/recyclerview/widget/i1;->clearReturnedFromScrapFlag()V

    :cond_2
    :goto_0
    invoke-virtual {p0, v0}, Landroidx/recyclerview/widget/a1;->i(Landroidx/recyclerview/widget/i1;)V

    iget-object p1, v2, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    if-eqz p1, :cond_3

    invoke-virtual {v0}, Landroidx/recyclerview/widget/i1;->isRecyclable()Z

    move-result p1

    if-nez p1, :cond_3

    iget-object p1, v2, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/o0;->d(Landroidx/recyclerview/widget/i1;)V

    :cond_3
    return-void
.end method

.method public final i(Landroidx/recyclerview/widget/i1;)V
    .locals 11

    .line 1
    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->isScrap()Z

    .line 2
    .line 3
    .line 4
    move-result v0

    .line 5
    const/4 v1, 0x0

    .line 6
    const/4 v2, 0x1

    .line 7
    iget-object v3, p0, Landroidx/recyclerview/widget/a1;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 8
    .line 9
    if-nez v0, :cond_14

    .line 10
    .line 11
    iget-object v0, p1, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 12
    .line 13
    invoke-virtual {v0}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 14
    .line 15
    .line 16
    move-result-object v0

    .line 17
    if-eqz v0, :cond_0

    .line 18
    .line 19
    goto/16 :goto_9

    .line 20
    .line 21
    :cond_0
    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->isTmpDetached()Z

    .line 22
    .line 23
    .line 24
    move-result v0

    .line 25
    if-nez v0, :cond_13

    .line 26
    .line 27
    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->shouldIgnore()Z

    .line 28
    .line 29
    .line 30
    move-result v0

    .line 31
    if-nez v0, :cond_12

    .line 32
    .line 33
    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->doesTransientStatePreventRecycling()Z

    .line 34
    .line 35
    .line 36
    move-result v0

    .line 37
    iget-object v4, v3, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 38
    .line 39
    if-eqz v4, :cond_1

    .line 40
    .line 41
    if-eqz v0, :cond_1

    .line 42
    .line 43
    invoke-virtual {v4, p1}, Landroidx/recyclerview/widget/i0;->onFailedToRecycleView(Landroidx/recyclerview/widget/i1;)Z

    .line 44
    .line 45
    .line 46
    move-result v4

    .line 47
    if-eqz v4, :cond_1

    .line 48
    .line 49
    const/4 v4, 0x1

    .line 50
    goto :goto_0

    .line 51
    :cond_1
    const/4 v4, 0x0

    .line 52
    :goto_0
    sget-boolean v5, Landroidx/recyclerview/widget/RecyclerView;->y0:Z

    .line 53
    .line 54
    iget-object v6, p0, Landroidx/recyclerview/widget/a1;->c:Ljava/util/ArrayList;

    .line 55
    .line 56
    if-eqz v5, :cond_3

    .line 57
    .line 58
    invoke-virtual {v6, p1}, Ljava/util/ArrayList;->contains(Ljava/lang/Object;)Z

    .line 59
    .line 60
    .line 61
    move-result v5

    .line 62
    if-nez v5, :cond_2

    .line 63
    .line 64
    goto :goto_1

    .line 65
    :cond_2
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 66
    .line 67
    new-instance v1, Ljava/lang/StringBuilder;

    .line 68
    .line 69
    const-string v2, "cached view received recycle internal? "

    .line 70
    .line 71
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 72
    .line 73
    .line 74
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 75
    .line 76
    .line 77
    invoke-static {v3, v1}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 78
    .line 79
    .line 80
    move-result-object p1

    .line 81
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 82
    .line 83
    .line 84
    throw v0

    .line 85
    :cond_3
    :goto_1
    if-nez v4, :cond_6

    .line 86
    .line 87
    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->isRecyclable()Z

    .line 88
    .line 89
    .line 90
    move-result v4

    .line 91
    if-eqz v4, :cond_4

    .line 92
    .line 93
    goto :goto_2

    .line 94
    :cond_4
    sget-boolean v2, Landroidx/recyclerview/widget/RecyclerView;->z0:Z

    .line 95
    .line 96
    if-eqz v2, :cond_5

    .line 97
    .line 98
    new-instance v2, Ljava/lang/StringBuilder;

    .line 99
    .line 100
    const-string v4, "trying to recycle a non-recycleable holder. Hopefully, it will re-visit here. We are still removing it from animation lists"

    .line 101
    .line 102
    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 103
    .line 104
    .line 105
    invoke-virtual {v3}, Landroidx/recyclerview/widget/RecyclerView;->y()Ljava/lang/String;

    .line 106
    .line 107
    .line 108
    move-result-object v4

    .line 109
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 110
    .line 111
    .line 112
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 113
    .line 114
    .line 115
    move-result-object v2

    .line 116
    const-string v4, "RecyclerView"

    .line 117
    .line 118
    invoke-static {v4, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 119
    .line 120
    .line 121
    :cond_5
    const/4 v2, 0x0

    .line 122
    goto/16 :goto_8

    .line 123
    .line 124
    :cond_6
    :goto_2
    iget v4, p0, Landroidx/recyclerview/widget/a1;->f:I

    .line 125
    .line 126
    if-lez v4, :cond_f

    .line 127
    .line 128
    const/16 v4, 0x20e

    .line 129
    .line 130
    invoke-virtual {p1, v4}, Landroidx/recyclerview/widget/i1;->hasAnyOfTheFlags(I)Z

    .line 131
    .line 132
    .line 133
    move-result v4

    .line 134
    if-nez v4, :cond_f

    .line 135
    .line 136
    invoke-virtual {v6}, Ljava/util/ArrayList;->size()I

    .line 137
    .line 138
    .line 139
    move-result v4

    .line 140
    iget v5, p0, Landroidx/recyclerview/widget/a1;->f:I

    .line 141
    .line 142
    if-lt v4, v5, :cond_7

    .line 143
    .line 144
    if-lez v4, :cond_7

    .line 145
    .line 146
    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/a1;->g(I)V

    .line 147
    .line 148
    .line 149
    add-int/lit8 v4, v4, -0x1

    .line 150
    .line 151
    :cond_7
    sget-boolean v5, Landroidx/recyclerview/widget/RecyclerView;->E0:Z

    .line 152
    .line 153
    if-eqz v5, :cond_e

    .line 154
    .line 155
    if-lez v4, :cond_e

    .line 156
    .line 157
    iget v5, p1, Landroidx/recyclerview/widget/i1;->mPosition:I

    .line 158
    .line 159
    iget-object v7, v3, Landroidx/recyclerview/widget/RecyclerView;->e0:Landroidx/recyclerview/widget/s;

    .line 160
    .line 161
    iget-object v8, v7, Landroidx/recyclerview/widget/s;->c:[I

    .line 162
    .line 163
    if-eqz v8, :cond_9

    .line 164
    .line 165
    iget v8, v7, Landroidx/recyclerview/widget/s;->d:I

    .line 166
    .line 167
    mul-int/lit8 v8, v8, 0x2

    .line 168
    .line 169
    const/4 v9, 0x0

    .line 170
    :goto_3
    if-ge v9, v8, :cond_9

    .line 171
    .line 172
    iget-object v10, v7, Landroidx/recyclerview/widget/s;->c:[I

    .line 173
    .line 174
    aget v10, v10, v9

    .line 175
    .line 176
    if-ne v10, v5, :cond_8

    .line 177
    .line 178
    const/4 v5, 0x1

    .line 179
    goto :goto_4

    .line 180
    :cond_8
    add-int/lit8 v9, v9, 0x2

    .line 181
    .line 182
    goto :goto_3

    .line 183
    :cond_9
    const/4 v5, 0x0

    .line 184
    :goto_4
    if-nez v5, :cond_e

    .line 185
    .line 186
    :cond_a
    add-int/lit8 v4, v4, -0x1

    .line 187
    .line 188
    if-ltz v4, :cond_d

    .line 189
    .line 190
    invoke-virtual {v6, v4}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 191
    .line 192
    .line 193
    move-result-object v5

    .line 194
    check-cast v5, Landroidx/recyclerview/widget/i1;

    .line 195
    .line 196
    iget v5, v5, Landroidx/recyclerview/widget/i1;->mPosition:I

    .line 197
    .line 198
    iget-object v8, v7, Landroidx/recyclerview/widget/s;->c:[I

    .line 199
    .line 200
    if-eqz v8, :cond_c

    .line 201
    .line 202
    iget v8, v7, Landroidx/recyclerview/widget/s;->d:I

    .line 203
    .line 204
    mul-int/lit8 v8, v8, 0x2

    .line 205
    .line 206
    const/4 v9, 0x0

    .line 207
    :goto_5
    if-ge v9, v8, :cond_c

    .line 208
    .line 209
    iget-object v10, v7, Landroidx/recyclerview/widget/s;->c:[I

    .line 210
    .line 211
    aget v10, v10, v9

    .line 212
    .line 213
    if-ne v10, v5, :cond_b

    .line 214
    .line 215
    const/4 v5, 0x1

    .line 216
    goto :goto_6

    .line 217
    :cond_b
    add-int/lit8 v9, v9, 0x2

    .line 218
    .line 219
    goto :goto_5

    .line 220
    :cond_c
    const/4 v5, 0x0

    .line 221
    :goto_6
    if-nez v5, :cond_a

    .line 222
    .line 223
    :cond_d
    add-int/2addr v4, v2

    .line 224
    :cond_e
    invoke-virtual {v6, v4, p1}, Ljava/util/ArrayList;->add(ILjava/lang/Object;)V

    .line 225
    .line 226
    .line 227
    const/4 v4, 0x1

    .line 228
    goto :goto_7

    .line 229
    :cond_f
    const/4 v4, 0x0

    .line 230
    :goto_7
    if-nez v4, :cond_10

    .line 231
    .line 232
    invoke-virtual {p0, p1, v2}, Landroidx/recyclerview/widget/a1;->a(Landroidx/recyclerview/widget/i1;Z)V

    .line 233
    .line 234
    .line 235
    const/4 v1, 0x1

    .line 236
    :cond_10
    move v2, v4

    .line 237
    :goto_8
    iget-object v3, v3, Landroidx/recyclerview/widget/RecyclerView;->g:Landroidx/recyclerview/widget/t1;

    .line 238
    .line 239
    invoke-virtual {v3, p1}, Landroidx/recyclerview/widget/t1;->n(Landroidx/recyclerview/widget/i1;)V

    .line 240
    .line 241
    .line 242
    if-nez v2, :cond_11

    .line 243
    .line 244
    if-nez v1, :cond_11

    .line 245
    .line 246
    if-eqz v0, :cond_11

    .line 247
    .line 248
    iget-object v0, p1, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 249
    .line 250
    invoke-static {v0}, Lb0/d;->g(Landroid/view/View;)V

    .line 251
    .line 252
    .line 253
    const/4 v0, 0x0

    .line 254
    iput-object v0, p1, Landroidx/recyclerview/widget/i1;->mBindingAdapter:Landroidx/recyclerview/widget/i0;

    .line 255
    .line 256
    iput-object v0, p1, Landroidx/recyclerview/widget/i1;->mOwnerRecyclerView:Landroidx/recyclerview/widget/RecyclerView;

    .line 257
    .line 258
    :cond_11
    return-void

    .line 259
    :cond_12
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 260
    .line 261
    new-instance v0, Ljava/lang/StringBuilder;

    .line 262
    .line 263
    const-string v1, "Trying to recycle an ignored view holder. You should first call stopIgnoringView(view) before calling recycle."

    .line 264
    .line 265
    invoke-direct {v0, v1}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 266
    .line 267
    .line 268
    invoke-static {v3, v0}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 269
    .line 270
    .line 271
    move-result-object v0

    .line 272
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 273
    .line 274
    .line 275
    throw p1

    .line 276
    :cond_13
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 277
    .line 278
    new-instance v1, Ljava/lang/StringBuilder;

    .line 279
    .line 280
    const-string v2, "Tmp detached view should be removed from RecyclerView before it can be recycled: "

    .line 281
    .line 282
    invoke-direct {v1, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 283
    .line 284
    .line 285
    invoke-virtual {v1, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 286
    .line 287
    .line 288
    invoke-static {v3, v1}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 289
    .line 290
    .line 291
    move-result-object p1

    .line 292
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 293
    .line 294
    .line 295
    throw v0

    .line 296
    :cond_14
    :goto_9
    new-instance v0, Ljava/lang/IllegalArgumentException;

    .line 297
    .line 298
    new-instance v2, Ljava/lang/StringBuilder;

    .line 299
    .line 300
    const-string v4, "Scrapped or attached views may not be recycled. isScrap:"

    .line 301
    .line 302
    invoke-direct {v2, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 303
    .line 304
    .line 305
    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->isScrap()Z

    .line 306
    .line 307
    .line 308
    move-result v4

    .line 309
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 310
    .line 311
    .line 312
    const-string v4, " isAttached:"

    .line 313
    .line 314
    invoke-virtual {v2, v4}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 315
    .line 316
    .line 317
    iget-object p1, p1, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 318
    .line 319
    invoke-virtual {p1}, Landroid/view/View;->getParent()Landroid/view/ViewParent;

    .line 320
    .line 321
    .line 322
    move-result-object p1

    .line 323
    if-eqz p1, :cond_15

    .line 324
    .line 325
    const/4 v1, 0x1

    .line 326
    :cond_15
    invoke-virtual {v2, v1}, Ljava/lang/StringBuilder;->append(Z)Ljava/lang/StringBuilder;

    .line 327
    .line 328
    .line 329
    invoke-virtual {v3}, Landroidx/recyclerview/widget/RecyclerView;->y()Ljava/lang/String;

    .line 330
    .line 331
    .line 332
    move-result-object p1

    .line 333
    invoke-virtual {v2, p1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 334
    .line 335
    .line 336
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 337
    .line 338
    .line 339
    move-result-object p1

    .line 340
    invoke-direct {v0, p1}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 341
    .line 342
    .line 343
    throw v0
.end method

.method public final j(Landroid/view/View;)V
    .locals 5

    .line 1
    invoke-static {p1}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 2
    .line 3
    .line 4
    move-result-object p1

    .line 5
    const/16 v0, 0xc

    .line 6
    .line 7
    invoke-virtual {p1, v0}, Landroidx/recyclerview/widget/i1;->hasAnyOfTheFlags(I)Z

    .line 8
    .line 9
    .line 10
    move-result v0

    .line 11
    iget-object v1, p0, Landroidx/recyclerview/widget/a1;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 12
    .line 13
    const/4 v2, 0x0

    .line 14
    if-nez v0, :cond_8

    .line 15
    .line 16
    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->isUpdated()Z

    .line 17
    .line 18
    .line 19
    move-result v0

    .line 20
    if-eqz v0, :cond_8

    .line 21
    .line 22
    iget-object v0, v1, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 23
    .line 24
    const/4 v3, 0x1

    .line 25
    if-eqz v0, :cond_5

    .line 26
    .line 27
    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->getUnmodifiedPayloads()Ljava/util/List;

    .line 28
    .line 29
    .line 30
    move-result-object v4

    .line 31
    check-cast v0, Landroidx/recyclerview/widget/l;

    .line 32
    .line 33
    invoke-interface {v4}, Ljava/util/List;->isEmpty()Z

    .line 34
    .line 35
    .line 36
    move-result v4

    .line 37
    if-eqz v4, :cond_3

    .line 38
    .line 39
    iget-boolean v0, v0, Landroidx/recyclerview/widget/l;->g:Z

    .line 40
    .line 41
    if-eqz v0, :cond_1

    .line 42
    .line 43
    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->isInvalid()Z

    .line 44
    .line 45
    .line 46
    move-result v0

    .line 47
    if-eqz v0, :cond_0

    .line 48
    .line 49
    goto :goto_0

    .line 50
    :cond_0
    const/4 v0, 0x0

    .line 51
    goto :goto_1

    .line 52
    :cond_1
    :goto_0
    const/4 v0, 0x1

    .line 53
    :goto_1
    if-eqz v0, :cond_2

    .line 54
    .line 55
    goto :goto_2

    .line 56
    :cond_2
    const/4 v0, 0x0

    .line 57
    goto :goto_3

    .line 58
    :cond_3
    :goto_2
    const/4 v0, 0x1

    .line 59
    :goto_3
    if-eqz v0, :cond_4

    .line 60
    .line 61
    goto :goto_4

    .line 62
    :cond_4
    const/4 v0, 0x0

    .line 63
    goto :goto_5

    .line 64
    :cond_5
    :goto_4
    const/4 v0, 0x1

    .line 65
    :goto_5
    if-eqz v0, :cond_6

    .line 66
    .line 67
    goto :goto_6

    .line 68
    :cond_6
    iget-object v0, p0, Landroidx/recyclerview/widget/a1;->b:Ljava/util/ArrayList;

    .line 69
    .line 70
    if-nez v0, :cond_7

    .line 71
    .line 72
    new-instance v0, Ljava/util/ArrayList;

    .line 73
    .line 74
    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    .line 75
    .line 76
    .line 77
    iput-object v0, p0, Landroidx/recyclerview/widget/a1;->b:Ljava/util/ArrayList;

    .line 78
    .line 79
    :cond_7
    invoke-virtual {p1, p0, v3}, Landroidx/recyclerview/widget/i1;->setScrapContainer(Landroidx/recyclerview/widget/a1;Z)V

    .line 80
    .line 81
    .line 82
    iget-object v0, p0, Landroidx/recyclerview/widget/a1;->b:Ljava/util/ArrayList;

    .line 83
    .line 84
    goto :goto_8

    .line 85
    :cond_8
    :goto_6
    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->isInvalid()Z

    .line 86
    .line 87
    .line 88
    move-result v0

    .line 89
    if-eqz v0, :cond_a

    .line 90
    .line 91
    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->isRemoved()Z

    .line 92
    .line 93
    .line 94
    move-result v0

    .line 95
    if-nez v0, :cond_a

    .line 96
    .line 97
    iget-object v0, v1, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 98
    .line 99
    invoke-virtual {v0}, Landroidx/recyclerview/widget/i0;->hasStableIds()Z

    .line 100
    .line 101
    .line 102
    move-result v0

    .line 103
    if-eqz v0, :cond_9

    .line 104
    .line 105
    goto :goto_7

    .line 106
    :cond_9
    new-instance p1, Ljava/lang/IllegalArgumentException;

    .line 107
    .line 108
    new-instance v0, Ljava/lang/StringBuilder;

    .line 109
    .line 110
    const-string v2, "Called scrap view with an invalid view. Invalid views cannot be reused from scrap, they should rebound from recycler pool."

    .line 111
    .line 112
    invoke-direct {v0, v2}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 113
    .line 114
    .line 115
    invoke-static {v1, v0}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 116
    .line 117
    .line 118
    move-result-object v0

    .line 119
    invoke-direct {p1, v0}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 120
    .line 121
    .line 122
    throw p1

    .line 123
    :cond_a
    :goto_7
    invoke-virtual {p1, p0, v2}, Landroidx/recyclerview/widget/i1;->setScrapContainer(Landroidx/recyclerview/widget/a1;Z)V

    .line 124
    .line 125
    .line 126
    iget-object v0, p0, Landroidx/recyclerview/widget/a1;->a:Ljava/util/ArrayList;

    .line 127
    .line 128
    :goto_8
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 129
    .line 130
    .line 131
    return-void
.end method

.method public final k(IJ)Landroidx/recyclerview/widget/i1;
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    move/from16 v1, p1

    .line 4
    .line 5
    iget-object v2, v0, Landroidx/recyclerview/widget/a1;->h:Landroidx/recyclerview/widget/RecyclerView;

    .line 6
    .line 7
    if-ltz v1, :cond_4b

    .line 8
    .line 9
    iget-object v3, v2, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    .line 10
    .line 11
    invoke-virtual {v3}, Landroidx/recyclerview/widget/e1;->b()I

    .line 12
    .line 13
    .line 14
    move-result v3

    .line 15
    if-ge v1, v3, :cond_4b

    .line 16
    .line 17
    iget-object v3, v2, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    .line 18
    .line 19
    iget-boolean v4, v3, Landroidx/recyclerview/widget/e1;->f:Z

    .line 20
    .line 21
    const/4 v5, 0x0

    .line 22
    const/16 v6, 0x20

    .line 23
    .line 24
    if-eqz v4, :cond_6

    .line 25
    .line 26
    iget-object v4, v0, Landroidx/recyclerview/widget/a1;->b:Ljava/util/ArrayList;

    .line 27
    .line 28
    if-eqz v4, :cond_4

    .line 29
    .line 30
    invoke-virtual {v4}, Ljava/util/ArrayList;->size()I

    .line 31
    .line 32
    .line 33
    move-result v4

    .line 34
    if-nez v4, :cond_0

    .line 35
    .line 36
    goto :goto_2

    .line 37
    :cond_0
    const/4 v7, 0x0

    .line 38
    :goto_0
    if-ge v7, v4, :cond_2

    .line 39
    .line 40
    iget-object v8, v0, Landroidx/recyclerview/widget/a1;->b:Ljava/util/ArrayList;

    .line 41
    .line 42
    invoke-virtual {v8, v7}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 43
    .line 44
    .line 45
    move-result-object v8

    .line 46
    check-cast v8, Landroidx/recyclerview/widget/i1;

    .line 47
    .line 48
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->wasReturnedFromScrap()Z

    .line 49
    .line 50
    .line 51
    move-result v9

    .line 52
    if-nez v9, :cond_1

    .line 53
    .line 54
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->getLayoutPosition()I

    .line 55
    .line 56
    .line 57
    move-result v9

    .line 58
    if-ne v9, v1, :cond_1

    .line 59
    .line 60
    invoke-virtual {v8, v6}, Landroidx/recyclerview/widget/i1;->addFlags(I)V

    .line 61
    .line 62
    .line 63
    goto :goto_3

    .line 64
    :cond_1
    add-int/lit8 v7, v7, 0x1

    .line 65
    .line 66
    goto :goto_0

    .line 67
    :cond_2
    iget-object v7, v2, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 68
    .line 69
    invoke-virtual {v7}, Landroidx/recyclerview/widget/i0;->hasStableIds()Z

    .line 70
    .line 71
    .line 72
    move-result v7

    .line 73
    if-eqz v7, :cond_4

    .line 74
    .line 75
    iget-object v7, v2, Landroidx/recyclerview/widget/RecyclerView;->e:Landroidx/recyclerview/widget/b;

    .line 76
    .line 77
    invoke-virtual {v7, v1, v5}, Landroidx/recyclerview/widget/b;->f(II)I

    .line 78
    .line 79
    .line 80
    move-result v7

    .line 81
    if-lez v7, :cond_4

    .line 82
    .line 83
    iget-object v8, v2, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 84
    .line 85
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i0;->getItemCount()I

    .line 86
    .line 87
    .line 88
    move-result v8

    .line 89
    if-ge v7, v8, :cond_4

    .line 90
    .line 91
    iget-object v8, v2, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 92
    .line 93
    invoke-virtual {v8, v7}, Landroidx/recyclerview/widget/i0;->getItemId(I)J

    .line 94
    .line 95
    .line 96
    move-result-wide v7

    .line 97
    const/4 v9, 0x0

    .line 98
    :goto_1
    if-ge v9, v4, :cond_4

    .line 99
    .line 100
    iget-object v10, v0, Landroidx/recyclerview/widget/a1;->b:Ljava/util/ArrayList;

    .line 101
    .line 102
    invoke-virtual {v10, v9}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 103
    .line 104
    .line 105
    move-result-object v10

    .line 106
    check-cast v10, Landroidx/recyclerview/widget/i1;

    .line 107
    .line 108
    invoke-virtual {v10}, Landroidx/recyclerview/widget/i1;->wasReturnedFromScrap()Z

    .line 109
    .line 110
    .line 111
    move-result v11

    .line 112
    if-nez v11, :cond_3

    .line 113
    .line 114
    invoke-virtual {v10}, Landroidx/recyclerview/widget/i1;->getItemId()J

    .line 115
    .line 116
    .line 117
    move-result-wide v11

    .line 118
    cmp-long v13, v11, v7

    .line 119
    .line 120
    if-nez v13, :cond_3

    .line 121
    .line 122
    invoke-virtual {v10, v6}, Landroidx/recyclerview/widget/i1;->addFlags(I)V

    .line 123
    .line 124
    .line 125
    move-object v8, v10

    .line 126
    goto :goto_3

    .line 127
    :cond_3
    add-int/lit8 v9, v9, 0x1

    .line 128
    .line 129
    goto :goto_1

    .line 130
    :cond_4
    :goto_2
    const/4 v8, 0x0

    .line 131
    :goto_3
    if-eqz v8, :cond_5

    .line 132
    .line 133
    const/4 v4, 0x1

    .line 134
    goto :goto_4

    .line 135
    :cond_5
    const/4 v4, 0x0

    .line 136
    goto :goto_4

    .line 137
    :cond_6
    const/4 v4, 0x0

    .line 138
    const/4 v8, 0x0

    .line 139
    :goto_4
    iget-object v7, v0, Landroidx/recyclerview/widget/a1;->c:Ljava/util/ArrayList;

    .line 140
    .line 141
    iget-object v9, v0, Landroidx/recyclerview/widget/a1;->a:Ljava/util/ArrayList;

    .line 142
    .line 143
    const/4 v10, -0x1

    .line 144
    const-string v11, "RecyclerView"

    .line 145
    .line 146
    if-nez v8, :cond_1f

    .line 147
    .line 148
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    .line 149
    .line 150
    .line 151
    move-result v8

    .line 152
    const/4 v12, 0x0

    .line 153
    :goto_5
    if-ge v12, v8, :cond_9

    .line 154
    .line 155
    invoke-virtual {v9, v12}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 156
    .line 157
    .line 158
    move-result-object v13

    .line 159
    check-cast v13, Landroidx/recyclerview/widget/i1;

    .line 160
    .line 161
    invoke-virtual {v13}, Landroidx/recyclerview/widget/i1;->wasReturnedFromScrap()Z

    .line 162
    .line 163
    .line 164
    move-result v14

    .line 165
    if-nez v14, :cond_8

    .line 166
    .line 167
    invoke-virtual {v13}, Landroidx/recyclerview/widget/i1;->getLayoutPosition()I

    .line 168
    .line 169
    .line 170
    move-result v14

    .line 171
    if-ne v14, v1, :cond_8

    .line 172
    .line 173
    invoke-virtual {v13}, Landroidx/recyclerview/widget/i1;->isInvalid()Z

    .line 174
    .line 175
    .line 176
    move-result v14

    .line 177
    if-nez v14, :cond_8

    .line 178
    .line 179
    iget-boolean v14, v3, Landroidx/recyclerview/widget/e1;->f:Z

    .line 180
    .line 181
    if-nez v14, :cond_7

    .line 182
    .line 183
    invoke-virtual {v13}, Landroidx/recyclerview/widget/i1;->isRemoved()Z

    .line 184
    .line 185
    .line 186
    move-result v14

    .line 187
    if-nez v14, :cond_8

    .line 188
    .line 189
    :cond_7
    invoke-virtual {v13, v6}, Landroidx/recyclerview/widget/i1;->addFlags(I)V

    .line 190
    .line 191
    .line 192
    move-object v8, v13

    .line 193
    goto/16 :goto_c

    .line 194
    .line 195
    :cond_8
    add-int/lit8 v12, v12, 0x1

    .line 196
    .line 197
    goto :goto_5

    .line 198
    :cond_9
    iget-object v6, v2, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 199
    .line 200
    iget-object v8, v6, Landroidx/recyclerview/widget/e;->c:Ljava/util/ArrayList;

    .line 201
    .line 202
    invoke-virtual {v8}, Ljava/util/ArrayList;->size()I

    .line 203
    .line 204
    .line 205
    move-result v12

    .line 206
    const/4 v13, 0x0

    .line 207
    :goto_6
    if-ge v13, v12, :cond_b

    .line 208
    .line 209
    invoke-virtual {v8, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 210
    .line 211
    .line 212
    move-result-object v14

    .line 213
    check-cast v14, Landroid/view/View;

    .line 214
    .line 215
    iget-object v15, v6, Landroidx/recyclerview/widget/e;->a:Landroidx/recyclerview/widget/p0;

    .line 216
    .line 217
    invoke-virtual {v15}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 218
    .line 219
    .line 220
    invoke-static {v14}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 221
    .line 222
    .line 223
    move-result-object v15

    .line 224
    invoke-virtual {v15}, Landroidx/recyclerview/widget/i1;->getLayoutPosition()I

    .line 225
    .line 226
    .line 227
    move-result v5

    .line 228
    if-ne v5, v1, :cond_a

    .line 229
    .line 230
    invoke-virtual {v15}, Landroidx/recyclerview/widget/i1;->isInvalid()Z

    .line 231
    .line 232
    .line 233
    move-result v5

    .line 234
    if-nez v5, :cond_a

    .line 235
    .line 236
    invoke-virtual {v15}, Landroidx/recyclerview/widget/i1;->isRemoved()Z

    .line 237
    .line 238
    .line 239
    move-result v5

    .line 240
    if-nez v5, :cond_a

    .line 241
    .line 242
    goto :goto_7

    .line 243
    :cond_a
    add-int/lit8 v13, v13, 0x1

    .line 244
    .line 245
    const/4 v5, 0x0

    .line 246
    goto :goto_6

    .line 247
    :cond_b
    const/4 v14, 0x0

    .line 248
    :goto_7
    if-eqz v14, :cond_11

    .line 249
    .line 250
    invoke-static {v14}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 251
    .line 252
    .line 253
    move-result-object v5

    .line 254
    iget-object v6, v2, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 255
    .line 256
    iget-object v8, v6, Landroidx/recyclerview/widget/e;->a:Landroidx/recyclerview/widget/p0;

    .line 257
    .line 258
    iget-object v8, v8, Landroidx/recyclerview/widget/p0;->a:Landroidx/recyclerview/widget/RecyclerView;

    .line 259
    .line 260
    invoke-virtual {v8, v14}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    .line 261
    .line 262
    .line 263
    move-result v8

    .line 264
    if-ltz v8, :cond_10

    .line 265
    .line 266
    iget-object v12, v6, Landroidx/recyclerview/widget/e;->b:Landroidx/recyclerview/widget/d;

    .line 267
    .line 268
    invoke-virtual {v12, v8}, Landroidx/recyclerview/widget/d;->d(I)Z

    .line 269
    .line 270
    .line 271
    move-result v13

    .line 272
    if-eqz v13, :cond_f

    .line 273
    .line 274
    invoke-virtual {v12, v8}, Landroidx/recyclerview/widget/d;->a(I)V

    .line 275
    .line 276
    .line 277
    invoke-virtual {v6, v14}, Landroidx/recyclerview/widget/e;->k(Landroid/view/View;)V

    .line 278
    .line 279
    .line 280
    iget-object v6, v2, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 281
    .line 282
    iget-object v8, v6, Landroidx/recyclerview/widget/e;->a:Landroidx/recyclerview/widget/p0;

    .line 283
    .line 284
    iget-object v8, v8, Landroidx/recyclerview/widget/p0;->a:Landroidx/recyclerview/widget/RecyclerView;

    .line 285
    .line 286
    invoke-virtual {v8, v14}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    .line 287
    .line 288
    .line 289
    move-result v8

    .line 290
    if-ne v8, v10, :cond_c

    .line 291
    .line 292
    goto :goto_8

    .line 293
    :cond_c
    iget-object v6, v6, Landroidx/recyclerview/widget/e;->b:Landroidx/recyclerview/widget/d;

    .line 294
    .line 295
    invoke-virtual {v6, v8}, Landroidx/recyclerview/widget/d;->d(I)Z

    .line 296
    .line 297
    .line 298
    move-result v12

    .line 299
    if-eqz v12, :cond_d

    .line 300
    .line 301
    :goto_8
    const/4 v6, -0x1

    .line 302
    goto :goto_9

    .line 303
    :cond_d
    invoke-virtual {v6, v8}, Landroidx/recyclerview/widget/d;->b(I)I

    .line 304
    .line 305
    .line 306
    move-result v6

    .line 307
    sub-int v6, v8, v6

    .line 308
    .line 309
    :goto_9
    if-eq v6, v10, :cond_e

    .line 310
    .line 311
    iget-object v8, v2, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 312
    .line 313
    invoke-virtual {v8, v6}, Landroidx/recyclerview/widget/e;->c(I)V

    .line 314
    .line 315
    .line 316
    invoke-virtual {v0, v14}, Landroidx/recyclerview/widget/a1;->j(Landroid/view/View;)V

    .line 317
    .line 318
    .line 319
    const/16 v6, 0x2020

    .line 320
    .line 321
    invoke-virtual {v5, v6}, Landroidx/recyclerview/widget/i1;->addFlags(I)V

    .line 322
    .line 323
    .line 324
    goto/16 :goto_b

    .line 325
    .line 326
    :cond_e
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 327
    .line 328
    new-instance v3, Ljava/lang/StringBuilder;

    .line 329
    .line 330
    const-string v4, "layout index should not be -1 after unhiding a view:"

    .line 331
    .line 332
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 333
    .line 334
    .line 335
    invoke-virtual {v3, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 336
    .line 337
    .line 338
    invoke-static {v2, v3}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 339
    .line 340
    .line 341
    move-result-object v2

    .line 342
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 343
    .line 344
    .line 345
    throw v1

    .line 346
    :cond_f
    new-instance v1, Ljava/lang/RuntimeException;

    .line 347
    .line 348
    new-instance v2, Ljava/lang/StringBuilder;

    .line 349
    .line 350
    const-string v3, "trying to unhide a view that was not hidden"

    .line 351
    .line 352
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 353
    .line 354
    .line 355
    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 356
    .line 357
    .line 358
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 359
    .line 360
    .line 361
    move-result-object v2

    .line 362
    invoke-direct {v1, v2}, Ljava/lang/RuntimeException;-><init>(Ljava/lang/String;)V

    .line 363
    .line 364
    .line 365
    throw v1

    .line 366
    :cond_10
    new-instance v1, Ljava/lang/IllegalArgumentException;

    .line 367
    .line 368
    new-instance v2, Ljava/lang/StringBuilder;

    .line 369
    .line 370
    const-string v3, "view is not a child, cannot hide "

    .line 371
    .line 372
    invoke-direct {v2, v3}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 373
    .line 374
    .line 375
    invoke-virtual {v2, v14}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 376
    .line 377
    .line 378
    invoke-virtual {v2}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 379
    .line 380
    .line 381
    move-result-object v2

    .line 382
    invoke-direct {v1, v2}, Ljava/lang/IllegalArgumentException;-><init>(Ljava/lang/String;)V

    .line 383
    .line 384
    .line 385
    throw v1

    .line 386
    :cond_11
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 387
    .line 388
    .line 389
    move-result v5

    .line 390
    const/4 v6, 0x0

    .line 391
    :goto_a
    if-ge v6, v5, :cond_13

    .line 392
    .line 393
    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 394
    .line 395
    .line 396
    move-result-object v8

    .line 397
    check-cast v8, Landroidx/recyclerview/widget/i1;

    .line 398
    .line 399
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->isInvalid()Z

    .line 400
    .line 401
    .line 402
    move-result v12

    .line 403
    if-nez v12, :cond_12

    .line 404
    .line 405
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->getLayoutPosition()I

    .line 406
    .line 407
    .line 408
    move-result v12

    .line 409
    if-ne v12, v1, :cond_12

    .line 410
    .line 411
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->isAttachedToTransitionOverlay()Z

    .line 412
    .line 413
    .line 414
    move-result v12

    .line 415
    if-nez v12, :cond_12

    .line 416
    .line 417
    invoke-virtual {v7, v6}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 418
    .line 419
    .line 420
    sget-boolean v5, Landroidx/recyclerview/widget/RecyclerView;->z0:Z

    .line 421
    .line 422
    if-eqz v5, :cond_14

    .line 423
    .line 424
    new-instance v5, Ljava/lang/StringBuilder;

    .line 425
    .line 426
    const-string v6, "getScrapOrHiddenOrCachedHolderForPosition("

    .line 427
    .line 428
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 429
    .line 430
    .line 431
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 432
    .line 433
    .line 434
    const-string v6, ") found match in cache: "

    .line 435
    .line 436
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 437
    .line 438
    .line 439
    invoke-virtual {v5, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 440
    .line 441
    .line 442
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 443
    .line 444
    .line 445
    move-result-object v5

    .line 446
    invoke-static {v11, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 447
    .line 448
    .line 449
    goto :goto_c

    .line 450
    :cond_12
    add-int/lit8 v6, v6, 0x1

    .line 451
    .line 452
    goto :goto_a

    .line 453
    :cond_13
    const/4 v5, 0x0

    .line 454
    :goto_b
    move-object v8, v5

    .line 455
    :cond_14
    :goto_c
    if-eqz v8, :cond_1f

    .line 456
    .line 457
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->isRemoved()Z

    .line 458
    .line 459
    .line 460
    move-result v5

    .line 461
    if-eqz v5, :cond_17

    .line 462
    .line 463
    sget-boolean v5, Landroidx/recyclerview/widget/RecyclerView;->y0:Z

    .line 464
    .line 465
    if-eqz v5, :cond_16

    .line 466
    .line 467
    iget-boolean v5, v3, Landroidx/recyclerview/widget/e1;->f:Z

    .line 468
    .line 469
    if-eqz v5, :cond_15

    .line 470
    .line 471
    goto :goto_d

    .line 472
    :cond_15
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 473
    .line 474
    new-instance v3, Ljava/lang/StringBuilder;

    .line 475
    .line 476
    const-string v4, "should not receive a removed view unless it is pre layout"

    .line 477
    .line 478
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 479
    .line 480
    .line 481
    invoke-static {v2, v3}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 482
    .line 483
    .line 484
    move-result-object v2

    .line 485
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 486
    .line 487
    .line 488
    throw v1

    .line 489
    :cond_16
    :goto_d
    iget-boolean v5, v3, Landroidx/recyclerview/widget/e1;->f:Z

    .line 490
    .line 491
    goto :goto_10

    .line 492
    :cond_17
    iget v5, v8, Landroidx/recyclerview/widget/i1;->mPosition:I

    .line 493
    .line 494
    if-ltz v5, :cond_1e

    .line 495
    .line 496
    iget-object v6, v2, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 497
    .line 498
    invoke-virtual {v6}, Landroidx/recyclerview/widget/i0;->getItemCount()I

    .line 499
    .line 500
    .line 501
    move-result v6

    .line 502
    if-ge v5, v6, :cond_1e

    .line 503
    .line 504
    iget-boolean v5, v3, Landroidx/recyclerview/widget/e1;->f:Z

    .line 505
    .line 506
    if-nez v5, :cond_18

    .line 507
    .line 508
    iget-object v5, v2, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 509
    .line 510
    iget v6, v8, Landroidx/recyclerview/widget/i1;->mPosition:I

    .line 511
    .line 512
    invoke-virtual {v5, v6}, Landroidx/recyclerview/widget/i0;->getItemViewType(I)I

    .line 513
    .line 514
    .line 515
    move-result v5

    .line 516
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->getItemViewType()I

    .line 517
    .line 518
    .line 519
    move-result v6

    .line 520
    if-eq v5, v6, :cond_18

    .line 521
    .line 522
    goto :goto_e

    .line 523
    :cond_18
    iget-object v5, v2, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 524
    .line 525
    invoke-virtual {v5}, Landroidx/recyclerview/widget/i0;->hasStableIds()Z

    .line 526
    .line 527
    .line 528
    move-result v5

    .line 529
    if-eqz v5, :cond_1a

    .line 530
    .line 531
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->getItemId()J

    .line 532
    .line 533
    .line 534
    move-result-wide v5

    .line 535
    iget-object v12, v2, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 536
    .line 537
    iget v13, v8, Landroidx/recyclerview/widget/i1;->mPosition:I

    .line 538
    .line 539
    invoke-virtual {v12, v13}, Landroidx/recyclerview/widget/i0;->getItemId(I)J

    .line 540
    .line 541
    .line 542
    move-result-wide v12

    .line 543
    cmp-long v14, v5, v12

    .line 544
    .line 545
    if-nez v14, :cond_19

    .line 546
    .line 547
    goto :goto_f

    .line 548
    :cond_19
    :goto_e
    const/4 v5, 0x0

    .line 549
    goto :goto_10

    .line 550
    :cond_1a
    :goto_f
    const/4 v5, 0x1

    .line 551
    :goto_10
    if-nez v5, :cond_1d

    .line 552
    .line 553
    const/4 v5, 0x4

    .line 554
    invoke-virtual {v8, v5}, Landroidx/recyclerview/widget/i1;->addFlags(I)V

    .line 555
    .line 556
    .line 557
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->isScrap()Z

    .line 558
    .line 559
    .line 560
    move-result v5

    .line 561
    if-eqz v5, :cond_1b

    .line 562
    .line 563
    iget-object v5, v8, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 564
    .line 565
    const/4 v6, 0x0

    .line 566
    invoke-virtual {v2, v5, v6}, Landroidx/recyclerview/widget/RecyclerView;->removeDetachedView(Landroid/view/View;Z)V

    .line 567
    .line 568
    .line 569
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->unScrap()V

    .line 570
    .line 571
    .line 572
    goto :goto_11

    .line 573
    :cond_1b
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->wasReturnedFromScrap()Z

    .line 574
    .line 575
    .line 576
    move-result v5

    .line 577
    if-eqz v5, :cond_1c

    .line 578
    .line 579
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->clearReturnedFromScrapFlag()V

    .line 580
    .line 581
    .line 582
    :cond_1c
    :goto_11
    invoke-virtual {v0, v8}, Landroidx/recyclerview/widget/a1;->i(Landroidx/recyclerview/widget/i1;)V

    .line 583
    .line 584
    .line 585
    const/4 v8, 0x0

    .line 586
    goto :goto_12

    .line 587
    :cond_1d
    const/4 v4, 0x1

    .line 588
    goto :goto_12

    .line 589
    :cond_1e
    new-instance v1, Ljava/lang/IndexOutOfBoundsException;

    .line 590
    .line 591
    new-instance v3, Ljava/lang/StringBuilder;

    .line 592
    .line 593
    const-string v4, "Inconsistency detected. Invalid view holder adapter position"

    .line 594
    .line 595
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 596
    .line 597
    .line 598
    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 599
    .line 600
    .line 601
    invoke-static {v2, v3}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 602
    .line 603
    .line 604
    move-result-object v2

    .line 605
    invoke-direct {v1, v2}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 606
    .line 607
    .line 608
    throw v1

    .line 609
    :cond_1f
    :goto_12
    if-nez v8, :cond_33

    .line 610
    .line 611
    iget-object v14, v2, Landroidx/recyclerview/widget/RecyclerView;->e:Landroidx/recyclerview/widget/b;

    .line 612
    .line 613
    const/4 v15, 0x0

    .line 614
    invoke-virtual {v14, v1, v15}, Landroidx/recyclerview/widget/b;->f(II)I

    .line 615
    .line 616
    .line 617
    move-result v14

    .line 618
    if-ltz v14, :cond_32

    .line 619
    .line 620
    iget-object v15, v2, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 621
    .line 622
    invoke-virtual {v15}, Landroidx/recyclerview/widget/i0;->getItemCount()I

    .line 623
    .line 624
    .line 625
    move-result v15

    .line 626
    if-ge v14, v15, :cond_32

    .line 627
    .line 628
    iget-object v15, v2, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 629
    .line 630
    invoke-virtual {v15, v14}, Landroidx/recyclerview/widget/i0;->getItemViewType(I)I

    .line 631
    .line 632
    .line 633
    move-result v15

    .line 634
    iget-object v12, v2, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 635
    .line 636
    invoke-virtual {v12}, Landroidx/recyclerview/widget/i0;->hasStableIds()Z

    .line 637
    .line 638
    .line 639
    move-result v12

    .line 640
    if-eqz v12, :cond_27

    .line 641
    .line 642
    iget-object v8, v2, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 643
    .line 644
    invoke-virtual {v8, v14}, Landroidx/recyclerview/widget/i0;->getItemId(I)J

    .line 645
    .line 646
    .line 647
    move-result-wide v12

    .line 648
    invoke-virtual {v9}, Ljava/util/ArrayList;->size()I

    .line 649
    .line 650
    .line 651
    move-result v8

    .line 652
    add-int/2addr v8, v10

    .line 653
    :goto_13
    if-ltz v8, :cond_22

    .line 654
    .line 655
    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 656
    .line 657
    .line 658
    move-result-object v17

    .line 659
    move-object/from16 v5, v17

    .line 660
    .line 661
    check-cast v5, Landroidx/recyclerview/widget/i1;

    .line 662
    .line 663
    invoke-virtual {v5}, Landroidx/recyclerview/widget/i1;->getItemId()J

    .line 664
    .line 665
    .line 666
    move-result-wide v18

    .line 667
    cmp-long v6, v18, v12

    .line 668
    .line 669
    if-nez v6, :cond_21

    .line 670
    .line 671
    invoke-virtual {v5}, Landroidx/recyclerview/widget/i1;->wasReturnedFromScrap()Z

    .line 672
    .line 673
    .line 674
    move-result v6

    .line 675
    if-nez v6, :cond_21

    .line 676
    .line 677
    invoke-virtual {v5}, Landroidx/recyclerview/widget/i1;->getItemViewType()I

    .line 678
    .line 679
    .line 680
    move-result v6

    .line 681
    if-ne v15, v6, :cond_20

    .line 682
    .line 683
    const/16 v6, 0x20

    .line 684
    .line 685
    invoke-virtual {v5, v6}, Landroidx/recyclerview/widget/i1;->addFlags(I)V

    .line 686
    .line 687
    .line 688
    invoke-virtual {v5}, Landroidx/recyclerview/widget/i1;->isRemoved()Z

    .line 689
    .line 690
    .line 691
    move-result v6

    .line 692
    if-eqz v6, :cond_26

    .line 693
    .line 694
    iget-boolean v6, v3, Landroidx/recyclerview/widget/e1;->f:Z

    .line 695
    .line 696
    if-nez v6, :cond_26

    .line 697
    .line 698
    const/4 v6, 0x2

    .line 699
    const/16 v7, 0xe

    .line 700
    .line 701
    invoke-virtual {v5, v6, v7}, Landroidx/recyclerview/widget/i1;->setFlags(II)V

    .line 702
    .line 703
    .line 704
    goto :goto_16

    .line 705
    :cond_20
    invoke-virtual {v9, v8}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 706
    .line 707
    .line 708
    iget-object v6, v5, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 709
    .line 710
    const/4 v10, 0x0

    .line 711
    invoke-virtual {v2, v6, v10}, Landroidx/recyclerview/widget/RecyclerView;->removeDetachedView(Landroid/view/View;Z)V

    .line 712
    .line 713
    .line 714
    iget-object v5, v5, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 715
    .line 716
    invoke-static {v5}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 717
    .line 718
    .line 719
    move-result-object v5

    .line 720
    const/4 v6, 0x0

    .line 721
    iput-object v6, v5, Landroidx/recyclerview/widget/i1;->mScrapContainer:Landroidx/recyclerview/widget/a1;

    .line 722
    .line 723
    iput-boolean v10, v5, Landroidx/recyclerview/widget/i1;->mInChangeScrap:Z

    .line 724
    .line 725
    invoke-virtual {v5}, Landroidx/recyclerview/widget/i1;->clearReturnedFromScrapFlag()V

    .line 726
    .line 727
    .line 728
    invoke-virtual {v0, v5}, Landroidx/recyclerview/widget/a1;->i(Landroidx/recyclerview/widget/i1;)V

    .line 729
    .line 730
    .line 731
    :cond_21
    add-int/lit8 v8, v8, -0x1

    .line 732
    .line 733
    const/4 v10, -0x1

    .line 734
    goto :goto_13

    .line 735
    :cond_22
    invoke-virtual {v7}, Ljava/util/ArrayList;->size()I

    .line 736
    .line 737
    .line 738
    move-result v5

    .line 739
    const/4 v6, -0x1

    .line 740
    add-int/2addr v5, v6

    .line 741
    :goto_14
    if-ltz v5, :cond_25

    .line 742
    .line 743
    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 744
    .line 745
    .line 746
    move-result-object v6

    .line 747
    check-cast v6, Landroidx/recyclerview/widget/i1;

    .line 748
    .line 749
    invoke-virtual {v6}, Landroidx/recyclerview/widget/i1;->getItemId()J

    .line 750
    .line 751
    .line 752
    move-result-wide v8

    .line 753
    cmp-long v10, v8, v12

    .line 754
    .line 755
    if-nez v10, :cond_24

    .line 756
    .line 757
    invoke-virtual {v6}, Landroidx/recyclerview/widget/i1;->isAttachedToTransitionOverlay()Z

    .line 758
    .line 759
    .line 760
    move-result v8

    .line 761
    if-nez v8, :cond_24

    .line 762
    .line 763
    invoke-virtual {v6}, Landroidx/recyclerview/widget/i1;->getItemViewType()I

    .line 764
    .line 765
    .line 766
    move-result v8

    .line 767
    if-ne v15, v8, :cond_23

    .line 768
    .line 769
    invoke-virtual {v7, v5}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 770
    .line 771
    .line 772
    move-object v8, v6

    .line 773
    goto :goto_17

    .line 774
    :cond_23
    invoke-virtual {v0, v5}, Landroidx/recyclerview/widget/a1;->g(I)V

    .line 775
    .line 776
    .line 777
    goto :goto_15

    .line 778
    :cond_24
    add-int/lit8 v5, v5, -0x1

    .line 779
    .line 780
    goto :goto_14

    .line 781
    :cond_25
    :goto_15
    const/4 v5, 0x0

    .line 782
    :cond_26
    :goto_16
    move-object v8, v5

    .line 783
    :goto_17
    if-eqz v8, :cond_27

    .line 784
    .line 785
    iput v14, v8, Landroidx/recyclerview/widget/i1;->mPosition:I

    .line 786
    .line 787
    const/4 v4, 0x1

    .line 788
    :cond_27
    if-nez v8, :cond_2c

    .line 789
    .line 790
    sget-boolean v5, Landroidx/recyclerview/widget/RecyclerView;->z0:Z

    .line 791
    .line 792
    if-eqz v5, :cond_28

    .line 793
    .line 794
    new-instance v5, Ljava/lang/StringBuilder;

    .line 795
    .line 796
    const-string v6, "tryGetViewHolderForPositionByDeadline("

    .line 797
    .line 798
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 799
    .line 800
    .line 801
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 802
    .line 803
    .line 804
    const-string v6, ") fetching from shared pool"

    .line 805
    .line 806
    invoke-virtual {v5, v6}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 807
    .line 808
    .line 809
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 810
    .line 811
    .line 812
    move-result-object v5

    .line 813
    invoke-static {v11, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 814
    .line 815
    .line 816
    :cond_28
    invoke-virtual/range {p0 .. p0}, Landroidx/recyclerview/widget/a1;->c()Landroidx/recyclerview/widget/z0;

    .line 817
    .line 818
    .line 819
    move-result-object v5

    .line 820
    iget-object v5, v5, Landroidx/recyclerview/widget/z0;->a:Landroid/util/SparseArray;

    .line 821
    .line 822
    invoke-virtual {v5, v15}, Landroid/util/SparseArray;->get(I)Ljava/lang/Object;

    .line 823
    .line 824
    .line 825
    move-result-object v5

    .line 826
    check-cast v5, Landroidx/recyclerview/widget/y0;

    .line 827
    .line 828
    if-eqz v5, :cond_2a

    .line 829
    .line 830
    iget-object v5, v5, Landroidx/recyclerview/widget/y0;->a:Ljava/util/ArrayList;

    .line 831
    .line 832
    invoke-virtual {v5}, Ljava/util/ArrayList;->isEmpty()Z

    .line 833
    .line 834
    .line 835
    move-result v6

    .line 836
    if-nez v6, :cond_2a

    .line 837
    .line 838
    invoke-virtual {v5}, Ljava/util/ArrayList;->size()I

    .line 839
    .line 840
    .line 841
    move-result v6

    .line 842
    const/4 v7, -0x1

    .line 843
    add-int/2addr v6, v7

    .line 844
    :goto_18
    if-ltz v6, :cond_2a

    .line 845
    .line 846
    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 847
    .line 848
    .line 849
    move-result-object v7

    .line 850
    check-cast v7, Landroidx/recyclerview/widget/i1;

    .line 851
    .line 852
    invoke-virtual {v7}, Landroidx/recyclerview/widget/i1;->isAttachedToTransitionOverlay()Z

    .line 853
    .line 854
    .line 855
    move-result v7

    .line 856
    if-nez v7, :cond_29

    .line 857
    .line 858
    invoke-virtual {v5, v6}, Ljava/util/ArrayList;->remove(I)Ljava/lang/Object;

    .line 859
    .line 860
    .line 861
    move-result-object v5

    .line 862
    check-cast v5, Landroidx/recyclerview/widget/i1;

    .line 863
    .line 864
    goto :goto_19

    .line 865
    :cond_29
    add-int/lit8 v6, v6, -0x1

    .line 866
    .line 867
    goto :goto_18

    .line 868
    :cond_2a
    const/4 v5, 0x0

    .line 869
    :goto_19
    if-eqz v5, :cond_2b

    .line 870
    .line 871
    invoke-virtual {v5}, Landroidx/recyclerview/widget/i1;->resetInternal()V

    .line 872
    .line 873
    .line 874
    sget-boolean v6, Landroidx/recyclerview/widget/RecyclerView;->y0:Z

    .line 875
    .line 876
    :cond_2b
    move-object v8, v5

    .line 877
    :cond_2c
    if-nez v8, :cond_33

    .line 878
    .line 879
    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView;->getNanoTime()J

    .line 880
    .line 881
    .line 882
    move-result-wide v5

    .line 883
    const-wide v7, 0x7fffffffffffffffL

    .line 884
    .line 885
    .line 886
    .line 887
    .line 888
    cmp-long v9, p2, v7

    .line 889
    .line 890
    if-eqz v9, :cond_2f

    .line 891
    .line 892
    iget-object v7, v0, Landroidx/recyclerview/widget/a1;->g:Landroidx/recyclerview/widget/z0;

    .line 893
    .line 894
    invoke-virtual {v7, v15}, Landroidx/recyclerview/widget/z0;->a(I)Landroidx/recyclerview/widget/y0;

    .line 895
    .line 896
    .line 897
    move-result-object v7

    .line 898
    iget-wide v7, v7, Landroidx/recyclerview/widget/y0;->c:J

    .line 899
    .line 900
    const-wide/16 v9, 0x0

    .line 901
    .line 902
    cmp-long v12, v7, v9

    .line 903
    .line 904
    if-eqz v12, :cond_2e

    .line 905
    .line 906
    add-long/2addr v7, v5

    .line 907
    cmp-long v9, v7, p2

    .line 908
    .line 909
    if-gez v9, :cond_2d

    .line 910
    .line 911
    goto :goto_1a

    .line 912
    :cond_2d
    const/4 v7, 0x0

    .line 913
    goto :goto_1b

    .line 914
    :cond_2e
    :goto_1a
    const/4 v7, 0x1

    .line 915
    :goto_1b
    if-nez v7, :cond_2f

    .line 916
    .line 917
    const/4 v1, 0x0

    .line 918
    return-object v1

    .line 919
    :cond_2f
    iget-object v7, v2, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 920
    .line 921
    invoke-virtual {v7, v2, v15}, Landroidx/recyclerview/widget/i0;->createViewHolder(Landroid/view/ViewGroup;I)Landroidx/recyclerview/widget/i1;

    .line 922
    .line 923
    .line 924
    move-result-object v8

    .line 925
    sget-boolean v7, Landroidx/recyclerview/widget/RecyclerView;->E0:Z

    .line 926
    .line 927
    if-eqz v7, :cond_30

    .line 928
    .line 929
    iget-object v7, v8, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 930
    .line 931
    invoke-static {v7}, Landroidx/recyclerview/widget/RecyclerView;->D(Landroid/view/View;)Landroidx/recyclerview/widget/RecyclerView;

    .line 932
    .line 933
    .line 934
    move-result-object v7

    .line 935
    if-eqz v7, :cond_30

    .line 936
    .line 937
    new-instance v9, Ljava/lang/ref/WeakReference;

    .line 938
    .line 939
    invoke-direct {v9, v7}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 940
    .line 941
    .line 942
    iput-object v9, v8, Landroidx/recyclerview/widget/i1;->mNestedRecyclerView:Ljava/lang/ref/WeakReference;

    .line 943
    .line 944
    :cond_30
    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView;->getNanoTime()J

    .line 945
    .line 946
    .line 947
    move-result-wide v9

    .line 948
    iget-object v7, v0, Landroidx/recyclerview/widget/a1;->g:Landroidx/recyclerview/widget/z0;

    .line 949
    .line 950
    sub-long/2addr v9, v5

    .line 951
    invoke-virtual {v7, v15}, Landroidx/recyclerview/widget/z0;->a(I)Landroidx/recyclerview/widget/y0;

    .line 952
    .line 953
    .line 954
    move-result-object v5

    .line 955
    iget-wide v6, v5, Landroidx/recyclerview/widget/y0;->c:J

    .line 956
    .line 957
    const-wide/16 v12, 0x0

    .line 958
    .line 959
    cmp-long v14, v6, v12

    .line 960
    .line 961
    if-nez v14, :cond_31

    .line 962
    .line 963
    goto :goto_1c

    .line 964
    :cond_31
    const-wide/16 v12, 0x4

    .line 965
    .line 966
    div-long/2addr v6, v12

    .line 967
    const-wide/16 v14, 0x3

    .line 968
    .line 969
    mul-long v6, v6, v14

    .line 970
    .line 971
    div-long/2addr v9, v12

    .line 972
    add-long/2addr v9, v6

    .line 973
    :goto_1c
    iput-wide v9, v5, Landroidx/recyclerview/widget/y0;->c:J

    .line 974
    .line 975
    sget-boolean v5, Landroidx/recyclerview/widget/RecyclerView;->z0:Z

    .line 976
    .line 977
    if-eqz v5, :cond_33

    .line 978
    .line 979
    const-string v5, "tryGetViewHolderForPositionByDeadline created new ViewHolder"

    .line 980
    .line 981
    invoke-static {v11, v5}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 982
    .line 983
    .line 984
    goto :goto_1d

    .line 985
    :cond_32
    new-instance v4, Ljava/lang/IndexOutOfBoundsException;

    .line 986
    .line 987
    new-instance v5, Ljava/lang/StringBuilder;

    .line 988
    .line 989
    const-string v6, "Inconsistency detected. Invalid item position "

    .line 990
    .line 991
    invoke-direct {v5, v6}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 992
    .line 993
    .line 994
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 995
    .line 996
    .line 997
    const-string v1, "(offset:"

    .line 998
    .line 999
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1000
    .line 1001
    .line 1002
    invoke-virtual {v5, v14}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1003
    .line 1004
    .line 1005
    const-string v1, ").state:"

    .line 1006
    .line 1007
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1008
    .line 1009
    .line 1010
    invoke-virtual {v3}, Landroidx/recyclerview/widget/e1;->b()I

    .line 1011
    .line 1012
    .line 1013
    move-result v1

    .line 1014
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1015
    .line 1016
    .line 1017
    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView;->y()Ljava/lang/String;

    .line 1018
    .line 1019
    .line 1020
    move-result-object v1

    .line 1021
    invoke-virtual {v5, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1022
    .line 1023
    .line 1024
    invoke-virtual {v5}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1025
    .line 1026
    .line 1027
    move-result-object v1

    .line 1028
    invoke-direct {v4, v1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 1029
    .line 1030
    .line 1031
    throw v4

    .line 1032
    :cond_33
    :goto_1d
    if-eqz v4, :cond_34

    .line 1033
    .line 1034
    iget-boolean v5, v3, Landroidx/recyclerview/widget/e1;->f:Z

    .line 1035
    .line 1036
    if-nez v5, :cond_34

    .line 1037
    .line 1038
    const/16 v5, 0x2000

    .line 1039
    .line 1040
    invoke-virtual {v8, v5}, Landroidx/recyclerview/widget/i1;->hasAnyOfTheFlags(I)Z

    .line 1041
    .line 1042
    .line 1043
    move-result v6

    .line 1044
    if-eqz v6, :cond_34

    .line 1045
    .line 1046
    const/4 v6, 0x0

    .line 1047
    invoke-virtual {v8, v6, v5}, Landroidx/recyclerview/widget/i1;->setFlags(II)V

    .line 1048
    .line 1049
    .line 1050
    iget-boolean v5, v3, Landroidx/recyclerview/widget/e1;->i:Z

    .line 1051
    .line 1052
    if-eqz v5, :cond_34

    .line 1053
    .line 1054
    invoke-static {v8}, Landroidx/recyclerview/widget/o0;->b(Landroidx/recyclerview/widget/i1;)V

    .line 1055
    .line 1056
    .line 1057
    iget-object v5, v2, Landroidx/recyclerview/widget/RecyclerView;->L:Landroidx/recyclerview/widget/o0;

    .line 1058
    .line 1059
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->getUnmodifiedPayloads()Ljava/util/List;

    .line 1060
    .line 1061
    .line 1062
    invoke-virtual {v5}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1063
    .line 1064
    .line 1065
    new-instance v5, Landroidx/recyclerview/widget/n0;

    .line 1066
    .line 1067
    invoke-direct {v5}, Landroidx/recyclerview/widget/n0;-><init>()V

    .line 1068
    .line 1069
    .line 1070
    invoke-virtual {v5, v8}, Landroidx/recyclerview/widget/n0;->a(Landroidx/recyclerview/widget/i1;)V

    .line 1071
    .line 1072
    .line 1073
    invoke-virtual {v2, v8, v5}, Landroidx/recyclerview/widget/RecyclerView;->T(Landroidx/recyclerview/widget/i1;Landroidx/recyclerview/widget/n0;)V

    .line 1074
    .line 1075
    .line 1076
    :cond_34
    iget-boolean v5, v3, Landroidx/recyclerview/widget/e1;->f:Z

    .line 1077
    .line 1078
    if-eqz v5, :cond_35

    .line 1079
    .line 1080
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->isBound()Z

    .line 1081
    .line 1082
    .line 1083
    move-result v5

    .line 1084
    if-eqz v5, :cond_35

    .line 1085
    .line 1086
    iput v1, v8, Landroidx/recyclerview/widget/i1;->mPreLayoutPosition:I

    .line 1087
    .line 1088
    goto :goto_21

    .line 1089
    :cond_35
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->isBound()Z

    .line 1090
    .line 1091
    .line 1092
    move-result v5

    .line 1093
    if-eqz v5, :cond_36

    .line 1094
    .line 1095
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->needsUpdate()Z

    .line 1096
    .line 1097
    .line 1098
    move-result v5

    .line 1099
    if-nez v5, :cond_36

    .line 1100
    .line 1101
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->isInvalid()Z

    .line 1102
    .line 1103
    .line 1104
    move-result v5

    .line 1105
    if-eqz v5, :cond_3b

    .line 1106
    .line 1107
    :cond_36
    sget-boolean v5, Landroidx/recyclerview/widget/RecyclerView;->y0:Z

    .line 1108
    .line 1109
    if-eqz v5, :cond_38

    .line 1110
    .line 1111
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->isRemoved()Z

    .line 1112
    .line 1113
    .line 1114
    move-result v5

    .line 1115
    if-nez v5, :cond_37

    .line 1116
    .line 1117
    goto :goto_1e

    .line 1118
    :cond_37
    new-instance v1, Ljava/lang/IllegalStateException;

    .line 1119
    .line 1120
    new-instance v3, Ljava/lang/StringBuilder;

    .line 1121
    .line 1122
    const-string v4, "Removed holder should be bound and it should come here only in pre-layout. Holder: "

    .line 1123
    .line 1124
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1125
    .line 1126
    .line 1127
    invoke-virtual {v3, v8}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 1128
    .line 1129
    .line 1130
    invoke-static {v2, v3}, Landroidx/recyclerview/widget/c;->b(Landroidx/recyclerview/widget/RecyclerView;Ljava/lang/StringBuilder;)Ljava/lang/String;

    .line 1131
    .line 1132
    .line 1133
    move-result-object v2

    .line 1134
    invoke-direct {v1, v2}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 1135
    .line 1136
    .line 1137
    throw v1

    .line 1138
    :cond_38
    :goto_1e
    iget-object v5, v2, Landroidx/recyclerview/widget/RecyclerView;->e:Landroidx/recyclerview/widget/b;

    .line 1139
    .line 1140
    const/4 v6, 0x0

    .line 1141
    invoke-virtual {v5, v1, v6}, Landroidx/recyclerview/widget/b;->f(II)I

    .line 1142
    .line 1143
    .line 1144
    move-result v5

    .line 1145
    const/4 v6, 0x0

    .line 1146
    iput-object v6, v8, Landroidx/recyclerview/widget/i1;->mBindingAdapter:Landroidx/recyclerview/widget/i0;

    .line 1147
    .line 1148
    iput-object v2, v8, Landroidx/recyclerview/widget/i1;->mOwnerRecyclerView:Landroidx/recyclerview/widget/RecyclerView;

    .line 1149
    .line 1150
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->getItemViewType()I

    .line 1151
    .line 1152
    .line 1153
    move-result v7

    .line 1154
    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView;->getNanoTime()J

    .line 1155
    .line 1156
    .line 1157
    move-result-wide v9

    .line 1158
    const-wide v11, 0x7fffffffffffffffL

    .line 1159
    .line 1160
    .line 1161
    .line 1162
    .line 1163
    cmp-long v13, p2, v11

    .line 1164
    .line 1165
    if-eqz v13, :cond_3c

    .line 1166
    .line 1167
    iget-object v11, v0, Landroidx/recyclerview/widget/a1;->g:Landroidx/recyclerview/widget/z0;

    .line 1168
    .line 1169
    invoke-virtual {v11, v7}, Landroidx/recyclerview/widget/z0;->a(I)Landroidx/recyclerview/widget/y0;

    .line 1170
    .line 1171
    .line 1172
    move-result-object v7

    .line 1173
    iget-wide v11, v7, Landroidx/recyclerview/widget/y0;->d:J

    .line 1174
    .line 1175
    const-wide/16 v13, 0x0

    .line 1176
    .line 1177
    cmp-long v7, v11, v13

    .line 1178
    .line 1179
    if-eqz v7, :cond_3a

    .line 1180
    .line 1181
    add-long/2addr v11, v9

    .line 1182
    cmp-long v7, v11, p2

    .line 1183
    .line 1184
    if-gez v7, :cond_39

    .line 1185
    .line 1186
    goto :goto_1f

    .line 1187
    :cond_39
    const/4 v7, 0x0

    .line 1188
    goto :goto_20

    .line 1189
    :cond_3a
    :goto_1f
    const/4 v7, 0x1

    .line 1190
    :goto_20
    if-nez v7, :cond_3c

    .line 1191
    .line 1192
    :cond_3b
    :goto_21
    const/4 v1, 0x0

    .line 1193
    goto/16 :goto_27

    .line 1194
    .line 1195
    :cond_3c
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->isTmpDetached()Z

    .line 1196
    .line 1197
    .line 1198
    move-result v7

    .line 1199
    if-eqz v7, :cond_3d

    .line 1200
    .line 1201
    iget-object v7, v8, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 1202
    .line 1203
    invoke-virtual {v2}, Landroid/view/ViewGroup;->getChildCount()I

    .line 1204
    .line 1205
    .line 1206
    move-result v11

    .line 1207
    iget-object v12, v8, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 1208
    .line 1209
    invoke-virtual {v12}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 1210
    .line 1211
    .line 1212
    move-result-object v12

    .line 1213
    invoke-static {v2, v7, v11, v12}, Landroidx/recyclerview/widget/RecyclerView;->d(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/View;ILandroid/view/ViewGroup$LayoutParams;)V

    .line 1214
    .line 1215
    .line 1216
    const/4 v7, 0x1

    .line 1217
    goto :goto_22

    .line 1218
    :cond_3d
    const/4 v7, 0x0

    .line 1219
    :goto_22
    iget-object v11, v2, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 1220
    .line 1221
    invoke-virtual {v11, v8, v5}, Landroidx/recyclerview/widget/i0;->bindViewHolder(Landroidx/recyclerview/widget/i1;I)V

    .line 1222
    .line 1223
    .line 1224
    if-eqz v7, :cond_3e

    .line 1225
    .line 1226
    iget-object v5, v8, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 1227
    .line 1228
    invoke-static {v2, v5}, Landroidx/recyclerview/widget/RecyclerView;->e(Landroidx/recyclerview/widget/RecyclerView;Landroid/view/View;)V

    .line 1229
    .line 1230
    .line 1231
    :cond_3e
    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView;->getNanoTime()J

    .line 1232
    .line 1233
    .line 1234
    move-result-wide v11

    .line 1235
    iget-object v5, v0, Landroidx/recyclerview/widget/a1;->g:Landroidx/recyclerview/widget/z0;

    .line 1236
    .line 1237
    invoke-virtual {v8}, Landroidx/recyclerview/widget/i1;->getItemViewType()I

    .line 1238
    .line 1239
    .line 1240
    move-result v7

    .line 1241
    sub-long/2addr v11, v9

    .line 1242
    invoke-virtual {v5, v7}, Landroidx/recyclerview/widget/z0;->a(I)Landroidx/recyclerview/widget/y0;

    .line 1243
    .line 1244
    .line 1245
    move-result-object v5

    .line 1246
    iget-wide v9, v5, Landroidx/recyclerview/widget/y0;->d:J

    .line 1247
    .line 1248
    const-wide/16 v13, 0x0

    .line 1249
    .line 1250
    cmp-long v7, v9, v13

    .line 1251
    .line 1252
    if-nez v7, :cond_3f

    .line 1253
    .line 1254
    goto :goto_23

    .line 1255
    :cond_3f
    const-wide/16 v13, 0x4

    .line 1256
    .line 1257
    div-long/2addr v9, v13

    .line 1258
    const-wide/16 v15, 0x3

    .line 1259
    .line 1260
    mul-long v9, v9, v15

    .line 1261
    .line 1262
    div-long/2addr v11, v13

    .line 1263
    add-long/2addr v11, v9

    .line 1264
    :goto_23
    iput-wide v11, v5, Landroidx/recyclerview/widget/y0;->d:J

    .line 1265
    .line 1266
    iget-object v5, v2, Landroidx/recyclerview/widget/RecyclerView;->B:Landroid/view/accessibility/AccessibilityManager;

    .line 1267
    .line 1268
    if-eqz v5, :cond_40

    .line 1269
    .line 1270
    invoke-virtual {v5}, Landroid/view/accessibility/AccessibilityManager;->isEnabled()Z

    .line 1271
    .line 1272
    .line 1273
    move-result v5

    .line 1274
    if-eqz v5, :cond_40

    .line 1275
    .line 1276
    const/4 v5, 0x1

    .line 1277
    goto :goto_24

    .line 1278
    :cond_40
    const/4 v5, 0x0

    .line 1279
    :goto_24
    if-eqz v5, :cond_46

    .line 1280
    .line 1281
    iget-object v5, v8, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 1282
    .line 1283
    sget-object v7, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 1284
    .line 1285
    invoke-static {v5}, Lg/j;->c(Landroid/view/View;)I

    .line 1286
    .line 1287
    .line 1288
    move-result v7

    .line 1289
    if-nez v7, :cond_41

    .line 1290
    .line 1291
    const/4 v7, 0x1

    .line 1292
    invoke-static {v5, v7}, Lg/j;->s(Landroid/view/View;I)V

    .line 1293
    .line 1294
    .line 1295
    :cond_41
    iget-object v7, v2, Landroidx/recyclerview/widget/RecyclerView;->m0:Landroidx/recyclerview/widget/k1;

    .line 1296
    .line 1297
    if-nez v7, :cond_42

    .line 1298
    .line 1299
    goto :goto_26

    .line 1300
    :cond_42
    iget-object v7, v7, Landroidx/recyclerview/widget/k1;->e:Landroidx/recyclerview/widget/j1;

    .line 1301
    .line 1302
    instance-of v9, v7, Landroidx/recyclerview/widget/j1;

    .line 1303
    .line 1304
    if-eqz v9, :cond_45

    .line 1305
    .line 1306
    invoke-virtual {v7}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 1307
    .line 1308
    .line 1309
    invoke-static {v5}, Lg/v;->a(Landroid/view/View;)Landroid/view/View$AccessibilityDelegate;

    .line 1310
    .line 1311
    .line 1312
    move-result-object v9

    .line 1313
    if-nez v9, :cond_43

    .line 1314
    .line 1315
    goto :goto_25

    .line 1316
    :cond_43
    instance-of v6, v9, Lg/a;

    .line 1317
    .line 1318
    if-eqz v6, :cond_44

    .line 1319
    .line 1320
    check-cast v9, Lg/a;

    .line 1321
    .line 1322
    iget-object v6, v9, Lg/a;->a:Lg/c;

    .line 1323
    .line 1324
    goto :goto_25

    .line 1325
    :cond_44
    new-instance v6, Lg/c;

    .line 1326
    .line 1327
    invoke-direct {v6, v9}, Lg/c;-><init>(Landroid/view/View$AccessibilityDelegate;)V

    .line 1328
    .line 1329
    .line 1330
    :goto_25
    if-eqz v6, :cond_45

    .line 1331
    .line 1332
    if-eq v6, v7, :cond_45

    .line 1333
    .line 1334
    iget-object v9, v7, Landroidx/recyclerview/widget/j1;->e:Ljava/util/WeakHashMap;

    .line 1335
    .line 1336
    invoke-virtual {v9, v5, v6}, Ljava/util/WeakHashMap;->put(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;

    .line 1337
    .line 1338
    .line 1339
    :cond_45
    invoke-static {v5, v7}, Lg/v;->b(Landroid/view/View;Lg/c;)V

    .line 1340
    .line 1341
    .line 1342
    :cond_46
    :goto_26
    iget-boolean v3, v3, Landroidx/recyclerview/widget/e1;->f:Z

    .line 1343
    .line 1344
    if-eqz v3, :cond_47

    .line 1345
    .line 1346
    iput v1, v8, Landroidx/recyclerview/widget/i1;->mPreLayoutPosition:I

    .line 1347
    .line 1348
    :cond_47
    const/4 v1, 0x1

    .line 1349
    :goto_27
    iget-object v3, v8, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 1350
    .line 1351
    invoke-virtual {v3}, Landroid/view/View;->getLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 1352
    .line 1353
    .line 1354
    move-result-object v3

    .line 1355
    if-nez v3, :cond_48

    .line 1356
    .line 1357
    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView;->generateDefaultLayoutParams()Landroid/view/ViewGroup$LayoutParams;

    .line 1358
    .line 1359
    .line 1360
    move-result-object v2

    .line 1361
    goto :goto_28

    .line 1362
    :cond_48
    invoke-virtual {v2, v3}, Landroidx/recyclerview/widget/RecyclerView;->checkLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Z

    .line 1363
    .line 1364
    .line 1365
    move-result v5

    .line 1366
    if-nez v5, :cond_49

    .line 1367
    .line 1368
    invoke-virtual {v2, v3}, Landroidx/recyclerview/widget/RecyclerView;->generateLayoutParams(Landroid/view/ViewGroup$LayoutParams;)Landroid/view/ViewGroup$LayoutParams;

    .line 1369
    .line 1370
    .line 1371
    move-result-object v2

    .line 1372
    :goto_28
    check-cast v2, Landroidx/recyclerview/widget/u0;

    .line 1373
    .line 1374
    iget-object v3, v8, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 1375
    .line 1376
    invoke-virtual {v3, v2}, Landroid/view/View;->setLayoutParams(Landroid/view/ViewGroup$LayoutParams;)V

    .line 1377
    .line 1378
    .line 1379
    goto :goto_29

    .line 1380
    :cond_49
    move-object v2, v3

    .line 1381
    check-cast v2, Landroidx/recyclerview/widget/u0;

    .line 1382
    .line 1383
    :goto_29
    iput-object v8, v2, Landroidx/recyclerview/widget/u0;->a:Landroidx/recyclerview/widget/i1;

    .line 1384
    .line 1385
    if-eqz v4, :cond_4a

    .line 1386
    .line 1387
    if-eqz v1, :cond_4a

    .line 1388
    .line 1389
    const/4 v1, 0x1

    .line 1390
    goto :goto_2a

    .line 1391
    :cond_4a
    const/4 v1, 0x0

    .line 1392
    :goto_2a
    iput-boolean v1, v2, Landroidx/recyclerview/widget/u0;->d:Z

    .line 1393
    .line 1394
    return-object v8

    .line 1395
    :cond_4b
    new-instance v3, Ljava/lang/IndexOutOfBoundsException;

    .line 1396
    .line 1397
    new-instance v4, Ljava/lang/StringBuilder;

    .line 1398
    .line 1399
    const-string v5, "Invalid item position "

    .line 1400
    .line 1401
    invoke-direct {v4, v5}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 1402
    .line 1403
    .line 1404
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1405
    .line 1406
    .line 1407
    const-string v5, "("

    .line 1408
    .line 1409
    invoke-virtual {v4, v5}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1410
    .line 1411
    .line 1412
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1413
    .line 1414
    .line 1415
    const-string v1, "). Item count:"

    .line 1416
    .line 1417
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1418
    .line 1419
    .line 1420
    iget-object v1, v2, Landroidx/recyclerview/widget/RecyclerView;->f0:Landroidx/recyclerview/widget/e1;

    .line 1421
    .line 1422
    invoke-virtual {v1}, Landroidx/recyclerview/widget/e1;->b()I

    .line 1423
    .line 1424
    .line 1425
    move-result v1

    .line 1426
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(I)Ljava/lang/StringBuilder;

    .line 1427
    .line 1428
    .line 1429
    invoke-virtual {v2}, Landroidx/recyclerview/widget/RecyclerView;->y()Ljava/lang/String;

    .line 1430
    .line 1431
    .line 1432
    move-result-object v1

    .line 1433
    invoke-virtual {v4, v1}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 1434
    .line 1435
    .line 1436
    invoke-virtual {v4}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 1437
    .line 1438
    .line 1439
    move-result-object v1

    .line 1440
    invoke-direct {v3, v1}, Ljava/lang/IndexOutOfBoundsException;-><init>(Ljava/lang/String;)V

    .line 1441
    .line 1442
    .line 1443
    throw v3
.end method

.method public final l(Landroidx/recyclerview/widget/i1;)V
    .locals 1

    .line 1
    iget-boolean v0, p1, Landroidx/recyclerview/widget/i1;->mInChangeScrap:Z

    if-eqz v0, :cond_0

    iget-object v0, p0, Landroidx/recyclerview/widget/a1;->b:Ljava/util/ArrayList;

    goto :goto_0

    :cond_0
    iget-object v0, p0, Landroidx/recyclerview/widget/a1;->a:Ljava/util/ArrayList;

    :goto_0
    invoke-virtual {v0, p1}, Ljava/util/ArrayList;->remove(Ljava/lang/Object;)Z

    const/4 v0, 0x0

    iput-object v0, p1, Landroidx/recyclerview/widget/i1;->mScrapContainer:Landroidx/recyclerview/widget/a1;

    const/4 v0, 0x0

    iput-boolean v0, p1, Landroidx/recyclerview/widget/i1;->mInChangeScrap:Z

    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->clearReturnedFromScrapFlag()V

    return-void
.end method

.method public final m()V
    .locals 4

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/a1;->h:Landroidx/recyclerview/widget/RecyclerView;

    iget-object v0, v0, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    if-eqz v0, :cond_0

    iget v0, v0, Landroidx/recyclerview/widget/t0;->i:I

    goto :goto_0

    :cond_0
    const/4 v0, 0x0

    :goto_0
    iget v1, p0, Landroidx/recyclerview/widget/a1;->e:I

    add-int/2addr v1, v0

    iput v1, p0, Landroidx/recyclerview/widget/a1;->f:I

    iget-object v0, p0, Landroidx/recyclerview/widget/a1;->c:Ljava/util/ArrayList;

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v1

    add-int/lit8 v1, v1, -0x1

    :goto_1
    if-ltz v1, :cond_1

    invoke-virtual {v0}, Ljava/util/ArrayList;->size()I

    move-result v2

    iget v3, p0, Landroidx/recyclerview/widget/a1;->f:I

    if-le v2, v3, :cond_1

    invoke-virtual {p0, v1}, Landroidx/recyclerview/widget/a1;->g(I)V

    add-int/lit8 v1, v1, -0x1

    goto :goto_1

    :cond_1
    return-void
.end method
