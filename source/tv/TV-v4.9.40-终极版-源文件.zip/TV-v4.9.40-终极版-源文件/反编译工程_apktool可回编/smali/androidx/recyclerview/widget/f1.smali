.class public final Landroidx/recyclerview/widget/f1;
.super Landroidx/recyclerview/widget/m0;
.source "SourceFile"
