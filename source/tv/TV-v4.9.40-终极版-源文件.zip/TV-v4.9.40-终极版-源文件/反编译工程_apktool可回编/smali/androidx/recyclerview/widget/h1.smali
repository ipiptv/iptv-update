.class public final Landroidx/recyclerview/widget/h1;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Runnable;


# instance fields
.field public a:I

.field public b:I

.field public c:Landroid/widget/OverScroller;

.field public d:Landroid/view/animation/Interpolator;

.field public e:Z

.field public f:Z

.field public final synthetic g:Landroidx/recyclerview/widget/RecyclerView;


# direct methods
.method public constructor <init>(Landroidx/recyclerview/widget/RecyclerView;)V
    .locals 2

    iput-object p1, p0, Landroidx/recyclerview/widget/h1;->g:Landroidx/recyclerview/widget/RecyclerView;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget-object v0, Landroidx/recyclerview/widget/RecyclerView;->G0:Landroidx/recyclerview/widget/g0;

    iput-object v0, p0, Landroidx/recyclerview/widget/h1;->d:Landroid/view/animation/Interpolator;

    const/4 v1, 0x0

    iput-boolean v1, p0, Landroidx/recyclerview/widget/h1;->e:Z

    iput-boolean v1, p0, Landroidx/recyclerview/widget/h1;->f:Z

    new-instance v1, Landroid/widget/OverScroller;

    invoke-virtual {p1}, Landroid/view/View;->getContext()Landroid/content/Context;

    move-result-object p1

    invoke-direct {v1, p1, v0}, Landroid/widget/OverScroller;-><init>(Landroid/content/Context;Landroid/view/animation/Interpolator;)V

    iput-object v1, p0, Landroidx/recyclerview/widget/h1;->c:Landroid/widget/OverScroller;

    return-void
.end method


# virtual methods
.method public final a(II)V
    .locals 13

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/h1;->g:Landroidx/recyclerview/widget/RecyclerView;

    .line 2
    .line 3
    const/4 v1, 0x2

    .line 4
    invoke-virtual {v0, v1}, Landroidx/recyclerview/widget/RecyclerView;->setScrollState(I)V

    .line 5
    .line 6
    .line 7
    const/4 v1, 0x0

    .line 8
    iput v1, p0, Landroidx/recyclerview/widget/h1;->b:I

    .line 9
    .line 10
    iput v1, p0, Landroidx/recyclerview/widget/h1;->a:I

    .line 11
    .line 12
    iget-object v1, p0, Landroidx/recyclerview/widget/h1;->d:Landroid/view/animation/Interpolator;

    .line 13
    .line 14
    sget-object v2, Landroidx/recyclerview/widget/RecyclerView;->G0:Landroidx/recyclerview/widget/g0;

    .line 15
    .line 16
    if-eq v1, v2, :cond_0

    .line 17
    .line 18
    iput-object v2, p0, Landroidx/recyclerview/widget/h1;->d:Landroid/view/animation/Interpolator;

    .line 19
    .line 20
    new-instance v1, Landroid/widget/OverScroller;

    .line 21
    .line 22
    invoke-virtual {v0}, Landroid/view/View;->getContext()Landroid/content/Context;

    .line 23
    .line 24
    .line 25
    move-result-object v3

    .line 26
    invoke-direct {v1, v3, v2}, Landroid/widget/OverScroller;-><init>(Landroid/content/Context;Landroid/view/animation/Interpolator;)V

    .line 27
    .line 28
    .line 29
    iput-object v1, p0, Landroidx/recyclerview/widget/h1;->c:Landroid/widget/OverScroller;

    .line 30
    .line 31
    :cond_0
    iget-object v4, p0, Landroidx/recyclerview/widget/h1;->c:Landroid/widget/OverScroller;

    .line 32
    .line 33
    const/4 v5, 0x0

    .line 34
    const/4 v6, 0x0

    .line 35
    const/high16 v9, -0x80000000

    .line 36
    .line 37
    const v10, 0x7fffffff

    .line 38
    .line 39
    .line 40
    const/high16 v11, -0x80000000

    .line 41
    .line 42
    const v12, 0x7fffffff

    .line 43
    .line 44
    .line 45
    move v7, p1

    .line 46
    move v8, p2

    .line 47
    invoke-virtual/range {v4 .. v12}, Landroid/widget/OverScroller;->fling(IIIIIIII)V

    .line 48
    .line 49
    .line 50
    iget-boolean p1, p0, Landroidx/recyclerview/widget/h1;->e:Z

    .line 51
    .line 52
    if-eqz p1, :cond_1

    .line 53
    .line 54
    const/4 p1, 0x1

    .line 55
    iput-boolean p1, p0, Landroidx/recyclerview/widget/h1;->f:Z

    .line 56
    .line 57
    goto :goto_0

    .line 58
    :cond_1
    invoke-virtual {v0, p0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 59
    .line 60
    .line 61
    sget-object p1, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 62
    .line 63
    invoke-static {v0, p0}, Lg/j;->m(Landroid/view/View;Ljava/lang/Runnable;)V

    .line 64
    .line 65
    .line 66
    :goto_0
    return-void
.end method

.method public final run()V
    .locals 20

    .line 1
    move-object/from16 v0, p0

    .line 2
    .line 3
    iget-object v9, v0, Landroidx/recyclerview/widget/h1;->g:Landroidx/recyclerview/widget/RecyclerView;

    .line 4
    .line 5
    iget-object v1, v9, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 6
    .line 7
    if-nez v1, :cond_0

    .line 8
    .line 9
    invoke-virtual {v9, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 10
    .line 11
    .line 12
    iget-object v1, v0, Landroidx/recyclerview/widget/h1;->c:Landroid/widget/OverScroller;

    .line 13
    .line 14
    invoke-virtual {v1}, Landroid/widget/OverScroller;->abortAnimation()V

    .line 15
    .line 16
    .line 17
    return-void

    .line 18
    :cond_0
    const/4 v10, 0x0

    .line 19
    iput-boolean v10, v0, Landroidx/recyclerview/widget/h1;->f:Z

    .line 20
    .line 21
    const/4 v11, 0x1

    .line 22
    iput-boolean v11, v0, Landroidx/recyclerview/widget/h1;->e:Z

    .line 23
    .line 24
    invoke-virtual {v9}, Landroidx/recyclerview/widget/RecyclerView;->m()V

    .line 25
    .line 26
    .line 27
    iget-object v12, v0, Landroidx/recyclerview/widget/h1;->c:Landroid/widget/OverScroller;

    .line 28
    .line 29
    invoke-virtual {v12}, Landroid/widget/OverScroller;->computeScrollOffset()Z

    .line 30
    .line 31
    .line 32
    move-result v1

    .line 33
    if-eqz v1, :cond_1a

    .line 34
    .line 35
    invoke-virtual {v12}, Landroid/widget/OverScroller;->getCurrX()I

    .line 36
    .line 37
    .line 38
    move-result v1

    .line 39
    invoke-virtual {v12}, Landroid/widget/OverScroller;->getCurrY()I

    .line 40
    .line 41
    .line 42
    move-result v2

    .line 43
    iget v3, v0, Landroidx/recyclerview/widget/h1;->a:I

    .line 44
    .line 45
    sub-int v3, v1, v3

    .line 46
    .line 47
    iget v4, v0, Landroidx/recyclerview/widget/h1;->b:I

    .line 48
    .line 49
    sub-int v4, v2, v4

    .line 50
    .line 51
    iput v1, v0, Landroidx/recyclerview/widget/h1;->a:I

    .line 52
    .line 53
    iput v2, v0, Landroidx/recyclerview/widget/h1;->b:I

    .line 54
    .line 55
    iget-object v1, v9, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 56
    .line 57
    iget-object v2, v9, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 58
    .line 59
    invoke-virtual {v9}, Landroid/view/View;->getWidth()I

    .line 60
    .line 61
    .line 62
    move-result v5

    .line 63
    invoke-static {v3, v1, v2, v5}, Landroidx/recyclerview/widget/RecyclerView;->l(ILandroid/widget/EdgeEffect;Landroid/widget/EdgeEffect;I)I

    .line 64
    .line 65
    .line 66
    move-result v7

    .line 67
    iget-object v1, v9, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 68
    .line 69
    iget-object v2, v9, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 70
    .line 71
    invoke-virtual {v9}, Landroid/view/View;->getHeight()I

    .line 72
    .line 73
    .line 74
    move-result v3

    .line 75
    invoke-static {v4, v1, v2, v3}, Landroidx/recyclerview/widget/RecyclerView;->l(ILandroid/widget/EdgeEffect;Landroid/widget/EdgeEffect;I)I

    .line 76
    .line 77
    .line 78
    move-result v8

    .line 79
    iget-object v4, v9, Landroidx/recyclerview/widget/RecyclerView;->r0:[I

    .line 80
    .line 81
    aput v10, v4, v10

    .line 82
    .line 83
    aput v10, v4, v11

    .line 84
    .line 85
    const/4 v5, 0x0

    .line 86
    const/4 v6, 0x1

    .line 87
    move-object v1, v9

    .line 88
    move v2, v7

    .line 89
    move v3, v8

    .line 90
    invoke-virtual/range {v1 .. v6}, Landroidx/recyclerview/widget/RecyclerView;->r(II[I[II)Z

    .line 91
    .line 92
    .line 93
    move-result v1

    .line 94
    iget-object v13, v9, Landroidx/recyclerview/widget/RecyclerView;->r0:[I

    .line 95
    .line 96
    if-eqz v1, :cond_1

    .line 97
    .line 98
    aget v1, v13, v10

    .line 99
    .line 100
    sub-int/2addr v7, v1

    .line 101
    aget v1, v13, v11

    .line 102
    .line 103
    sub-int/2addr v8, v1

    .line 104
    :cond_1
    invoke-virtual {v9}, Landroid/view/View;->getOverScrollMode()I

    .line 105
    .line 106
    .line 107
    move-result v1

    .line 108
    const/4 v14, 0x2

    .line 109
    if-eq v1, v14, :cond_2

    .line 110
    .line 111
    invoke-virtual {v9, v7, v8}, Landroidx/recyclerview/widget/RecyclerView;->k(II)V

    .line 112
    .line 113
    .line 114
    :cond_2
    iget-object v1, v9, Landroidx/recyclerview/widget/RecyclerView;->m:Landroidx/recyclerview/widget/i0;

    .line 115
    .line 116
    if-eqz v1, :cond_3

    .line 117
    .line 118
    aput v10, v13, v10

    .line 119
    .line 120
    aput v10, v13, v11

    .line 121
    .line 122
    invoke-virtual {v9, v7, v8, v13}, Landroidx/recyclerview/widget/RecyclerView;->Z(II[I)V

    .line 123
    .line 124
    .line 125
    aget v1, v13, v10

    .line 126
    .line 127
    aget v2, v13, v11

    .line 128
    .line 129
    sub-int/2addr v7, v1

    .line 130
    sub-int/2addr v8, v2

    .line 131
    iget-object v3, v9, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 132
    .line 133
    invoke-virtual {v3}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 134
    .line 135
    .line 136
    move v15, v1

    .line 137
    move/from16 v16, v7

    .line 138
    .line 139
    move/from16 v17, v8

    .line 140
    .line 141
    move v8, v2

    .line 142
    goto :goto_0

    .line 143
    :cond_3
    move/from16 v16, v7

    .line 144
    .line 145
    move/from16 v17, v8

    .line 146
    .line 147
    const/4 v8, 0x0

    .line 148
    const/4 v15, 0x0

    .line 149
    :goto_0
    iget-object v1, v9, Landroidx/recyclerview/widget/RecyclerView;->p:Ljava/util/ArrayList;

    .line 150
    .line 151
    invoke-virtual {v1}, Ljava/util/ArrayList;->isEmpty()Z

    .line 152
    .line 153
    .line 154
    move-result v1

    .line 155
    if-nez v1, :cond_4

    .line 156
    .line 157
    invoke-virtual {v9}, Landroid/view/View;->invalidate()V

    .line 158
    .line 159
    .line 160
    :cond_4
    iget-object v7, v9, Landroidx/recyclerview/widget/RecyclerView;->r0:[I

    .line 161
    .line 162
    aput v10, v7, v10

    .line 163
    .line 164
    aput v10, v7, v11

    .line 165
    .line 166
    const/4 v6, 0x0

    .line 167
    const/16 v18, 0x1

    .line 168
    .line 169
    move-object v1, v9

    .line 170
    move v2, v15

    .line 171
    move v3, v8

    .line 172
    move/from16 v4, v16

    .line 173
    .line 174
    move/from16 v5, v17

    .line 175
    .line 176
    move-object/from16 v19, v7

    .line 177
    .line 178
    move/from16 v7, v18

    .line 179
    .line 180
    move v14, v8

    .line 181
    move-object/from16 v8, v19

    .line 182
    .line 183
    invoke-virtual/range {v1 .. v8}, Landroidx/recyclerview/widget/RecyclerView;->s(IIII[II[I)V

    .line 184
    .line 185
    .line 186
    aget v1, v13, v10

    .line 187
    .line 188
    sub-int v16, v16, v1

    .line 189
    .line 190
    aget v1, v13, v11

    .line 191
    .line 192
    sub-int v17, v17, v1

    .line 193
    .line 194
    if-nez v15, :cond_5

    .line 195
    .line 196
    if-eqz v14, :cond_6

    .line 197
    .line 198
    :cond_5
    invoke-virtual {v9, v15, v14}, Landroidx/recyclerview/widget/RecyclerView;->t(II)V

    .line 199
    .line 200
    .line 201
    :cond_6
    invoke-static {v9}, Landroidx/recyclerview/widget/RecyclerView;->c(Landroidx/recyclerview/widget/RecyclerView;)Z

    .line 202
    .line 203
    .line 204
    move-result v1

    .line 205
    if-nez v1, :cond_7

    .line 206
    .line 207
    invoke-virtual {v9}, Landroid/view/View;->invalidate()V

    .line 208
    .line 209
    .line 210
    :cond_7
    invoke-virtual {v12}, Landroid/widget/OverScroller;->getCurrX()I

    .line 211
    .line 212
    .line 213
    move-result v1

    .line 214
    invoke-virtual {v12}, Landroid/widget/OverScroller;->getFinalX()I

    .line 215
    .line 216
    .line 217
    move-result v2

    .line 218
    if-ne v1, v2, :cond_8

    .line 219
    .line 220
    const/4 v1, 0x1

    .line 221
    goto :goto_1

    .line 222
    :cond_8
    const/4 v1, 0x0

    .line 223
    :goto_1
    invoke-virtual {v12}, Landroid/widget/OverScroller;->getCurrY()I

    .line 224
    .line 225
    .line 226
    move-result v2

    .line 227
    invoke-virtual {v12}, Landroid/widget/OverScroller;->getFinalY()I

    .line 228
    .line 229
    .line 230
    move-result v3

    .line 231
    if-ne v2, v3, :cond_9

    .line 232
    .line 233
    const/4 v2, 0x1

    .line 234
    goto :goto_2

    .line 235
    :cond_9
    const/4 v2, 0x0

    .line 236
    :goto_2
    invoke-virtual {v12}, Landroid/widget/OverScroller;->isFinished()Z

    .line 237
    .line 238
    .line 239
    move-result v3

    .line 240
    if-nez v3, :cond_c

    .line 241
    .line 242
    if-nez v1, :cond_a

    .line 243
    .line 244
    if-eqz v16, :cond_b

    .line 245
    .line 246
    :cond_a
    if-nez v2, :cond_c

    .line 247
    .line 248
    if-eqz v17, :cond_b

    .line 249
    .line 250
    goto :goto_3

    .line 251
    :cond_b
    const/4 v1, 0x0

    .line 252
    goto :goto_4

    .line 253
    :cond_c
    :goto_3
    const/4 v1, 0x1

    .line 254
    :goto_4
    iget-object v2, v9, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 255
    .line 256
    invoke-virtual {v2}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 257
    .line 258
    .line 259
    if-eqz v1, :cond_18

    .line 260
    .line 261
    invoke-virtual {v9}, Landroid/view/View;->getOverScrollMode()I

    .line 262
    .line 263
    .line 264
    move-result v1

    .line 265
    const/4 v2, 0x2

    .line 266
    if-eq v1, v2, :cond_16

    .line 267
    .line 268
    invoke-virtual {v12}, Landroid/widget/OverScroller;->getCurrVelocity()F

    .line 269
    .line 270
    .line 271
    move-result v1

    .line 272
    float-to-int v1, v1

    .line 273
    if-gez v16, :cond_d

    .line 274
    .line 275
    neg-int v2, v1

    .line 276
    goto :goto_5

    .line 277
    :cond_d
    if-lez v16, :cond_e

    .line 278
    .line 279
    move v2, v1

    .line 280
    goto :goto_5

    .line 281
    :cond_e
    const/4 v2, 0x0

    .line 282
    :goto_5
    if-gez v17, :cond_f

    .line 283
    .line 284
    neg-int v1, v1

    .line 285
    goto :goto_6

    .line 286
    :cond_f
    if-lez v17, :cond_10

    .line 287
    .line 288
    goto :goto_6

    .line 289
    :cond_10
    const/4 v1, 0x0

    .line 290
    :goto_6
    if-gez v2, :cond_11

    .line 291
    .line 292
    invoke-virtual {v9}, Landroidx/recyclerview/widget/RecyclerView;->v()V

    .line 293
    .line 294
    .line 295
    iget-object v3, v9, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 296
    .line 297
    invoke-virtual {v3}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 298
    .line 299
    .line 300
    move-result v3

    .line 301
    if-eqz v3, :cond_12

    .line 302
    .line 303
    iget-object v3, v9, Landroidx/recyclerview/widget/RecyclerView;->H:Landroid/widget/EdgeEffect;

    .line 304
    .line 305
    neg-int v4, v2

    .line 306
    invoke-virtual {v3, v4}, Landroid/widget/EdgeEffect;->onAbsorb(I)V

    .line 307
    .line 308
    .line 309
    goto :goto_7

    .line 310
    :cond_11
    if-lez v2, :cond_12

    .line 311
    .line 312
    invoke-virtual {v9}, Landroidx/recyclerview/widget/RecyclerView;->w()V

    .line 313
    .line 314
    .line 315
    iget-object v3, v9, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 316
    .line 317
    invoke-virtual {v3}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 318
    .line 319
    .line 320
    move-result v3

    .line 321
    if-eqz v3, :cond_12

    .line 322
    .line 323
    iget-object v3, v9, Landroidx/recyclerview/widget/RecyclerView;->J:Landroid/widget/EdgeEffect;

    .line 324
    .line 325
    invoke-virtual {v3, v2}, Landroid/widget/EdgeEffect;->onAbsorb(I)V

    .line 326
    .line 327
    .line 328
    :cond_12
    :goto_7
    if-gez v1, :cond_13

    .line 329
    .line 330
    invoke-virtual {v9}, Landroidx/recyclerview/widget/RecyclerView;->x()V

    .line 331
    .line 332
    .line 333
    iget-object v3, v9, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 334
    .line 335
    invoke-virtual {v3}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 336
    .line 337
    .line 338
    move-result v3

    .line 339
    if-eqz v3, :cond_14

    .line 340
    .line 341
    iget-object v3, v9, Landroidx/recyclerview/widget/RecyclerView;->I:Landroid/widget/EdgeEffect;

    .line 342
    .line 343
    neg-int v4, v1

    .line 344
    invoke-virtual {v3, v4}, Landroid/widget/EdgeEffect;->onAbsorb(I)V

    .line 345
    .line 346
    .line 347
    goto :goto_8

    .line 348
    :cond_13
    if-lez v1, :cond_14

    .line 349
    .line 350
    invoke-virtual {v9}, Landroidx/recyclerview/widget/RecyclerView;->u()V

    .line 351
    .line 352
    .line 353
    iget-object v3, v9, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 354
    .line 355
    invoke-virtual {v3}, Landroid/widget/EdgeEffect;->isFinished()Z

    .line 356
    .line 357
    .line 358
    move-result v3

    .line 359
    if-eqz v3, :cond_14

    .line 360
    .line 361
    iget-object v3, v9, Landroidx/recyclerview/widget/RecyclerView;->K:Landroid/widget/EdgeEffect;

    .line 362
    .line 363
    invoke-virtual {v3, v1}, Landroid/widget/EdgeEffect;->onAbsorb(I)V

    .line 364
    .line 365
    .line 366
    :cond_14
    :goto_8
    if-nez v2, :cond_15

    .line 367
    .line 368
    if-eqz v1, :cond_16

    .line 369
    .line 370
    :cond_15
    sget-object v1, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 371
    .line 372
    invoke-static {v9}, Lg/j;->k(Landroid/view/View;)V

    .line 373
    .line 374
    .line 375
    :cond_16
    sget-boolean v1, Landroidx/recyclerview/widget/RecyclerView;->E0:Z

    .line 376
    .line 377
    if-eqz v1, :cond_1a

    .line 378
    .line 379
    iget-object v1, v9, Landroidx/recyclerview/widget/RecyclerView;->e0:Landroidx/recyclerview/widget/s;

    .line 380
    .line 381
    iget-object v2, v1, Landroidx/recyclerview/widget/s;->c:[I

    .line 382
    .line 383
    if-eqz v2, :cond_17

    .line 384
    .line 385
    const/4 v3, -0x1

    .line 386
    invoke-static {v2, v3}, Ljava/util/Arrays;->fill([II)V

    .line 387
    .line 388
    .line 389
    :cond_17
    iput v10, v1, Landroidx/recyclerview/widget/s;->d:I

    .line 390
    .line 391
    goto :goto_a

    .line 392
    :cond_18
    iget-boolean v1, v0, Landroidx/recyclerview/widget/h1;->e:Z

    .line 393
    .line 394
    if-eqz v1, :cond_19

    .line 395
    .line 396
    iput-boolean v11, v0, Landroidx/recyclerview/widget/h1;->f:Z

    .line 397
    .line 398
    goto :goto_9

    .line 399
    :cond_19
    invoke-virtual {v9, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 400
    .line 401
    .line 402
    sget-object v1, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 403
    .line 404
    invoke-static {v9, v0}, Lg/j;->m(Landroid/view/View;Ljava/lang/Runnable;)V

    .line 405
    .line 406
    .line 407
    :goto_9
    iget-object v1, v9, Landroidx/recyclerview/widget/RecyclerView;->d0:Landroidx/recyclerview/widget/u;

    .line 408
    .line 409
    if-eqz v1, :cond_1a

    .line 410
    .line 411
    invoke-virtual {v1, v9, v15, v14}, Landroidx/recyclerview/widget/u;->a(Landroidx/recyclerview/widget/RecyclerView;II)V

    .line 412
    .line 413
    .line 414
    :cond_1a
    :goto_a
    iget-object v1, v9, Landroidx/recyclerview/widget/RecyclerView;->n:Landroidx/recyclerview/widget/t0;

    .line 415
    .line 416
    invoke-virtual {v1}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 417
    .line 418
    .line 419
    iput-boolean v10, v0, Landroidx/recyclerview/widget/h1;->e:Z

    .line 420
    .line 421
    iget-boolean v1, v0, Landroidx/recyclerview/widget/h1;->f:Z

    .line 422
    .line 423
    if-eqz v1, :cond_1b

    .line 424
    .line 425
    invoke-virtual {v9, v0}, Landroid/view/View;->removeCallbacks(Ljava/lang/Runnable;)Z

    .line 426
    .line 427
    .line 428
    sget-object v1, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 429
    .line 430
    invoke-static {v9, v0}, Lg/j;->m(Landroid/view/View;Ljava/lang/Runnable;)V

    .line 431
    .line 432
    .line 433
    goto :goto_b

    .line 434
    :cond_1b
    invoke-virtual {v9, v10}, Landroidx/recyclerview/widget/RecyclerView;->setScrollState(I)V

    .line 435
    .line 436
    .line 437
    invoke-virtual {v9, v11}, Landroidx/recyclerview/widget/RecyclerView;->f0(I)V

    .line 438
    .line 439
    .line 440
    :goto_b
    return-void
.end method
