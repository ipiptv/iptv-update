.class public abstract Landroidx/recyclerview/widget/m0;
.super Ljava/lang/Object;
.source "SourceFile"
