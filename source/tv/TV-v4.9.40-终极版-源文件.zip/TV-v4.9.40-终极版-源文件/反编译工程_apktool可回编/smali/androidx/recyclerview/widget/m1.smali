.class public final Landroidx/recyclerview/widget/m1;
.super Landroidx/recyclerview/widget/u0;
.source "SourceFile"


# instance fields
.field public e:Landroidx/recyclerview/widget/p1;
