.class public abstract Landroidx/recyclerview/widget/o0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public a:Landroidx/recyclerview/widget/p0;

.field public final b:Ljava/util/ArrayList;

.field public final c:J

.field public final d:J

.field public final e:J

.field public final f:J


# direct methods
.method public constructor <init>()V
    .locals 2

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 v0, 0x0

    iput-object v0, p0, Landroidx/recyclerview/widget/o0;->a:Landroidx/recyclerview/widget/p0;

    new-instance v0, Ljava/util/ArrayList;

    invoke-direct {v0}, Ljava/util/ArrayList;-><init>()V

    iput-object v0, p0, Landroidx/recyclerview/widget/o0;->b:Ljava/util/ArrayList;

    const-wide/16 v0, 0x78

    iput-wide v0, p0, Landroidx/recyclerview/widget/o0;->c:J

    iput-wide v0, p0, Landroidx/recyclerview/widget/o0;->d:J

    const-wide/16 v0, 0xfa

    iput-wide v0, p0, Landroidx/recyclerview/widget/o0;->e:J

    iput-wide v0, p0, Landroidx/recyclerview/widget/o0;->f:J

    return-void
.end method

.method public static b(Landroidx/recyclerview/widget/i1;)V
    .locals 2

    .line 1
    iget v0, p0, Landroidx/recyclerview/widget/i1;->mFlags:I

    and-int/lit8 v0, v0, 0xe

    invoke-virtual {p0}, Landroidx/recyclerview/widget/i1;->isInvalid()Z

    move-result v1

    if-eqz v1, :cond_0

    return-void

    :cond_0
    and-int/lit8 v0, v0, 0x4

    if-nez v0, :cond_1

    invoke-virtual {p0}, Landroidx/recyclerview/widget/i1;->getOldPosition()I

    invoke-virtual {p0}, Landroidx/recyclerview/widget/i1;->getAbsoluteAdapterPosition()I

    :cond_1
    return-void
.end method


# virtual methods
.method public abstract a(Landroidx/recyclerview/widget/i1;Landroidx/recyclerview/widget/i1;Landroidx/recyclerview/widget/n0;Landroidx/recyclerview/widget/n0;)Z
.end method

.method public final c(Landroidx/recyclerview/widget/i1;)V
    .locals 9

    .line 1
    iget-object v0, p0, Landroidx/recyclerview/widget/o0;->a:Landroidx/recyclerview/widget/p0;

    .line 2
    .line 3
    if-eqz v0, :cond_7

    .line 4
    .line 5
    const/4 v1, 0x1

    .line 6
    invoke-virtual {p1, v1}, Landroidx/recyclerview/widget/i1;->setIsRecyclable(Z)V

    .line 7
    .line 8
    .line 9
    iget-object v2, p1, Landroidx/recyclerview/widget/i1;->mShadowedHolder:Landroidx/recyclerview/widget/i1;

    .line 10
    .line 11
    const/4 v3, 0x0

    .line 12
    if-eqz v2, :cond_0

    .line 13
    .line 14
    iget-object v2, p1, Landroidx/recyclerview/widget/i1;->mShadowingHolder:Landroidx/recyclerview/widget/i1;

    .line 15
    .line 16
    if-nez v2, :cond_0

    .line 17
    .line 18
    iput-object v3, p1, Landroidx/recyclerview/widget/i1;->mShadowedHolder:Landroidx/recyclerview/widget/i1;

    .line 19
    .line 20
    :cond_0
    iput-object v3, p1, Landroidx/recyclerview/widget/i1;->mShadowingHolder:Landroidx/recyclerview/widget/i1;

    .line 21
    .line 22
    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->shouldBeKeptAsChild()Z

    .line 23
    .line 24
    .line 25
    move-result v2

    .line 26
    if-nez v2, :cond_7

    .line 27
    .line 28
    iget-object v2, p1, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 29
    .line 30
    iget-object v0, v0, Landroidx/recyclerview/widget/p0;->a:Landroidx/recyclerview/widget/RecyclerView;

    .line 31
    .line 32
    invoke-virtual {v0}, Landroidx/recyclerview/widget/RecyclerView;->d0()V

    .line 33
    .line 34
    .line 35
    iget-object v3, v0, Landroidx/recyclerview/widget/RecyclerView;->f:Landroidx/recyclerview/widget/e;

    .line 36
    .line 37
    iget-object v4, v3, Landroidx/recyclerview/widget/e;->b:Landroidx/recyclerview/widget/d;

    .line 38
    .line 39
    iget-object v5, v3, Landroidx/recyclerview/widget/e;->a:Landroidx/recyclerview/widget/p0;

    .line 40
    .line 41
    iget v6, v3, Landroidx/recyclerview/widget/e;->d:I

    .line 42
    .line 43
    const/4 v7, 0x0

    .line 44
    if-ne v6, v1, :cond_2

    .line 45
    .line 46
    iget-object v1, v3, Landroidx/recyclerview/widget/e;->e:Landroid/view/View;

    .line 47
    .line 48
    if-ne v1, v2, :cond_1

    .line 49
    .line 50
    goto :goto_1

    .line 51
    :cond_1
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 52
    .line 53
    const-string v0, "Cannot call removeViewIfHidden within removeView(At) for a different view"

    .line 54
    .line 55
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 56
    .line 57
    .line 58
    throw p1

    .line 59
    :cond_2
    const/4 v8, 0x2

    .line 60
    if-eq v6, v8, :cond_6

    .line 61
    .line 62
    :try_start_0
    iput v8, v3, Landroidx/recyclerview/widget/e;->d:I

    .line 63
    .line 64
    iget-object v6, v5, Landroidx/recyclerview/widget/p0;->a:Landroidx/recyclerview/widget/RecyclerView;

    .line 65
    .line 66
    invoke-virtual {v6, v2}, Landroid/view/ViewGroup;->indexOfChild(Landroid/view/View;)I

    .line 67
    .line 68
    .line 69
    move-result v6

    .line 70
    const/4 v8, -0x1

    .line 71
    if-ne v6, v8, :cond_3

    .line 72
    .line 73
    invoke-virtual {v3, v2}, Landroidx/recyclerview/widget/e;->k(Landroid/view/View;)V

    .line 74
    .line 75
    .line 76
    goto :goto_0

    .line 77
    :cond_3
    invoke-virtual {v4, v6}, Landroidx/recyclerview/widget/d;->d(I)Z

    .line 78
    .line 79
    .line 80
    move-result v8

    .line 81
    if-eqz v8, :cond_4

    .line 82
    .line 83
    invoke-virtual {v4, v6}, Landroidx/recyclerview/widget/d;->f(I)Z

    .line 84
    .line 85
    .line 86
    invoke-virtual {v3, v2}, Landroidx/recyclerview/widget/e;->k(Landroid/view/View;)V

    .line 87
    .line 88
    .line 89
    invoke-virtual {v5, v6}, Landroidx/recyclerview/widget/p0;->g(I)V
    :try_end_0
    .catchall {:try_start_0 .. :try_end_0} :catchall_0

    .line 90
    .line 91
    .line 92
    :goto_0
    iput v7, v3, Landroidx/recyclerview/widget/e;->d:I

    .line 93
    .line 94
    goto :goto_2

    .line 95
    :cond_4
    iput v7, v3, Landroidx/recyclerview/widget/e;->d:I

    .line 96
    .line 97
    :goto_1
    const/4 v1, 0x0

    .line 98
    :goto_2
    if-eqz v1, :cond_5

    .line 99
    .line 100
    invoke-static {v2}, Landroidx/recyclerview/widget/RecyclerView;->I(Landroid/view/View;)Landroidx/recyclerview/widget/i1;

    .line 101
    .line 102
    .line 103
    move-result-object v3

    .line 104
    iget-object v4, v0, Landroidx/recyclerview/widget/RecyclerView;->c:Landroidx/recyclerview/widget/a1;

    .line 105
    .line 106
    invoke-virtual {v4, v3}, Landroidx/recyclerview/widget/a1;->l(Landroidx/recyclerview/widget/i1;)V

    .line 107
    .line 108
    .line 109
    invoke-virtual {v4, v3}, Landroidx/recyclerview/widget/a1;->i(Landroidx/recyclerview/widget/i1;)V

    .line 110
    .line 111
    .line 112
    sget-boolean v3, Landroidx/recyclerview/widget/RecyclerView;->z0:Z

    .line 113
    .line 114
    if-eqz v3, :cond_5

    .line 115
    .line 116
    new-instance v3, Ljava/lang/StringBuilder;

    .line 117
    .line 118
    const-string v4, "after removing animated view: "

    .line 119
    .line 120
    invoke-direct {v3, v4}, Ljava/lang/StringBuilder;-><init>(Ljava/lang/String;)V

    .line 121
    .line 122
    .line 123
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 124
    .line 125
    .line 126
    const-string v2, ", "

    .line 127
    .line 128
    invoke-virtual {v3, v2}, Ljava/lang/StringBuilder;->append(Ljava/lang/String;)Ljava/lang/StringBuilder;

    .line 129
    .line 130
    .line 131
    invoke-virtual {v3, v0}, Ljava/lang/StringBuilder;->append(Ljava/lang/Object;)Ljava/lang/StringBuilder;

    .line 132
    .line 133
    .line 134
    invoke-virtual {v3}, Ljava/lang/StringBuilder;->toString()Ljava/lang/String;

    .line 135
    .line 136
    .line 137
    move-result-object v2

    .line 138
    const-string v3, "RecyclerView"

    .line 139
    .line 140
    invoke-static {v3, v2}, Landroid/util/Log;->d(Ljava/lang/String;Ljava/lang/String;)I

    .line 141
    .line 142
    .line 143
    :cond_5
    xor-int/lit8 v2, v1, 0x1

    .line 144
    .line 145
    invoke-virtual {v0, v2}, Landroidx/recyclerview/widget/RecyclerView;->e0(Z)V

    .line 146
    .line 147
    .line 148
    if-nez v1, :cond_7

    .line 149
    .line 150
    invoke-virtual {p1}, Landroidx/recyclerview/widget/i1;->isTmpDetached()Z

    .line 151
    .line 152
    .line 153
    move-result v1

    .line 154
    if-eqz v1, :cond_7

    .line 155
    .line 156
    iget-object p1, p1, Landroidx/recyclerview/widget/i1;->itemView:Landroid/view/View;

    .line 157
    .line 158
    invoke-virtual {v0, p1, v7}, Landroidx/recyclerview/widget/RecyclerView;->removeDetachedView(Landroid/view/View;Z)V

    .line 159
    .line 160
    .line 161
    goto :goto_3

    .line 162
    :catchall_0
    move-exception p1

    .line 163
    iput v7, v3, Landroidx/recyclerview/widget/e;->d:I

    .line 164
    .line 165
    throw p1

    .line 166
    :cond_6
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 167
    .line 168
    const-string v0, "Cannot call removeViewIfHidden within removeViewIfHidden"

    .line 169
    .line 170
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 171
    .line 172
    .line 173
    throw p1

    .line 174
    :cond_7
    :goto_3
    return-void
.end method

.method public abstract d(Landroidx/recyclerview/widget/i1;)V
.end method

.method public abstract e()V
.end method

.method public abstract f()Z
.end method
