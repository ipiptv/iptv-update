.class public final Landroidx/recyclerview/widget/s1;
.super Ljava/lang/Object;
.source "SourceFile"


# static fields
.field public static final d:Lf/b;


# instance fields
.field public a:I

.field public b:Landroidx/recyclerview/widget/n0;

.field public c:Landroidx/recyclerview/widget/n0;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    new-instance v0, Lf/b;

    const/16 v1, 0x14

    invoke-direct {v0, v1}, Lf/b;-><init>(I)V

    sput-object v0, Landroidx/recyclerview/widget/s1;->d:Lf/b;

    return-void
.end method

.method public static a()Landroidx/recyclerview/widget/s1;
    .locals 1

    .line 1
    sget-object v0, Landroidx/recyclerview/widget/s1;->d:Lf/b;

    invoke-virtual {v0}, Lf/b;->a()Ljava/lang/Object;

    move-result-object v0

    check-cast v0, Landroidx/recyclerview/widget/s1;

    if-nez v0, :cond_0

    new-instance v0, Landroidx/recyclerview/widget/s1;

    invoke-direct {v0}, Landroidx/recyclerview/widget/s1;-><init>()V

    :cond_0
    return-object v0
.end method
