.class public abstract Landroidx/recyclerview/widget/x0;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract a(Landroidx/recyclerview/widget/RecyclerView;)V
.end method
