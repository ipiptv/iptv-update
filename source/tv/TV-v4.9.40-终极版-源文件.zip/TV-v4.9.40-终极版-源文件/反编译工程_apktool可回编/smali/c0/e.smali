.class public interface abstract Lc0/e;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract invoke(Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
.end method
