.class public final Lg/a;
.super Landroid/view/View$AccessibilityDelegate;
.source "SourceFile"


# instance fields
.field public final a:Lg/c;


# direct methods
.method public constructor <init>(Lg/c;)V
    .locals 0

    .line 1
    invoke-direct {p0}, Landroid/view/View$AccessibilityDelegate;-><init>()V

    iput-object p1, p0, Lg/a;->a:Lg/c;

    return-void
.end method


# virtual methods
.method public final dispatchPopulateAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    .locals 1

    .line 1
    iget-object v0, p0, Lg/a;->a:Lg/c;

    invoke-virtual {v0, p1, p2}, Lg/c;->a(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z

    move-result p1

    return p1
.end method

.method public final getAccessibilityNodeProvider(Landroid/view/View;)Landroid/view/accessibility/AccessibilityNodeProvider;
    .locals 1

    .line 1
    iget-object v0, p0, Lg/a;->a:Lg/c;

    invoke-virtual {v0, p1}, Lg/c;->b(Landroid/view/View;)Lg/d0;

    move-result-object p1

    if-eqz p1, :cond_0

    iget-object p1, p1, Lg/d0;->a:Ljava/lang/Object;

    check-cast p1, Landroid/view/accessibility/AccessibilityNodeProvider;

    goto :goto_0

    :cond_0
    const/4 p1, 0x0

    :goto_0
    return-object p1
.end method

.method public final onInitializeAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lg/a;->a:Lg/c;

    invoke-virtual {v0, p1, p2}, Lg/c;->c(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    return-void
.end method

.method public final onInitializeAccessibilityNodeInfo(Landroid/view/View;Landroid/view/accessibility/AccessibilityNodeInfo;)V
    .locals 17

    .line 1
    move-object/from16 v0, p1

    .line 2
    .line 3
    move-object/from16 v1, p2

    .line 4
    .line 5
    new-instance v2, Lh/o;

    .line 6
    .line 7
    invoke-direct {v2, v1}, Lh/o;-><init>(Landroid/view/accessibility/AccessibilityNodeInfo;)V

    .line 8
    .line 9
    .line 10
    sget-object v3, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 11
    .line 12
    new-instance v3, Lg/h;

    .line 13
    .line 14
    const v4, 0x7f050068

    .line 15
    .line 16
    .line 17
    const/4 v5, 0x0

    .line 18
    invoke-direct {v3, v4, v5}, Lg/h;-><init>(II)V

    .line 19
    .line 20
    .line 21
    invoke-virtual {v3, v0}, Lg/i;->a(Landroid/view/View;)Ljava/lang/Object;

    .line 22
    .line 23
    .line 24
    move-result-object v3

    .line 25
    check-cast v3, Ljava/lang/Boolean;

    .line 26
    .line 27
    const/4 v4, 0x1

    .line 28
    if-eqz v3, :cond_0

    .line 29
    .line 30
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 31
    .line 32
    .line 33
    move-result v3

    .line 34
    if-eqz v3, :cond_0

    .line 35
    .line 36
    const/4 v3, 0x1

    .line 37
    goto :goto_0

    .line 38
    :cond_0
    const/4 v3, 0x0

    .line 39
    :goto_0
    sget v6, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 40
    .line 41
    const-string v7, "androidx.view.accessibility.AccessibilityNodeInfoCompat.BOOLEAN_PROPERTY_KEY"

    .line 42
    .line 43
    const/16 v8, 0x1c

    .line 44
    .line 45
    if-lt v6, v8, :cond_1

    .line 46
    .line 47
    invoke-static {v1, v3}, Lg/d;->i(Landroid/view/accessibility/AccessibilityNodeInfo;Z)V

    .line 48
    .line 49
    .line 50
    goto :goto_1

    .line 51
    :cond_1
    invoke-static/range {p2 .. p2}, Lh/j;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;

    .line 52
    .line 53
    .line 54
    move-result-object v9

    .line 55
    if-eqz v9, :cond_2

    .line 56
    .line 57
    invoke-virtual {v9, v7, v5}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 58
    .line 59
    .line 60
    move-result v10

    .line 61
    and-int/lit8 v10, v10, -0x2

    .line 62
    .line 63
    or-int/2addr v3, v10

    .line 64
    invoke-virtual {v9, v7, v3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 65
    .line 66
    .line 67
    :cond_2
    :goto_1
    new-instance v3, Lg/h;

    .line 68
    .line 69
    const v9, 0x7f050063

    .line 70
    .line 71
    .line 72
    const/4 v10, 0x3

    .line 73
    invoke-direct {v3, v9, v10}, Lg/h;-><init>(II)V

    .line 74
    .line 75
    .line 76
    invoke-virtual {v3, v0}, Lg/i;->a(Landroid/view/View;)Ljava/lang/Object;

    .line 77
    .line 78
    .line 79
    move-result-object v3

    .line 80
    check-cast v3, Ljava/lang/Boolean;

    .line 81
    .line 82
    if-eqz v3, :cond_3

    .line 83
    .line 84
    invoke-virtual {v3}, Ljava/lang/Boolean;->booleanValue()Z

    .line 85
    .line 86
    .line 87
    move-result v3

    .line 88
    if-eqz v3, :cond_3

    .line 89
    .line 90
    const/4 v3, 0x1

    .line 91
    goto :goto_2

    .line 92
    :cond_3
    const/4 v3, 0x0

    .line 93
    :goto_2
    const/4 v9, 0x2

    .line 94
    if-lt v6, v8, :cond_4

    .line 95
    .line 96
    invoke-static {v1, v3}, Lg/d;->k(Landroid/view/accessibility/AccessibilityNodeInfo;Z)V

    .line 97
    .line 98
    .line 99
    goto :goto_4

    .line 100
    :cond_4
    invoke-static/range {p2 .. p2}, Lh/j;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;

    .line 101
    .line 102
    .line 103
    move-result-object v10

    .line 104
    if-eqz v10, :cond_6

    .line 105
    .line 106
    invoke-virtual {v10, v7, v5}, Landroid/os/BaseBundle;->getInt(Ljava/lang/String;I)I

    .line 107
    .line 108
    .line 109
    move-result v11

    .line 110
    and-int/lit8 v11, v11, -0x3

    .line 111
    .line 112
    if-eqz v3, :cond_5

    .line 113
    .line 114
    const/4 v3, 0x2

    .line 115
    goto :goto_3

    .line 116
    :cond_5
    const/4 v3, 0x0

    .line 117
    :goto_3
    or-int/2addr v3, v11

    .line 118
    invoke-virtual {v10, v7, v3}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 119
    .line 120
    .line 121
    :cond_6
    :goto_4
    new-instance v3, Lg/h;

    .line 122
    .line 123
    const v7, 0x7f050064

    .line 124
    .line 125
    .line 126
    const/16 v10, 0x8

    .line 127
    .line 128
    invoke-direct {v3, v7, v10, v8, v4}, Lg/h;-><init>(IIII)V

    .line 129
    .line 130
    .line 131
    invoke-virtual {v3, v0}, Lg/i;->a(Landroid/view/View;)Ljava/lang/Object;

    .line 132
    .line 133
    .line 134
    move-result-object v3

    .line 135
    check-cast v3, Ljava/lang/CharSequence;

    .line 136
    .line 137
    if-lt v6, v8, :cond_7

    .line 138
    .line 139
    invoke-static {v1, v3}, Lg/d;->h(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/CharSequence;)V

    .line 140
    .line 141
    .line 142
    goto :goto_5

    .line 143
    :cond_7
    invoke-static/range {p2 .. p2}, Lh/j;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;

    .line 144
    .line 145
    .line 146
    move-result-object v4

    .line 147
    const-string v7, "androidx.view.accessibility.AccessibilityNodeInfoCompat.PANE_TITLE_KEY"

    .line 148
    .line 149
    invoke-virtual {v4, v7, v3}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 150
    .line 151
    .line 152
    :goto_5
    new-instance v3, Lg/h;

    .line 153
    .line 154
    const v4, 0x7f050069

    .line 155
    .line 156
    .line 157
    const/16 v7, 0x40

    .line 158
    .line 159
    const/16 v8, 0x1e

    .line 160
    .line 161
    invoke-direct {v3, v4, v7, v8, v9}, Lg/h;-><init>(IIII)V

    .line 162
    .line 163
    .line 164
    invoke-virtual {v3, v0}, Lg/i;->a(Landroid/view/View;)Ljava/lang/Object;

    .line 165
    .line 166
    .line 167
    move-result-object v3

    .line 168
    check-cast v3, Ljava/lang/CharSequence;

    .line 169
    .line 170
    if-lt v6, v8, :cond_8

    .line 171
    .line 172
    invoke-static {v1, v3}, Lh/k;->c(Landroid/view/accessibility/AccessibilityNodeInfo;Ljava/lang/CharSequence;)V

    .line 173
    .line 174
    .line 175
    goto :goto_6

    .line 176
    :cond_8
    invoke-static/range {p2 .. p2}, Lh/j;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;

    .line 177
    .line 178
    .line 179
    move-result-object v4

    .line 180
    const-string v7, "androidx.view.accessibility.AccessibilityNodeInfoCompat.STATE_DESCRIPTION_KEY"

    .line 181
    .line 182
    invoke-virtual {v4, v7, v3}, Landroid/os/Bundle;->putCharSequence(Ljava/lang/String;Ljava/lang/CharSequence;)V

    .line 183
    .line 184
    .line 185
    :goto_6
    move-object/from16 v3, p0

    .line 186
    .line 187
    iget-object v4, v3, Lg/a;->a:Lg/c;

    .line 188
    .line 189
    invoke-virtual {v4, v0, v2}, Lg/c;->d(Landroid/view/View;Lh/o;)V

    .line 190
    .line 191
    .line 192
    invoke-virtual/range {p2 .. p2}, Landroid/view/accessibility/AccessibilityNodeInfo;->getText()Ljava/lang/CharSequence;

    .line 193
    .line 194
    .line 195
    move-result-object v4

    .line 196
    const/16 v7, 0x1a

    .line 197
    .line 198
    iget-object v8, v2, Lh/o;->a:Landroid/view/accessibility/AccessibilityNodeInfo;

    .line 199
    .line 200
    if-ge v6, v7, :cond_10

    .line 201
    .line 202
    invoke-static/range {p2 .. p2}, Lh/j;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;

    .line 203
    .line 204
    .line 205
    move-result-object v6

    .line 206
    const-string v7, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_START_KEY"

    .line 207
    .line 208
    invoke-virtual {v6, v7}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 209
    .line 210
    .line 211
    invoke-static/range {p2 .. p2}, Lh/j;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;

    .line 212
    .line 213
    .line 214
    move-result-object v6

    .line 215
    const-string v9, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_END_KEY"

    .line 216
    .line 217
    invoke-virtual {v6, v9}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 218
    .line 219
    .line 220
    invoke-static/range {p2 .. p2}, Lh/j;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;

    .line 221
    .line 222
    .line 223
    move-result-object v6

    .line 224
    const-string v10, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_FLAGS_KEY"

    .line 225
    .line 226
    invoke-virtual {v6, v10}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 227
    .line 228
    .line 229
    invoke-static/range {p2 .. p2}, Lh/j;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;

    .line 230
    .line 231
    .line 232
    move-result-object v1

    .line 233
    const-string v6, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ID_KEY"

    .line 234
    .line 235
    invoke-virtual {v1, v6}, Landroid/os/Bundle;->remove(Ljava/lang/String;)V

    .line 236
    .line 237
    .line 238
    const v1, 0x7f050062

    .line 239
    .line 240
    .line 241
    invoke-virtual {v0, v1}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 242
    .line 243
    .line 244
    move-result-object v11

    .line 245
    check-cast v11, Landroid/util/SparseArray;

    .line 246
    .line 247
    if-eqz v11, :cond_b

    .line 248
    .line 249
    new-instance v12, Ljava/util/ArrayList;

    .line 250
    .line 251
    invoke-direct {v12}, Ljava/util/ArrayList;-><init>()V

    .line 252
    .line 253
    .line 254
    const/4 v13, 0x0

    .line 255
    :goto_7
    invoke-virtual {v11}, Landroid/util/SparseArray;->size()I

    .line 256
    .line 257
    .line 258
    move-result v14

    .line 259
    if-ge v13, v14, :cond_a

    .line 260
    .line 261
    invoke-virtual {v11, v13}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 262
    .line 263
    .line 264
    move-result-object v14

    .line 265
    check-cast v14, Ljava/lang/ref/WeakReference;

    .line 266
    .line 267
    invoke-virtual {v14}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 268
    .line 269
    .line 270
    move-result-object v14

    .line 271
    if-nez v14, :cond_9

    .line 272
    .line 273
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 274
    .line 275
    .line 276
    move-result-object v14

    .line 277
    invoke-virtual {v12, v14}, Ljava/util/ArrayList;->add(Ljava/lang/Object;)Z

    .line 278
    .line 279
    .line 280
    :cond_9
    add-int/lit8 v13, v13, 0x1

    .line 281
    .line 282
    goto :goto_7

    .line 283
    :cond_a
    const/4 v13, 0x0

    .line 284
    :goto_8
    invoke-virtual {v12}, Ljava/util/ArrayList;->size()I

    .line 285
    .line 286
    .line 287
    move-result v14

    .line 288
    if-ge v13, v14, :cond_b

    .line 289
    .line 290
    invoke-virtual {v12, v13}, Ljava/util/ArrayList;->get(I)Ljava/lang/Object;

    .line 291
    .line 292
    .line 293
    move-result-object v14

    .line 294
    check-cast v14, Ljava/lang/Integer;

    .line 295
    .line 296
    invoke-virtual {v14}, Ljava/lang/Integer;->intValue()I

    .line 297
    .line 298
    .line 299
    move-result v14

    .line 300
    invoke-virtual {v11, v14}, Landroid/util/SparseArray;->remove(I)V

    .line 301
    .line 302
    .line 303
    add-int/lit8 v13, v13, 0x1

    .line 304
    .line 305
    goto :goto_8

    .line 306
    :cond_b
    instance-of v11, v4, Landroid/text/Spanned;

    .line 307
    .line 308
    if-eqz v11, :cond_c

    .line 309
    .line 310
    move-object v11, v4

    .line 311
    check-cast v11, Landroid/text/Spanned;

    .line 312
    .line 313
    invoke-interface {v4}, Ljava/lang/CharSequence;->length()I

    .line 314
    .line 315
    .line 316
    move-result v12

    .line 317
    const-class v13, Landroid/text/style/ClickableSpan;

    .line 318
    .line 319
    invoke-interface {v11, v5, v12, v13}, Landroid/text/Spanned;->getSpans(IILjava/lang/Class;)[Ljava/lang/Object;

    .line 320
    .line 321
    .line 322
    move-result-object v11

    .line 323
    check-cast v11, [Landroid/text/style/ClickableSpan;

    .line 324
    .line 325
    goto :goto_9

    .line 326
    :cond_c
    const/4 v11, 0x0

    .line 327
    :goto_9
    if-eqz v11, :cond_10

    .line 328
    .line 329
    array-length v12, v11

    .line 330
    if-lez v12, :cond_10

    .line 331
    .line 332
    invoke-static {v8}, Lh/j;->c(Landroid/view/accessibility/AccessibilityNodeInfo;)Landroid/os/Bundle;

    .line 333
    .line 334
    .line 335
    move-result-object v12

    .line 336
    const-string v13, "androidx.view.accessibility.AccessibilityNodeInfoCompat.SPANS_ACTION_ID_KEY"

    .line 337
    .line 338
    const/high16 v14, 0x7f050000

    .line 339
    .line 340
    invoke-virtual {v12, v13, v14}, Landroid/os/BaseBundle;->putInt(Ljava/lang/String;I)V

    .line 341
    .line 342
    .line 343
    invoke-virtual {v0, v1}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 344
    .line 345
    .line 346
    move-result-object v12

    .line 347
    check-cast v12, Landroid/util/SparseArray;

    .line 348
    .line 349
    if-nez v12, :cond_d

    .line 350
    .line 351
    new-instance v12, Landroid/util/SparseArray;

    .line 352
    .line 353
    invoke-direct {v12}, Landroid/util/SparseArray;-><init>()V

    .line 354
    .line 355
    .line 356
    invoke-virtual {v0, v1, v12}, Landroid/view/View;->setTag(ILjava/lang/Object;)V

    .line 357
    .line 358
    .line 359
    :cond_d
    const/4 v1, 0x0

    .line 360
    :goto_a
    array-length v13, v11

    .line 361
    if-ge v1, v13, :cond_10

    .line 362
    .line 363
    aget-object v13, v11, v1

    .line 364
    .line 365
    const/4 v14, 0x0

    .line 366
    :goto_b
    invoke-virtual {v12}, Landroid/util/SparseArray;->size()I

    .line 367
    .line 368
    .line 369
    move-result v15

    .line 370
    if-ge v14, v15, :cond_f

    .line 371
    .line 372
    invoke-virtual {v12, v14}, Landroid/util/SparseArray;->valueAt(I)Ljava/lang/Object;

    .line 373
    .line 374
    .line 375
    move-result-object v15

    .line 376
    check-cast v15, Ljava/lang/ref/WeakReference;

    .line 377
    .line 378
    invoke-virtual {v15}, Ljava/lang/ref/Reference;->get()Ljava/lang/Object;

    .line 379
    .line 380
    .line 381
    move-result-object v15

    .line 382
    check-cast v15, Landroid/text/style/ClickableSpan;

    .line 383
    .line 384
    invoke-virtual {v13, v15}, Ljava/lang/Object;->equals(Ljava/lang/Object;)Z

    .line 385
    .line 386
    .line 387
    move-result v15

    .line 388
    if-eqz v15, :cond_e

    .line 389
    .line 390
    invoke-virtual {v12, v14}, Landroid/util/SparseArray;->keyAt(I)I

    .line 391
    .line 392
    .line 393
    move-result v13

    .line 394
    goto :goto_c

    .line 395
    :cond_e
    add-int/lit8 v14, v14, 0x1

    .line 396
    .line 397
    goto :goto_b

    .line 398
    :cond_f
    sget v13, Lh/o;->b:I

    .line 399
    .line 400
    add-int/lit8 v14, v13, 0x1

    .line 401
    .line 402
    sput v14, Lh/o;->b:I

    .line 403
    .line 404
    :goto_c
    new-instance v14, Ljava/lang/ref/WeakReference;

    .line 405
    .line 406
    aget-object v15, v11, v1

    .line 407
    .line 408
    invoke-direct {v14, v15}, Ljava/lang/ref/WeakReference;-><init>(Ljava/lang/Object;)V

    .line 409
    .line 410
    .line 411
    invoke-virtual {v12, v13, v14}, Landroid/util/SparseArray;->put(ILjava/lang/Object;)V

    .line 412
    .line 413
    .line 414
    aget-object v14, v11, v1

    .line 415
    .line 416
    move-object v15, v4

    .line 417
    check-cast v15, Landroid/text/Spanned;

    .line 418
    .line 419
    invoke-virtual {v2, v7}, Lh/o;->a(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 420
    .line 421
    .line 422
    move-result-object v5

    .line 423
    invoke-interface {v15, v14}, Landroid/text/Spanned;->getSpanStart(Ljava/lang/Object;)I

    .line 424
    .line 425
    .line 426
    move-result v16

    .line 427
    invoke-static/range {v16 .. v16}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 428
    .line 429
    .line 430
    move-result-object v3

    .line 431
    invoke-interface {v5, v3}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 432
    .line 433
    .line 434
    invoke-virtual {v2, v9}, Lh/o;->a(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 435
    .line 436
    .line 437
    move-result-object v3

    .line 438
    invoke-interface {v15, v14}, Landroid/text/Spanned;->getSpanEnd(Ljava/lang/Object;)I

    .line 439
    .line 440
    .line 441
    move-result v5

    .line 442
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 443
    .line 444
    .line 445
    move-result-object v5

    .line 446
    invoke-interface {v3, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 447
    .line 448
    .line 449
    invoke-virtual {v2, v10}, Lh/o;->a(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 450
    .line 451
    .line 452
    move-result-object v3

    .line 453
    invoke-interface {v15, v14}, Landroid/text/Spanned;->getSpanFlags(Ljava/lang/Object;)I

    .line 454
    .line 455
    .line 456
    move-result v5

    .line 457
    invoke-static {v5}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 458
    .line 459
    .line 460
    move-result-object v5

    .line 461
    invoke-interface {v3, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 462
    .line 463
    .line 464
    invoke-virtual {v2, v6}, Lh/o;->a(Ljava/lang/String;)Ljava/util/ArrayList;

    .line 465
    .line 466
    .line 467
    move-result-object v3

    .line 468
    invoke-static {v13}, Ljava/lang/Integer;->valueOf(I)Ljava/lang/Integer;

    .line 469
    .line 470
    .line 471
    move-result-object v5

    .line 472
    invoke-interface {v3, v5}, Ljava/util/List;->add(Ljava/lang/Object;)Z

    .line 473
    .line 474
    .line 475
    add-int/lit8 v1, v1, 0x1

    .line 476
    .line 477
    move-object/from16 v3, p0

    .line 478
    .line 479
    const/4 v5, 0x0

    .line 480
    goto :goto_a

    .line 481
    :cond_10
    const v1, 0x7f050061

    .line 482
    .line 483
    .line 484
    invoke-virtual {v0, v1}, Landroid/view/View;->getTag(I)Ljava/lang/Object;

    .line 485
    .line 486
    .line 487
    move-result-object v0

    .line 488
    check-cast v0, Ljava/util/List;

    .line 489
    .line 490
    if-nez v0, :cond_11

    .line 491
    .line 492
    invoke-static {}, Ljava/util/Collections;->emptyList()Ljava/util/List;

    .line 493
    .line 494
    .line 495
    move-result-object v0

    .line 496
    :cond_11
    const/4 v5, 0x0

    .line 497
    :goto_d
    invoke-interface {v0}, Ljava/util/List;->size()I

    .line 498
    .line 499
    .line 500
    move-result v1

    .line 501
    if-ge v5, v1, :cond_12

    .line 502
    .line 503
    invoke-interface {v0, v5}, Ljava/util/List;->get(I)Ljava/lang/Object;

    .line 504
    .line 505
    .line 506
    move-result-object v1

    .line 507
    check-cast v1, Lh/i;

    .line 508
    .line 509
    iget-object v1, v1, Lh/i;->a:Ljava/lang/Object;

    .line 510
    .line 511
    check-cast v1, Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;

    .line 512
    .line 513
    invoke-virtual {v8, v1}, Landroid/view/accessibility/AccessibilityNodeInfo;->addAction(Landroid/view/accessibility/AccessibilityNodeInfo$AccessibilityAction;)V

    .line 514
    .line 515
    .line 516
    add-int/lit8 v5, v5, 0x1

    .line 517
    .line 518
    goto :goto_d

    .line 519
    :cond_12
    return-void
.end method

.method public final onPopulateAccessibilityEvent(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lg/a;->a:Lg/c;

    invoke-virtual {v0, p1, p2}, Lg/c;->e(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    return-void
.end method

.method public final onRequestSendAccessibilityEvent(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z
    .locals 1

    .line 1
    iget-object v0, p0, Lg/a;->a:Lg/c;

    invoke-virtual {v0, p1, p2, p3}, Lg/c;->f(Landroid/view/ViewGroup;Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)Z

    move-result p1

    return p1
.end method

.method public final performAccessibilityAction(Landroid/view/View;ILandroid/os/Bundle;)Z
    .locals 1

    .line 1
    iget-object v0, p0, Lg/a;->a:Lg/c;

    invoke-virtual {v0, p1, p2, p3}, Lg/c;->g(Landroid/view/View;ILandroid/os/Bundle;)Z

    move-result p1

    return p1
.end method

.method public final sendAccessibilityEvent(Landroid/view/View;I)V
    .locals 1

    .line 1
    iget-object v0, p0, Lg/a;->a:Lg/c;

    invoke-virtual {v0, p1, p2}, Lg/c;->h(Landroid/view/View;I)V

    return-void
.end method

.method public final sendAccessibilityEventUnchecked(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lg/a;->a:Lg/c;

    invoke-virtual {v0, p1, p2}, Lg/c;->i(Landroid/view/View;Landroid/view/accessibility/AccessibilityEvent;)V

    return-void
.end method
