.class public interface abstract Lg/g;
.super Ljava/lang/Object;
.source "SourceFile"
