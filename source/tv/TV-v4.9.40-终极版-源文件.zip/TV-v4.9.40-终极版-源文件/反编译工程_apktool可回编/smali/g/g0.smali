.class public Lg/g0;
.super Lg/i0;
.source "SourceFile"


# instance fields
.field public final a:Landroid/view/WindowInsets$Builder;


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Lg/i0;-><init>()V

    invoke-static {}, Lg/f0;->a()Landroid/view/WindowInsets$Builder;

    move-result-object v0

    iput-object v0, p0, Lg/g0;->a:Landroid/view/WindowInsets$Builder;

    return-void
.end method


# virtual methods
.method public b()Lg/q0;
    .locals 3

    .line 1
    invoke-virtual {p0}, Lg/i0;->a()V

    .line 2
    .line 3
    .line 4
    iget-object v0, p0, Lg/g0;->a:Landroid/view/WindowInsets$Builder;

    .line 5
    .line 6
    invoke-static {v0}, Lg/f0;->b(Landroid/view/WindowInsets$Builder;)Landroid/view/WindowInsets;

    .line 7
    .line 8
    .line 9
    move-result-object v0

    .line 10
    const/4 v1, 0x0

    .line 11
    invoke-static {v0, v1}, Lg/q0;->a(Landroid/view/WindowInsets;Landroid/view/View;)Lg/q0;

    .line 12
    .line 13
    .line 14
    move-result-object v0

    .line 15
    iget-object v2, v0, Lg/q0;->a:Lg/p0;

    .line 16
    .line 17
    invoke-virtual {v2, v1}, Lg/p0;->j([Lc/b;)V

    .line 18
    .line 19
    .line 20
    return-object v0
.end method

.method public c(Lc/b;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lg/g0;->a:Landroid/view/WindowInsets$Builder;

    invoke-virtual {p1}, Lc/b;->b()Landroid/graphics/Insets;

    move-result-object p1

    invoke-static {v0, p1}, Lg/f0;->f(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    return-void
.end method

.method public d(Lc/b;)V
    .locals 1

    .line 1
    iget-object v0, p0, Lg/g0;->a:Landroid/view/WindowInsets$Builder;

    invoke-virtual {p1}, Lc/b;->b()Landroid/graphics/Insets;

    move-result-object p1

    invoke-static {v0, p1}, Lg/f0;->d(Landroid/view/WindowInsets$Builder;Landroid/graphics/Insets;)V

    return-void
.end method
