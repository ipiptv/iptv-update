.class public final Lg/h;
.super Lg/i;
.source "SourceFile"


# instance fields
.field public final synthetic d:I


# direct methods
.method public constructor <init>(II)V
    .locals 1

    .line 1
    iput p2, p0, Lg/h;->d:I

    .line 2
    const-class p2, Ljava/lang/Boolean;

    const/16 v0, 0x1c

    invoke-direct {p0, p1, p2, v0}, Lg/i;-><init>(ILjava/lang/Class;I)V

    return-void
.end method

.method public synthetic constructor <init>(IIII)V
    .locals 0

    .line 3
    iput p4, p0, Lg/h;->d:I

    const-class p2, Ljava/lang/CharSequence;

    invoke-direct {p0, p1, p2, p3}, Lg/i;-><init>(ILjava/lang/Class;I)V

    return-void
.end method


# virtual methods
.method public final b(Landroid/view/View;)Ljava/lang/Boolean;
    .locals 1

    .line 1
    iget v0, p0, Lg/h;->d:I

    .line 2
    .line 3
    packed-switch v0, :pswitch_data_0

    .line 4
    .line 5
    .line 6
    goto :goto_0

    .line 7
    :pswitch_0
    invoke-static {p1}, Lg/r;->d(Landroid/view/View;)Z

    .line 8
    .line 9
    .line 10
    move-result p1

    .line 11
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 12
    .line 13
    .line 14
    move-result-object p1

    .line 15
    return-object p1

    .line 16
    :goto_0
    invoke-static {p1}, Lg/r;->c(Landroid/view/View;)Z

    .line 17
    .line 18
    .line 19
    move-result p1

    .line 20
    invoke-static {p1}, Ljava/lang/Boolean;->valueOf(Z)Ljava/lang/Boolean;

    .line 21
    .line 22
    .line 23
    move-result-object p1

    .line 24
    return-object p1

    .line 25
    :pswitch_data_0
    .packed-switch 0x0
        :pswitch_0
    .end packed-switch
.end method
