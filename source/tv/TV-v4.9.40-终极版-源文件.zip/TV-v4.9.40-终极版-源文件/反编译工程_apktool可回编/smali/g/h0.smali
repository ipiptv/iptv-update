.class public final Lg/h0;
.super Lg/g0;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 0

    invoke-direct {p0}, Lg/g0;-><init>()V

    return-void
.end method
