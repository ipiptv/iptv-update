.class public abstract Lg/i0;
.super Ljava/lang/Object;
.source "SourceFile"


# direct methods
.method public constructor <init>()V
    .locals 1

    .line 1
    new-instance v0, Lg/q0;

    invoke-direct {v0}, Lg/q0;-><init>()V

    invoke-direct {p0, v0}, Lg/i0;-><init>(Lg/q0;)V

    return-void
.end method

.method public constructor <init>(Lg/q0;)V
    .locals 0

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final a()V
    .locals 0

    .line 1
    return-void
.end method

.method public abstract b()Lg/q0;
.end method

.method public abstract c(Lc/b;)V
.end method

.method public abstract d(Lc/b;)V
.end method
