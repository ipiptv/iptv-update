.class public final Lg/m;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Landroid/view/View$OnApplyWindowInsetsListener;


# instance fields
.field public a:Lg/q0;

.field public final synthetic b:Landroid/view/View;


# direct methods
.method public constructor <init>(Landroid/view/View;Lg/g;)V
    .locals 0
    .annotation system Ldalvik/annotation/Signature;
        value = {
            "()V"
        }
    .end annotation

    .line 1
    iput-object p1, p0, Lg/m;->b:Landroid/view/View;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    const/4 p1, 0x0

    iput-object p1, p0, Lg/m;->a:Lg/q0;

    return-void
.end method


# virtual methods
.method public onApplyWindowInsets(Landroid/view/View;Landroid/view/WindowInsets;)Landroid/view/WindowInsets;
    .locals 3

    .line 1
    invoke-static {p2, p1}, Lg/q0;->a(Landroid/view/WindowInsets;Landroid/view/View;)Lg/q0;

    move-result-object p1

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    const/4 v2, 0x0

    if-ge v0, v1, :cond_0

    iget-object v0, p0, Lg/m;->b:Landroid/view/View;

    invoke-static {p2, v0}, Lg/n;->a(Landroid/view/WindowInsets;Landroid/view/View;)V

    iget-object p2, p0, Lg/m;->a:Lg/q0;

    invoke-virtual {p1, p2}, Lg/q0;->equals(Ljava/lang/Object;)Z

    move-result p2

    if-eqz p2, :cond_0

    throw v2

    :cond_0
    iput-object p1, p0, Lg/m;->a:Lg/q0;

    throw v2
.end method
