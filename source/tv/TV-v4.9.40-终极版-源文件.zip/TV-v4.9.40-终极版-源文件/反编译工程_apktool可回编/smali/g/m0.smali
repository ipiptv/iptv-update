.class public Lg/m0;
.super Lg/l0;
.source "SourceFile"


# direct methods
.method public constructor <init>(Lg/q0;Landroid/view/WindowInsets;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lg/l0;-><init>(Lg/q0;Landroid/view/WindowInsets;)V

    return-void
.end method


# virtual methods
.method public l(Lc/b;)V
    .locals 0

    .line 1
    return-void
.end method
