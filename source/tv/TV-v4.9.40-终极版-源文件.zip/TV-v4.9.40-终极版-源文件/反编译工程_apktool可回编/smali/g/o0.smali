.class public final Lg/o0;
.super Lg/m0;
.source "SourceFile"


# static fields
.field public static final synthetic l:I


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 1
    invoke-static {}, Lg/n0;->a()Landroid/view/WindowInsets;

    .line 2
    .line 3
    .line 4
    move-result-object v0

    .line 5
    const/4 v1, 0x0

    .line 6
    invoke-static {v0, v1}, Lg/q0;->a(Landroid/view/WindowInsets;Landroid/view/View;)Lg/q0;

    .line 7
    .line 8
    .line 9
    return-void
.end method

.method public constructor <init>(Lg/q0;Landroid/view/WindowInsets;)V
    .locals 0

    .line 1
    invoke-direct {p0, p1, p2}, Lg/m0;-><init>(Lg/q0;Landroid/view/WindowInsets;)V

    return-void
.end method


# virtual methods
.method public final d(Landroid/view/View;)V
    .locals 0

    .line 1
    return-void
.end method
