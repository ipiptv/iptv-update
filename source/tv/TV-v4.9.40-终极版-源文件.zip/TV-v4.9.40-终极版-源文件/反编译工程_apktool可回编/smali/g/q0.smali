.class public final Lg/q0;
.super Ljava/lang/Object;
.source "SourceFile"


# instance fields
.field public final a:Lg/p0;


# direct methods
.method public static constructor <clinit>()V
    .locals 2

    .line 1
    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_0

    sget v0, Lg/o0;->l:I

    goto :goto_0

    :cond_0
    sget v0, Lg/p0;->b:I

    :goto_0
    return-void
.end method

.method public constructor <init>()V
    .locals 1

    .line 1
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    new-instance v0, Lg/p0;

    invoke-direct {v0, p0}, Lg/p0;-><init>(Lg/q0;)V

    iput-object v0, p0, Lg/q0;->a:Lg/p0;

    return-void
.end method

.method public constructor <init>(Landroid/view/WindowInsets;)V
    .locals 2

    .line 2
    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I

    const/16 v1, 0x1e

    if-lt v0, v1, :cond_0

    new-instance v0, Lg/o0;

    invoke-direct {v0, p0, p1}, Lg/o0;-><init>(Lg/q0;Landroid/view/WindowInsets;)V

    :goto_0
    iput-object v0, p0, Lg/q0;->a:Lg/p0;

    goto :goto_1

    :cond_0
    const/16 v1, 0x1d

    if-lt v0, v1, :cond_1

    new-instance v0, Lg/m0;

    invoke-direct {v0, p0, p1}, Lg/m0;-><init>(Lg/q0;Landroid/view/WindowInsets;)V

    goto :goto_0

    :cond_1
    const/16 v1, 0x1c

    if-lt v0, v1, :cond_2

    new-instance v0, Lg/l0;

    invoke-direct {v0, p0, p1}, Lg/l0;-><init>(Lg/q0;Landroid/view/WindowInsets;)V

    goto :goto_0

    :cond_2
    new-instance v0, Lg/k0;

    invoke-direct {v0, p0, p1}, Lg/k0;-><init>(Lg/q0;Landroid/view/WindowInsets;)V

    goto :goto_0

    :goto_1
    return-void
.end method

.method public static a(Landroid/view/WindowInsets;Landroid/view/View;)Lg/q0;
    .locals 2

    .line 1
    new-instance v0, Lg/q0;

    .line 2
    .line 3
    invoke-virtual {p0}, Ljava/lang/Object;->getClass()Ljava/lang/Class;

    .line 4
    .line 5
    .line 6
    invoke-direct {v0, p0}, Lg/q0;-><init>(Landroid/view/WindowInsets;)V

    .line 7
    .line 8
    .line 9
    if-eqz p1, :cond_1

    .line 10
    .line 11
    sget-object p0, Lg/v;->a:Ljava/lang/reflect/Field;

    .line 12
    .line 13
    invoke-static {p1}, Lg/l;->b(Landroid/view/View;)Z

    .line 14
    .line 15
    .line 16
    move-result p0

    .line 17
    if-eqz p0, :cond_1

    .line 18
    .line 19
    sget p0, Landroid/os/Build$VERSION;->SDK_INT:I

    .line 20
    .line 21
    const/16 v1, 0x17

    .line 22
    .line 23
    if-lt p0, v1, :cond_0

    .line 24
    .line 25
    invoke-static {p1}, Lg/o;->a(Landroid/view/View;)Lg/q0;

    .line 26
    .line 27
    .line 28
    move-result-object p0

    .line 29
    goto :goto_0

    .line 30
    :cond_0
    invoke-static {p1}, Lg/n;->j(Landroid/view/View;)Lg/q0;

    .line 31
    .line 32
    .line 33
    move-result-object p0

    .line 34
    :goto_0
    iget-object v1, v0, Lg/q0;->a:Lg/p0;

    .line 35
    .line 36
    invoke-virtual {v1, p0}, Lg/p0;->k(Lg/q0;)V

    .line 37
    .line 38
    .line 39
    invoke-virtual {p1}, Landroid/view/View;->getRootView()Landroid/view/View;

    .line 40
    .line 41
    .line 42
    move-result-object p0

    .line 43
    invoke-virtual {v1, p0}, Lg/p0;->d(Landroid/view/View;)V

    .line 44
    .line 45
    .line 46
    :cond_1
    return-object v0
.end method


# virtual methods
.method public final equals(Ljava/lang/Object;)Z
    .locals 1

    .line 1
    if-ne p0, p1, :cond_0

    .line 2
    .line 3
    const/4 p1, 0x1

    .line 4
    return p1

    .line 5
    :cond_0
    instance-of v0, p1, Lg/q0;

    .line 6
    .line 7
    if-nez v0, :cond_1

    .line 8
    .line 9
    const/4 p1, 0x0

    .line 10
    return p1

    .line 11
    :cond_1
    check-cast p1, Lg/q0;

    .line 12
    .line 13
    iget-object p1, p1, Lg/q0;->a:Lg/p0;

    .line 14
    .line 15
    iget-object v0, p0, Lg/q0;->a:Lg/p0;

    .line 16
    .line 17
    invoke-static {v0, p1}, Lf/a;->a(Ljava/lang/Object;Ljava/lang/Object;)Z

    .line 18
    .line 19
    .line 20
    move-result p1

    .line 21
    return p1
.end method

.method public final hashCode()I
    .locals 1

    .line 1
    iget-object v0, p0, Lg/q0;->a:Lg/p0;

    if-nez v0, :cond_0

    const/4 v0, 0x0

    goto :goto_0

    :cond_0
    invoke-virtual {v0}, Lg/p0;->hashCode()I

    move-result v0

    :goto_0
    return v0
.end method
