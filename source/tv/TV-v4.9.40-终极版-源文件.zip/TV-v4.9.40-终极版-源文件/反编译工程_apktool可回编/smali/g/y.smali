.class public final Lg/y;
.super Lx/e;
.source "SourceFile"

# interfaces
.implements Lc0/c;


# instance fields
.field public c:Landroid/view/ViewGroup;

.field public d:Landroid/view/View;

.field public e:I

.field public f:I

.field public g:I

.field public synthetic h:Ljava/lang/Object;

.field public final synthetic i:Landroid/view/ViewGroup;


# direct methods
.method public constructor <init>(Landroid/view/ViewGroup;Lv/a;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lg/y;->i:Landroid/view/ViewGroup;

    invoke-direct {p0, p2}, Lx/e;-><init>(Lv/a;)V

    return-void
.end method


# virtual methods
.method public final c(Ljava/lang/Object;Ljava/lang/Object;)Ljava/lang/Object;
    .locals 0

    .line 1
    check-cast p1, Lg0/b;

    .line 2
    .line 3
    check-cast p2, Lv/a;

    .line 4
    .line 5
    invoke-virtual {p0, p1, p2}, Lg/y;->d(Ljava/lang/Object;Lv/a;)Lv/a;

    .line 6
    .line 7
    .line 8
    move-result-object p1

    .line 9
    check-cast p1, Lg/y;

    .line 10
    .line 11
    sget-object p2, Lt/g;->a:Lt/g;

    .line 12
    .line 13
    invoke-virtual {p1, p2}, Lg/y;->e(Ljava/lang/Object;)Ljava/lang/Object;

    .line 14
    .line 15
    .line 16
    move-result-object p1

    .line 17
    return-object p1
.end method

.method public final d(Ljava/lang/Object;Lv/a;)Lv/a;
    .locals 2

    .line 1
    new-instance v0, Lg/y;

    iget-object v1, p0, Lg/y;->i:Landroid/view/ViewGroup;

    invoke-direct {v0, v1, p2}, Lg/y;-><init>(Landroid/view/ViewGroup;Lv/a;)V

    iput-object p1, v0, Lg/y;->h:Ljava/lang/Object;

    return-object v0
.end method

.method public final e(Ljava/lang/Object;)Ljava/lang/Object;
    .locals 12

    .line 1
    sget-object v0, Lw/a;->a:Lw/a;

    .line 2
    .line 3
    iget v1, p0, Lg/y;->g:I

    .line 4
    .line 5
    const/4 v2, 0x2

    .line 6
    const/4 v3, 0x1

    .line 7
    if-eqz v1, :cond_2

    .line 8
    .line 9
    if-eq v1, v3, :cond_1

    .line 10
    .line 11
    if-ne v1, v2, :cond_0

    .line 12
    .line 13
    iget v1, p0, Lg/y;->f:I

    .line 14
    .line 15
    iget v4, p0, Lg/y;->e:I

    .line 16
    .line 17
    iget-object v5, p0, Lg/y;->c:Landroid/view/ViewGroup;

    .line 18
    .line 19
    iget-object v6, p0, Lg/y;->h:Ljava/lang/Object;

    .line 20
    .line 21
    check-cast v6, Lg0/b;

    .line 22
    .line 23
    invoke-static {p1}, Lb0/d;->F(Ljava/lang/Object;)V

    .line 24
    .line 25
    .line 26
    move-object p1, p0

    .line 27
    goto/16 :goto_2

    .line 28
    .line 29
    :cond_0
    new-instance p1, Ljava/lang/IllegalStateException;

    .line 30
    .line 31
    const-string v0, "call to \'resume\' before \'invoke\' with coroutine"

    .line 32
    .line 33
    invoke-direct {p1, v0}, Ljava/lang/IllegalStateException;-><init>(Ljava/lang/String;)V

    .line 34
    .line 35
    .line 36
    throw p1

    .line 37
    :cond_1
    iget v1, p0, Lg/y;->f:I

    .line 38
    .line 39
    iget v4, p0, Lg/y;->e:I

    .line 40
    .line 41
    iget-object v5, p0, Lg/y;->d:Landroid/view/View;

    .line 42
    .line 43
    iget-object v6, p0, Lg/y;->c:Landroid/view/ViewGroup;

    .line 44
    .line 45
    iget-object v7, p0, Lg/y;->h:Ljava/lang/Object;

    .line 46
    .line 47
    check-cast v7, Lg0/b;

    .line 48
    .line 49
    invoke-static {p1}, Lb0/d;->F(Ljava/lang/Object;)V

    .line 50
    .line 51
    .line 52
    move-object p1, p0

    .line 53
    goto :goto_1

    .line 54
    :cond_2
    invoke-static {p1}, Lb0/d;->F(Ljava/lang/Object;)V

    .line 55
    .line 56
    .line 57
    iget-object p1, p0, Lg/y;->h:Ljava/lang/Object;

    .line 58
    .line 59
    check-cast p1, Lg0/b;

    .line 60
    .line 61
    iget-object v1, p0, Lg/y;->i:Landroid/view/ViewGroup;

    .line 62
    .line 63
    invoke-virtual {v1}, Landroid/view/ViewGroup;->getChildCount()I

    .line 64
    .line 65
    .line 66
    move-result v4

    .line 67
    const/4 v5, 0x0

    .line 68
    move-object v6, p0

    .line 69
    :goto_0
    if-ge v5, v4, :cond_6

    .line 70
    .line 71
    invoke-virtual {v1, v5}, Landroid/view/ViewGroup;->getChildAt(I)Landroid/view/View;

    .line 72
    .line 73
    .line 74
    move-result-object v7

    .line 75
    iput-object p1, v6, Lg/y;->h:Ljava/lang/Object;

    .line 76
    .line 77
    iput-object v1, v6, Lg/y;->c:Landroid/view/ViewGroup;

    .line 78
    .line 79
    iput-object v7, v6, Lg/y;->d:Landroid/view/View;

    .line 80
    .line 81
    iput v5, v6, Lg/y;->e:I

    .line 82
    .line 83
    iput v4, v6, Lg/y;->f:I

    .line 84
    .line 85
    iput v3, v6, Lg/y;->g:I

    .line 86
    .line 87
    iput-object v7, p1, Lg0/b;->b:Ljava/lang/Object;

    .line 88
    .line 89
    const/4 v8, 0x3

    .line 90
    iput v8, p1, Lg0/b;->a:I

    .line 91
    .line 92
    iput-object v6, p1, Lg0/b;->d:Lv/a;

    .line 93
    .line 94
    sget-object v8, Lw/a;->a:Lw/a;

    .line 95
    .line 96
    sget-object v8, Lw/a;->a:Lw/a;

    .line 97
    .line 98
    if-ne v8, v0, :cond_3

    .line 99
    .line 100
    return-object v0

    .line 101
    :cond_3
    move-object v10, v7

    .line 102
    move-object v7, p1

    .line 103
    move-object p1, v6

    .line 104
    move-object v6, v1

    .line 105
    move v1, v4

    .line 106
    move v4, v5

    .line 107
    move-object v5, v10

    .line 108
    :goto_1
    instance-of v8, v5, Landroid/view/ViewGroup;

    .line 109
    .line 110
    if-eqz v8, :cond_5

    .line 111
    .line 112
    check-cast v5, Landroid/view/ViewGroup;

    .line 113
    .line 114
    new-instance v8, Lg/y;

    .line 115
    .line 116
    const/4 v9, 0x0

    .line 117
    invoke-direct {v8, v5, v9}, Lg/y;-><init>(Landroid/view/ViewGroup;Lv/a;)V

    .line 118
    .line 119
    .line 120
    new-instance v5, Landroidx/recyclerview/widget/r0;

    .line 121
    .line 122
    invoke-direct {v5, v3, v8}, Landroidx/recyclerview/widget/r0;-><init>(ILjava/lang/Object;)V

    .line 123
    .line 124
    .line 125
    iput-object v7, p1, Lg/y;->h:Ljava/lang/Object;

    .line 126
    .line 127
    iput-object v6, p1, Lg/y;->c:Landroid/view/ViewGroup;

    .line 128
    .line 129
    iput-object v9, p1, Lg/y;->d:Landroid/view/View;

    .line 130
    .line 131
    iput v4, p1, Lg/y;->e:I

    .line 132
    .line 133
    iput v1, p1, Lg/y;->f:I

    .line 134
    .line 135
    iput v2, p1, Lg/y;->g:I

    .line 136
    .line 137
    invoke-virtual {v7, v5, p1}, Lg0/b;->d(Landroidx/recyclerview/widget/r0;Lv/a;)Ljava/lang/Object;

    .line 138
    .line 139
    .line 140
    move-result-object v5

    .line 141
    if-ne v5, v0, :cond_4

    .line 142
    .line 143
    return-object v0

    .line 144
    :cond_4
    move-object v5, v6

    .line 145
    move-object v6, v7

    .line 146
    :goto_2
    move-object v10, v6

    .line 147
    move-object v6, p1

    .line 148
    move-object p1, v10

    .line 149
    move-object v11, v5

    .line 150
    move v5, v1

    .line 151
    move-object v1, v11

    .line 152
    goto :goto_3

    .line 153
    :cond_5
    move v5, v1

    .line 154
    move-object v1, v6

    .line 155
    move-object v6, p1

    .line 156
    move-object p1, v7

    .line 157
    :goto_3
    add-int/2addr v4, v3

    .line 158
    move v10, v5

    .line 159
    move v5, v4

    .line 160
    move v4, v10

    .line 161
    goto :goto_0

    .line 162
    :cond_6
    sget-object p1, Lt/g;->a:Lt/g;

    .line 163
    .line 164
    return-object p1
.end method
