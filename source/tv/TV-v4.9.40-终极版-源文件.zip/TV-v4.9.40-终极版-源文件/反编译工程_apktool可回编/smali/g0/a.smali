.class public interface abstract Lg0/a;
.super Ljava/lang/Object;
.source "SourceFile"


# virtual methods
.method public abstract iterator()Ljava/util/Iterator;
.end method
