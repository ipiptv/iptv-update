.class public final Lg0/c;
.super Ljava/lang/Object;
.source "SourceFile"

# interfaces
.implements Ljava/lang/Iterable;
.implements Le0/a;


# instance fields
.field public final synthetic a:Lg0/a;


# direct methods
.method public constructor <init>(Lh0/c;)V
    .locals 0

    .line 1
    iput-object p1, p0, Lg0/c;->a:Lg0/a;

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    return-void
.end method


# virtual methods
.method public final iterator()Ljava/util/Iterator;
    .locals 1

    .line 1
    iget-object v0, p0, Lg0/c;->a:Lg0/a;

    invoke-interface {v0}, Lg0/a;->iterator()Ljava/util/Iterator;

    move-result-object v0

    return-object v0
.end method
