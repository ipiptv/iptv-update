package com.github.tvbox.osc.api;

import android.text.TextUtils;

import com.github.tvbox.osc.util.HawkConfig;
import com.orhanobut.hawk.Hawk;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * 夸克网盘轻量客户端（基于网页端接口，需配置 Cookie）
 */
public class QuarkApi {

    private static final String BASE = "https://drive-pc.quark.cn";
    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

    private static QuarkApi instance;
    private final OkHttpClient client;

    public static QuarkApi get() {
        if (instance == null) instance = new QuarkApi();
        return instance;
    }

    private QuarkApi() {
        client = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(25, TimeUnit.SECONDS)
                .build();
    }

    public static boolean hasCookie() {
        String ck = Hawk.get(HawkConfig.QUARK_COOKIE, "");
        return !TextUtils.isEmpty(ck);
    }

    private Request.Builder baseBuilder(String url) {
        String ck = Hawk.get(HawkConfig.QUARK_COOKIE, "");
        return new Request.Builder()
                .url(url)
                .header("Cookie", ck == null ? "" : ck)
                .header("User-Agent", UA)
                .header("Referer", "https://pan.quark.cn/")
                .header("Origin", "https://pan.quark.cn");
    }

    public interface ListCallback {
        void onResult(List<QuarkFile> list, String error);
    }

    public interface UrlCallback {
        void onResult(String url, String error);
    }

    /** 列出目录 */
    public void list(String pdirFid, final ListCallback cb) {
        String url = BASE + "/1/clouddrive/file/sort?pr=ucpro&fr=pc&pdir_fid=" + (pdirFid == null ? "0" : pdirFid)
                + "&_page=1&_size=100&_fetch_total=1&_fetch_sub_dirs=0"
                + "&_sort=file_type:asc,updated_at:desc";
        client.newCall(baseBuilder(url).get().build()).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                cb.onResult(null, "网络错误：" + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    String body = response.body() != null ? response.body().string() : "";
                    JSONObject obj = new JSONObject(body);
                    if (obj.optInt("status", -1) != 200) {
                        cb.onResult(null, obj.optString("message", "接口返回异常"));
                        return;
                    }
                    JSONArray arr = obj.optJSONObject("data") == null ? null : obj.optJSONObject("data").optJSONArray("list");
                    List<QuarkFile> result = new ArrayList<>();
                    if (arr != null) {
                        for (int i = 0; i < arr.length(); i++) {
                            JSONObject it = arr.optJSONObject(i);
                            if (it == null) continue;
                            QuarkFile f = new QuarkFile();
                            f.fid = it.optString("fid");
                            f.name = it.optString("file_name");
                            f.dir = it.optInt("file_type", 0) == 0;
                            f.size = it.optLong("size", 0);
                            f.updatedAt = it.optLong("l_updated_at", 0);
                            result.add(f);
                        }
                    }
                    cb.onResult(result, null);
                } catch (Exception e) {
                    cb.onResult(null, "解析失败：" + e.getMessage());
                }
            }
        });
    }

    /** 获取下载/播放直链 */
    public void downloadUrl(String fid, final UrlCallback cb) {
        String url = BASE + "/1/clouddrive/file/download?pr=ucpro&fr=pc";
        String json = "{\"fids\":[\"" + fid + "\"]}";
        RequestBody body = RequestBody.create(MediaType.parse("application/json"), json);
        client.newCall(baseBuilder(url).post(body).build()).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                cb.onResult(null, "网络错误：" + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    String s = response.body() != null ? response.body().string() : "";
                    JSONObject obj = new JSONObject(s);
                    JSONArray data = obj.optJSONArray("data");
                    if (data != null && data.length() > 0) {
                        String dl = data.optJSONObject(0) == null ? "" : data.optJSONObject(0).optString("download_url");
                        if (!TextUtils.isEmpty(dl)) {
                            cb.onResult(dl, null);
                            return;
                        }
                    }
                    cb.onResult(null, obj.optString("message", "取播放地址失败"));
                } catch (Exception e) {
                    cb.onResult(null, "解析失败：" + e.getMessage());
                }
            }
        });
    }

    public static String formatSize(long size) {
        if (size <= 0) return "";
        if (size < 1024L * 1024L) return (size / 1024L) + "KB";
        if (size < 1024L * 1024L * 1024L) return String.format("%.0fMB", size / 1024.0 / 1024.0);
        return String.format("%.1fGB", size / 1024.0 / 1024.0 / 1024.0);
    }

    public static boolean isVideo(String name) {
        if (name == null) return false;
        String n = name.toLowerCase();
        return n.endsWith(".mp4") || n.endsWith(".mkv") || n.endsWith(".avi") || n.endsWith(".ts")
                || n.endsWith(".mov") || n.endsWith(".flv") || n.endsWith(".rmvb") || n.endsWith(".wmv")
                || n.endsWith(".m4v") || n.endsWith(".mpg") || n.endsWith(".mpeg") || n.endsWith(".webm")
                || n.endsWith(".iso") || n.endsWith(".3gp");
    }

    public static class QuarkFile {
        public String fid;
        public String name;
        public boolean dir;
        public long size;
        public long updatedAt;
    }
}
