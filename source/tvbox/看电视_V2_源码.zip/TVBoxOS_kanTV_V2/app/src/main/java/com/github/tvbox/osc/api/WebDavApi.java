package com.github.tvbox.osc.api;

import android.text.TextUtils;

import com.github.tvbox.osc.util.HawkConfig;
import com.orhanobut.hawk.Hawk;

import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserFactory;

import java.io.IOException;
import java.io.StringReader;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Credentials;
import okhttp3.MediaType;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

/**
 * 通用 WebDAV 客户端（标准协议，无文件大小限制）
 * 可用 AList / OpenList 之类网关把夸克挂出来，再在这里填 WebDAV 地址
 */
public class WebDavApi {

    private static WebDavApi instance;
    private final OkHttpClient client;

    public static WebDavApi get() {
        if (instance == null) instance = new WebDavApi();
        return instance;
    }

    private WebDavApi() {
        client = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(30, TimeUnit.SECONDS)
                .build();
    }

    public static boolean hasConfig() {
        String url = Hawk.get(HawkConfig.WEBDAV_URL, "");
        return !TextUtils.isEmpty(url);
    }

    public static String baseUrl() {
        String url = Hawk.get(HawkConfig.WEBDAV_URL, "");
        if (url == null) url = "";
        url = url.trim();
        if (url.endsWith("/")) url = url.substring(0, url.length() - 1);
        return url;
    }

    private Request.Builder authBuilder(String url) {
        String user = Hawk.get(HawkConfig.WEBDAV_USER, "");
        String pass = Hawk.get(HawkConfig.WEBDAV_PASS, "");
        Request.Builder b = new Request.Builder().url(url);
        if (!TextUtils.isEmpty(user)) {
            b.header("Authorization", Credentials.basic(user, pass == null ? "" : pass));
        }
        return b;
    }

    public static String encodePath(String path) {
        if (path == null || path.isEmpty() || "/".equals(path)) return "/";
        StringBuilder sb = new StringBuilder();
        String[] parts = path.split("/");
        for (String p : parts) {
            if (p.isEmpty()) continue;
            try {
                sb.append("/").append(URLEncoder.encode(p, "UTF-8").replace("+", "%20"));
            } catch (Exception e) {
                sb.append("/").append(p);
            }
        }
        return sb.toString();
    }

    public static String fullUrl(String path) {
        return baseUrl() + encodePath(path);
    }

    public interface ListCallback {
        void onResult(List<QuarkApi.QuarkFile> list, String error);
    }

    public void list(String path, final ListCallback cb) {
        if (!hasConfig()) {
            cb.onResult(null, "还没配置 WebDAV 地址");
            return;
        }
        String reqPath = path == null ? "/" : path;
        if (!reqPath.endsWith("/")) reqPath = reqPath + "/";
        String url = fullUrl(reqPath);
        String body = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>"
                + "<d:propfind xmlns:d=\"DAV:\"><d:prop>"
                + "<d:displayname/><d:resourcetype/><d:getcontentlength/><d:getlastmodified/>"
                + "</d:prop></d:propfind>";
        Request req = authBuilder(url)
                .method("PROPFIND", RequestBody.create(MediaType.parse("application/xml; charset=utf-8"), body))
                .header("Depth", "1")
                .build();
        client.newCall(req).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                cb.onResult(null, "网络错误：" + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                String xml = response.body() != null ? response.body().string() : "";
                if (!response.isSuccessful()) {
                    cb.onResult(null, "服务器返回 " + response.code());
                    return;
                }
                try {
                    List<QuarkApi.QuarkFile> list = parse(xml, path);
                    cb.onResult(list, null);
                } catch (Exception e) {
                    cb.onResult(null, "解析失败：" + e.getMessage());
                }
            }
        });
    }


    /** 同步列目录，供后台全盘扫描使用 */
    public List<QuarkApi.QuarkFile> listSync(String path) throws IOException {
        if (!hasConfig()) throw new IOException("还没配置 WebDAV 地址");
        String reqPath = path == null ? "/" : path;
        if (!reqPath.endsWith("/")) reqPath = reqPath + "/";
        String url = fullUrl(reqPath);
        String body = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>"
                + "<d:propfind xmlns:d=\"DAV:\"><d:prop>"
                + "<d:displayname/><d:resourcetype/><d:getcontentlength/><d:getlastmodified/>"
                + "</d:prop></d:propfind>";
        Request req = authBuilder(url)
                .method("PROPFIND", RequestBody.create(MediaType.parse("application/xml; charset=utf-8"), body))
                .header("Depth", "1")
                .build();
        Response response = client.newCall(req).execute();
        try {
            String xml = response.body() != null ? response.body().string() : "";
            if (!response.isSuccessful()) throw new IOException("HTTP " + response.code());
            return parse(xml, reqPath);
        } catch (Exception e) {
            if (e instanceof IOException) throw (IOException) e;
            throw new IOException(e.getMessage());
        } finally {
            try { response.close(); } catch (Exception ignore) {}
        }
    }

    private List<QuarkApi.QuarkFile> parse(String xml, String requestPath) throws Exception {
        List<QuarkApi.QuarkFile> result = new ArrayList<>();
        XmlPullParser parser = XmlPullParserFactory.newInstance().newPullParser();
        parser.setInput(new StringReader(xml));
        int event = parser.getEventType();
        QuarkApi.QuarkFile cur = null;
        String tag = "";
        String href = "";
        boolean isDir = false;
        long size = 0;
        String name = "";
        while (event != XmlPullParser.END_DOCUMENT) {
            String tagName = localName(parser.getName());
            switch (event) {
                case XmlPullParser.START_TAG:
                    tag = tagName;
                    if ("response".equals(tagName)) {
                        cur = new QuarkApi.QuarkFile();
                        href = "";
                        isDir = false;
                        size = 0;
                        name = "";
                    } else if ("collection".equals(tagName)) {
                        isDir = true;
                    }
                    break;
                case XmlPullParser.TEXT:
                    String text = parser.getText();
                    if (text == null) text = "";
                    if ("href".equals(tag)) href = text.trim();
                    else if ("displayname".equals(tag)) name = text.trim();
                    else if ("getcontentlength".equals(tag)) {
                        try {
                            size = Long.parseLong(text.trim());
                        } catch (Exception ignore) {
                        }
                    }
                    break;
                case XmlPullParser.END_TAG:
                    if ("response".equals(tagName) && cur != null) {
                        String decoded = stripBase(decode(href));
                        if (decoded != null) {
                            String normReq = requestPath == null || requestPath.isEmpty() ? "/" : requestPath;
                            if (!normReq.endsWith("/")) normReq = normReq + "/";
                            String normItem = decoded.endsWith("/") ? decoded.substring(0, decoded.length() - 1) : decoded;
                            String normReqNoSlash = normReq.substring(0, normReq.length() - 1);
                            if (!normItem.equals(normReqNoSlash) && !normItem.equals(normReq)) {
                                cur.fid = normItem;
                                cur.name = name.isEmpty() ? lastSegment(normItem) : name;
                                cur.dir = isDir;
                                cur.size = size;
                                result.add(cur);
                            }
                        }
                        cur = null;
                    }
                    tag = "";
                    break;
            }
            event = parser.next();
        }
        return result;
    }


    /** AList 返回的 href 带 /dav 这类网关前缀，去掉后才是相对路径 */
    private static String stripBase(String path) {
        try {
            java.net.URI u = java.net.URI.create(baseUrl());
            String bp = u.getPath();
            if (bp != null && !bp.isEmpty() && path != null && path.startsWith(bp)) {
                String r = path.substring(bp.length());
                return r.isEmpty() ? "/" : r;
            }
        } catch (Throwable ignore) {
        }
        return path;
    }

    private static String localName(String raw) {
        if (raw == null) return "";
        int idx = raw.indexOf(':');
        return idx >= 0 ? raw.substring(idx + 1) : raw;
    }

    private static String lastSegment(String path) {
        if (path == null) return "";
        String p = path.endsWith("/") ? path.substring(0, path.length() - 1) : path;
        int idx = p.lastIndexOf('/');
        return idx >= 0 ? p.substring(idx + 1) : p;
    }

    private static String decode(String href) {
        if (href == null || href.isEmpty()) return null;
        try {
            // 可能是完整 URL，取 path 部分
            String path = href;
            int schemeIdx = path.indexOf("://");
            if (schemeIdx >= 0) {
                int slash = path.indexOf('/', schemeIdx + 3);
                path = slash >= 0 ? path.substring(slash) : "/";
            }
            return java.net.URLDecoder.decode(path, "UTF-8");
        } catch (Exception e) {
            return href;
        }
    }
}
