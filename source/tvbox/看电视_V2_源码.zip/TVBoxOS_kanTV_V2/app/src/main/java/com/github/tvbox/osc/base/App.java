package com.github.tvbox.osc.base;

import android.app.Activity;
import androidx.multidex.MultiDexApplication;

import com.github.tvbox.osc.bean.VodInfo;
import com.github.tvbox.osc.callback.EmptyCallback;
import com.github.tvbox.osc.callback.LoadingCallback;
import com.github.tvbox.osc.data.AppDataManager;
import com.github.tvbox.osc.server.ControlManager;
import com.github.tvbox.osc.util.AppManager;
import com.github.tvbox.osc.util.EpgUtil;
import com.github.tvbox.osc.util.FileUtils;
import com.github.tvbox.osc.util.HawkConfig;
import com.github.tvbox.osc.util.LOG;
import com.github.tvbox.osc.util.OkGoHelper;
import com.github.tvbox.osc.util.PlayerHelper;
import com.kingja.loadsir.core.LoadSir;
import com.orhanobut.hawk.Hawk;
import com.p2p.P2PClass;
import com.whl.quickjs.android.QuickJSLoader;
import com.github.catvod.crawler.JsLoader;

import me.jessyan.autosize.AutoSizeConfig;
import me.jessyan.autosize.unit.Subunits;

/**
 * @author pj567
 * @date :2020/12/17
 * @description:
 */
public class App extends MultiDexApplication {
    private static App instance;

    private static P2PClass p;
    public static String burl;
    private static String dashData;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        initParams();
        // 内置默认直播源
        try {
            if (com.orhanobut.hawk.Hawk.get(com.github.tvbox.osc.util.HawkConfig.LIVE_API_URL, "").isEmpty()) {
                com.orhanobut.hawk.Hawk.put(com.github.tvbox.osc.util.HawkConfig.LIVE_API_URL,
                        "https://gitee.com/IptvIptv/Iptv/raw/master/bbxx365_hotel.m3u");
            }
        } catch (Throwable ignore) {
        }
        // 内置点播源配置：首次运行把 assets 里的配置写入本地缓存，避免启动时联网下载
        try {
            String apiUrl = com.orhanobut.hawk.Hawk.get(com.github.tvbox.osc.util.HawkConfig.API_URL, "");
            if (!apiUrl.isEmpty()) {
                java.io.File apiCache = new java.io.File(getFilesDir().getAbsolutePath() + "/" + com.github.tvbox.osc.util.MD5.encode(apiUrl));
                if (!apiCache.exists()) {
                    java.io.InputStream is = getAssets().open("api_default.json");
                    java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
                    byte[] buf = new byte[8192];
                    int n;
                    while ((n = is.read(buf)) > 0) bos.write(buf, 0, n);
                    is.close();
                    com.github.tvbox.osc.util.FileUtils.saveCache(apiCache, new String(bos.toByteArray(), "UTF-8"));
                }
            }
        } catch (Throwable ignore) {
        }
        // 内置默认影视源（配置地址）
        try {
            if (com.orhanobut.hawk.Hawk.get(com.github.tvbox.osc.util.HawkConfig.API_URL, "").isEmpty()) {
                com.orhanobut.hawk.Hawk.put(com.github.tvbox.osc.util.HawkConfig.API_URL,
                        "https://9280.kstore.vip/wex.json");
            }
        } catch (Throwable ignore) {
        }
        // OKGo（必须同步，网络与台标依赖）
        OkGoHelper.init(); //台标获取
        // 以下初始化不阻塞首屏，放到后台线程执行，减少启动黑屏时间
        new Thread(new Runnable() {
            @Override
            public void run() {
                try {
                    EpgUtil.init();
                } catch (Throwable ignore) {
                }
                try {
                    ControlManager.init(App.this);
                } catch (Throwable ignore) {
                }
                try {
                    AppDataManager.init();
                } catch (Throwable ignore) {
                }
                try {
                    QuickJSLoader.init();
                } catch (Throwable ignore) {
                }
                try {
                    FileUtils.cleanPlayerCache();
                } catch (Throwable ignore) {
                }
            }
        }, "app-bg-init").start();
        LoadSir.beginBuilder()
                .addCallback(new EmptyCallback())
                .addCallback(new LoadingCallback())
                .commit();
        AutoSizeConfig.getInstance().setCustomFragment(true).getUnitsManager()
                .setSupportDP(false)
                .setSupportSP(false)
                .setSupportSubunits(Subunits.MM);
        PlayerHelper.init();
    }

    private void initParams() {
        // Hawk
        Hawk.init(this).build();
        Hawk.put(HawkConfig.DEBUG_OPEN, false);
        Hawk.put(HawkConfig.PLAYER_IS_LIVE, false);
        if (!Hawk.contains(HawkConfig.PLAY_TYPE)) {
            Hawk.put(HawkConfig.PLAY_TYPE, 2);
        } else if (Hawk.get(HawkConfig.PLAY_TYPE, 2) == 0) {
            Hawk.put(HawkConfig.PLAY_TYPE, 2);
        }
    }

    public static App getInstance() {
        return instance;
    }

    @Override
    public void onTerminate() {
        super.onTerminate();
        JsLoader.destroy();
    }


    private VodInfo vodInfo;
    public void setVodInfo(VodInfo vodinfo){
        this.vodInfo = vodinfo;
    }
    public VodInfo getVodInfo(){
        return this.vodInfo;
    }

    public static P2PClass getp2p() {
        try {
            if (p == null) {
                p = new P2PClass(FileUtils.getExternalCachePath());
            }
            return p;
        } catch (Exception e) {
            LOG.e(e.toString());
            return null;
        }
    }

    public Activity getCurrentActivity() {
        return AppManager.getInstance().currentActivity();
    }

    public void setDashData(String data) {
        dashData = data;
    }
    public String getDashData() {
        return dashData;
    }
}