package com.github.tvbox.osc.ui.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;

import com.github.tvbox.osc.R;
import com.github.tvbox.osc.util.HawkConfig;
import com.orhanobut.hawk.Hawk;

/**
 * 启动入口：先显示启动图（由 windowBackground 提供，进程未起也立刻可见），
 * 再按设置里的「首页默认显示：直播/点播」决定进入直播还是首页。
 */
public class BootActivity extends Activity {

    private static BootActivity instance;

    public static void dismissIfShowing() {
        final BootActivity boot = instance;
        if (boot == null) return;
        boot.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                try {
                    if (!boot.isFinishing()) boot.finish();
                } catch (Throwable ignore) {
                }
            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        final boolean toLive = Hawk.get(HawkConfig.DEFAULT_LOAD_LIVE, false);
        setTheme(toLive ? R.style.BootSplashTheme : R.style.BootSplashThemeHome);
        super.onCreate(savedInstanceState);
        instance = this;
        setContentView(R.layout.activity_boot_splash);
        View root = findViewById(R.id.boot_root);
        if (root != null) {
            root.setBackgroundColor(0xFF000000);
        }
        com.github.tvbox.osc.ui.view.RingSpinnerView ring =
                findViewById(R.id.boot_ring);
        if (ring != null) {
            int px = com.github.tvbox.osc.ui.view.RingSpinnerView.targetSizePx(this);
            android.widget.FrameLayout.LayoutParams lp =
                    new android.widget.FrameLayout.LayoutParams(px, px);
            lp.gravity = android.view.Gravity.CENTER;
            ring.setLayoutParams(lp);
        }
        // 让启动图先画出来，再切到目标页，避免本页没画就被盖住（黑屏）
        getWindow().getDecorView().postDelayed(new Runnable() {
            @Override
            public void run() {
                Intent intent;
                if (toLive) {
                    intent = new Intent(BootActivity.this, LivePlayActivity.class);
                    intent.putExtra("from_boot", true);
                } else {
                    intent = new Intent(BootActivity.this, HomeActivity.class);
                }
                try {
                    startActivity(intent);
                } catch (Throwable ignore) {
                }
            }
        }, 200);
        // 兜底：目标页 10 秒还没起来也撤掉启动图
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                dismissIfShowing();
            }
        }, 10000);
    }

    @Override
    protected void onDestroy() {
        if (instance == this) instance = null;
        super.onDestroy();
    }
}
