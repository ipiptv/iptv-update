package com.github.tvbox.osc.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import androidx.recyclerview.widget.LinearLayoutManager;

import com.github.tvbox.osc.R;
import com.github.tvbox.osc.api.QuarkApi;
import com.github.tvbox.osc.api.WebDavApi;
import com.github.tvbox.osc.util.HawkConfig;
import com.orhanobut.hawk.Hawk;
import com.github.tvbox.osc.base.BaseActivity;
import com.github.tvbox.osc.ui.adapter.NetdiskAdapter;
import com.owen.tvrecyclerview.widget.TvRecyclerView;

import java.util.ArrayList;
import java.util.List;

/**
 * 夸克网盘文件浏览页：进入文件夹、点视频播放
 */
public class NetdiskActivity extends BaseActivity {

    private TvRecyclerView rvNetdisk;
    private TextView tvNdPath;
    private TextView tvNdTip;
    private NetdiskAdapter adapter;

    private String currentFid = "0";
    private boolean useWebDav = false;
    private String currentPath = "/";
    private final ArrayList<String> pathStack = new ArrayList<>();
    private final ArrayList<String> fidStack = new ArrayList<>();

    @Override
    protected int getLayoutResID() {
        return R.layout.activity_netdisk;
    }

    @Override
    protected void init() {
        rvNetdisk = findViewById(R.id.rvNetdisk);
        tvNdPath = findViewById(R.id.tvNdPath);
        tvNdTip = findViewById(R.id.tvNdTip);
        rvNetdisk.setLayoutManager(new LinearLayoutManager(this));
        adapter = new NetdiskAdapter(new NetdiskAdapter.OnFileClick() {
            @Override
            public void onClick(QuarkApi.QuarkFile file) {
                if (file.dir) {
                    pathStack.add(file.name);
                    if (useWebDav) {
                        fidStack.add(currentPath);
                        currentPath = file.fid;
                    } else {
                        fidStack.add(currentFid);
                        currentFid = file.fid;
                    }
                    updatePath();
                    loadFiles();
                } else if (QuarkApi.isVideo(file.name)) {
                    playFile(file);
                } else {
                    com.github.tvbox.osc.util.ToastUtil.show(NetdiskActivity.this, "这个文件不是视频，暂不支持播放", Toast.LENGTH_SHORT);
                }
            }
        });
        rvNetdisk.setAdapter(adapter);
        findViewById(R.id.tvNdRefresh).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                loadFiles();
            }
        });
        useWebDav = Hawk.get(HawkConfig.NETDISK_TYPE, 0) == 1 && WebDavApi.hasConfig();
        if (useWebDav) {
            String root = Hawk.get(HawkConfig.WEBDAV_ROOT, "/");
            if (root == null || root.isEmpty()) root = "/";
            currentPath = root;
            updatePath();
            loadFiles();
            return;
        }
        if (!QuarkApi.hasCookie()) {
            Intent login = new Intent(NetdiskActivity.this, QuarkLoginActivity.class);
            startActivity(login);
            finish();
            return;
        }
        loadFiles();
    }

    private void updatePath() {
        String path = "夸克网盘";
        for (String p : pathStack) path = path + " / " + p;
        tvNdPath.setText(path);
    }

    private void loadFiles() {
        tvNdTip.setVisibility(View.VISIBLE);
        tvNdTip.setText("加载中…");
        if (useWebDav) {
            WebDavApi.get().list(currentPath, new WebDavApi.ListCallback() {
                @Override
                public void onResult(List<QuarkApi.QuarkFile> list, String error) {
                    runOnUiThread(new Runnable() {
                        @Override
                        public void run() {
                            if (isFinishing()) return;
                            if (error != null) {
                                tvNdTip.setVisibility(View.VISIBLE);
                                tvNdTip.setText("加载失败：" + error);
                                return;
                            }
                            if (list == null || list.isEmpty()) {
                                tvNdTip.setVisibility(View.VISIBLE);
                                tvNdTip.setText("这个文件夹里没有内容");
                                adapter.setData(new ArrayList<QuarkApi.QuarkFile>());
                                return;
                            }
                            tvNdTip.setVisibility(View.GONE);
                            adapter.setData(list);
                            rvNetdisk.post(new Runnable() {
                                @Override
                                public void run() {
                                    rvNetdisk.setSelectedPosition(0);
                                    View first = rvNetdisk.getLayoutManager() == null ? null : rvNetdisk.getLayoutManager().findViewByPosition(0);
                                    if (first != null) first.requestFocus();
                                }
                            });
                        }
                    });
                }
            });
            return;
        }
        QuarkApi.get().list(currentFid, new QuarkApi.ListCallback() {
            @Override
            public void onResult(List<QuarkApi.QuarkFile> list, String error) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing()) return;
                        if (error != null) {
                            tvNdTip.setVisibility(View.VISIBLE);
                            tvNdTip.setText("加载失败：" + error);
                            return;
                        }
                        if (list == null || list.isEmpty()) {
                            tvNdTip.setVisibility(View.VISIBLE);
                            tvNdTip.setText("这个文件夹里没有内容");
                            adapter.setData(new ArrayList<QuarkApi.QuarkFile>());
                            return;
                        }
                        tvNdTip.setVisibility(View.GONE);
                        adapter.setData(list);
                        rvNetdisk.post(new Runnable() {
                            @Override
                            public void run() {
                                rvNetdisk.setSelectedPosition(0);
                                View first = rvNetdisk.getLayoutManager() == null ? null : rvNetdisk.getLayoutManager().findViewByPosition(0);
                                if (first != null) first.requestFocus();
                            }
                        });
                    }
                });
            }
        });
    }

    private void playFile(final QuarkApi.QuarkFile file) {
        if (useWebDav) {
            String url = WebDavApi.fullUrl(file.fid);
            Intent intent = new Intent(NetdiskActivity.this, NetdiskPlayActivity.class);
            intent.putExtra("url", url);
            intent.putExtra("name", file.name);
            intent.putExtra("webdav", true);
            startActivity(intent);
            return;
        }
        tvNdTip.setVisibility(View.VISIBLE);
        tvNdTip.setText("正在获取播放地址…");
        QuarkApi.get().downloadUrl(file.fid, new QuarkApi.UrlCallback() {
            @Override
            public void onResult(String url, String error) {
                runOnUiThread(new Runnable() {
                    @Override
                    public void run() {
                        if (isFinishing()) return;
                        if (error != null || TextUtils.isEmpty(url)) {
                            tvNdTip.setText("取播放地址失败：" + (error == null ? "" : error));
                            return;
                        }
                        tvNdTip.setVisibility(View.GONE);
                        Intent intent = new Intent(NetdiskActivity.this, NetdiskPlayActivity.class);
                        intent.putExtra("url", url);
                        intent.putExtra("name", file.name);
                        startActivity(intent);
                    }
                });
            }
        });
    }

    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (!fidStack.isEmpty()) {
                String prev = fidStack.remove(fidStack.size() - 1);
                if (useWebDav) currentPath = prev;
                else currentFid = prev;
                if (!pathStack.isEmpty()) pathStack.remove(pathStack.size() - 1);
                updatePath();
                loadFiles();
                return true;
            }
        }
        return super.onKeyDown(keyCode, event);
    }
}
