package com.github.tvbox.osc.ui.activity;

import android.os.Bundle;
import android.widget.TextView;

import com.github.tvbox.osc.R;
import com.github.tvbox.osc.base.BaseActivity;
import com.github.tvbox.osc.util.PlayerHelper;
import com.orhanobut.hawk.Hawk;
import com.github.tvbox.osc.util.HawkConfig;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import xyz.doikki.videoplayer.player.VideoView;

/**
 * 网盘视频播放页（简单版：全屏播放，返回键退出）
 */
public class NetdiskPlayActivity extends BaseActivity {

    private VideoView ndVideo;
    private ArrayList<String> listUrls;
    private ArrayList<String> listNames;
    private int curIndex = 0;
    private TextView tvNdName;

    @Override
    protected int getLayoutResID() {
        return R.layout.activity_netdisk_play;
    }

    @Override
    protected void init() {
        ndVideo = findViewById(R.id.ndVideo);
        tvNdName = findViewById(R.id.tvNdPlayName);
        String url = getIntent().getStringExtra("url");
        String name = getIntent().getStringExtra("name");
        listUrls = getIntent().getStringArrayListExtra("list_urls");
        listNames = getIntent().getStringArrayListExtra("list_names");
        curIndex = getIntent().getIntExtra("index", 0);
        if (listUrls != null && curIndex >= 0 && curIndex < listUrls.size()) {
            url = listUrls.get(curIndex);
            if (listNames != null && curIndex < listNames.size()) name = listNames.get(curIndex);
        }
        tvNdName.setText(name == null ? "" : name);
        ndVideo.setOnStateChangeListener(new xyz.doikki.videoplayer.player.VideoView.SimpleOnStateChangeListener() {
            @Override
            public void onPlayStateChanged(int playState) {
                if (playState == xyz.doikki.videoplayer.player.VideoView.STATE_PLAYBACK_COMPLETED) {
                    playNext();
                }
            }
        });

        try {
            JSONObject cfg = new JSONObject();
            cfg.put("pl", Hawk.get(HawkConfig.PLAY_TYPE, 2));
            cfg.put("ijk", Hawk.get(HawkConfig.IJK_CODEC, "硬解码"));
            cfg.put("pr", Hawk.get(HawkConfig.PLAY_RENDER, 0));
            cfg.put("sc", Hawk.get(HawkConfig.PLAY_SCALE, 0));
            PlayerHelper.updateCfg(ndVideo, cfg);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        Map<String, String> headers = new HashMap<>();
        boolean webdav = getIntent().getBooleanExtra("webdav", false);
        if (webdav) {
            String user = Hawk.get(HawkConfig.WEBDAV_USER, "");
            String pass = Hawk.get(HawkConfig.WEBDAV_PASS, "");
            if (user != null && !user.isEmpty()) {
                headers.put("Authorization", okhttp3.Credentials.basic(user, pass == null ? "" : pass));
            }
        } else {
            headers.put("Referer", "https://pan.quark.cn/");
        }
        String ua = Hawk.get(HawkConfig.USER_AGENT, "");
        if (ua == null || ua.trim().isEmpty()) {
            ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
        }
        headers.put("User-Agent", ua.trim());

        ndVideo.setUrl(url, headers);
        ndVideo.start();
    }

    private void playNext() {
        if (listUrls == null || curIndex + 1 >= listUrls.size()) return;
        curIndex++;
        String next = listUrls.get(curIndex);
        if (listNames != null && curIndex < listNames.size() && tvNdName != null) {
            tvNdName.setText(listNames.get(curIndex));
        }
        Map<String, String> headers = new HashMap<>();
        String user = Hawk.get(HawkConfig.WEBDAV_USER, "");
        String pass = Hawk.get(HawkConfig.WEBDAV_PASS, "");
        if (user != null && !user.isEmpty()) {
            headers.put("Authorization", okhttp3.Credentials.basic(user, pass == null ? "" : pass));
        }
        String ua = Hawk.get(HawkConfig.USER_AGENT, "");
        if (ua == null || ua.trim().isEmpty()) {
            ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
        }
        headers.put("User-Agent", ua.trim());
        ndVideo.release();
        ndVideo.setUrl(next, headers);
        ndVideo.start();
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (ndVideo != null) ndVideo.pause();
    }

    @Override
    protected void onDestroy() {
        if (ndVideo != null) ndVideo.release();
        super.onDestroy();
    }
}
