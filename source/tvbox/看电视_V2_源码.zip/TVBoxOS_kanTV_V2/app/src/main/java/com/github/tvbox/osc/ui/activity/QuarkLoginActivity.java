package com.github.tvbox.osc.ui.activity;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.github.tvbox.osc.R;
import com.github.tvbox.osc.base.BaseActivity;
import com.github.tvbox.osc.ui.tv.QRCodeGen;
import com.github.tvbox.osc.util.HawkConfig;
import com.orhanobut.hawk.Hawk;

import org.json.JSONObject;

import java.io.IOException;
import java.util.List;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;

/**
 * 夸克网盘扫码登录页：显示二维码，手机夸克 App 扫码确认后自动写入 Cookie
 */
public class QuarkLoginActivity extends BaseActivity {

    private static final String UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";
    private static final String BROWSER_UA = "Mozilla/5.0 (Linux; Android 9; TV) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

    private ImageView ivQr;
    private TextView tvStatus;
    private TextView tvRefresh;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private OkHttpClient client;
    private String token = "";
    private boolean finishedFlag = false;
    private boolean scanned = false;

    /** 未扫码时自动换新码，避免二维码过期 */
    private final Runnable refreshRunnable = new Runnable() {
        @Override
        public void run() {
            if (finishedFlag || scanned) return;
            if (tvStatus != null) tvStatus.setText("二维码已刷新，请扫电视上最新的码");
            startLogin();
        }
    };

    @Override
    protected int getLayoutResID() {
        return R.layout.activity_quark_login;
    }

    @Override
    protected void init() {
        ivQr = findViewById(R.id.ivQuarkQr);
        tvStatus = findViewById(R.id.tvQuarkStatus);
        tvRefresh = findViewById(R.id.tvQuarkRefresh);
        client = new OkHttpClient.Builder()
                .connectTimeout(15, TimeUnit.SECONDS)
                .readTimeout(20, TimeUnit.SECONDS)
                .followRedirects(true)
                .build();
        tvRefresh.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startLogin();
            }
        });
        startLogin();
    }

    private void startLogin() {
        handler.removeCallbacksAndMessages(null);
        finishedFlag = false;
        scanned = false;
        token = "";
        ivQr.setImageBitmap(null);
        tvStatus.setText("正在获取二维码…");
        Request request = new Request.Builder()
                .url("https://uop.quark.cn/cas/ajax/getTokenForQrcodeLogin")
                .post(okhttp3.RequestBody.create(okhttp3.MediaType.parse("application/json"), "{}"))
                .header("User-Agent", BROWSER_UA)
                .header("Referer", "https://pan.quark.cn/")
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                postStatus("获取二维码失败：" + e.getMessage());
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                try {
                    String body = response.body() == null ? "" : response.body().string();
                    JSONObject obj = new JSONObject(body);
                    JSONObject members = obj.optJSONObject("data") == null ? null : obj.optJSONObject("data").optJSONObject("members");
                    String tk = members == null ? "" : members.optString("token");
                    if (TextUtils.isEmpty(tk)) {
                        postStatus("获取二维码失败：" + obj.optString("message", "返回异常"));
                        return;
                    }
                    token = tk;
                    showQr(buildQrContent(tk));
                } catch (Exception e) {
                    postStatus("解析失败：" + e.getMessage());
                }
            }
        });
    }

    private String buildQrContent(String tk) {
        try {
            String biz = java.net.URLEncoder.encode("S:custom|OPT:SAREA@0|OPT:IMMERSIVE@1|OPT:BACK_BTN_STYLE@0", "UTF-8");
            return "https://su.quark.cn/4_eMHBJ?token=" + tk
                    + "&client_id=532&ssb=weblogin&uc_param_str="
                    + "&uc_biz_str=" + biz;
        } catch (Exception e) {
            return "https://su.quark.cn/4_eMHBJ?token=" + tk + "&client_id=532&ssb=weblogin";
        }
    }

    private void showQr(final String content) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (finishedFlag) return;
                int size = (int) getResources().getDimension(R.dimen.vs_400);
                ivQr.setImageBitmap(QRCodeGen.generateBitmap(content, size, size, 2));
                tvStatus.setText("请用手机夸克 App 扫一扫，扫码后在手机上确认登录（二维码过期会自动刷新）");
                handler.postDelayed(pollRunnable, 2000);
                handler.removeCallbacks(refreshRunnable);
                handler.postDelayed(refreshRunnable, 110000);
            }
        });
    }

    private final Runnable pollRunnable = new Runnable() {
        @Override
        public void run() {
            if (finishedFlag) return;
            if (TextUtils.isEmpty(token)) return;
            Request request = new Request.Builder()
                    .url("https://uop.quark.cn/cas/ajax/getServiceTicketByQrcodeToken?token=" + token)
                    .header("User-Agent", BROWSER_UA)
                    .header("Referer", "https://pan.quark.cn/")
                    .build();
            client.newCall(request).enqueue(new Callback() {
                @Override
                public void onFailure(Call call, IOException e) {
                    handler.postDelayed(pollRunnable, 3000);
                }

                @Override
                public void onResponse(Call call, Response response) throws IOException {
                    try {
                        String body = response.body() == null ? "" : response.body().string();
                        JSONObject obj = new JSONObject(body);
                        int status = obj.optInt("status", 0);
                        if (status == 2000000) {
                            scanned = true;
                            handler.removeCallbacks(refreshRunnable);
                            JSONObject data = obj.optJSONObject("data");
                            JSONObject members = data == null ? null : data.optJSONObject("members");
                            final String st = members == null ? "" : members.optString("st");
                            if (!TextUtils.isEmpty(st)) {
                                postStatus("扫码成功，正在换取登录凭证…");
                                exchangeTicket(st);
                                return;
                            }
                        } else if (status == 50004001 || status <= 0) {
                            // 未扫码，保持轮询
                        } else {
                            // 任意其他状态都视为已扫码/待确认，停止自动换码
                            scanned = true;
                            handler.removeCallbacks(refreshRunnable);
                            postStatus("已扫码，请在手机上点击确认登录");
                        }
                        handler.postDelayed(pollRunnable, 1200);
                    } catch (Exception e) {
                        handler.postDelayed(pollRunnable, 3000);
                    }
                }
            });
        }
    };

    private void exchangeTicket(String st) {
        String url = "https://pan.quark.cn/account/info?st=" + st + "&lw=";
        Request request = new Request.Builder()
                .url(url)
                .header("User-Agent", BROWSER_UA)
                .header("Referer", "https://pan.quark.cn/")
                .build();
        client.newCall(request).enqueue(new Callback() {
            @Override
            public void onFailure(Call call, IOException e) {
                postStatus("换取登录凭证失败：" + e.getMessage());
                restartLater();
            }

            @Override
            public void onResponse(Call call, Response response) throws IOException {
                final String cookie = collectCookie(response);
                handler.post(new Runnable() {
                    @Override
                    public void run() {
                        if (TextUtils.isEmpty(cookie)) {
                            tvStatus.setText("登录失败：没拿到 Cookie，请重试");
                            restartLater();
                            return;
                        }
                        Hawk.put(HawkConfig.QUARK_COOKIE, cookie);
                        finishedFlag = true;
                        com.github.tvbox.osc.util.ToastUtil.show(QuarkLoginActivity.this, "夸克网盘登录成功", Toast.LENGTH_SHORT);
                        Intent intent = new Intent(QuarkLoginActivity.this, NetdiskActivity.class);
                        startActivity(intent);
                        finish();
                    }
                });
            }
        });
    }

    private String collectCookie(Response response) {
        StringBuilder sb = new StringBuilder();
        List<String> cookies = response.headers().values("Set-Cookie");
        for (String c : cookies) {
            String kv = c.split(";")[0].trim();
            if (kv.contains("=") && !kv.isEmpty()) {
                if (sb.length() > 0) sb.append("; ");
                sb.append(kv);
            }
        }
        return sb.toString();
    }

    private void restartLater() {
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
                if (!finishedFlag) startLogin();
            }
        }, 3000);
    }

    private void postStatus(final String text) {
        handler.post(new Runnable() {
            @Override
            public void run() {
                if (!finishedFlag && tvStatus != null) tvStatus.setText(text);
            }
        });
    }

    @Override
    protected void onDestroy() {
        finishedFlag = true;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
