package com.github.tvbox.osc.ui.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.github.tvbox.osc.R;
import com.github.tvbox.osc.api.QuarkApi;

import java.util.ArrayList;
import java.util.List;

public class NetdiskAdapter extends RecyclerView.Adapter<NetdiskAdapter.Holder> {

    public interface OnFileClick {
        void onClick(QuarkApi.QuarkFile file);
    }

    private final List<QuarkApi.QuarkFile> data = new ArrayList<>();
    private final OnFileClick listener;

    public NetdiskAdapter(OnFileClick listener) {
        this.listener = listener;
    }

    public void setData(List<QuarkApi.QuarkFile> list) {
        data.clear();
        if (list != null) data.addAll(list);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new Holder(LayoutInflater.from(parent.getContext()).inflate(R.layout.item_netdisk_file, parent, false));
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, int position) {
        final QuarkApi.QuarkFile f = data.get(position);
        String prefix = f.dir ? "📁 " : "▶ ";
        String size = f.dir ? "" : ("   " + QuarkApi.formatSize(f.size));
        holder.tvFile.setText(prefix + f.name + size);
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (listener != null) listener.onClick(f);
            }
        });
    }

    @Override
    public int getItemCount() {
        return data.size();
    }

    static class Holder extends RecyclerView.ViewHolder {
        TextView tvFile;

        public Holder(@NonNull View itemView) {
            super(itemView);
            tvFile = itemView.findViewById(R.id.tvFile);
        }
    }
}
