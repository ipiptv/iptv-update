package com.github.tvbox.osc.ui.dialog;

import android.content.Context;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;

import com.github.tvbox.osc.R;

public class InputTextDialog extends BaseDialog {

    public interface OnTextConfirm {
        void onConfirm(String text);
    }

    private final EditText input;
    private final TextView title;
    private final TextView tip;

    public InputTextDialog(@NonNull Context context, String titleText, String defaultValue, String tipText) {
        super(context, R.style.CustomDialogStyleDim);
        setContentView(R.layout.dialog_input_text);
        title = findViewById(R.id.title);
        tip = findViewById(R.id.tip);
        input = findViewById(R.id.input);
        title.setText(titleText);
        if (tipText != null && !tipText.isEmpty()) {
            tip.setVisibility(View.VISIBLE);
            tip.setText(tipText);
        }
        if (defaultValue != null) input.setText(defaultValue);
        input.requestFocus();
    }

    public void setOnTextConfirm(final OnTextConfirm listener) {
        findViewById(R.id.btnOk).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String text = input.getText() == null ? "" : input.getText().toString().trim();
                dismiss();
                if (listener != null) listener.onConfirm(text);
            }
        });
        findViewById(R.id.btnClear).setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                input.setText("");
            }
        });
    }
}
