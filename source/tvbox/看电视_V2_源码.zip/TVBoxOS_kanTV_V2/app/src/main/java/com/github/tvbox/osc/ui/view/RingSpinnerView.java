package com.github.tvbox.osc.ui.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.SweepGradient;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;

/**
 * 细线圆环加载动画：一圈 0.56 秒，带渐隐拖尾，自己绘制（不用 ProgressBar，避免缩放错位）。
 */
public class RingSpinnerView extends View {

    private static final long LOOP_MS = 560;

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint arcPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF oval = new RectF();
    /** 全局相位原点：启动页与直播页遮罩共用，交接时角度完全接续，不会跳一下 */
    private static long sPhaseOrigin = 0;

    private static long phaseOrigin() {
        if (sPhaseOrigin == 0) sPhaseOrigin = SystemClock.uptimeMillis();
        return sPhaseOrigin;
    }

    /** 圆环直径：按真实屏幕短边的固定比例算（不依赖 density），保证各页面像素级一致 */
    public static int targetSizePx(Context context) {
        android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
        try {
            android.view.WindowManager wm = (android.view.WindowManager) context.getSystemService(Context.WINDOW_SERVICE);
            if (wm != null) wm.getDefaultDisplay().getRealMetrics(dm);
        } catch (Throwable ignore) {
            dm = context.getResources().getDisplayMetrics();
        }
        int shortSide = Math.min(dm.widthPixels, dm.heightPixels);
        if (shortSide <= 0) shortSide = 1080;
        return (int) (shortSide * 0.185f);
    }

    public RingSpinnerView(Context context) {
        this(context, null);
    }

    public RingSpinnerView(Context context, AttributeSet attrs) {
        super(context, attrs);
        trackPaint.setColor(Color.WHITE);
        trackPaint.setAlpha(62);
        arcPaint.setAlpha(255);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        float stroke = Math.max(2f, Math.min(w, h) * 0.030f);
        float radius = Math.min(w, h) / 2f - stroke / 2f;
        oval.set(w / 2f - radius, h / 2f - radius, w / 2f + radius, h / 2f + radius);

        // 底轨道
        trackPaint.setStyle(Paint.Style.STROKE);
        trackPaint.setStrokeWidth(stroke);
        canvas.drawOval(oval, trackPaint);

        // 亮弧（渐隐拖尾）
        long t = (SystemClock.uptimeMillis() - phaseOrigin()) % LOOP_MS;
        float angle = t / (float) LOOP_MS * 360f;

        arcPaint.setStyle(Paint.Style.STROKE);
        arcPaint.setStrokeWidth(stroke);
        arcPaint.setShader(new SweepGradient(w / 2f, h / 2f,
                new int[]{0x00FFFFFF, 0x66FFFFFF, 0xFFFFFFFF},
                new float[]{0f, 0.35f, 1f}));
        canvas.save();
        canvas.rotate(angle, w / 2f, h / 2f);
        canvas.drawArc(oval, -90f, 108f, false, arcPaint);
        canvas.restore();
        arcPaint.setShader(null);

        postInvalidateOnAnimation();
    }
}
