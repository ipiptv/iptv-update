package com.github.tvbox.osc.ui.view;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.View;

/**
 * 启动页用的极简进度线：一条细线 + 一段亮光匀速扫过，1.1 秒一循环。
 * 自己绘制，避免 ProgressBar 的缩放错位和"卡住"观感。
 */
public class SplashLineView extends View {

    private static final long LOOP_MS = 1100;

    private final Paint trackPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint sweepPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final long startMs = SystemClock.uptimeMillis();

    public SplashLineView(Context context) {
        this(context, null);
    }

    public SplashLineView(Context context, AttributeSet attrs) {
        super(context, attrs);
        trackPaint.setColor(Color.WHITE);
        trackPaint.setAlpha(38);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        int w = getWidth();
        int h = getHeight();
        if (w <= 0 || h <= 0) return;

        float density = getResources().getDisplayMetrics().density;
        float stroke = Math.max(2f, 1.6f * density);
        float cy = h / 2f;

        trackPaint.setStrokeWidth(stroke);
        canvas.drawLine(0, cy, w, cy, trackPaint);

        float seg = w * 0.34f;
        long t = (SystemClock.uptimeMillis() - startMs) % LOOP_MS;
        float progress = t / (float) LOOP_MS;
        float eased = progress < 0.5f
                ? 2f * progress * progress
                : 1f - 2f * (1f - progress) * (1f - progress);
        float left = -seg + (w + seg) * eased;

        sweepPaint.setShader(new LinearGradient(left, 0, left + seg, 0,
                new int[]{0x00FFFFFF, 0xFFFFFFFF, 0x00FFFFFF},
                new float[]{0f, 0.5f, 1f}, Shader.TileMode.CLAMP));
        sweepPaint.setStrokeWidth(stroke + Math.max(1f, 0.8f * density));
        canvas.drawLine(left, cy, left + seg, cy, sweepPaint);
        sweepPaint.setShader(null);

        postInvalidateOnAnimation();
    }
}
