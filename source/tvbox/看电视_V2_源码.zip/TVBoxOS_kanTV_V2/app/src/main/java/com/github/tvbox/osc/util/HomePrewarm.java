package com.github.tvbox.osc.util;

import android.os.Handler;
import android.os.Looper;

import com.github.tvbox.osc.api.ApiConfig;

/**
 * 首页静默预热：直播起播后，在后台把首页需要的「接口配置 + spider jar」先加载好，
 * 等用户从直播按返回时，首页可以直接渲染，不再现场初始化。
 */
public class HomePrewarm {

    private static volatile boolean started = false;

    public static void start(long delayMs) {
        if (started) return;
        started = true;
        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {
                runPrewarm();
            }
        }, delayMs);
    }

    private static void runPrewarm() {
        try {
            ApiConfig.get().loadConfig(false, new ApiConfig.LoadConfigCallback() {
                @Override
                public void success() {
                    loadJar();
                }

                @Override
                public void error(String msg) {
                    LOG.e("home prewarm config error: " + msg);
                }

                @Override
                public void notice(String msg) {
                }
            }, null);
        } catch (Throwable th) {
            LOG.e("home prewarm failed: " + th.getMessage());
        }
    }

    private static void loadJar() {
        try {
            String spider = ApiConfig.get().getSpider();
            if (spider == null || spider.isEmpty()) {
                ApiConfig.markHomePrewarmed();
                return;
            }
            ApiConfig.get().loadJar(false, spider, new ApiConfig.LoadConfigCallback() {
                @Override
                public void success() {
                    ApiConfig.markHomePrewarmed();
                    LOG.i("home prewarm done");
                }

                @Override
                public void error(String msg) {
                    LOG.e("home prewarm jar error: " + msg);
                    // jar 加载失败也让首页走正常流程，不在这里标记完成
                }

                @Override
                public void notice(String msg) {
                }
            });
        } catch (Throwable th) {
            LOG.e("home prewarm jar failed: " + th.getMessage());
        }
    }
}
