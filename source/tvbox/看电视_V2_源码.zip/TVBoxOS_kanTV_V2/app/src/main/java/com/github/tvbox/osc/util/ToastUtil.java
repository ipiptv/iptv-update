package com.github.tvbox.osc.util;

import android.app.Activity;
import android.content.Context;
import android.content.ContextWrapper;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.lang.ref.WeakReference;

/**
 * 轻提示。
 * 优先用页面内自绘浮层（不受系统 TOAST_WINDOW 开关影响，也不会和第三方接口的提示混在一起），
 * 拿不到 Activity 时才退回系统 Toast。
 */
public final class ToastUtil {

    private static final Handler MAIN = new Handler(Looper.getMainLooper());
    private static WeakReference<View> sCurrent = new WeakReference<>(null);
    private static Runnable sDismiss;

    private ToastUtil() {
    }

    public static void show(Context context, CharSequence text) {
        show(context, text, Toast.LENGTH_SHORT);
    }

    public static void show(Context context, CharSequence text, int duration) {
        if (text == null) return;
        final Activity activity = findActivity(context);
        if (activity == null) {
            try {
                com.github.tvbox.osc.util.ToastUtil.show(context, text, duration);
            } catch (Throwable ignore) {
            }
            return;
        }
        final String msg = text.toString();
        final long ms = duration == Toast.LENGTH_LONG ? 2600L : 1600L;
        Runnable task = new Runnable() {
            @Override
            public void run() {
                attach(activity, msg, ms);
            }
        };
        if (Looper.myLooper() == Looper.getMainLooper()) task.run();
        else MAIN.post(task);
    }

    private static Activity findActivity(Context context) {
        Context ctx = context;
        while (ctx != null) {
            if (ctx instanceof Activity) return (Activity) ctx;
            if (ctx instanceof ContextWrapper) ctx = ((ContextWrapper) ctx).getBaseContext();
            else return null;
        }
        return null;
    }

    private static void attach(final Activity activity, String msg, final long ms) {
        if (activity.isFinishing()) return;
        try {
            ViewGroup root = (ViewGroup) activity.getWindow().getDecorView().findViewById(android.R.id.content);
            if (root == null) return;

            View old = sCurrent.get();
            if (old != null) {
                ViewGroup p = (ViewGroup) old.getParent();
                if (p != null) p.removeView(old);
            }
            if (sDismiss != null) MAIN.removeCallbacks(sDismiss);

            TextView tv = new TextView(activity);
            tv.setText(msg);
            tv.setTextColor(Color.WHITE);
            tv.setTextSize(17f);
            tv.setGravity(Gravity.CENTER);
            int padH = dp(activity, 22), padV = dp(activity, 12);
            tv.setPadding(padH, padV, padH, padV);
            GradientDrawable bg = new GradientDrawable();
            bg.setColor(0xE6222222);
            bg.setCornerRadius(dp(activity, 10));
            tv.setBackground(bg);

            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.gravity = Gravity.BOTTOM | Gravity.CENTER_HORIZONTAL;
            lp.bottomMargin = dp(activity, 90);
            root.addView(tv, lp);
            tv.bringToFront();
            tv.setAlpha(0f);
            tv.animate().alpha(1f).setDuration(120).start();

            sCurrent = new WeakReference<>(tv);
            sDismiss = new Runnable() {
                @Override
                public void run() {
                    View v = sCurrent.get();
                    if (v == null) return;
                    v.animate().alpha(0f).setDuration(160).withEndAction(new Runnable() {
                        @Override
                        public void run() {
                            View inside = sCurrent.get();
                            if (inside == null) return;
                            ViewGroup p = (ViewGroup) inside.getParent();
                            if (p != null) p.removeView(inside);
                        }
                    }).start();
                }
            };
            MAIN.postDelayed(sDismiss, ms);
        } catch (Throwable ignore) {
        }
    }

    private static int dp(Context ctx, int v) {
        return (int) (v * ctx.getResources().getDisplayMetrics().density + 0.5f);
    }
}
